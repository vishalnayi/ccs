<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/plugins/font-awesome/css/font-awesome.min.css',
        'css/plugins/simple-line-icons/simple-line-icons.min.css',
        'css/plugins/bootstrap-switch/css/bootstrap-switch.min.css',
        //'css/plugins/select2/css/select2.min.css',
        //'css/plugins/select2/css/select2-bootstrap.min.css',
        'css/components-md.min.css',
        'css/plugins-md.min.css',
        'css/login.min.css',
        'css/custom.css',
        'css/responsive.css',
        'css/bootstrap-multiselect.css',
//        'css/style.css',
//        'css/site.css',
//        'css/rmp-custom.min.css',
        'js/vakata-jstree/themes/default/style.min.css',
    ];
    public $js = [
        'js/vakata-jstree/jstree.min.js',
        'js/common.js?id=7',
        'js/plugins/jquery-ui/jquery-ui.min.js',
        'js/plugins/bootstrap/js/bootstrap.min.js',
        'js/plugins/js.cookie.min.js',
        'js/plugins/jquery-slimscroll/jquery.slimscroll.min.js',
        'js/plugins/jquery.blockui.min.js',
        'js/plugins/bootstrap-switch/js/bootstrap-switch.min.js',
        'js/plugins/app.min.js',
        'js/plugins/layout.min.js',
        'js/plugins/select2/js/select2.full.min.js',
        'js/plugins/backstretch/jquery.backstretch.min.js',
        'js/nodetree-common.js',
        'js/jQuery.circleProgressBar.js',
        'js/raphael-min.js',
        'js/main.js',
        'js/bootstrap-multiselect.js',  
//        'js/terms.js',
//        'js/plugins/moment.min.js',
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
    ];
}
