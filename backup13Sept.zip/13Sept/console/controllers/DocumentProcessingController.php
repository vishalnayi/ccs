<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use yii\console\Controller;
use common\models\ClientSite;

/**
 * This class handles documents that require processing
 *
 * @author Damien Buttler <damien@rocketorange.com>
 * @since 2.0
 */
class DocumentProcessingController extends \yii\console\Controller
{
    /**
     * This command retrieves documents and places them in the site directories.
     *
     * @author Damien Buttler <damien@rocketorange.com>
     * @since 2.0
     */
    public function actionTest(){
        echo "test";exit;
    }
    public function actionProcessDocuments()
    {
        //echo "string";exit;
        $sites = ClientSite::find()->where(['download_documents' => 1])->all();

        foreach ($sites as $site) {
            $site->processNewDocuments();
        }
    }


    public function actionClientUnknown()
    {
        $site=new ClientSite;
        $site->processUnknownDocuments();
    }

    public function actionPrimaryReport()
    {
        $site=new ClientSite;
        $site->processPrimaryDocuments();
    }
}
