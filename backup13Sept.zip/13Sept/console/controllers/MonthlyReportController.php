<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use common\models\Client;
use common\models\User;
use common\models\ClientSearch;
use common\models\UserSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\ImportForm;
use yii\web\UploadedFile;
use common\models\UploadImageForm;
use common\models\UserClientAccess;
use common\models\ClientPdfEmail;
use common\models\SiteOperationalProgram;
use common\models\SiteOperationalProgramSearch;
use kartik\mpdf\Pdf;
use yii\helpers\Url;
use common\models\MailForm;
use common\models\UploadDocument;
use common\models\ClientSiteReportCategory;
use common\models\ClientSite;
use common\models\ReportType;
use common\models\ReportCategory;
use common\models\UserSiteAccess;
use yii\base\DynamicModel;
use yii\helpers\ArrayHelper;
use common\models\Provider;
use common\models\DocumentSearchTerm;

/**
 * This class handles documents that require processing
 *
 * @author Damien Buttler <damien@rocketorange.com>
 * @since 2.0
 */
class MonthlyReportController extends \yii\console\Controller
{
    /**
     * This command retrieves documents and places them in the site directories.
     *
     * @author Damien Buttler <damien@rocketorange.com>
     * @since 2.0
     */
    public function actionSendReport()
    {
        $client = new Client();
        //$sites = ClientSite::find()->where(['download_documents' => 1])->all();
        $providers = Provider::find()->all();
        //$FromDate='01-12-2020';
        //echo $toDate=date('d-m-Y');echo "<br>";
        $datestring=date('Y-m-d').' first day of last month';
        $datestring1=date('Y-m-d').' first day of this month';
        $dt=date_create($datestring);
        $dt1=date_create($datestring1);
        $FromDate=$dt->format('d-m-Y');
        $toDate=$dt1->format('d-m-Y');
        
        foreach ($providers as $supplier) {
            $content =  $this->renderPartial('print_report.php',['supplier'=>$supplier->id,'FromDate'=>$FromDate,'toDate'=>$toDate,'supplierdata'=>$supplier]);
            //echo $content;exit;
            $subject='Supplier :'.$supplier->name.' Monthly Report';
            $fname=$supplier->name.$dt1->format('dmY').'.pdf';
            $cssInline= '.kv-heading-1{font-size:50px} ';
            $filename= Yii::$app->basePath . '/uploads/'.$supplier->name.'08022021.pdf';
            $pdf = new Pdf(); // or new Pdf();
            $mpdf = $pdf->api; // fetches mpdf api        

            $mpdf->WriteHtml($content); // call mpdf write html
            $mailContent = $mpdf->Output('', 'S');
            $client->sendMonthlyPdfAlert('Please find attached pdf.',$mailContent,'zalak.vrinsoft@gmail.com',$FromDate,$toDate,$subject,$fname);
            $client->sendMonthlyPdfAlert('Please find attached pdf.',$mailContent,'kiara@rmpystems.com',$FromDate,$toDate,$subject,$fname);
        }
    }
}
