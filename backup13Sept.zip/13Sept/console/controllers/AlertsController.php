<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use yii\console\Controller;
use common\models\Client;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use common\models\ClientSiteReportCategory;
use common\models\ReportInterval;

/**
 * Send alerts for in application
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class AlertsController extends \yii\console\Controller
{
    /**
     * Send alerts for overdue reports
     */
    public function actionSendAlerts()
    {
        $reports = SiteOperationalProgram::findLateReports();
        foreach($reports as $client=>$reports) {
            $client = Client::findOne($client);
            $mailBody = $this->renderFile('/var/www/frontend/views/site-operational-program/email-alerts.php',
                ['reports' => $reports,
                 'client' => $client,
                ],
            true);
            /*echo $mailBody;*/
            //$client->sendAlert($mailBody);

            $getToleranceEmail = array();
            $getLateEmail = array();
            if(isset($reports['tolerance'])){
                $getToleranceEmail = array();
                foreach ($reports['tolerance'] as $key => $report) {
                    $getEmail = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                    $getToleranceEmail = explode(',',$getEmail['additional_emails']);

                    //send email Alert
                    $client->sendAlert($mailBody,$getToleranceEmail);
                    /*$is_sent_primary = $report['sop']['attributes']['is_sent_primary'];
                    if($is_sent_primary == 0){
                        $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                        $model->is_sent_primary = 1;
                        $model->save();
                    }*/
                }
            }
            if(isset($reports['late'])){
                foreach ($reports['late'] as $key => $report) {

                    $getLateEmail = array();
                    $getEmail = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                    $getLateEmail = explode(',',$getEmail['additional_emails']);
                    $checkPrimary = $report['sop']['attributes']['is_sent_primary'];
                    $secondaryAlarm = $report['sop']['attributes']['secondary_alarm'];
                    $checkSecondary = $report['sop']['attributes']['is_sent_secondary'];
                    $secondary_alarm_date = $report['sop']['attributes']['secondary_alarm_date'];
                    $territoryAlarm = $report['sop']['attributes']['territory_alarm'];
                    $checkTerritory = $report['sop']['attributes']['is_sent_territory'];
                    $territory_alarm_date = $report['sop']['attributes']['territory_alarm_date'];
                    $date = date('Y-m-d');

                    //send email Alert
                    if($checkPrimary == 0){
                        //get secondary alarm date
                        //$IntervalLength = ReportInterval::findOne($report['sop']['attributes']['secondary_interval_id']);
                        $SecondaryDate = strtotime($date);
                        $SecondaryIntervalDays = $report['sop']['attributes']['secondary_interval_id']. 'Days';
                        $reportDueDate = strtotime('+'. $SecondaryIntervalDays, $SecondaryDate);
                        $SecondartAlarmDate = date('Y-m-d', $reportDueDate);

                        //get territory alarm date
                        //$IntervalLength = ReportInterval::findOne($report['sop']['attributes']['territory_interval_id']);
                        $TerritoryDate = strtotime($SecondartAlarmDate);
                        $TerritoryIntervalDays = $report['sop']['attributes']['territory_interval_id']. 'Days';
                        $reportDueDate = strtotime('+'. $TerritoryIntervalDays, $TerritoryDate);
                        $TerritoryAlarmDate = date('Y-m-d', $reportDueDate);
                        
                        $client->sendAlert($mailBody,$getLateEmail);

                        $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                        $model->is_sent_primary = 1;
                        $model->secondary_alarm_date = $SecondartAlarmDate;
                        $model->territory_alarm_date = $TerritoryAlarmDate;
                        $model->save();
                    }else if($checkPrimary == 1 && ($secondaryAlarm == 1 && $checkSecondary == 0 && $secondary_alarm_date == $date))  {
                            
                            $client->sendAlert($mailBody,$getLateEmail);

                            $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                            $model->is_sent_secondary = 1;
                            $model->save();
                    }else if($checkSecondary == 1 && ($territoryAlarm == 1 && $territory_alarm_date == $date)){
                            $client->sendAlert($mailBody,$getLateEmail);

                            //$IntervalLength = ReportInterval::findOne($report['sop']['attributes']['territory_interval_id']);
                            $TerritoryDate = strtotime($territory_alarm_date);
                            $TerritoryIntervalDays = $report['sop']['attributes']['territory_interval_id']. 'Days';
                            $reportDueDate = strtotime('+'. $TerritoryIntervalDays, $TerritoryDate);
                            $reportDueDate = strtotime('+'. $IntervalLength['interval_length'], $TerritoryDate);
                            $TerritoryAlarmDate = date('Y-m-d', $reportDueDate);

                            $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                            $model->is_sent_territory = 1;
                            $model->territory_alarm_date = $TerritoryAlarmDate;
                            $model->save();
                    }
                }
            }
        }
    }
        public function actionCbre(){
        $site = ClientSite::findOne('175');
        // echo "<pre>";
        // print_r($site);
        // die;
                    $files = SiteOperationalProgram::renameCBREClient($site,'26');
                    echo "<pre>";
                    print_r($files);
                    die;
    }
    public function actionDemo(){
        //die('hello');
        // $clients = Client::find()->asArray()->all();   
        // $client = (array_unique(array_column($clients, 'id')));
        // echo "<pre>";
        // print_r($client);
        // die;

        // $site = ClientSite::findOne('51');
        //             $files = SiteOperationalProgram::checkDishaDemo($site);
        //             echo "files ".$site->directory;
        // echo "<pre>";
        //  print_r($files);
        //  die;


         $clientSiteReportCategories = ClientSiteReportCategory::find()->where(['!=','provider_id','7'])->asArray()->all();
         
         $sitesWithoutIntegra = (array_unique(array_column($clientSiteReportCategories, 'client_site_id')));
                   $c = array('9');
foreach ($c as $key => $c) {
    # code...

         $sites = ClientSite::find()->where(['client_id'=>$c])->all();
         $client = Client::find()->where(['id'=>$c])->all();

        
            // echo "<pre>";    
            // print_r($sites);
            // die;

         foreach ($sites as $key => $site) {
             if(in_array($site->id, $sitesWithoutIntegra)){
                    $files = SiteOperationalProgram::checkDishaDemo_new($site);
               if($files){
                    echo " ======================================================================== ****** Done Client  ".$c." site ".$site->id." and site name ".$site->name." and sitee directory ".$site->directory." ******** ";
               }else{
                    echo " =========================================================== No reports for client ".$c;
                    // echo "<pre>";
                    // print_r($files);
                    // die;
               }

             }else{
                echo " ======================================================================Not renming Client : ".$c." and site ".$site->id;
             }
         }
             
        } 
        //$site = ClientSite::findOne('104');   
        //echo "<pre>";
       // $sops = SiteOperationalProgram::find()->where(['site_id'=>'171'])->all(); 
       // $sops = ReportType::find()->where(['id'=>16])->all(); 
        // print_r($sops);  
        // //die;
        // print_r($site->directory);  die;
        // print_r($site->reportCategories);
        // print_r($site->clientSiteReportCategories);
        // print_r($site->searchTerms);
        // die;
        //$files = SiteOperationalProgram::checkDishaDemo($site);
        //echo "<pre>";
        //print_r($files);
        die;
    }
}
