<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use common\models\Client;
use common\models\Reports;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;
use yii\helpers\Url;
use common\models\UserSiteAccess;
use yii\base\DynamicModel;
use yii\helpers\ArrayHelper;

/**
 * This class handles documents that require processing
 *
 * @author Damien Buttler <damien@rocketorange.com>
 * @since 2.0
 */
class PrintReportController extends \yii\console\Controller
{
    /**
     * This command retrieves documents and places them in the site directories.
     *
     * @author Damien Buttler <damien@rocketorange.com>
     * @since 2.0
     */
    public function actionDeleteReport()
    {
        $reports = new Reports();
        //$sites = ClientSite::find()->where(['download_documents' => 1])->all();
        /*$reportA = Reports::find()->all();*/
        $previous= date('Y-m-d H:i:s', strtotime('-5 minutes'));
        $qry="SELECT * FROM reports where created_at<='".$previous."' ";
        $conn1 = Yii::$app->getDb();
        $command = $conn1->createCommand($qry);
        $reportA = $command->queryAll();
        /*print_r($reportA);*/
        
        foreach ($reportA as $r) {
            /*unlink($r['filename']);          */     
            $site_folder = [];      
            $this->delete_files($r['foldername'],$site_folder);
            $sql = 'DELETE FROM reports WHERE id='.$r['id'].' ';
            $conn = Yii::$app->getDb();
            $conn->createCommand($sql)->getRawSql();
            $query = $conn->createCommand($sql)->execute();
        }
    }

    public function actionDeleteFolders(){
        $site_folder = [];      
        $foldername='/var/www/frontend/uploads';
        $this->delete_files($foldername,$site_folder);
    }

    protected function delete_files($target,$site_folder) {
        /*echo $target;*/
        
        if(is_dir($target)){
            /*echo "string";*/
            $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned
            /*echo "<pre>";print_r($files);*/
            foreach( $files as $file ){
                array_push($site_folder,$file);
                $this->delete_files( $file ,$site_folder);      
            }

            /*rmdir( $target );*/
        } elseif(is_file($target)) {
            $ext = pathinfo($target, PATHINFO_EXTENSION);
            if ($ext!="zip" && $ext!="csv") {
                echo $target;echo "<br>";
                unlink( $target ); 
            }
            /*echo $ext;
            echo $target;echo "<br>";*/
            
        }
    }
}
