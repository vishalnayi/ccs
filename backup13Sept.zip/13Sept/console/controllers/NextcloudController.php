<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use yii\console\Controller;
use common\models\Client;

/**
 * This class handles things related to Nextcloud
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class NextcloudController extends \yii\console\Controller
{
    /**
     * Run owncloudclientcmd to sync files with the Nextcloud server
     */
    public function actionSyncNextcloud()
    {
        $nextcloud = Yii::$app->owncloudHelper;
        $nextcloud->syncFiles();
    }

    /**
     * Create the RMP mirror and sync with Nextcloud server
     */
    public function actionMirrorFiles()
    {
        $clients = Client::find()->all();

        $nodelList = [];
        $clientSiteList = [];
        foreach($clients as $client) {
            $nodeList[$client->name] = $client->buildNodeList(0, '/'.$client->name.'/');
            $clientSiteList[$client->name] = $client->buildClientSiteList($nodeList[$client->name], $client); 
        }

        $cloudMirror = Yii::$app->cloudMirrorHelper;
        $cloudMirror->buildPaths($clientSiteList);

        $nextcloud = Yii::$app->owncloudHelper;
        $nextcloud->syncFiles();

        $this->stdout("Mirroring done.\n");
    }
}
