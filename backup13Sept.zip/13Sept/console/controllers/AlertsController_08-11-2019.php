<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace console\controllers;

use Yii;
use yii\console\Controller;
use common\models\Client;
use common\models\SiteOperationalProgram;
use common\models\ReportInterval;

/**
 * Send alerts for in application
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class AlertsController extends \yii\console\Controller
{
    /**
     * Send alerts for overdue reports
     */
    public function actionSendAlerts()
    {
        $reports = SiteOperationalProgram::findLateReports();
        foreach($reports as $client=>$reports) {
            $client = Client::findOne($client);
            $mailBody = $this->renderFile('/var/www/frontend/views/site-operational-program/email-alerts.php',
                ['reports' => $reports,
                 'client' => $client,
                ],
            true);
            //$client->sendAlert($mailBody);

            $getToleranceEmail = array();
            $getLateEmail = array();
            if(isset($reports['tolerance'])){
                $getToleranceEmail = array();
                foreach ($reports['tolerance'] as $key => $report) {
                    $getEmail = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                    $getToleranceEmail = explode(',',$getEmail['additional_emails']);

                    //send email Alert
                    $client->sendAlert($mailBody,$getToleranceEmail);
                    /*$is_sent_primary = $report['sop']['attributes']['is_sent_primary'];
                    if($is_sent_primary == 0){
                        $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                        $model->is_sent_primary = 1;
                        $model->save();
                    }*/
                }
            }
            if(isset($reports['late'])){
                foreach ($reports['late'] as $key => $report) {

                    $getLateEmail = array();
                    $getEmail = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                    $getLateEmail = explode(',',$getEmail['additional_emails']);
                    $checkPrimary = $report['sop']['attributes']['is_sent_primary'];
                    $secondaryAlarm = $report['sop']['attributes']['secondary_alarm'];
                    $checkSecondary = $report['sop']['attributes']['is_sent_secondary'];
                    $secondary_alarm_date = $report['sop']['attributes']['secondary_alarm_date'];
                    $territoryAlarm = $report['sop']['attributes']['territory_alarm'];
                    $checkTerritory = $report['sop']['attributes']['is_sent_territory'];
                    $territory_alarm_date = $report['sop']['attributes']['territory_alarm_date'];
                    $date = date('Y-m-d');

                    //send email Alert
                    if($checkPrimary == 0){
                        //get secondary alarm date
                        $IntervalLength = ReportInterval::findOne($report['sop']['attributes']['secondary_interval_id']);
                        $SecondaryDate = strtotime($date);
                        $reportDueDate = strtotime('+'. $IntervalLength['interval_length'], $SecondaryDate);
                        $SecondartAlarmDate = date('Y-m-d', $reportDueDate);

                        //get territory alarm date
                        $IntervalLength = ReportInterval::findOne($report['sop']['attributes']['territory_interval_id']);
                        $TerritoryDate = strtotime($SecondartAlarmDate);
                        $reportDueDate = strtotime('+'. $IntervalLength['interval_length'], $TerritoryDate);
                        $TerritoryAlarmDate = date('Y-m-d', $reportDueDate);
                        
                        $client->sendAlert($mailBody,$getLateEmail);

                        $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                        $model->is_sent_primary = 1;
                        $model->secondary_alarm_date = $SecondartAlarmDate;
                        $model->territory_alarm_date = $TerritoryAlarmDate;
                        $model->save();
                    }else if($checkPrimary == 1 && ($secondaryAlarm == 1 && $checkSecondary == 0 && $secondary_alarm_date == $date))  {
                            
                            $client->sendAlert($mailBody,$getLateEmail);

                            $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                            $model->is_sent_secondary = 1;
                            $model->save();
                    }else if($checkSecondary == 1 && ($territoryAlarm == 1 && $territory_alarm_date == $date)){
                            $client->sendAlert($mailBody,$getLateEmail);

                            $IntervalLength = ReportInterval::findOne($report['sop']['attributes']['territory_interval_id']);
                            $TerritoryDate = strtotime($territory_alarm_date);
                            $reportDueDate = strtotime('+'. $IntervalLength['interval_length'], $TerritoryDate);
                            $TerritoryAlarmDate = date('Y-m-d', $reportDueDate);

                            $model = SiteOperationalProgram::findOne($report['sop']['attributes']['id']);
                            $model->is_sent_territory = 1;
                            $model->territory_alarm_date = $TerritoryAlarmDate;
                            $model->save();
                    }
                }
            }
        }
    }
}
