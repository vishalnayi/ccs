<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=rmp',
            'username' => 'rmp',
            'password' => 'rmp-2123',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'owncloudHelper' => [
            'class' => 'common\components\OwncloudHelper',
            'host' => 'http://54.187.79.32/nextcloud',
            'hostPath' => 'http://admin:rmpsystems2016@54.187.79.32/nextcloud',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
            'localPath' => '/var/www/owncloud_files/',
            'binPath' => '/usr/bin/owncloudcmd',
        ],
    ],
];
