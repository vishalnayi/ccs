<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use common\models\Client;
/*$session = Yii::$app->session; */


$allowAllSite = 0;
$getSupplierClients=ClientSite::getSupplierClients($supplier,2,$allowAllSite);
/*$MySites =  ClientSite::getSupplierSites($supplier,2,$allowAllSite);*/
/*echo "<pre>";print_r($getSupplierClients);exit();*/
?>

<table border="0" cellspacing="0" cellpadding="0" style="background:#FFFFFF;width: 100%;margin: 0;">
    <tr>
        <td colspan="2" style="-webkit-print-color-adjust: exact;">
            <b>Supplier : <?php echo $supplierdata->name; ?></b>
            <p>CCS Performance Review M1-Q1</p>
            <p>Covered Period : <?php echo $FromDate; ?> To <?php echo $toDate; ?></p>
            <p>Report Generated : 01-02-2021</p>
        </td>
        
    </tr>
</table>
<hr>
<?php 
foreach ($getSupplierClients as $key => $value1) {
    if(isset($value1['client_id'])){
   // echo "<pre>";print_r($value1['client_id']);exit();
    $MySites =  ClientSite::getSupplierSites($value1['client_id'],$supplier,2,$allowAllSite);
    $j=1;
?>
<table border="0" cellspacing="0" cellpadding="0" style="background:#FFFFFF;width: 100%;margin: 0;">
    <tr>
        <td colspan="2" style="-webkit-print-color-adjust: exact;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 10px 10px 10px 10px;color:white;background: #0c0c0c;border: 0.5px solid grey;">
                    <tr>]
                        <td style="text-align: left;font-size: 15px;;color: white;margin: 36px 0 15px 0;font-weight: 900;">Client : <?php echo $value1['clientname']; ?></td>
                    </tr>
            </table>
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
                    <!-- <tr>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Company/Client Served</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Site Address</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Report Type</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Last Report Received</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Frequency</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Next Report Due</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Within Tolerance</td>
                        <td style="text-align: left;font-size: 14px;background-color: grey;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">If no,X of days delayed</td>
                    </tr> -->
                    <?php 
                    //$j=1;
                    if(!empty($MySites)){ ?>
                    <tr>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Site Address</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Report Type</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Last Report Received</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Frequency</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Next Report Due</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">Within Tolerance</td>
                        <td style="text-align: left;font-size: 14px;background-color: #b3aeae;padding:5px;color: #000;border:1px solid #4a4848;margin: 36px 0 15px 0;font-weight: 900;">If no,X of days delayed</td>
                    </tr>
                    <?php 
                    foreach ($MySites as $MySite) { 
                        $mySiteId = $MySite['id'];
                        $sitesWithoutPrimaryAlarmSet = array();
                        //$j=1;
                        array_push($sitesWithoutPrimaryAlarmSet, $mySiteId);
                        if(!empty($sitesWithoutPrimaryAlarmSet)){ 
                            //$j=1;
                            $statusClass = '';
                            $reports = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,'','','');
                                
                            foreach ($reports as $key => $MyReport) { 
                                if($key != 'clientTotal'){  
                                    $RCompliance = $MyReport['percentage'];
                                        if($RCompliance != '-'){
                                            if($RCompliance<90){
                                                $statusClass = 'reject';
                                            }elseif($RCompliance>=90 && $RCompliance<=99){
                                                $statusClass = 'pending';
                                            }elseif($RCompliance==100){
                                                $statusClass = 'approve';    
                                            }
                                            $RCompliance = $RCompliance.'%';
                                        }else{
                                           $statusClass = ''; 
                                        }     
                                        $loadFileHrefReport = isset($MyReport['href'])?$MyReport['href']:"";
                    ?>
                    <tr>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php echo $MySite['name']; ?></td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php  echo $MyReport['name'];?></td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php echo $MyReport['lastReportDate']; ?></td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php echo $MyReport['frequency']; ?></td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php echo ($MyReport['frequency'] == "-")?"-":$MyReport['nextDate']; ?></td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;">Yes</td>
                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"></td>
                    </tr>
                    <?php $j++;
                        // if($j>5){
                        //     break;
                        // }
                    } }
                   // echo $j;
                    if ($j==1) { ?>
                    <!-- <tr>
                        <td colspan="8" style="text-align: center;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;">No Data Found</td>
                        </tr> -->
                    <?php }  
                


                    }

                    $sop = new SiteOperationalProgram;
                    $latereports=SiteOperationalProgram::findSiteLateReports($mySiteId,$supplier,$MySite,$FromDate,$toDate);
                    //echo "<pre>";print_r($latereports);exit;
                     foreach($latereports as $client=>$reports){
                        foreach($reports as $key=>$reportList){
                            //$lateDates = $sop->findS3ReportsDashboardStatics($rts, $clientSite, '5', $dateRange);
                            $client = Client::findOne($client);
                            if (isset($reportList)){
                                foreach($reportList as $report){

                                    $doctype_id= $report['sop']->reportType->doctype_id;
                                    /*print_r($report['lastreport'][$doctype_id]['lastReportDate']);exit;*/

                                $now = time(); // or your date as well
                                $your_date = strtotime($report['info']['dueDate']);
                                $datediff = $now - $your_date;

                                $remainingdays= round($datediff / (60 * 60 * 24)); 
                                ?>
                                    <tr>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php echo $MySite['name']; ?></td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?= $report['sop']->reportType->name ?></td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?php if (isset($report['lastreport'][$doctype_id])) { echo $report['lastreport'][$doctype_id]['lastReportDate']; } ?></td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?= $report['sop']->reportInterval->name ?></td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?= $report['info']['dueDate'] ?></td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;">No</td>
                                        <td style="text-align: left;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;"><?= $remainingdays ?></td>
                                    </tr>
                               <?php $j++; }
                            }
                        }
                     }

                    }
                    //echo $j;
                    if ($j==1) { ?>
                    <tr>
                        <td colspan="8" style="text-align: center;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;">No Data Found</td>
                        </tr>
                    <?php }
                }else{ ?>
                <tr> 
                        <td colspan='8' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No reports found.</td>
                    </tr> 
                <?php }
                    if ($j==1) { ?>
                    <!-- <tr>
                        <td colspan="8" style="text-align: center;font-size: 14px;color: #000;margin: 36px 0 15px 0;border:1px solid #4a4848;">No Data Found</td>
                        </tr> -->
                    <?php }  
                    ?>
            </table>
        </td>
    </tr>
</table>
<?php  } } ?>

