<?php
/**
 * Load the top navigation for a guest user.
 *
 * @author Ben Pitt
 *
 */

use yii\helpers\Html;

/* @var $this yii\web\View */
?>

<div id="top-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 text-right"><?php echo Html::a('Login', '/site/login', ['class' => 'btn dark']) ?></div>
        </div>
    </div>
</div>
<div class="clearfix"> </div>