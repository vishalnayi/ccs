<?php
/**
 * Load the top navigation for a logged in user.
 *
 * @author Ben Pitt
 *
 */

use yii\helpers\Html;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use yii\widgets\ActiveForm;
use common\components\CheckPermissionHelper;

$viewClientSites = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','view',Yii::$app->user->identity->role);
$viewSecondaryAlarm = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Secondary Alarm','view',Yii::$app->user->identity->role);
$viewSiteReports = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Site Reports','view',Yii::$app->user->identity->role);
$viewSecondaryAlarms = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Secondary Alarms','view',Yii::$app->user->identity->role);
$viewTertiary = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Tertiary Alarm','view',Yii::$app->user->identity->role);

if($viewClientSites=='0' && $viewClientSites=='0' && $viewClientSites=='0' && $viewClientSites=='0'){
    $visibleSiteMenu = 0;
}else{
    $visibleSiteMenu = 1;
}


$viewPrintReports = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Print Reports','view',Yii::$app->user->identity->role);

$viewUsers = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','view',Yii::$app->user->identity->role);


/* @var $this yii\web\View */
/* @param $headingString */
?>

<div class="page-header navbar">
    <div class="page-header-inner container">
        <div class="page-logo">
            <a href="/">
                <img src="/img/login-logo.png" alt="logo" class="logo-default" width="150" height="40" /> </a>
            <!-- <img src="/img/rmp-systems-logo.png" alt="logo" class="logo-default" width="80" height="40" /> </a>-->
            <!-- <div class="menu-toggler sidebar-toggler"></div>            -->
        </div>
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
        <div class="page-top">
            <div class="top-menu">
                <ul class="nav navbar-nav mln-left-menu">
                    <li <?php if($this->params['currentPage'] == 'Dashboard'){ echo 'class="active"'; } ?>><a href="/">Dashboard</a></li>
                    <?php if($viewUsers == '1'){ ?><li <?php if($this->params['currentPage'] == 'Users'){ echo 'class="active"'; } ?>><a href="/user">Users</a></li><?php } ?>
                    <?php if($visibleSiteMenu == '1'){ ?><li <?php if($this->params['currentPage'] == 'Sites'){ echo 'class="active"'; } ?>><a href="/client-site">Sites</a></li><?php } ?>
                    <?php if($viewPrintReports == '1'){ ?><li <?php if($this->params['currentPage'] == 'Print Reports'){ echo 'class="active"'; } ?>><a href="/client-site/print-reports">Print Reports</a></li><?php } ?>
                     <li <?php if($this->params['currentPage'] == 'Upcoming Schedule'){ echo 'class="active"'; } ?>><a href="/client-site/schedulecalendar">Upcoming Schedule</a></li>
                </ul>
                <ul class="nav navbar-nav pull-right">                    
                    <li class="separator hide"> </li>
                    <li class="dropdown dropdown-user dropdown-dark">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <span class="username username-hide-on-mobile"> <?php echo $headingString ?></span>
                            <img alt="" class="img-circle" src="../img/avatar2.png" /> </a>
                        <ul class="dropdown-menu dropdown-menu-default">
                            <?php /*<li>
                                <a href="page_user_profile_1.html">
                                    <i class="icon-user"></i> My Profile </a>
                            </li> */ ?>
                            <li>
                                <a href="/">
                                    <i class="icon-home"></i> Dashboard </a>
									<!--<i class="icon-bar-chart"></i> Dashboard </a>-->
                            </li>
                            <?php if($user->role == User::ROLE_SUPER || $user->role == User::ROLE_AUDITOR): ?>
                            <li>
                                <a href="/user/switch-user">
                                    <i class="icon-users"></i> Switch User </a>
                            </li>
                            <?php endif; ?>
                            <li class="divider"> </li>
                            <li>
                                <a href="/site/logout">
                                    <i class="icon-key"></i> Log Out </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"> </div>
