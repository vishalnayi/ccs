<?php

use yii\helpers\Html;
use common\models\User;
use common\components\CheckPermissionHelper;

$viewClientSites = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','view',Yii::$app->user->identity->role);
$viewSecondaryAlarm = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Secondary Alarm','view',Yii::$app->user->identity->role);
$viewSiteReports = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Site Reports','view',Yii::$app->user->identity->role);
$viewSecondaryAlarms = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Secondary Alarms','view',Yii::$app->user->identity->role);
$viewTertiary = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Tertiary Alarm','view',Yii::$app->user->identity->role);

if($viewClientSites=='0' && $viewClientSites=='0' && $viewClientSites=='0' && $viewClientSites=='0'){
    $visibleSiteMenu = 0;
}else{
    $visibleSiteMenu = 1;
}

$viewDashboard = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Dashboard','view',Yii::$app->user->identity->role);

$viewPrintReports = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Print Reports','view',Yii::$app->user->identity->role);

$viewUsers = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','view',Yii::$app->user->identity->role);

if($this->params['currentPage'] == 'Dashboard'){ 
  echo "";

}else{
    if($user->role == User::ROLE_SUPER) {
        $userReadAccess = 'Modify';
    } elseif($user->role == User::ROLE_ADMIN) {
        $userReadAccess = 'Modify';
    } else {
        $userReadAccess = 'Browse';
    }
    

    //$items[] = [ 'url' => '/', 'label' => 'Dashboard', 'icon' => 'icon-settings', 'selected' => false];
    $items=[];
    if($user->role >= User::ROLE_ADMIN) {
        if($viewUsers == '1'){
            $items[] = [
                'label' => 'Users',
                'url' => '/user',
                'icon' => 'icon-users'
            ];
        }
    }elseif($user->role == User::ROLE_AUDITOR){
        if($viewUsers == '1'){
            $items[] = [
                'label' => 'Users',
                'url' => '/user',
                'icon' => 'icon-users'
            ];
        }
    } elseif($user->role == User::ROLE_USER) {
        // Change this to user in top dropdown
        $items[] = [
            'label' => 'My Data',
            'url' => '/user/view/?id='. $user->id,
            'icon' => 'icon-user'
        ];
    }
    if($user->role > User::ROLE_ADMIN) {
        //if($viewUsers == '1'){
            $items[] = [
                'label' => 'Contacts',
                'url' => '/contact',
                'icon' => 'icon-book-open'
            ];
        //}
    }elseif($user->role == User::ROLE_AUDITOR){
       // if($viewUsers == '1'){
            $items[] = [
                'label' => 'Contacts',
                'url' => '/contact',
                'icon' => 'icon-book-open'
            ];
        //}
    }
    if($user->role == User::ROLE_SUPER) {
        $items[] = [
            'label' => 'Nodes',
            'url' => 'javascript:;',
            'icon' => 'icon-grid',
            'children' => [
                [
                    'label' => $userReadAccess . ' Nodes',
                    'url' => '/node',
                    'icon' => 'icon-calendar',
                ],
                [
                    'label' => 'Browse Node Tree',
                    'url' => '/node/node-tree',
                    'icon' => 'icon-layers',
                ],
            ]
        ];
    }

    if($visibleSiteMenu == '1'){

    if($user->role == User::ROLE_SUPER) {
            $items[] = [
                'label' => 'Sites',
                'url' => 'javascript:;',
                'icon' => 'icon-map',
                'children' => [
                    [
                        'label' => $userReadAccess . ' Sites',
                        'url' => '/client-site',
                        'icon' => 'icon-directions',
                    ],
                    [
                        'label' => 'Archive Sites',
                        'url' => '/client-site-archive',
                        'icon' => 'icon-trash',
                    ],
                    [
                        'label' => 'Primary Alarm',
                        'url' => '/site-operational-program',
                        'icon' => 'icon-globe',
                    ],
                    [
                        'label' => 'Secondary Alarm',
                        'url' => '/secondary-alarm',
                        'icon' => 'icon-globe',
                    ],
                    [
                        'label' => 'Tertiary Alarm',
                        'url' => '/tertiary-alarm',
                        'icon' => 'icon-globe',
                    ]
                ]
            ];
        }else{
            $items[] = [
                'label' => 'Sites',
                'url' => 'javascript:;',
                'icon' => 'icon-map',
                'children' => [
                    [
                        'label' => $userReadAccess . ' Sites',
                        'url' => '/client-site',
                        'icon' => 'icon-directions',
                    ],
                    [
                        'label' => 'Primary Alarm',
                        'url' => '/site-operational-program',
                        'icon' => 'icon-globe',
                    ],
                    [
                        'label' => 'Secondary Alarm',
                        'url' => '/secondary-alarm',
                        'icon' => 'icon-globe',
                    ],
                    [
                        'label' => 'Tertiary Alarm',
                        'url' => '/tertiary-alarm',
                        'icon' => 'icon-globe',
                    ]
                ]
            ];
        }
    }

    if($viewPrintReports == '1'){
        $items[] = [
            'label' => 'Print Reports',
            'url' => '/client-site/print-reports',
            'icon' => 'icon-book-open'
        ];
    }
    $items[] = [
        'label' => 'Upcoming Schedule',
        'url' => '/client-site/schedulecalendar',
        'icon' => 'icon-book-open'
    ];
    $items[] = [
            'label' => 'Late/Tolerance Reports',
            'url' => '/site-operational-program/late-tolerance-reports',
            'icon' => 'icon-book-open'
        ];
    if($user->role == User::ROLE_AUDITOR) {
        $items[] = [
            'label' => 'Auditor User',
            'url' => '',
            'icon' => '',
            'heading' => true
        ];
        $items[] = [
            'label' => 'System Admin Auditor',
            'url' => 'javascript:;',
            'icon' => 'icon-settings',
            'children' => [
                [
                    'label' => 'Client',
    //                'url' => '/client/view/?id='. $user->client_id,
                    'url' => '/client',
                    'icon' => 'icon-notebook',
                ],
            ]
        ];
    }elseif($user->role == User::ROLE_SUPER) {
        $items[] = [
            'label' => 'Super User',
            'url' => '',
            'icon' => '',
            'heading' => true
        ];
        $items[] = [
            'label' => 'System Admin',
            'url' => 'javascript:;',
            'icon' => 'icon-settings',
            'children' => [
                [
                    'label' => 'Client',
    //                'url' => '/client/view/?id='. $user->client_id,
                    'url' => '/client',
                    'icon' => 'icon-notebook',
                ],
                [
                    'label' => 'Switch User',
                    'url' => '/user/switch-user',
                    'icon' => 'icon-users',
                ],
                [
                    'label' => 'Sync Owncloud',
                    'url' => '/site-operational-program/sync-owncloud',
                    'icon' => 'icon-cloud-download',
                ],
                [
                    'label' => 'Rights Modules',
                    'url' => '/rights-modules',
                    'icon' => 'icon-notebook',
                ],
                [
                    'label' => 'User Permissions',
                    'url' => '/user-permissions',
                    'icon' => 'icon-notebook',
                ],
                [
                    'label' => 'Suppliers',
                    'url' => '/provider',
                    'icon' => 'icon-magnifier',
                ],
                [
                    'label' => 'Report Categories',
                    'url' => '/report-category',
                    'icon' => 'icon-magnifier',
                ],
                [
                    'label' => 'Document Search Terms',
                    'url' => '/document-search-term',
                    'icon' => 'icon-magnifier',
                ],
                [
                    'label' => 'Report Type',
                    'url' => '/report-type',
                    'icon' => 'icon-magnifier',
                ],
                [
                    'label' => 'Report Interval',
                    'url' => '/report-interval',
                    'icon' => 'icon-magnifier',
                ],
                [
                    'label' => 'Document Discover Log',
                    'url' => '/document-discover-log',
                    'icon' => 'icon-direction',
                ],
                [
                    'label' => 'Document Discover Test',
                    'url' => '/document-discover-log/test',
                    'icon' => 'icon-direction',
                ],
            ]
        ];
    }

    ?>
    <div class="page-sidebar-wrapper">
        <div class="page-sidebar navbar-collapse collapse">
            <ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                <li class="custom-toggle">
                    <div class="menu-toggler sidebar-toggler"></div>   
                </li>
                <?php if($viewDashboard == '1'){ ?>
                <li class="nav-item start">
                    <!-- <a href="http://rmpsystems.com" target="_blank" class="nav-link"> -->
                    <a href="/" class="nav-link">
                        <i class="icon-home"></i>
                        <span class="title">Home</span>
                    </a>
                </li>
                <?php } ?>
                <?php foreach ($items as $item): ?>
                    <?php if (isset($item['heading']) && Html::encode($item['heading'])) { ?>
                        <li class="heading">
                            <h3 class="uppercase"><?php echo $item['label'] ?></h3>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item <?php echo $currentPage === $item['label']? 'active open':''; ?>">
                            <a href="<?php echo $item['url'] ?>"
                               class="nav-link <?php echo !empty($item['children']) ?? 'nav-toggle'; ?>">
                                <i class="<?php echo $item['icon'] ?>"></i>
                                <span class="title"><?php echo Html::encode($item['label']) ?></span>
                                <?php if ($currentPage === $item['label']): ?>
                                    <span class="selected"></span>
                                <?php endif; ?>
                                <?php if (!empty($item['children'])): ?>
                                <span class="arrow"></span>
                                <?php endif; ?>
                            </a>
                            <?php if (!empty($item['children'])): ?>
                                <ul class="sub-menu">
                                    <?php foreach ($item['children'] as $child): ?>
                                        <li class="nav-link <?php echo $currentChild === $child['label']? 'active open':''; ?>">
                                            <a href="<?php echo $child['url'] ?>" class="nav-link ">
                                                <i class="<?php echo $child['icon'] ?>"></i>
                                                <span class="title"><?php echo Html::encode($child['label']) ?></span>
                                                <?php if ($currentChild === $child['label']): ?>
                                                    <span class="selected"></span>
                                                <?php endif; ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                <?php }
                endforeach; ?>
            </ul>
        </div>
    </div>
<?php } ?>