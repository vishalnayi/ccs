<?php
namespace frontend\widgets;

use yii;
use yii\base\Widget;
use yii\helpers\Html;

class RedRocketAdminNav extends Widget
{
    protected $headingString = '';

    public function init()
    {
        parent::init();

        if(!Yii::$app->user->isGuest) {
            $user = Yii::$app->user->identity;
//                $headingString = ' ('. $user->client->name .' | '. User::getRole($user->role) .')'; // DEBUG
            $this->headingString = $user->username;
        }
    }

    public function run()
    {
        if(!Yii::$app->user->isGuest) {
            $user = Yii::$app->user->identity;
            return $this->render('loggedin', ['headingString' => $this->headingString, 'user' => $user]);
        }

        return $this->render('guest');
    }
}