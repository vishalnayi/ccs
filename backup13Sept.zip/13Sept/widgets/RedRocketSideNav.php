<?php
namespace frontend\widgets;

use yii;
use yii\base\Widget;
use common\models\User;

class RedRocketSideNav extends Widget
{
    protected $role = '';
    public $currentPage = '';
    public $currentChild = '';

    public function init()
    {
        parent::init();
        if ($this->currentPage === null) {
            $this->currentPage = 'dashboard';
        }
    }

    public function run()
    {
        $user = Yii::$app->user->identity;
        return $this->render('sideNav', [
            'user' => $user,
            'currentPage' => $this->currentPage,
            'currentChild' => $this->currentChild
        ]);
    }
}
