<?php
return [
    'adminEmail' => 'admin@cleancloudsystems.com',
    'supportEmail' => 'alerts@cleancloudsystems.com',
    'user.passwordResetTokenExpire' => 3600,
    'adminAlertRecipients' => ['damien@example.com'],
];
