<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=rmp-app-prod-db-1.cw7hxr2b7ow7.us-west-2.rds.amazonaws.com;dbname=rmp_app_prod',
            'username' => 'rmp',
            'password' => 'oi24o09as8LKJELKJ13KLJD',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'owncloudHelper' => [
            'class' => 'common\components\OwncloudHelper',
            'host' => 'http://172.31.21.178',
            'hostPath' => 'http://admin:rmpsystems2016@172.31.21.178',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
            'localPath' => '/var/www/owncloud_files/',
            'binPath' => '/usr/bin/owncloudcmd',
        ],
        's3Helper' => [
            'nextcloudBucket' => 'nextcloud-prod',
            'appBucket' => 'application-prod',
            'region' => 'us-west-2',
        ],
        'nextcloudHelper' => [
            'class' => 'common\components\NextcloudHelper',
            'baseUri' => 'http://ccsvault.cleancloudsystems.com/remote.php/dav/files/admin/',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
        ],
    ],
];
