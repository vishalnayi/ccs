<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=rmp',
            'username' => 'rmp',
            'password' => 'rmp-2123',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'owncloudHelper' => [
            'class' => 'common\components\OwncloudHelper',
            'host' => 'http://192.168.33.39/nextcloud',
            'hostPath' => 'http://admin:rmpsystems2016@54.187.79.32/nextcloud',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
            'localPath' => '/var/www/owncloud_files/',
            'binPath' => '/usr/bin/owncloudcmd',
        ],
        's3Helper' => [
            'nextcloudBucket' => 'nextcloud-local-dev',
            'appBucket' => 'app-local-dev',
            'region' => 'us-west-2',
        ],
        'nextcloudHelper' => [
            'class' => 'common\components\NextcloudHelper',
            'baseUri' => 'http://ccsvault.cleancloudsystems.com/remote.php/dav/files/admin/s3/',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
        ],
    ],
];
