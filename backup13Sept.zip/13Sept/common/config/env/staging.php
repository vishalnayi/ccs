<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=rmp-staging-app-database.cw7hxr2b7ow7.us-west-2.rds.amazonaws.com;dbname=rmp_app_staging',
            'username' => 'rmp',
            'password' => 'rmp-2123*(sd2',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'owncloudHelper' => [
            'class' => 'common\components\OwncloudHelper',
            'host' => 'http://ip-172-31-11-82.us-west-2.compute.internal/nextcloud',
            'hostPath' => 'http://admin:rmpsystems2016@ip-172-31-11-82.us-west-2.compute.internal/nextcloud',
            'username' => 'admin',
            'password' => 'rmpsystems2016',
            'localPath' => '/var/www/owncloud_files/',
            'binPath' => '/usr/bin/owncloudcmd',
        ],
    ],
];
