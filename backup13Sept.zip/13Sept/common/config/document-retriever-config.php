<?php

return [
    'class' => 'common\components\DocumentRetriever',
    'originalServer' => 'sub4.mail.dreamhost.com',
    'cleancloudServer' => 'mail.cleancloudsystems.com',
];
