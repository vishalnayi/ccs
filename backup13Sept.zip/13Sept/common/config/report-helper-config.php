<?php

return [
    'class' => 'common\components\ReportHelper',
];

