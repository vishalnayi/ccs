<?php

return [
    'class' => 'common\components\BaseMailer',
    'key' => 'AKIAS2QP4LEJQDAG7A5W',
    'secret' => '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',
    'region' => 'us-west-2',
    'from' => 'info.cleancloudsystems@gmail.com',//'Alerts@rmpsystems.com',
    'fromName' => 'RMP Systems',
    'diagnosticEmailAddress' => 'info.cleancloudsystems@gmail.com',
];
