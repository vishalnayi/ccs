<?php

return [
    'class' => 'common\components\MailMessage',
];

