<?php

require_once( dirname(__FILE__) . '/../helpers.php');

return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'cloudMirrorHelper' => require(__DIR__.'/cloudMirror-config.php'),
        'mailHelper' => require(__DIR__.'/mailer-config.php'),
        'mailMessage' => require(__DIR__.'/mail-message-config.php'),
        'documentRetriever' => require(__DIR__.'/document-retriever-config.php'),
        'reportHelper' => require(__DIR__.'/report-helper-config.php'),
        's3Helper' => [
            'class' => 'common\components\S3Helper',
            'key' => 'AKIAI2DY3HZSOP7LUI3A',
            'secret' => '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',
            'hostname' => 's3-us-west-2.amazonaws.com',
            'port' => 443,
            'version' => 'latest',
            'rootPath' => 's3',
        ],
        'mail' => [
    	    'class' => 'yashop\ses\Mailer',
    	    'access_key' => 'AKIAS2QP4LEJQDAG7A5W',
    	    'secret_key' => '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',
    	    'host' => 'email.us-west-2.amazonaws.com' // not required
    	],
        'i18n' => [
        'translations' => [
                '*' => [
                    'class'          => 'yii\i18n\PhpMessageSource',
                    'basePath'       => '@app/messages', // if advanced application, set @frontend/messages
                    'sourceLanguage' => 'en',
                    'fileMap'        => [
                        //'main' => 'main.php',
                    ],
                ],
            ],
        ],
    ],
    'modules' => [
        'gridview' => ['class' => 'kartik\grid\Module']
    ],
];
