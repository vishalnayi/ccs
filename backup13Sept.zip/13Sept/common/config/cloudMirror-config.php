<?php

use \common\models\ClientSite;

return [
        'class' => 'common\components\CloudMirrorHelper',
        'mirrorPath' => ClientSite::OWNCLOUD_DIRECTORY .'/RMP_mirror',
];
