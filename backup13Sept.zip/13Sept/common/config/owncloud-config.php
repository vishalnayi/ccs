<?php

return [
        'class' => 'common\components\OwncloudHelper',
        'host' => 'http://54.187.79.32/nextcloud',
        'username' => 'admin',
        'password' => 'rmpsystems2016',
];
