<?php

    function dd($obj)
    {
        die(var_dump($obj));
    }

    function logger($msg)
    {
        file_put_contents('/tmp/logger.log', date('Y-m-d H:i:s') .": ". $msg ."\n", FILE_APPEND);
    }
