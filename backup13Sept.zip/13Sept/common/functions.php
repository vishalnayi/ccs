<?php


function isValidEmailFormat($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function getFileExtension($filename)
{
    $extension = substr($filename, strrpos($filename, '.')+1);

    return strtolower($extension);
}

function is_dir_empty($dir) {
    if (!is_readable($dir)) return NULL; 
        $handle = opendir($dir);
        while (false !== ($entry = readdir($handle))) {
            if ($entry != "." && $entry != "..") {
                return false;
            }
        }

    return true;
}

function sendErrorEmail($class, $action, $message)
{
    $mailMessage = Yii::$app->mailMessage;
    $mailMessage->sendDiagnosticErrorEmail($class, $action, $message);
}

/**
 * This method is designed to replace spaces with
 * underscores and move to lowercase.
 */
function formatPath($string)
{
    $string = strtolower($string);
    $string = str_replace(' ', '_', $string);
    $string = preg_replace('/[^a-zA-Z0-9\-_.]/', '', $string);

    return $string;
}
