<?php

namespace common\components;

use yii\base\Component;

class OwncloudHelper extends Component
{
    public $host;
    public $username;
    public $password;
    public $localPath;
    public $hostPath;
    public $binPath;

    public function syncFiles()
    {
        // echo $this->binPath .' '. $this->localPath .' '. $this->hostPath;
        // die;
        ///usr/bin/owncloudcmd /var/www/owncloud_files/ http://admin:rmpsystems2016@172.31.21.178
        system($this->binPath .' '. $this->localPath .' '. $this->hostPath);
    }

    public function test()
    {
        $shares = $this->handle->fileSharing()->getAllShares();
        dd($shares);
    }
}
