<?php

namespace common\components;

use Yii;
use yii\base\Component;
use Aws\S3\S3Client;


Class S3Helper extends Component
{
    protected $client;
    
    public $key;
    public $secret;
    public $region;
    public $hostname;
    public $port;
    public $bucket;
    public $version;
    public $rootPath;

    public $nextcloudBucket;
    public $appBucket;
    
    public function init()
    {
        parent::init();

        $this->client = S3Client::factory([
            'region' => $this->region,
            'version' => $this->version,
            'credentials' => [
                'key'    => $this->key,
                'secret' => $this->secret,
            ],
        ]);
    }
    
    public function createBucket($bucket)
    {
        $result = $this->client->createBucket(array(
            'Bucket'             => $bucket,
            'LocationConstraint' => $this->region,
        ));
        return $result;
    }
    
    public function saveFile($file, $key, $bucket)
    {
        $result = $this->client->putObject([
            'Bucket' => $bucket,
            'Key' => $key,
            'SourceFile' => $file,
            'ACL'        => 'public-read',
        ]);
    }

    /**
     * Move path or file
     */
    public function movePath($rootPath, $newPath, $existingMirrorPath, $bucket)
    {
        $this->clonePath($rootPath, $newPath, $bucket);
        $this->removePath($existingMirrorPath, $bucket);
    }

    /**
     * Move path or file
     */
    public function movePathUpdated($oldPath, $newPath, $bucket)
    {
        $this->clonePath($oldPath, $newPath, $bucket);
        $this->removePath($oldPath, $bucket);
    }

    /**
     * Copy existing file or path to a new one.
     */
    public function clonePath($existingPath, $newPath, $bucket)
    {
        $keys = $this->directoryListing($existingPath, $bucket);

        foreach ($keys as $file) {
            $newFile = '';
            $newFile = str_replace($existingPath, $newPath, $file);

            try {
                $result = $this->client->copyObject([
                    'Bucket' => $bucket,
                    'CopySource' => $bucket .'/'. $file,
                    'Key' => $newFile,
                ]);
            } catch (\S3Exception $e) {
                dd($e->getMessage());
            }
        }
    }

    public function removePath($path, $bucket)
    {
        $keys = $this->directoryListing($path, $bucket);

        foreach ($keys as $file) {
            try {
                $result = $this->client->deleteObject([
                    'Bucket' => $bucket,
                    'Key' => $file,
                ]);
                echo "Removing $file<br />";
            } catch (\S3Exception $e) {
                dd($e->getMessage());
            }
        }
    }

    public function directoryListing($path, $bucket, $singleDepth=false, $filenamesOnly=false)
    {
        $keys = $this->client->getIterator('ListObjects', [
            'Bucket' => $bucket,
            'Prefix' => $path,
            'Region' => $this->region,
        ]);

        $keys = $this->retrieveKeys($keys);

        if ($singleDepth) {
            $keys = $this->getSingleDepthPath($keys, $path);
        }

        if ($filenamesOnly) {
            $keys = $this->getFilenames($keys);
        }

        return $keys;
    }

    protected function getFilenames($keys)
    {
        $filenames = [];

        foreach ($keys as $key) {
            $array = explode('/', $key);
            $filenames[] = end($array);
        }

        return $filenames;
    }

    protected function getSingleDepthPath($keys, $path)
    {
        $arrayTmp = [];

        foreach ($keys as $key) {
            $arrayTmp[] = str_replace($path, '', $key);
        }

        $keys = [];

        foreach ($arrayTmp as $item) {
            $item = explode('/', $item);
            if ($item[1] == '') {
                continue;
            }
            if (!in_array($item[1], $keys)) {
                $keys[] = $item[1];
            }
        }

        return $keys;
    }

    protected function retrieveKeys($objects)
    {
        $keys = [];

        foreach ($objects as $object) {
            $keys[] = $object['Key'];
        }

        return $keys;
    }

    public function getFile($key, $bucket)
    {
        try {
            $fileObject = $this->client->getObject([
                'Bucket' => $bucket,
                'Key' => $key,
            ]);
        } catch (S3Exception $e) {
            dd($e->getMessage());
        }

        return $fileObject;
    }

    public function saveFiletoLocal($key, $bucket,$savepath)
    {
        try {
            $fileObject = $this->client->getObject([
                'Bucket' => $bucket,
                'Key' => $key,
                'SaveAs' => $savepath,
            ]);
        } catch (S3Exception $e) {
            dd($e->getMessage());
        }

        return $fileObject;
    }

    /**
     * Check to see if file exists
     *
     * @param string $filepath - Must be preceeded by `/`
     * @param string $filename
     * @param string $bucket
     * @return boolean
     */
    public function fileExists($filepath, $bucket)
    {
        $objects = $this->client->getIterator('ListObjects', [
            'Bucket' => $bucket,
            'Prefix' => $filepath,
            'Region' => $this->region,
        ]);

        $objects = $this->retrieveKeys($objects);

        // Annoyingly, AWS won't allow `count($objects)` here. We need to loop through.
        foreach ($objects as $object) {
            return true;
        }

        return false;
    }

    public function copyFile($targetKey, $sourceKey, $bucket)
    {
        $this->client->copyObject(array(
            'Bucket'     => $targetBucket,
            'Key'        => $targetKey,
            'CopySource' => "{$sourceBucket}/{$sourceKey}",
        ));
    }
    
    public function deleteFile($key, $bucket)
    {
        $result = $this->client->deleteObject(array(
            'Bucket' => $bucket,
            'Key'    => $key,
        ));
        return $result;
    }





    /****************  REMOVE BELOW THIS LINE  ******************/
    public function deleteBucket($bucket)
    {
        $this->client->deleteBucket(array('Bucket' => $bucket));
    }
    
    public function listFiles(array $params)
    {
        $files = [];

        $iterator = $this->client->getIterator('ListObjects', $params);
        foreach ($iterator as $object) {
            $files[] = $object['Key'];
        }
        return $files;
    }
    
    public function getFileKeys($bucket)
    {
        $keys = array();
        $iterator = $this->client->getIterator('ListObjects', array(
            'Bucket' => $bucket
        ));
        foreach ($iterator as $object) 
            $keys[] = $object['Key'];
        return $keys;
    }
    
    public function putFileFromString($bucket, $key, $data)
    {
        $result = $this->client->putObject(array(
            'Bucket' => $bucket,
            'Key'    => $key,
            'Body'   => $data
        ));
        return $result;
    }
    
    public function putFile($bucket, $key, $file = null, $acl='public-read')
    {
        //use $key as the file
        if(null == $file)
            $file = $key;
        $result = $this->client->putObject(array(
            'Bucket'     => $bucket,
            'Key'        => $key,
            'Body'       => fopen($file, 'r+'),
            'ACL'  => $acl,
        ));
        return $result;
    }
    
    public function waitForFile($bucket, $key)
    {
        $this->client->waitUntilObjectExists(array(
            'Bucket' => $bucket,
            'Key' => $key
        ));
    }
    
    public function waitForBucket($bucket)
    {
        $this->client->waitUntil('BucketExists', array('Bucket' => $bucket));
    }
    
    public function changeAccess($bucket, $key, $access = 'public-read')
    {
        $this->client->putObjectAcl(array(
            'Bucket' => $bucket,
            'Key' => $key,
            'ACL' => $access
        ));
    }

    public function listDirs($bucket) {
        $objects = $this->client->getIterator( 'ListObjects', [ 'Bucket' => $bucket ] );
        $dirs = [];
        foreach( $objects as $ob ) {
            if( preg_match( '/^.*\/$/', $ob[ 'Key' ] ) ) {
                $split = explode( '/', $ob[ 'Key' ] );                
                $dirs = $this->nest_dir( $dirs, $split );
            }
        }
        return $dirs;
    }

    public function nest_dir( $ref, $dirs ) {
        $dirs = array_filter( $dirs );
            foreach( $dirs as $index => $dir ) {
                $parent = @$dirs[ $index - 1 ];

            if( $parent && isset( $ref[ $parent ] ) ) {
                $ref[ $parent ][ $dir ] = $this->nest_dir( [], array_slice( $dirs, $index + 1 ) );
                continue;
            }
            if( !$parent || ( $parent && array_search( $parent, $dirs ) === 0 ) )
                $ref[ $dir ] = [];
            }
        return $ref;
    }

}

