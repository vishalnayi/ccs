<?php

namespace common\components;

use Yii;
use yii\base\Component;
use common\models\UserPermissions;
use common\models\User;

Class CheckPermissionHelper extends Component
{
    
    public function getUserPermissionAccess($userid,$module_name,$action,$role=''){     
        // select up.p_field_1,up.p_field_2,up.p_field_3,up.p_field_4,r.module_name,u.role,u.email from user_permissions up join user u on up.user_id = u.id JOIN rights_modules r on up.user_rights_id = r.id where up.user_id = 1 ORDER BY r.id
        $permissions = UserPermissions::find()->select(['user_permissions.user_id','user_permissions.p_field_1','user_permissions.p_field_2','user_permissions.p_field_3','user_permissions.p_field_4','r.module_name','u.role','u.email'])
            ->innerJoin('user u','user_permissions.user_id=u.id')
            ->innerJoin('rights_modules r','user_permissions.user_rights_id=r.id')
            ->where(['user_permissions.user_id'=>$userid,'r.module_name'=>$module_name])
            //->createCommand()->getRawSql();           
           ->asArray()->all();
         
         
           if($role == User::ROLE_SUPER){
                return 1;
           }elseif($role == User::ROLE_AUDITOR){
                return 1;
           }elseif(!empty($permissions)){
                if($action == 'index') {
                    if($permissions[0]['p_field_1'] == 0) {
                       return 0;
                    }else{
                      return 1;
                    }
                }elseif($action == 'view') {
                    if($permissions[0]['p_field_1'] == 0) {
                      return 0;
                    }else{
                      return 1;
                    }
                }elseif($action == 'create') {
                    if($permissions[0]['p_field_2'] == 0) {
                        return 0;
                    }else{
                      return 1;
                    }
                }elseif($action == 'update') {
                    if($permissions[0]['p_field_3'] == 0) {
                        return 0;
                    }else{
                      return 1;
                    }
                }elseif($action == 'delete') {
                    if($permissions[0]['p_field_4'] == 0) {
                        return 0;
                    }else{
                      return 1;
                    }
                } 
           }else{
              return 0;
           } 
    }
    
}

