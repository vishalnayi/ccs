<?php

namespace common\components;

use Yii;
use yii\base\Component;

class ReportHelper extends Component
{
    public function convertDocumentToImage($pdfPath, $docType)
    {
        $filename = '/tmp/from-pdf-'. md5(microtime()) .'.png';
        $fileCropped = '/tmp/cropped-'. md5(microtime()) . '.png';
        $logImagePath = '/tmp/logimage-'. md5(microtime()) .'.png';

        if($docType != 'csv'){
            try {

                if ($docType == 'pdf') {
                    $pdfPath .= '[0]'; // Only load into memory the first page
                }

                $image = new \Imagick();
                $image->setResolution(300, 300);
                $image->readImage($pdfPath);
                $image->setImageAlphaChannel(\Imagick::ALPHACHANNEL_REMOVE);
                $image->adaptiveResizeImage(1080, 1920);
                $image->setImageFormat('png');
                if ($docType == 'doc') {
                    $image->setIteratorIndex(0); // Load first page - defaults to last - Seems to increase resulting image size
                }
                $image->writeImage($filename);
                

            } catch (\ImagickException $e) {
                sendErrorEmail('ReportHelper', 'Image manipulation', 'File: '. $pdfPath .'; '. $e->getMessage());
                  
                return [0,0]; // @todo - fix this line
            }
        }

        return $filename;
    }

    public function readSectionOfDocument($imagePath, $term, $docType)
    {
        $x1 = $term->x1!=""?$term->x1:50;
        $y1 = $term->y1!=""?$term->y1:50;
        $x2 = $term->x2!=""?$term->x2:100;
        $y2 = $term->y2!=""?$term->y2:100;

        $width = $x2 - $x1;
        $height = $y2 - $y1;

        $fileCropped = '/tmp/cropped-'. md5(microtime() . rand(10000,99999)) . '.png';
        $logImagePath = '/tmp/logimage-'. md5(microtime() . rand(10000,99999)) .'.png';

        try {
            /*print_r($imagePath);*/
            $im = imagecreatefrompng($imagePath);
            /*echo "im : ".$im.' x:'.$x1.' y: '.$y1.' width: '.abs($width).' height:'.abs($height);*/
            $im2 = imageCrop($im, ['x' => $x1, 'y' => $y1, 'width' => abs($width), 'height' => abs($height)]);

            $imageCropped = imagepng($im2, $fileCropped);

            $this->createLogImage($im, $logImagePath, $x1, $y1, $x2, $y2);

        } catch (\ImagickException $e) {
            sendErrorEmail('ReportHelper', 'Image manipulation', 'File: '. $imagePath .'; '. $e->getMessage());

            return [0,0]; // @todo - fix this line
        }

        return [$fileCropped, $logImagePath];
    }

    /**
     * Create log image - Original image but with lines overlayed to
     * show where the document was cropped.
     */
    protected function createLogImage($image, $logImagePath, $x1, $y1, $x2, $y2)
    {
        $lineColour = imagecolorallocate($image, 220, 0, 0);

        imageline($image, $x1, $y1, $x2, $y1, $lineColour); // Top horizontal line
        imageline($image, $x1, $y1, $x1, $y2, $lineColour); // Left vertical line
        imageline($image, $x1, $y2, $x2, $y2, $lineColour); // Bottom horizontal line
        imageline($image, $x2, $y1, $x2, $y2, $lineColour); // Right vertical line

        imagepng($image, $logImagePath);
    }
}
