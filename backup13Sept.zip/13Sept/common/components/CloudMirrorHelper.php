<?php

namespace common\components;

use yii\base\Component;
use common\models\ClientSite;

class CloudMirrorHelper extends Component
{
    public $mirrorPath;
    protected $tmpMirrorPath = '/tmp/RMP_mirror';

    public function buildPaths($clients)
    {
        //shell_exec('for file in $(ls '. $this->mirrorPath .'); do rm -rf '. $this->mirrorPath .'/$file/*; done');
        shell_exec('rm -rf '. $this->tmpMirrorPath);
        foreach($clients as $clientName=>$sites) {
            foreach($sites as $site) {
                if(!isset($site['path'])) {
                    continue;
                }
            
                try {
                    $sitePath = str_replace(' ', '_', $this->tmpMirrorPath . $site['path']);
                    $sitePath = preg_replace('/'. $site['site_name'] .'$/', '', $sitePath);
                    if(!file_exists($sitePath)) {
                        mkdir($sitePath, 0755, true);
                    }
                    $this->copyFilesWithRsync($site, $sitePath, $clientName);
                } catch(Exception $e) {
                    die('Unable to create path: '. $sitePath .'; '. $e->getMessage());
                }
            }
        }

        system('rsync -avzt --delete '. $this->tmpMirrorPath .'/* '. $this->mirrorPath);
    }

    protected function copyFilesWithRsync($site, $sitePath, $clientName)
    {
        $sourcePath = ClientSite::OWNCLOUD_DIRECTORY .'/'. $site['site_directory'];
        $destPath = str_replace(' ', '_', $sitePath .'/'. $site['site_name']);
        //echo 'cp -R  "'. $sourcePath .'" '. $destPath ."\n";
        //system('cp -R  "'. $sourcePath .'" '. $destPath);
        print('rsync -avz --delete '. $sourcePath .'/* '. $destPath);
        system('rsync -avz --delete '. $sourcePath .'/* '. $destPath);
        system('chmod -R 777 '. $destPath);
        $currentDestPath = $destPath .'/'. $site['site_directory'];
        $newDestPath = str_replace(' ', '_', $destPath .'/'. $site['site_name']);
            echo "current - $currentDestPath\n";
            echo "new - $newDestPath\n";
        //if($currentDestPath != $newDestPath) {
        //    system('mv '. $currentDestPath .' '. $newDestPath);
        //}
    }

    protected function copyFiles($site, $sitePath, $clientName)
    {
        $sourcePath = ClientSite::OWNCLOUD_DIRECTORY .'/'. $site['site_directory'];
        $destPath = str_replace(' ', '_', $sitePath);
        echo 'cp -R  "'. $sourcePath .'" '. $destPath ."\n";
        system('cp -R  "'. $sourcePath .'" '. $destPath);
        system('chmod -R 777 '. $destPath);
        $currentDestPath = $destPath .'/'. $site['site_directory'];
        $newDestPath = str_replace(' ', '_', $destPath .'/'. $site['site_name']);
            echo "current - $currentDestPath\n";
            echo "new - $newDestPath\n";
        if($currentDestPath != $newDestPath) {
            system('mv '. $currentDestPath .' '. $newDestPath);
        }
    }
}
