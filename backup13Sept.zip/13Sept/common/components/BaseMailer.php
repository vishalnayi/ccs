<?php

namespace common\components;

use Aws\Ses\SesClient;


class BaseMailer extends \Yii\base\Object
{
    public $key;
    public $secret;
    public $region;
    public $from;
    public $fromName;
    public $diagnosticEmailAddress;

    public $mail;

	protected $client;
	protected $msg;

    /**
     * Initialise mailer with configuration
     */
    public function init()
    {
        parent::init();

        $this->client = $client = SesClient::factory([
            'credentials' => [
                'key'    => $this->key,
                'secret' => $this->secret,
            ],
            'region' => $this->region,
            'version' => 'latest',
        ]);

        $this->msg['Source'] = $this->from;
        $this->msg['Destination']['ToAddresses'] = [];
        $this->msg['Destination']['CcAddresses'] = [];
        $this->msg['Destination']['BccAddresses'] = [];
    }

    public function send()
    {
        try {
            $result = $this->client->sendEmail($this->msg);
        
            $msgId = $result->get('MessageId');
        } catch (Exception $e) {
            \Yii::error('There was a problem sending email: '. $e->getMessage());
        }
    }    

    /**
     * Amazon SES doesn't seem to allow names, only addresses.
     */
    public function addAddress($address, $name=null)
    {
        if (is_array($address)) {
            $this->msg['Destination']['ToAddresses'] = array_merge($this->msg['Destination']['ToAddresses'], $address);
        } else {
            $this->msg['Destination']['ToAddresses'][] = $address;
        }
    }

    public function addCcAddress($address)
    {
        if (is_array($address)) {
            $this->msg['Destination']['CcAddresses'] = array_merge($this->msg['Destination']['CcAddresses'], $address);
        } else {
            $this->msg['Destination']['CcAddresses'][] = $address;
        }
    }

    public function addBccAddress($address)
    {
        if (is_array($address)) {
            $this->msg['Destination']['BccAddresses'] = array_merge($this->msg['Destination']['BccAddresses'], $address);
        } else {
            $this->msg['Destination']['BccAddresses'][] = $address;
        }
    }

    public function addSubject($subject)
    {
   	    $this->msg['Message']['Subject']['Data'] = $subject;
    }

    public function addBody($body)
    {
        $this->msg['Message']['Body']['Html']['Data'] = $body;
    }
}
