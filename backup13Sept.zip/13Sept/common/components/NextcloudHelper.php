<?php

namespace common\components;

use Yii;
use yii\base\Component;
use GuzzleHttp\Client as GuzzleClient;
use Psr\Http\Message\ResponseInterface;

Class NextcloudHelper extends Component
{
    protected $client;
    
    public $username;
    public $password;
    public $baseUri;
    
    public function init()
    {
        parent::init();

        $this->client = new GuzzleClient([
            'base_uri' => $this->baseUri,
            'timeout' => 120,
            'auth' => [
                $this->username,
                $this->password,
            ],
        ]);
    }
    
    public function saveFile($source, $dest)
    {
        $body = fopen($source, 'r');
        echo "== Put file: $source\n";
        $promise = $this->client->requestAsync('PUT', $dest,
            ['body' => $body,
            ]
        );

        $response = $promise->wait();
        $returning = ['statusCode' => $response->getStatusCode(),
                      'reasonPhrase' => $response->getReasonPhrase(),
                  ];

        return $response->getStatusCode() == 201 || $response->getStatusCode() == 204 ? true : false;
    }

    public function copyFile($source, $dest)
    {
		$headers = [
            'Destination' => $this->baseUri . $dest,
            'Overwrite' => 'T',
		];

        echo "== Copy file: $source\n";
        $this->client->request('COPY', $source, [
        	'headers' => $headers,
        ]);
    }

    /**
     * Make new directory
     *
     * @param string $path
     * @param boolean $force - Set if path is known not to exist
     * @return boolean
     */
    public function makePath($path, $force=false)
    {
        if ($force || !$this->pathExists($path)) {
        	echo "== Make path: $path\n";
            $response = $this->client->request('MKCOL', $path);

            return $response->getStatusCode() == 201 ? true : false;
        }

        return true;
    }

    /**
     * WebDAV is not able to recursively create a path, so we need to 
     * do it step by step. This method breaks up the paths like so:
     *
     * 0 => 'dir1',
     * 1 => 'dir1/dir2',
     * 2 => 'dir1/dir2/dir3',
     */
    public function makePathRecursive($path)
    {
        if ($this->pathExists($path)) {
            return true;
        }

        $paths = $this->buildPathArray($path);

        foreach ($paths as $path) {
            $this->makePath($path);
        }

        return true;
    }

    /**
     * WebDAV is not able to recursively create a path, so we need to 
     * do it step by step. This method breaks up the paths like so:
     *
     * 0 => 'dir1',
     * 1 => 'dir1/dir2',
     * 2 => 'dir1/dir2/dir3',
     */
    protected function buildPathArray($path)
    {
        $fullPath = '';

        $directories = explode('/', $path);
        foreach ($directories as $directory) {
            $fullPath .= $directory .'/';
            $paths[] = $fullPath;
        }

        return $paths;
    }

    public function pathExists($path)
    {
        try {
        echo "== Check path exists: $path\n";
            $response = $this->client->request('PROPFIND', $path);
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            return false; // Guzzle throws an exception when path not found
        }

        return true;
    }


    ////////////////////////////////////////////////////////////////////////////////

    /**
     * Move path or file
     */
    public function movePath($rootPath, $newPath, $existingMirrorPath, $bucket)
    {
        $this->clonePath($rootPath, $newPath, $bucket);
        $this->removePath($existingMirrorPath, $bucket);
    }

    /**
     * Copy existing file or path to a new one.
     */
    public function clonePath($existingPath, $newPath, $bucket)
    {
        $keys = $this->directoryListing($existingPath, $bucket);

        foreach ($keys as $file) {
            $newFile = '';
            $newFile = str_replace($existingPath, $newPath, $file);

            try {
                $result = $this->client->copyObject([
                    'Bucket' => $bucket,
                    'CopySource' => $bucket .'/'. $file,
                    'Key' => $newFile,
                ]);
            } catch (\S3Exception $e) {
                dd($e->getMessage());
            }
        }
    }

    public function removePath($path, $bucket)
    {
        $keys = $this->directoryListing($path, $bucket);

        foreach ($keys as $file) {
            try {
                $result = $this->client->deleteObject([
                    'Bucket' => $bucket,
                    'Key' => $file,
                ]);
                echo "Removing $file<br />";
            } catch (\S3Exception $e) {
                dd($e->getMessage());
            }
        }
    }

    public function directoryListing($path, $bucket, $singleDepth=false)
    {
        $keys = $this->client->getIterator('ListObjects', [
            'Bucket' => $bucket,
            'Prefix' => $path,
            'Region' => $this->region,
        ]);

        $keys = $this->retrieveKeys($keys);

        if ($singleDepth) {
            $keys = $this->getSingleDepthPath($keys, $path);
        }

        return $keys;
    }

    protected function getSingleDepthPath($keys, $path)
    {
        $arrayTmp = [];

        foreach ($keys as $key) {
            $arrayTmp[] = str_replace($path, '', $key);
        }

        $keys = [];

        foreach ($arrayTmp as $item) {
            $item = explode('/', $item);
            if ($item[1] == '') {
                continue;
            }
            if (!in_array($item[1], $keys)) {
                $keys[] = $item[1];
            }
        }

        return $keys;
    }

    protected function retrieveKeys($objects)
    {
        $keys = [];

        foreach ($objects as $object) {
            $keys[] = $object['Key'];
        }

        return $keys;
    }

    public function getFile($key, $bucket)
    {
        try {
            $result = $this->client->getObject([
                'Bucket' => $bucket,
                'Key' => $key,
            ]);
        } catch (S3Exception $e) {
            dd($e->getMessage());
        }

        return $result;
    }

    /**
     * Check to see if file exists
     *
     * @param string $filepath - Must be preceeded by `/`
     * @param string $filename
     * @param string $bucket
     * @return boolean
     */
    public function fileExists($filepath, $bucket)
    {
        $filepath = '/'. $filepath;

        $objects = $this->client->getIterator('ListObjects', [
            'Bucket' => $bucket,
            'Prefix' => $filepath,
            'Region' => $this->region,
        ]);

        // Annoyingly, AWS won't allow `count($objects)` here. We need to loop through.
        foreach ($objects as $object) {
            dd($object);
            return true;
        }

        return false;
    }






    /****************  REMOVE BELOW THIS LINE  ******************/
    public function deleteBucket($bucket)
    {
        $this->client->deleteBucket(array('Bucket' => $bucket));
    }
    
    public function listFiles(array $params)
    {
        $files = [];

        $iterator = $this->client->getIterator('ListObjects', $params);
        foreach ($iterator as $object) {
            $files[] = $object['Key'];
        }
        return $files;
    }
    
    public function getFileKeys($bucket)
    {
        $keys = array();
        $iterator = $this->client->getIterator('ListObjects', array(
            'Bucket' => $bucket
        ));
        foreach ($iterator as $object) 
            $keys[] = $object['Key'];
        return $keys;
    }
    
    public function putFileFromString($bucket, $key, $data)
    {
        $result = $this->client->putObject(array(
            'Bucket' => $bucket,
            'Key'    => $key,
            'Body'   => $data
        ));
        return $result;
    }
    
    public function putFile($bucket, $key, $file = null, $acl='public-read')
    {
        //use $key as the file
        if(null == $file)
            $file = $key;
        $result = $this->client->putObject(array(
            'Bucket'     => $bucket,
            'Key'        => $key,
            'Body'       => fopen($file, 'r+'),
            'ACL'  => $acl,
        ));
        return $result;
    }
    
    public function deleteFile($bucket, $key)
    {
        $result = $this->client->deleteObject(array(
            'Bucket' => $bucket,
            'Key'    => $key,
        ));
        return $result;
    }
    
    public function waitForFile($bucket, $key)
    {
        $this->client->waitUntilObjectExists(array(
            'Bucket' => $bucket,
            'Key' => $key
        ));
    }
    
    public function waitForBucket($bucket)
    {
        $this->client->waitUntil('BucketExists', array('Bucket' => $bucket));
    }
    
    public function changeAccess($bucket, $key, $access = 'public-read')
    {
        $this->client->putObjectAcl(array(
            'Bucket' => $bucket,
            'Key' => $key,
            'ACL' => $access
        ));
    }
}

