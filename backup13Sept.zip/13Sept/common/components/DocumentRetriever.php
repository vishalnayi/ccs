<?php

namespace common\components;

use Yii;
use Ddeboer\Imap\Server;
use Ddeboer\Imap\SearchExpression;
use Ddeboer\Imap\Search\Email\To;
use Ddeboer\Imap\Search\Text\Body;
use Ddeboer\Imap\Search\Flag\Unseen;


class DocumentRetriever extends \yii\base\Object
{
    public $originalServer;
    public $cleancloudServer;

    public $allowedDocTypes = [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'jpg',
        'jpeg',
        'png',
        'csv',
    ];

    /**
     * Initialise component
     */
    public function init()
    {
        parent::init();
    }

    protected function instantiateServer($emailAddress)
    {
        /*echo $this->cleancloudServer;
        echo "<br>";
        echo $this->originalServer;exit;*/
        if (preg_match('/cleancloudsystems.com/', $emailAddress) == 1) {
            $host = $this->cleancloudServer;
        } else {
            $host = $this->originalServer;
        }
        //echo $host;
        return new Server($host, 993, '/imap/ssl/validate-cert');
    }

	public function testEmailCredentials($username, $password)
	{
        $server = $this->instantiateServer($username);

        try {
            $connection = $server->authenticate($username, $password);

			return true;

        } catch(\Ddeboer\Imap\Exception\AuthenticationFailedException $e) {

        	return false;
        }
	}

    public function getNewDocuments($username, $password)
    {
        $reportHelper = Yii::$app->reportHelper;
        $server = $this->instantiateServer($username);

        $documents = [];

        try {
            $connection = $server->authenticate($username, $password);

        } catch(\Ddeboer\Imap\Exception\AuthenticationFailedException $e) {
            // @todo log error
            // @todo send alert that it failed.
            echo "==== Authentication has failed for $username\n";
            echo $e->getMessage();
            return []; // return empty array
        }

        $search = new SearchExpression();
        $search->addCondition(new UNSEEN());

        $mailbox = $connection->getMailbox('INBOX');
        $messages = $mailbox->getMessages($search);
        echo $username;

        $messageKey = 0; // Must group documents to their associated email.
        foreach ($messages as $message) {
            echo "=========================================================================\n";
            echo "Subject: ". $message->getSubject() ."\n";
            $emailAttributes = $this->getEmailAttributes($message);

        	foreach ($message->getAttachments() as $attachment) {
                /*echo $attachment->getFilename();exit;*/
                if (!$attachment->getFilename()) { // Attachment not valid
                    echo "======= BAD DOCUMENT - FILENAME VALUE IS NULL\n";
                    continue;
                }
                $extension = getFileExtension($attachment->getFilename());
                if($extension=='csv'){
                    $documentFilename = '/tmp/'. md5(microtime() . rand(1,9999)) .'.csv';                 
                }elseif($extension=='png'){
                    $documentFilename = '/tmp/'. md5(microtime() . rand(1,9999)) .'.png';                 
                }elseif($extension=='jpg'){
                    $documentFilename = '/tmp/'. md5(microtime() . rand(1,9999)) .'.jpg';                 
                }elseif($extension=='jpeg'){
                    $documentFilename = '/tmp/'. md5(microtime() . rand(1,9999)) .'.jpeg';                 
                }else{
				    $documentFilename = '/tmp/'. md5(microtime() . rand(1,9999)) .'.pdf';
                }
				file_put_contents($documentFilename, $attachment->getDecodedContent());
                if (!in_array($extension, $this->allowedDocTypes)) {
                    continue;
                }
                $documentPdfFilename = $this->getPdfDocumentLocation($documentFilename, $extension);
                echo "document: ". $documentFilename ."\n";
                if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='csv'){
                    $documents[$messageKey][] = array_merge([
                        'documentFilename' => $documentFilename,
                        'documentPdfFilename' => $documentPdfFilename,
                        'documentExtension' => $extension,
                        'documentText' => '',
                        'documentImagePath' => $reportHelper->convertDocumentToImage($documentPdfFilename, $extension),
                    ], $emailAttributes);
                }else{
                    $documents[$messageKey][] = array_merge([
                        'documentFilename' => $documentFilename,
                        'documentPdfFilename' => $documentPdfFilename,
                        'documentExtension' => $extension,
                        'documentText' => $this->getDocumentText($documentPdfFilename, $extension),
                        'documentImagePath' => $reportHelper->convertDocumentToImage($documentPdfFilename, $extension),
    				], $emailAttributes);
                }
        	}

            $message->markAsSeen();

        	$messageKey++;
        }
        
        return $documents;
    }

    

    public function getNewDocumentsDashboard($filename,$documentFilename,$extension)
    {
        $reportHelper = Yii::$app->reportHelper;

        $documents = [];
        $emailAttributes= [
            'date' => date('Y-m-d H:i:s'),
            'timezone' => date_default_timezone_get(),
            'subject' => $filename,
            'from' => '',
            'to' => '',
            //'headers' => $message->getHeaders(),
            'messageText' => $filename,
            'messageHtml' => $filename,
        ];
        $messageKey=0;
        $documentPdfFilename = $this->getPdfDocumentLocation($documentFilename, $extension);
        echo "document: ". $documentFilename ."\n";
        if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='csv'){
            $documents[$messageKey][] = array_merge([
                'documentFilename' => $documentFilename,
                'documentPdfFilename' => $documentPdfFilename,
                'documentExtension' => $extension,
                'documentText' => '',
                'documentImagePath' => $reportHelper->convertDocumentToImage($documentPdfFilename, $extension),
            ], $emailAttributes);
        }else{
            $documents[$messageKey][] = array_merge([
                'documentFilename' => $documentFilename,
                'documentPdfFilename' => $documentPdfFilename,
                'documentExtension' => $extension,
                'documentText' => $this->getDocumentText($documentPdfFilename, $extension),
                'documentImagePath' => $reportHelper->convertDocumentToImage($documentPdfFilename, $extension),
            ], $emailAttributes);
        }
        
        return $documents;
    }

    /**
     * This method will create a PDF document from the uploaded file
     * and return its location
     *
     * @param string $filename - temp name
     * @param string $extension
     * @return string
     */
    public function getPdfDocumentLocation($filename, $extension)
    {
        if ($extension == 'pdf' || $extension == 'csv' || $extension == 'jpg' || $extension == 'jpeg' || $extension == 'png' ) {
            return $filename;
        }

        $tmpFile = '/tmp/'. md5(microtime() . rand(1,9999)) .'.pdf';
        copy($filename, $tmpFile);
        shell_exec('/usr/bin/soffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" '.
               ' --convert-to pdf:writer_pdf_Export --outdir /tmp '. $tmpFile);

        shell_exec('rm -rf /var/www/.cache'); // @todo: determine how to prevent this being created

        return $tmpFile;
    }

    protected function getEmailAttributes($message)
    {
        return [
            'date' => $message->getDate()->format('Y-m-d H:i:s'),
            'timezone' => $message->getDate()->getTimeZone()->getName(),
            'subject' => $message->getSubject(),
            'from' => $message->getFrom()->getAddress(),
            'to' => $this->extractAddresses($message->getTo()),
            //'headers' => $message->getHeaders(),
            'messageText' => $message->getBodyText(),
            'messageHtml' => $message->getBodyHtml(),
        ];
    }

    protected function extractAddresses($addresses)
    {
		$addressArray = [];

		foreach ($addresses as $address) {
			$addressArray[] = $address->getAddress();
		}

		return $addressArray;
    }

    public function getDocumentText($file)
    {
        $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
        $text = system('pdf2txt -o '. $tmpFile .' "'. $file .'"');
        $text = file_get_contents($tmpFile);
        unlink($tmpFile);

        return $text;
    }

    public function extractTextFromImage($image)
    {
        $outputPath = '/tmp/'. md5(microtime());
        $outputFilename = $outputPath .'.txt';

        system("tesseract $image $outputPath");
        $text = file_get_contents($outputFilename);

        unlink($outputFilename);

        return $text;
    }
}
