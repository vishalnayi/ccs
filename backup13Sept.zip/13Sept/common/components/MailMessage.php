<?php

namespace common\components;

/*********************************************
 *
 * This class is a handle of common system email
 * message that need to be sent by the application
 *
 *********************************************/

use Yii;

class MailMessage extends \yii\base\Object
{
    protected $mailer;

    public function init()
    {
        $this->mailer = Yii::$app->mailHelper;

        parent::init();
    }

    /**
     * Send diagnostic email
     *
     * @param string $class
     * @param string $action
     * @param mixes $message
     */
    public function sendDiagnosticErrorEmail($class, $action, $message)
    {
        $env = Yii::$app->params['env'] ?? 'unknown-env';

        $mailer = $this->mailer;

        if (!is_string($message)) {
            $message = print_r($message, true);
        }

        $body = "<p>The system has encountered a problem.</p>\n\n";
        $body .= "<p>Environment: $env</p>";
        $body .= "<p>Class: $class</p>\n\n";
        $body .= "<p>Action: $action</p>\n\n";
        $body .= $message;

        $mailer->addAddress($mailer->diagnosticEmailAddress);
        $mailer->addSubject("RMP system error - $env");
        $mailer->addBody($body);

        $mailer->send();
    }

    /**
     * Send an alert that notifies that the document could not be processed
     */
    public function sendBadDocumentAlert($attrs)
    {
        $env = Yii::$app->params['env'] ?? 'unknown-env';

        $body = \Yii::$app->view->render('@app/../frontend/views/mail/bad-document-alert', [
            'subject' => $attrs['subject'],
            'date' => $attrs['date'],
            'from' => $attrs['from'],
            'to' => $attrs['to'][0],
        ]);

        $mailer = $this->mailer;

        $mailer->addAddress($mailer->diagnosticEmailAddress);
        $mailer->addSubject("DPE document issue - $env");
        $mailer->addBody($body);

        $mailer->send();
    }
}
