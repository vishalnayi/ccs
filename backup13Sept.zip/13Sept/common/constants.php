<?php

    define('BASE_PATH', \Yii::$app->basePath);

