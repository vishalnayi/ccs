<?php

namespace common\behaviors;

use Yii;
use yii\base\Behavior;
use yii\db\ActiveRecord;
use common\models\User;

class SetClientBehavior extends Behavior
{
    public function events()
    {
        return [
            ActiveRecord::EVENT_BEFORE_INSERT => 'beforeInsert',
        ];
    }
    public function beforeInsert()
    {
        if(Yii::$app->user->identity->role != User::ROLE_SUPER) {
            $this->owner->client_id = Yii::$app->user->identity->client_id;
        }
    }
}

