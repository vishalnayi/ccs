<?php

namespace common\models;

use Yii;
use yii\base\DynamicModel;
/**
 * This is the model class for table "contacts".
 *
 * @property integer $id
 * @property integer $report_category_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class Companies extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'companies';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id','postcode'], 'integer'],
            [['company_name','email','domain_url','industry','phone_number','city','state'], 'string'],
            [['email'], 'email'],
            [['email'], 'unique', 'message' => 'The email address already exists'],            
            [['company_name'], 'required'],

            [['created_at','updated_at'],'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),                  
            'company_name' => Yii::t('app', 'Company Name'),
            'email' => Yii::t('app', 'Email'),
            'domain_url' => Yii::t('app', 'Website'),
            'industry' => Yii::t('app', 'Industry'),
            'phone_number' => Yii::t('app', 'Phone Number'),
            'city' => Yii::t('app', 'City'),
            'state' => Yii::t('app', 'State'),
            'postcode' => Yii::t('app', 'Postcode'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

   
}
