<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\SecondaryAlarm;

/**
 * SiteOperationalProgramSearch represents the model behind the search form about `common\models\SiteOperationalProgram`.
 */
class SecondaryAlarmSearch extends SecondaryAlarm
{
    public $clientSite;
    public $site;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'site_id', 'report_type_id', 'created_at', 'updated_at'], 'integer'],
            [['name','clientSite','reportType','site'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params, $filter=null)
    {
        $query = SecondaryAlarm::find();        
        $query->where(['site_operational_program.primary_alarm' => 1]);

        $query->joinWith(['clientSite', 'site']);
        

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);


        $dataProvider->sort->attributes['client_site'] = [
            'asc' => ['client_site.name' => SORT_ASC],
            'desc' => ['client_site.name' => SORT_DESC],
        ];

        $dataProvider->sort->attributes['site'] = [
            'asc' => ['site.name' => SORT_ASC],
            'desc' => ['site.name' => SORT_DESC],
            'label' => 'Site Yeah',
            'asdada' => '',
        ];

        $this->load($params);

        if (!$this->validate()) {
            return $this->getErrors();
            return $dataProvider;
        }

        if(isset($filter['clientId'])) {
            $query->andWhere('client_site.client_id=:clientId', [
                                    ':clientId' => $filter['clientId'],
            ]);
        }

        if(isset($filter['forceSites'])) {
            $query->andWhere(['in', 'site_operational_program.site_id', $filter['forceSites']]);
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'report_type_id' => $this->report_type_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'site_operational_program.name', $this->name])
        ->andFilterWhere(['like', 'client_site.name', $this->clientSite])
        ->andFilterWhere(['like', 'site.name', $this->site]);

        //echo $query->createCommand()->getRawSql(); exit;

        return $dataProvider;
    }
}
