<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/**
 * This is the model class for table "report_type".
 *
 * @property integer $id
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property SiteOperationalProgram[] $siteReports
 */
class Report extends BaseModel
{
    const REPORT_CATEGORY_OTHERS = 'Other_rc';
    const REPORT_CATEGORY_OTHERS_ID = 9999;

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    protected $maxOtherIndex = 10000; // If report type is unknown, use a unique number from 9999 decrementing
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'no-table';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Get filename from document attributes
     *
     * @param sting $rootPath
     * @param array $document
     * @param sting $clientPath
     * @return array
     */
    public function getFilename($document, $rootPath,$clientId)
    {
        $datetime = $document['date'];
        $reportType = ReportType::find()->where(['id' => $document['reportTypeId']])->one();
        $ext = strtolower($document['documentExtension']);
        $providerId = isset($document['providerId'])?$document['providerId']:"";        
        $searchTermId = isset($document['searchTermId'])?$document['searchTermId']:"";
        if (!is_null($reportType)) {
            $doctypeId = $reportType->doctype_id;
            $doctypeName = $reportType->name;
           
        } else {
            $doctypeId = 9999;
            $doctypeName = 'Others';
        }

        $s3 = Yii::$app->s3Helper;

        $plusMinutes = 0;
        $files = $s3->directoryListing($rootPath, $s3->nextcloudBucket, true, true);
        while (true) {
            $filename = $this->buildFilename($doctypeId, $datetime, $plusMinutes, $ext,$searchTermId, $providerId,$clientId);
            if (!in_array($filename, $files)) {
                break;
            }
            $plusMinutes++;
            if ($plusMinutes > 20) {
                \Yii::error('Stuck in loop trying to determine filename');
                throw new \yii\web\HttpException(500, 'LOCAL FILE SYSTEM - Stuck in loop trying to determine filename: '. $rootPath . $filename);
            }
        }

        return $filename;
    }

    /**
     * Return root and mirror paths. 
     *
     * @return array
     */
    public function getReportPaths($directory, $mirrorPath, $reportTypeId, $date)
    {
        $reportType = ReportType::find()->where(['id' => $reportTypeId])->one();

        if (!is_null($reportType)) {
            $doctypeId = $reportType->doctype_id;

            if ($doctypeId == self::REPORT_CATEGORY_OTHERS_ID) {
                $reportCategory = self::REPORT_CATEGORY_OTHERS;
                $doctypeName = 'Others';
            } else {
                $reportCategory = formatPath($reportType->reportCategory->name);
                $doctypeName = formatPath($reportType->directory);
            }
           
        } else {
            $doctypeId = self::REPORT_CATEGORY_OTHERS_ID;
            $doctypeName = 'Others';
            $reportCategory = self::REPORT_CATEGORY_OTHERS;
        }


        $rootPath = $this->getRootPath($directory, $reportCategory, $doctypeName, $date);
        $mirrorPath = $mirrorPath . $rootPath;

        return [$rootPath, $mirrorPath];
    }

    public function getRootPath($directory, $reportCategory, $doctypeName, $date)
    {
        $datePath = $this->getDatePath($date);

        return $directory .'-'. $reportCategory .'/'. $doctypeName .'/'. $datePath;
    }

    public function saveReport($document, $filename, $rootPath, $mirrorPath)
    {
        $s3 = Yii::$app->s3Helper;


        $rootFilename = $rootPath .'/'. $filename;
        $mirrorFilename = $mirrorPath .'/'. $filename;
        
        echo "=== Root file: ". $this->bucket ."/$rootFilename\n";
        echo "=== Mirror file: ". $this->bucket ."/$mirrorFilename\n";

        $timeCreatePathsEnd = time();

        $s3->saveFile($document['documentFilename'], $rootFilename, $this->bucket);
        if ($mirrorPath) { // Don't save mirror if path == false
            $s3->saveFile($document['documentFilename'], $mirrorFilename, $this->bucket);
        }
        unlink($document['documentFilename']);

        return [$rootPath, $mirrorPath, $timeCreatePathsEnd];
    }

    public function getDatePath($date)
    {
        return date('F_Y', strtotime($date));
    }

    /**
     * Build file string. 
     *
     * @param string $clientPath
     * @param string $doctypeName
     * @param string $datetime
     * @param integer $plusMinutes - Add a minute trying to find unique filename
     */
    public function buildFilename($doctypeId, $datetime, $plusMinutes, $ext,$searchTermId, $providerId,$clientId)   
    {   
        // echo " provider id : ".$providerId`;
        // echo " client id : ".$clientId;
        // echo " search term id : ".$searchTermId;
        // die;
        $time = strtotime($datetime) + 60 * $plusMinutes;   
        if($providerId != "" && $searchTermId != "" && $clientId != ""){    
            $filename = date('Ymd', $time) .'_'. date('Hi', $time) .'_'. $doctypeId.'_'. $providerId.'_'.$clientId.'.'. $ext;                   
        }elseif($providerId != "" && $searchTermId == "" && $clientId != ""){   
            $filename = date('Ymd', $time) .'_'. date('Hi', $time) .'_'. $doctypeId.'_'. $providerId.'_'.$clientId.'.'. $ext;   
        }elseif($providerId == "" && $searchTermId == "" && $clientId == ""){   
            $filename = date('Ymd', $time) .'_'. date('Hi', $time) .'_'. $doctypeId.'.'. $ext;  
        }elseif($providerId == "" && $searchTermId == "" && $clientId != ""){   
            $filename = date('Ymd', $time) .'_'. date('Hi', $time) .'_'. $doctypeId.'.'. $ext;  
        }elseif ($providerId != "" ) {
            # code...
        }

        return $filename;
    }
}
