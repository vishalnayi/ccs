<?php
namespace common\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use common\models\RightsModules;
use yii\helpers\ArrayHelper;
use common\models\User;



/**
 * User model
 *
 * @property integer $id
 * @property string $user_id
 * @property string $user_role
 * @property string $user_rights_id
 * @property string $p_field_1
 * @property string $p_field_2
 * @property string $p_field_3
 * @property string $p_field_4
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 */

class UserPermissions extends BaseModel
{
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_permissions';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'user_role', 'user_rights_id', 'p_field_1', 'p_field_2', 'p_field_3', 'p_field_4'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    public function beforeSave($insert)
    {
        $post = [];
       
        if(isset($_POST['txt_permission'])){
            $user_id = $insert['user_id'];
            $i = 0;
            
            foreach($_POST['txt_permission'] as  $kt => $permission){
                
                if($permission[2] == '1' || $permission[3] == '1' || $permission[4]== '1'){
                    $permission[1] = '1';
                }
              
                $post[$i]['user_id'] = $user_id;
               
                $post[$i]['user_rights_id'] = $kt;
                $post[$i]['p_field_1'] = $permission[1];
                $post[$i]['p_field_2'] = $permission[2];
                $post[$i]['p_field_3'] = $permission[3];
                $post[$i]['p_field_4'] = $permission[4];
                $post[$i]['status'] = '1';

                $i++;               
            }
           
        }
        // echo "<pre>";
        // print_r($post);
        // die;
        //parent::beforeSave($insert);
        return parent::beforeSave($post);
        //return true;
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getModuledata()
    {
        return $this->hasOne(RightsModules::className(), ['id' => 'user_rights_id']);
    }
    
    /*public function attributeLabels()
    {
        return [
            'password_hash' => 'Password',
        ];
    }*/
}
