<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\TertiaryAlarm;

/**
 * SiteOperationalProgramSearch represents the model behind the search form about `common\models\SiteOperationalProgram`.
 */
class TertiaryAlarmSearch extends TertiaryAlarm
{
    public $clientSite;
    public $site;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'site_id', 'report_type_id', 'created_at', 'updated_at'], 'integer'],
            [['name','clientSite','reportType','site'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params, $filter=null)
    {
        $query = TertiaryAlarm::find();

        $query->joinWith(['clientSite', 'site']);
        $query->where(['site_operational_program.primary_alarm' => 1,'site_operational_program.secondary_alarm' => 1]);
        
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

// echo "<pre>";print_r($dataProvider);exit;
        $dataProvider->sort->attributes['client_site'] = [
            'asc' => ['client_site.name' => SORT_ASC],
            'desc' => ['client_site.name' => SORT_DESC],
        ];

        $dataProvider->sort->attributes['site'] = [
            'asc' => ['site.name' => SORT_ASC],
            'desc' => ['site.name' => SORT_DESC],
            'label' => 'Site Yeah',
            'asdada' => '',
        ];

        $this->load($params);

        if (!$this->validate()) {
            return $this->getErrors();
            return $dataProvider;
        }

        if(isset($filter['clientId'])) {
            $query->andWhere('client_site.client_id=:clientId', [
                                    ':clientId' => $filter['clientId'],
            ]);

        }

        $query->andFilterWhere([
            'id' => $this->id,
            'report_type_id' => $this->report_type_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'site_operational_program.name', $this->name])
        ->andFilterWhere(['like', 'client_site.name', $this->clientSite])
        ->andFilterWhere(['like', 'site.name', $this->site]);

        return $dataProvider;
    }
}
