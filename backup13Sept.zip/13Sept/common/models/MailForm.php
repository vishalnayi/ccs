<?php
namespace common\models;

use yii\base\Model;

/**
 * UploadForm is the model behind the upload form.
 */
class MailForm extends Model
{
    /**
     * @var UploadedFile file attribute
     */
    public $clientId;
    public $email;
    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['clientId'], 'required'],
            [ ['email', 'email'],'required'],           
        ];
    }
}
