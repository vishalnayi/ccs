<?php
namespace common\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use common\models\RightsModules;
use yii\helpers\ArrayHelper;
use common\models\User;
//use common\models\ClientSite;




/**
 * User model
 *
 * @property integer $id
 * @property string $user_id
 * @property string $user_role
 * @property string $user_rights_id
 * @property string $p_field_1
 * @property string $p_field_2
 * @property string $p_field_3
 * @property string $p_field_4
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 */

class UserSiteAccess extends BaseModel
{
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_site_access';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'site_id'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    public function beforeSave($insert)
    {       
        return parent::beforeSave($insert);
        //return true;
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getClientSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }
    
    /*public function attributeLabels()
    {
        return [
            'password_hash' => 'Password',
        ];
    }*/
}
