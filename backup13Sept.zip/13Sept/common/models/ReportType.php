<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/**
 * This is the model class for table "report_type".
 *
 * @property integer $id
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property SiteOperationalProgram[] $siteReports
 */
class ReportType extends BaseModel
{
    const DOCTYPE_PDF = 1;
    const DOCTYPE_DOC = 2;
    const DOCTYPE_XLS = 3;
    const DOCTYPE_JPG = 4;

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'report_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'report_category_id', 'directory', 'doctype_id'], 'required'],
            [['report_category_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['directory'], 'match', 'pattern' => '/^[a-z0-9_]*$/', 'message' => 'Chars must belimited to lowercase a-z, 0-9 and `_`'],
            [['doctype_id', 'directory'], 'unique'],

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSiteReports()
    {
        return $this->hasMany(SiteOperationalProgram::className(), ['report_type_id' => 'id']);
    }

    public function getReportCategory()
    {
		return $this->hasOne(ReportCategory::className(), ['id' => 'report_category_id']);
    }

    public static function getReportTypes()
    {
        return ArrayHelper::map(ReportType::find()->all(), 'id', 'name');
    }

    public static function getReportType($type)
    {
        return self::getReportTypes()[$type];
    }

    public static function getReportTypeByDoctype($clientId, $type)
    {
        return self::GetReportTypesByDoctype($clientId)[$type];
    }

    public function findReportType($document, $searchTerms)
    {
        $typeWeight = 0; // Keep track of highest weight found
        $termsFound = [];
        $reportTypeId = 0;
        $docTypeId = self::getDocTypeId($document['documentExtension']);

        $reportHelper = Yii::$app->reportHelper;
        $documentRetriever = \Yii::$app->documentRetriever;
        $document['section'] = [];

        foreach ($searchTerms as $searchTerm) {
            if ($searchTerm->doctype_id != $docTypeId) {
                continue;
            }
            
            if ($searchTerm->search_subject == 1) {
		        $document['subjectFormatted'] = $document['subject'];
                if (preg_match('/'. strtolower($searchTerm->search_term) .'/', strtolower($document['subject']))) {
                    $termsFound[DocumentSearchTerm::SUBJECT] = $searchTerm;
                    $document['subjectFormatted'] = $this->buildTermString($document['subject'], $searchTerm);
                    if ($searchTerm->weight > $typeWeight) {
                        $reportTypeId = $searchTerm->report_type_id;
                        $providerId = $searchTerm->provider_id;
                        $searchTermId = $searchTerm->id;
                        $typeWeight = $searchTerm->weight;
                    }
                }
            }

            if ($searchTerm->search_message_html == 1) {
                if (preg_match('/'. strtolower($searchTerm->search_term) .'/', strtolower($document['messageHtml']))) {
                    $termsFound[DocumentSearchTerm::MESSAGE_HTML] = $searchTerm->search_term;
                    $document['messageHtml'] = $this->buildTermString($document['messageHtml'], $searchTerm);
                    if ($searchTerm->weight > $typeWeight) {
                        $reportTypeId = $searchTerm->report_type_id;
                        $providerId = $searchTerm->provider_id;
                        $searchTermId = $searchTerm->id;
                        $typeWeight = $searchTerm->weight;
                    }
                }
            }

            if ($searchTerm->search_document_text == 1) {
		        $document['documentTextFormatted'] = $document['documentText'];
                if (preg_match('/'. $searchTerm->search_term .'/', $document['documentText'])) {
                    $termsFound[DocumentSearchTerm::DOCUMENT_TEXT] = $searchTerm->search_term;
                    $document['documentTextFormatted'] = $this->buildTermString($document['documentText'], $searchTerm, true);
                    if ($searchTerm->weight > $typeWeight) {
                        $reportTypeId = $searchTerm->report_type_id;
                        $providerId = $searchTerm->provider_id;
                        $searchTermId = $searchTerm->id;
                        $typeWeight = $searchTerm->weight;
                    }
                }
            }

            /*echo "<pre>";print_r($searchTerm);*/

            if ($searchTerm->search_section == 1) {
                list($croppedFile, $logFile) = $reportHelper->readSectionOfDocument($document['documentImagePath'],$searchTerm,$document['documentExtension']);
                $croppedDocumentText = $documentRetriever->extractTextFromImage($croppedFile);
                unlink($croppedFile);
                $document['croppedLogFile'] = $logFile;
                if (preg_match('/'. strtolower($searchTerm->search_term) .'/', strtolower($croppedDocumentText))) {
                    $termsFound[DocumentSearchTerm::DOCUMENT_CROPPED_DOCUMENT_TEXT] = $searchTerm->search_term;
                    $croppedDocumentText = $this->buildTermString($croppedDocumentText, $searchTerm, true);
                    if ($searchTerm->weight > $typeWeight) {
                        $reportTypeId = $searchTerm->report_type_id;
                        $providerId = $searchTerm->provider_id;
                        $searchTermId = $searchTerm->id;
                        $typeWeight = $searchTerm->weight;
                    }
                }
                $document['section'][] = ['croppedDocumentText' => $croppedDocumentText,
                                          'croppedLogFile' => $logFile,
                ];
            }
        }

        $document['reportTypeId'] = $reportTypeId;
         $document['providerId'] = isset($providerId)?$providerId:"";
        $document['searchTermId'] = isset($searchTermId)?$searchTermId:"";
        
        return $document;
    }

    protected function buildTermString($string, $term, $paragraph=false)
    {
        $string = $this->cleanseHTML($string);

        if ($paragraph) {
            $string = \Yii::$app->formatter->asParagraphs($string);
        }

        $span = '<span data-html="true" class="found-search-term" rel="tooltip" data-delay=\'{"show": 0, "hide": 1500 }\' title="' .
            '<table>' .
            '<tr><th>Report Category:</th><td>'. $term->reportCategory->name .'</td></tr>' .
            '<tr><th>Provider:</th><td>'. $term->provider->name .'</td></tr>' .
            '<tr><th>Report type:</th><td>'. $term->reportType->name .'</td></tr>' .
            '<tr><th>Search term:</th><td>'. $term->search_term .'</td></tr>' .
            "<tr><td><a href='/document-search-term/update?id=". $term->id ."' target='_blank'>Update term</a></td></tr>" .
            '</table>">'. $term->search_term .'</span>';
        $string = str_replace($term->search_term, $span, $string);

		return $string;
    }

    protected function cleanseHtml($html)
    {
        $html = str_replace('<script', '<disablescript', $html);
        $html = str_replace('<style', '<disablestyle', $html);

        return $html;
    }

    static public function getDocType($type)
    {
        return self::getDocTypes()[$type] ?? false;
    }

    public function getDocTypes()
    {
        return [
            self::DOCTYPE_PDF => 'pdf',
            self::DOCTYPE_DOC => 'doc',
            self::DOCTYPE_XLS => 'xls',
            self::DOCTYPE_JPG => 'jpg',
        ];
    }

    static function getDocTypeId($extension)
    {
        return self::getDocTypeIds()[$extension] ?? false;
    }

    static public function getDocTypeIds()
    {
        return [
            'pdf' => self::DOCTYPE_PDF,
            'doc' => self::DOCTYPE_DOC,
            'xls' => self::DOCTYPE_XLS,
            'jpg' => self::DOCTYPE_JPG,
        ];
    }

    public function findReportTypeFromFilename($filename)
    {
        $filename = substr($filename, 0, strrpos($filename, '.'));
        $attrs = explode('_', $filename);
        $typeId = $attrs[2];

        $type = ReportType::find()->where(['doctype_id' => $typeId])->one();

        return $type;
    }
}
