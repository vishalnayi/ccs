<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "report_category".
 *
 * @property integer $id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class ReportCategory extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'report_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [[], 'safe'],
            [['name'], 'string', 'max' => 255],
            ['name', 'match', 'pattern' => '/^[a-z0-9_]+$/i', 
                'message' => 'Name limited to \'a-z0-9_\''],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getPath()
    {
        $path = strtolower($this->name);
        $path = str_replace(' ', '_', $path);

        return $path;
    }
}
