<?php
namespace common\models;

use yii\base\Model;
/**
 * ClientListForm is the model for dropdown box for Client selection.
 */
class ContactListForm extends Model
{
    /**
     * @var UploadedFile file attribute
     */
    public $company_name;
    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['company_name'], 'required'],            
        ];
    }
}
