<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use common\behaviors\CustomTimestampBehavior;

class BaseModel extends \yii\db\ActiveRecord
{
    public function behaviors()
    {
        return ArrayHelper::merge([
            CustomTimestampBehavior::className(),
        ], parent::behaviors());
    }

    public function convertTimeToStr($time)
    {
        return date('d/m/Y', $time);
    }
}
