<?php

namespace common\models;

use Yii;
use common\models\BaseModel;
use yii\behaviors\TimestampBehavior;
use common\components\CustomTimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "client".
 *
 * @property integer $id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User[] $users
 */
class Client extends BaseModel
{
    public $nodeList = [];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'client';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'string', 'length' => [3,255]],
            [['name'], 'required'],
            ['name', 'match', 'pattern' => '/^[ a-z0-9_-]+$/i', 
            'message' => 'Name limited to \'a-z 0-9 -_\' (no quotes)'],
            [['client_id'], 'safe'],
            [['img_url'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'img_url'=>'Logo',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::className(), ['client_id' => 'id']);
    }

    public function getAdminUsers()
    {
        return $this->hasMany(User::className(), ['client_id' => 'id',
        ])->where(['role' => User::ROLE_ADMIN]);
    }

    public function buildNodeList($parentId=0, $parentPath='/')
    {
        $nodes = Node::find()->where(['client_id' => $this->id,
                                      'parent_id' => $parentId,
        ])->all();

        foreach($nodes as $node) {
            $path = $parentPath . $node->name;
            $this->nodeList[$node->id] = 
                ['name' => $node->name,
                 'node_id' => $node->id,
                 'path' => $path,
                 'parent_id' => $node->parent_id,
            ];
            $this->buildNodeList($node->id, $path .'/');
        }

        return $this->nodeList;
    }

    public function buildClientSiteList($nodes, $client)
    {
        $clientSiteList = [];

        foreach($nodes as $node) {
            $clientSites = ClientSite::find()->where([
                'node_id' => $node['node_id'],
            ])
            ->all();
            foreach($clientSites as $site) {
                $clientSiteList[$site->id] = [
                    'site_id' => $site->id,
                    'site_name' => $site->name,
                    'site_directory' => $site->directory,
                    'path' => $node['path'] .'/'. $site->name,
                ];
            }
        }

        $clientSites = ClientSite::find()->where([
                    'node_id' => 0,
                    'client_id' => $client->id, 
        ])->all();

        foreach($clientSites as $site) {
            $clientSiteList[$site->id] = [
                'site_id' => $site->id,
                'site_name' => $site->name,
                'site_directory' => $site->directory,
                'path' => '/'. $client->name .'/'. $site->name,
            ];
        }
    
        return $clientSiteList;
    }

    /*public function sendAlert($body,$emailArray)
    {
        Yii::$app->mail->compose('//mail/alert', ['body' => $body])
                 ->setFrom(Yii::$app->params['adminEmail'])
                 ->setTo(Yii::$app->params['supportEmail'])
                 ->setSubject('RMP Systems - Report Alert')
                 ->send();
                 
        foreach ($emailArray as $email) {
            if(!empty($email)) {
                Yii::$app->mail->compose('//mail/alert', ['body' => $body])
                     ->setFrom(Yii::$app->params['adminEmail'])
                     ->setTo($email)
                     ->setSubject('RMP Systems - Report Alert')
                     ->send();
            }
        }
    }*/

    public function sendAlert($body,$emailArray)
    {
        /*Yii::$app->mail->compose('//mail/alert', ['body' => $body])
                 ->setFrom(Yii::$app->params['adminEmail'])
                 ->setTo(Yii::$app->params['supportEmail'])
                 ->setSubject('RMP Systems - Report Alert')
                 ->send();*/
        $curl = curl_init();
        echo $to_email=Yii::$app->params['supportEmail'];
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$to_email,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('message' => $body,'subject' => 'RMP Systems - Report Alert'),
        ));

        $response = curl_exec($curl);
        echo $response;
        /*echo $response;exit;*/
        curl_close($curl);
                 
        foreach ($emailArray as $email) {
            if(!empty($email)) {
                echo $email.'<br>';
                /*Yii::$app->mail->compose('//mail/alert', ['body' => $body])
                     ->setFrom(Yii::$app->params['adminEmail'])
                     ->setTo($email)
                     ->setSubject('RMP Systems - Report Alert')
                     ->send();*/
                $curl = curl_init();
                $to_email=$email;
                curl_setopt_array($curl, array(
                  CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$to_email,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_POSTFIELDS => array('message' => $body,'subject' => 'RMP Systems - Report Alert'),
                ));

                $response = curl_exec($curl);
                echo $response;
                /*echo $response;exit;*/
                curl_close($curl);
            }
        }
    }

    public function sendPdfAlert($body,$pathToPdfFile,$to_email,$clientId,$FromDate,$toDate)
    {
        /*echo $pathToPdfFile;exit;*/
        Yii::$app->mail->compose('//mail/monthly_pdf_alert', ['body' => $body,'clientId'=>$clientId,'FromDate'=>$FromDate,'toDate'=>$toDate])
                 ->setFrom([Yii::$app->params['adminEmail']=>'Clean Cloud System'])
                 ->setTo($to_email)
                 ->setSubject('Clean Cloud System Report')
                 ->attachContent($pathToPdfFile, [
                        'fileName'    => 'Report.pdf',
                        'contentType' => 'application/pdf'
                    ])
                 ->send();
        
        /*$curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$to_email,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('message' => $body,'subject' => 'Clean Cloud System Report','pathToPdfFile'=>$pathToPdfFile,'fileName'=>'Report.pdf'),
        ));

        $response = curl_exec($curl);
        curl_close($curl);*/
    }

    public function sendPdfAlertCurl($body,$pathToPdfFile,$to_email,$clientId,$FromDate,$toDate)
    {
        /*echo $pathToPdfFile;exit;*/
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$to_email,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('message' => $body,'subject' => 'Clean Cloud System Report','pathToPdfFile'=>$pathToPdfFile,'fileName'=>'Report.pdf'),
        ));

        $response = curl_exec($curl);
        /*echo $response;exit;*/
        curl_close($curl);
    }

    public function sendAlertCurl($body,$to_email)
    {
        /*echo $pathToPdfFile;exit;*/
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$to_email,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('message' => $body,'subject' => 'Clean Cloud System Report'),
        ));

        $response = curl_exec($curl);
        /*echo $response;exit;*/
        curl_close($curl);
    }

     public function sendMonthlyPdfAlert($body,$pathToPdfFile,$to_email,$FromDate,$toDate,$subject,$fname)
    {
        Yii::$app->mail->compose(['html' => 'monthlyReport-html', 'text' => 'monthlyReport-text'], ['body' => $body,'FromDate'=>$FromDate,'toDate'=>$toDate])
                 ->setFrom([Yii::$app->params['adminEmail']=>'Clean Cloud System'])
                 ->setTo($to_email)
                 ->setSubject($subject)
                 //->setFromName('Clean Cloud System Report')
                 ->attachContent($pathToPdfFile, [
                        'fileName'    => $fname,
                        'contentType' => 'application/pdf'
                    ])
                 ->send();
    }

     public function sendMonthlyCsvAlert($body,$pathToPdfFile,$to_email,$FromDate,$toDate,$subject,$fname)
    {
        Yii::$app->mail->compose(['html' => 'monthlyReport-html', 'text' => 'monthlyReport-text'], ['body' => $body,'FromDate'=>$FromDate,'toDate'=>$toDate])
                 ->setFrom([Yii::$app->params['adminEmail']=>'Clean Cloud System'])
                 ->setTo($to_email)
                 ->setSubject($subject)
                 //->setFromName('Clean Cloud System Report')
                 ->attachContent($pathToPdfFile, [
                        'fileName'    => $fname,
                        'contentType' => 'application/csv'
                    ])
                 ->send();
    }

}
