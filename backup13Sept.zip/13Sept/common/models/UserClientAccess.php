<?php
namespace common\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use common\models\RightsModules;
use yii\helpers\ArrayHelper;
use common\models\User;

class UserClientAccess extends BaseModel
{
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_client_access';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'client_id'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    public function beforeSave($insert)
    {       
        return parent::beforeSave($insert);
        //return true;
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }
    
    /*public function attributeLabels()
    {
        return [
            'password_hash' => 'Password',
        ];
    }*/
}
