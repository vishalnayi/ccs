<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "report_frequency".
 *
 * @property integer $id
 * @property string $name
 * @property string $time_period
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property SiteOperationalProgram[] $siteReports
 */
class ReportFrequency extends BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'report_frequency';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'time_period', 'created_at', 'updated_at'], 'required'],
            [['name', 'time_period'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'time_period' => 'Time Period',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSiteReports()
    {
        return $this->hasMany(SiteOperationalProgram::className(), ['report_frequency_id' => 'id']);
    }
}
