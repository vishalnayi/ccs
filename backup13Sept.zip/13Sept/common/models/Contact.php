<?php

namespace common\models;

use Yii;
use yii\base\DynamicModel;
/**
 * This is the model class for table "contacts".
 *
 * @property integer $id
 * @property integer $report_category_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class Contact extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'contacts';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id','postcode'], 'integer'],
           // ['phone','match', 'pattern' => '\(?\+[0-9]{1,3}\)? ?-?[0-9]{1,3} ?-?[0-9]{3,5} ?-?[0-9]{4}( ?-?[0-9]{3})?','message'=>"Please enter valid phone number"],
         /*['mobile','match', 'pattern' => '/^\+[0-9]{2}\s[0-9]{3}\s[0-9]{3}\s[0-9]{3}$/','message'=>"Please enter valid mobile number"],
         ['phone','match', 'pattern' => '/^\+[0-9]{2}\s[0-9]{2}\s[0-9]{4}\s[0-9]{4}$/','message'=>"Please enter valid phone number"],*/
           // ['phone','match', 'pattern' => '/^(?:00|\+)[0-9]{4}-?[0-9]{7}$/m','message'=>"Pppplease enter valid phone number"],
            //['phone','match', 'pattern' => '/^(?:00|\+)[0-9]{4}-?[0-9]{7}$/'],
            [['name','job_title','street','suburb','state','phone','mobile','website','comment','company_name'], 'string'],
            [['email'], 'email'],
            [['email'], 'unique', 'message' => 'The email address already exists'],            
            [['name','job_title','street','email','phone'], 'required'],
            [['is_distributor'], 'required'],

            [['created_at','updated_at'],'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),         
            'is_distributor' => Yii::t('app', 'is_distributor'),    
            'name' => Yii::t('app', 'Name'),
            'job_title' => Yii::t('app', 'Job Title'),
            'company_name' => Yii::t('app', 'Company Name'),
            'street' => Yii::t('app', 'Street'),
            'suburb' => Yii::t('app', 'City'),
            'state' => Yii::t('app', 'State'),
            'phone' => Yii::t('app', 'Phone'),
            'mobile' => Yii::t('app', 'Mobile'),
            'email' => Yii::t('app', 'Email'),
            'website' => Yii::t('app', 'Website'),
            'comment' => Yii::t('app', 'Comment'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getSites()
    {
        return $this->hasMany(SiteContact::className(), ['contact_id' => 'id']);
    }
    public function getCompanies()
    {
        return $this->hasOne(Companies::className(), ['id' => 'company_name']);
    }

    public function getClientsContact()
    {
        return $this->hasMany(ClientContact::className(), ['contact_id' => 'id']);
    }

    public function getSupplier()
    {
        return $this->hasMany(SupplierContact::className(), ['contact_id' => 'id']);
    }

    public static function getDynamicClientModel()
    {
        $model = DynamicModel::validateData(['client_id','site_id','supplier_id']);                        
        $model->addRule(['client_id','site_id','supplier_id'], 'required'); 
        return $model;
    }

   
}
