<?php
namespace common\models;

use Yii;
use yii\base\Model;

/**
 * Login form
 */
class OtpForm extends Model
{
    public $username;
    public $password;
    //public $otp;
    public $rememberMe = true;

    private $_user;


    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // username and password are both required
            [['username', 'password'], 'required'],
            // rememberMe must be a boolean value
            ['rememberMe', 'boolean'],
            // password is validated by validatePassword()
            ['password', 'validatePassword'],
            ['otp', 'validateOTP'],
        ];
    }

    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            if (!$user || !$user->validatePassword($this->password)) {
                $this->addError($attribute, 'Incorrect username or password.');
            }
        }
    }

    public function validateOTP($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            /*print_r($user);
            echo $this->otp;exit;*/
            if ($this->otp!=$user->otp) {
                //echo "string";
                 $this->addError($attribute, 'Incorrect otp.');
            }
            /*if (!$user || !$user->validateOTP($this->otp)) {
                $this->addError($attribute, 'Incorrect otp.');
            }*/
        }
    }

    /**
     * Logs in a user using the provided username and password.
     *
     * @return boolean whether the user is logged in successfully
     */
    /*public function login()
    {
        if ($this->validate()) {
            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 0);
        } else {
            return false;
        }
    }*/
    public function login()
    {
        if ($this->validate()) {
        /*echo "string";exit;*/
        
            return true;
            /*$user=$this->getUser();
            
            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 0);*/
        } else {
            return false;
        }
    }

    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    protected function getUser()
    {
        if ($this->_user === null) {
            $this->_user = User::findByUsername($this->username);
        }

        return $this->_user;
    }
    

    public function sendEmail1($user)
    {

        if ($user) {
                $otp=rand('1111','9999');
                Yii::$app->db->createCommand('UPDATE user SET otp='.$otp.' WHERE id='.$user->id.' ')->execute();
                               // die('ahi aave');
            
                return Yii::$app->mail->compose(['html' => 'verifyOTP-html', 'text' => 'verifyOTP-text'], ['user' => $user,'otp'=>$otp])
                     ->setFrom([Yii::$app->params['adminEmail']=>'CleanCloudSystems Verification Code'])
                     ->setTo($user->email)
                     ->setSubject('CleanCloudSystems Verification Code')
                     ->send();
        }else {
            return false;
        }
    }

    public function sendEmail($user)
    {

        if ($user) {
            $otp=rand('1111','9999');
            Yii::$app->db->createCommand('UPDATE user SET otp='.$otp.' WHERE id='.$user->id.' ')->execute();
            $html='<div class="password-reset"><p>Hello '.$user->username.',</p><p>Your Verification code is '.$otp.'.</p><p>Thanks</p></div>';
            $subject='CleanCloudSystems Verification Code';
            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => 'http://vrinsoft.in/mailer/mail.php?to='.$user->email,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => array('message' => $html,'subject' => $subject),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
        }else {
            return false;
        }

        //return false;
    }
}
