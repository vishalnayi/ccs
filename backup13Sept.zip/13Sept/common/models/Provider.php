<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "provider".
 *
 * @property integer $id
 * @property integer $report_category_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class Provider extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'provider';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['report_category_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['name', 'report_category_id'], 'required'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'report_category_id' => Yii::t('app', 'Report Category ID'),
            'name' => Yii::t('app', 'Name'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getReportCategory()
    {
		return $this->hasOne(ReportCategory::className(), ['id' => 'report_category_id']);
    }
}
