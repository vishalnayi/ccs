<?php

namespace common\models;

use Yii;
use yii\base\DynamicModel;

/**
 * This is the model class for table "site_report".
 *
 * @property integer $id
 * @property integer $site_id
 * @property integer $report_type_id
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property ReportType $reportType
 * @property ReportFrequency $reportFrequency
 */
class SecondaryAlarm extends BaseModel
{
    const STATUS_ONTIME = 'on-time';
    const STATUS_TOLERANCE = 'tolerance';
    const STATUS_LATE = 'late';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'site_operational_program';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['site_id', 'report_type_id', 'secondary_interval_id', 'name','secondary_alarm'], 'required'],
            [['site_id', 'report_type_id', 'secondary_interval_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['additional_emails_secondary'], 'string']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'site_id' => 'Site',
            'report_type_id' => 'Report Type',
            'secondary_interval_id' => 'Interval Duration (In Days)',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'additional_emails_secondary'=>'Additional Emails',
        ];
    }

    public function getSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    public function getClientSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReportType()
    {
        return $this->hasOne(ReportType::className(), ['id' => 'report_type_id']);
    }

    public function getReportInterval()
    {
        return $this->hasOne(ReportInterval::className(), ['id' => 'secondary_interval_id']);
    }

    public static function getNodeReports($clientId, $siteId)
    {
        $reportList = [];

        $reports = SiteOperationalProgram::find()->where(['site_id' => $siteId])->all();
        foreach($reports as $report) {
            $reportList[] = ['id' => $report->id .'_report',
                           'text' => $report->name,
                           'icon' => '/img/pdf.png',
                           'children' => false,
            ];
        }

        return $reportList;
    }

    public function searchSiteDirectory($clientId, $parent, $reportCategory)
    {
        $list = [];

        $siteId = $parent['id'];
        $path = $parent['path'];
        $catId = $parent['catId'];
        $reportCategoryId = $reportCategory ? $reportCategory->id : 0;

        $site = ClientSite::findOne($siteId);

        $s3 = Yii::$app->s3Helper;
        $reportCategoryPath = $reportCategory ? $reportCategory->path : Report::REPORT_CATEGORY_OTHERS;
        $directory = $site->directory .'-'. $reportCategoryPath;
        $files = $s3->directoryListing($directory . $path, $this->bucket, true);

        foreach ($files as $file) {
            if(preg_match('/\.((pdf)|(xls)|(doc))$/i', $file)) {
                $filePath = $directory . $path .'/'. $file;
                $directoryPath = $directory . $path;
                $fileAttr = self::getReportAttributes($file);
                $link = '/document/move-document?Document[site_id]='. $siteId .
                        '&Document[existing_path]='. $directoryPath .
                        '&Document[existing_filename]='. $file;
                $title = '<h3>'. $file .'</h3><p><a href="'. $link .'">Rename/move</a></p>';
                $list[$fileAttr['8601'] . $file] = ['id' => $file,
                                    'text' => $file,
                                    'icon' => '/img/'. $fileAttr['file_extension'] .'.png',
                                    'children' => false,
                                    'a_attr' => ['href' => '/site-operational-program/load-file?document='. $filePath .'&filename='. $file,
                                                 'target' => '_blank',
                                                 'title' => $title,
                                                 'rel' => 'tooltip',
                                                 'data-html' => true,
                                                 'data-delay' => '{"show": 0, "hide": 2500 }',
                                    ],
                ];
            } else {
                $list[] = ['id' => 'site|'. $siteId .'|cat|'. $reportCategoryId .'|'. $path .'/'. $file,
                           'text' => $file,
                           'icon' => '/img/dir.png',  
                           'children' => true,
                ];
                // TODO: Children is not true on Ben's version. may have issues at another time if deploying.
            }
        }

        ksort($list);
        $list = self::removeKeys($list);

        return $list;
    }

    /**
     * Check if path has any directories within
     */
    protected function checkForContents($folder)
    {
        $dh = opendir($folder);
        while (($path = readdir($dh)) !== false) {
            if($path !== '.' && $path != '..') {
                return true;
            }

            return false;
        }
    }

    public static function removeKeys($list)
    {
        $newList = [];

        foreach($list as $key=>$value) {
            $newList[] = $value;
        }

        return $newList;
    }

    public static function getReportAttributes($filename)
    {
        $file = explode('_', $filename);

        if(count($file) !== 3) {
            return false;
        }

        $ext = substr($filename, strrpos($filename, '.')+1, strlen($filename));
        \Yii::error('filename: '. $filename);
        \Yii::error('extension: '. $ext);

        return [
                '8601' => $file[0] . $file[1],
                'date' => $file[0],
                'time' => $file[1],
                'report_id' => $file[2],
                'file_extension' => $ext,
        ];
    }

    public function formatDateTo8601($date, $time)
    {
        list($year, $month, $day, $time) = [
            substr($date, 4, 4),
            substr($date, 2, 2),
            substr($date, 0, 2),
            $time,
        ];

        return $year . $month . $day . $time;
    }

    public static function trimFilename($file)
    {
        $file = substr($file, strrpos($file, '/')+1);
        $file = substr($file, 0, strrpos($file, '.'));
        if(strpos($file, '(')) {
            $file = substr($file, 0, strrpos($file, '('));
        }

        return $file;
    }

    public static function getReportFormModel()
    {
        $model = DynamicModel::validateData(
                    ['date_from',
                     'date_to',
                     'client_site',
                     'node',
                     'report_types',
        ]);
        $model->addRule(['client_site','node'], 'integer');
        $model->addRule(['report_types'], 'required');
        $model->addRule(['date_from','date_to'], 'string');
        $model->addRule(['client_site'], function($attribute, $params) use($model) {
            if(!empty($model->client_site) && !empty($model->node)) {
                $model->addError($attribute, 'You cannot select both Client and Node');
            }
        });

        return $model;
    }


    /**
     * Find reports from S3 bucket for given path
     */
    public function findS3Reports($reportTypes, $clientSite, $dateRange)
    {
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterDocs($files)
    {
        $fileList = [];

        $docTypes = ['pdf', 'doc', 'xls'];

        foreach ($files as $file) {
            $ext = getFileExtension($file);
            if (in_array($ext, $docTypes)) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterForDocType($files, $docType)
    {
        $fileList = [];

        foreach ($files as $file) {
            if (preg_match("/${docType}/", $file) == 1) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Find files from local file system
     * @todo: This method can be removed once we're satisfied the call to s3 is working as required.
     */
    public function findReports($reportTypes, $clientSite, $dateRange)
    {
        $files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $clientSite->directory ." -iname '*.pdf' -or -iname '*.doc' -or -iname '*.xls'");
        $files = explode("\n", $files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }

    public function splitPath($file)
    {
        $path = substr($file, 0, strrpos($file, '/'));
        $filename = substr($file, strrpos($file, '/')+1);

        return [$path, $filename];
    }

    protected function filterFiles($reportTypes, $files, $clientSite, $dateRange)
    {
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            list($path, $name) = $this->splitPath($file);

            // Only add report if it belongs to a selected report type
            if(!array_key_exists($fileAttr['report_id'], $reportTypes)) {
                continue;
            }

            if(!$this->isWithinDates($fileAttr, $dateRange)) {
                continue;
            }

            $reportTypes[$fileAttr['report_id']]['reports'][$fileAttr['8601'].$fileShort] = 
                        array_merge($fileAttr, [
                            'string' => $fileShort,
                            'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                            'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                            'filePath' => $file,
                            'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                            'filename' => $name,
                            'path' => $path,
                            'clientSiteId' => $clientSite->id,
                        ]);
        }

        $reportTypes = $this->orderReportTypes($reportTypes);
        if (isset($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
            $reportTypes = $this->retrieveStatusData($clientSite->client_id, $reportTypes);
        }

        return $reportTypes;
    }

    public function buildOthersReportType($clientSite)
    {
        return [
                'name' => 'Others',
                'clientSite' => $clientSite->attributes,
                'reportInterval' => [
                    'id' => 1,
                    'name' => '',
                    'interval_length' => 'len',
                    'tolerance' => 'toler',
                ],
        ];
    }

    protected function retrieveStatusData($clientId, $reportTypes)
    {
        $reportTypesWithStatus = $reportTypes;

        foreach($reportTypes as $key=>$type) {

            $reportInfo = [self::STATUS_ONTIME => 0,
                           self::STATUS_TOLERANCE => 0,
                           self::STATUS_LATE => 0,
                           'total' => 0,
            ];

            $reportTypesWithStatus[$key]['statuses'] = [
                         'last_report_due' => '--2',
                         'last_report_class' => '--3',
                         'percentages' => '--p',
                         'status_bar' => ['status_string' => '', 'status_class' => ''],
            ];

            if(!isset($type['reports'])) {
                $reportTypesWithStatus[$key]['reports'] = [];
                continue;
            }
            foreach($type['reports'] as $report) {

                if(!isset($lastReportDate)) {
                    $lastReportDate = $report['date'];
                    $firstReport = true;
                }

                $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                $report['info'] = $statuses['info'];
                if (!isset($statuses['increment'])) dd($report);
                $reportInfo[$statuses['increment']]++;
                $reportInfo['total']++;
                $newReports[$report['date-8601']] = $report;
                $lastReportDate = $report['date'];
                $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentages($reportInfo);
                $firstReport = false;
            }
            if ($report['report_id'] != '9999') {
                $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
            }
            $reportTypesWithStatus[$key]['reports'] = $newReports;

            unset($newReports);
            unset($lastReportDate);
        }

        return $reportTypesWithStatus;
    }

    protected function buildReportPercentages($info)
    {
        if($info['total'] == 0) {
            return 'no totals to calculate';
        }

        $ontime = number_format($info[self::STATUS_ONTIME] / $info['total'] *100, 2);
        $tolerance = number_format($info[self::STATUS_TOLERANCE] / $info['total'] *100, 2);
        $late = number_format($info[self::STATUS_LATE] / $info['total'] *100, 2);

        return 'Ontime: '. $ontime .'%; Tolerance: '. $tolerance .'%; Late: '. $late .'%';
    }

    protected function buildReportStatusBarString($statuses, $tolerance)
    {
        $toleranceTime = strtotime('+'. $tolerance, $statuses['next_report_due']);
        if($statuses['next_report_due'] > time()) {
            $statusClass = self::STATUS_ONTIME; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        } elseif($toleranceTime < time()) {
            $statusClass = self::STATUS_LATE; 
            $statusString = 'Last report on '. date('j/m/Y', $statuses['next_report_due']) .' overdue';
        } else {
            $statusClass = self::STATUS_TOLERANCE; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        }

        return [
            'status_string' => $statusString,
            'status_class' => 'status-'. $statusClass,
        ];
    }

    /**
     * Determine if report is late
     *
     * @param string $report shortend filename
     * @param ReportInterval $interval
     * 
     * @return string
     */
    protected function determineIfLate($report, $interval)
    {
        $date = $this->convertDateFromFileFormat($report['date']);
        $time = $this->convertTimeFromFileFormat($report['time']);
        $reportDate = strtotime($date .' '. $time);
        $reportDueDate = strtotime('+'. $interval->interval_length, $reportDate);
        $toleranceDate = strtotime('+'. $interval->tolerance, $reportDueDate);
        $now = time();
        if($reportDueDate > $now) {
            $status = self::STATUS_ONTIME;
        } elseif($toleranceDate > $now) {
            $status = self::STATUS_TOLERANCE;
        } else {
            $status = self::STATUS_LATE;
        }

        return ['status' => $status,
                'reportDate' => $this->convertTimeToStr($reportDate),
                'dueDate' => $this->convertTimeToStr($reportDueDate),
                'toleranceDate' => $this->convertTimeToStr($toleranceDate),
        ];
    }

    protected function getReportStatus($report, $type, $lastReportDate, $firstReport)
    {

        $attrs = self::getReportAttributes($report['string']);
        if ($attrs['report_id'] == '9999') {
            $status = 'N/A';    
            $delta = '';
            $increment = 'on-time';
            $reportDueDate = '';
            $nextReportDueDate = '';
        } else {
            $reportDate = strtotime($report['date'] .' '. $report['time']);
            $lastReportDate = strtotime($lastReportDate);
            $reportDueDate = strtotime('+'. $type['reportInterval']['interval_length'], $lastReportDate);
            $nextReportDueDate = strtotime('+'. $type['reportInterval']['interval_length'], $reportDate);
            $toleranceDate = strtotime('+'. $type['reportInterval']['tolerance'], $reportDueDate);
            $delta = $this->calculateDaysDifference($reportDate, $lastReportDate);
            if($firstReport) {
                $delta = 'N/A';
            }
            if($reportDate < $reportDueDate) {
                $status = self::STATUS_ONTIME;
                $increment = self::STATUS_ONTIME;
            } elseif($reportDate < $toleranceDate) {
                $status = self::STATUS_TOLERANCE;
                $increment = self::STATUS_TOLERANCE;
            } else {
                $status = self::STATUS_LATE;
                $increment = self::STATUS_LATE;
            }
        }

        return ['info' => ['status' => $status,
                           'delta' => $delta,
                'status-class' => 'status-'. $status,
               ],           
               'increment' => $increment, 
               'last_report_due' => $reportDueDate,
               'next_report_due' => $nextReportDueDate,
        ];
    }

    /**
     * Calculate in days the difference between two reports
     *
     * @param string $currentReport in epoch
     * @param string $lastReport in epoch
     *
     * @return string
     */
    protected function calculateDaysDifference($current, $last)
    {
        $diff = $current - $last;
        $time = floor($diff / 86400);

        return $time;
    }

    protected function orderReportTypes($reportTypes)
    {
        $orderedReportTypes = $reportTypes;

        foreach($reportTypes as $key=>$type) {
            if(!isset($type['reports'])) {
                continue;
            }
            foreach($type['reports'] as $report) {
                if(count($report) === 0) {
                    continue;
                }
                $newReports[$report['date-8601']] = $report;
            }
            ksort($newReports);
            $orderedReportTypes[$key]['reports'] = $newReports;
            unset($newReports);
        }

        return $orderedReportTypes;
    }

    protected function getReportInfo($reportId, $clientSiteId)
    {
        $report = SiteOperationalProgram::find()->where(['site_id' => $clientSiteId, 'report_type_id' => $reportTypeId]);
    }

    protected function isWithinDates($fileAttr, $dateRange)
    {
        if($dateRange['date_from'] == '' || $dateRange['date_to'] == '') {
            return true;
        }
    
        $date = $fileAttr['date'];
        $fileDate = $this->convertDateFromFileFormat($date);

        if($fileDate >= $dateRange['date_from'] &&
           $fileDate <= $dateRange['date_to']) {
            return true;
        }

        return false;
    }

    protected function convertDateFromFileFormat($date)
    {
        return substr($date, 0, 4) .'-'. substr($date, 4, 2) .'-'. substr($date, 6, 2);
    }

    protected function convertTimeFromFileFormat($time)
    {
        return substr($time, 0, 2) .':'. substr($time, 2, 2);
    }

    public static function findLateReports()
    {
        $reports = [];

        $sops = SiteOperationalProgram::find()->where(['site_id' => 163])->all();
        foreach($sops as $sop) {
            if($status = $sop->compileAlerts()) {
                if(!$status) {
                    continue;
                }
                $reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,
                ];
            }
        }

        return $reports;
    }

    public function compileAlerts()
    {
        if(!$this->clientSite || !$this->client) {
            return false;
        }

        // Prevent undetermined reports (9999) from being included
        if($this->reportType->doctype_id >= 9000) {
            return false;
        }

        $path = $this->clientSite->directory;
        $reportTypeStr = '_'. $this->reportType->doctype_id;
        //$files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf | grep '. $reportTypeStr); // @#todo Remove - user for when reading file system
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($this->clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterForDocType($files, $reportTypeStr);

        $fileList = [];
        //$files = explode("\n", $files); // @todo remove - Used for when reading file system
        if(!isset($files[0]) || $files[0] == '') { // Don't include SOPs that have no files associated
            return false;
        }
        foreach($files as $file) {
            if($file == "") { 
                continue;
            }
            $file = $this->trimFilename($file);
            $file = $this->getReportAttributes($file);
            $fileList[$file[8601]] = $file;
        }
        ksort($fileList);

        $reportInfo = $this->determineIfLate(end($fileList), $this->reportInterval);
        var_dump($reportInfo);

        if($reportInfo['status'] == self::STATUS_LATE || $reportInfo['status'] == self::STATUS_TOLERANCE) {
            return $reportInfo;
        }

        return false;
    }

    /**
     * Get client for this report
     *
     * @return Client
     */
    public function getClient()
    {
        if(isset($this->clientSite) 
            && isset($this->clientSite->node)
            && isset($this->clientSite->node->client)) {
                return $this->clientSite->node->client;
            } else {
                return false;
            }
    }

    public static function sendAlerts($reports)
    {
        foreach($reports as $client) {
            return $this->renderPartial('email-alerts', ['client' => $client]);
        }
    }
}
