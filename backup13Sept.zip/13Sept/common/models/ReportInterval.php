<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "report_interval".
 *
 * @property integer $id
 * @property string $name
 * @property string $interval_length
 * @property string $tolerance
 * @property string $created_at
 * @property string $updated_at
 *
 * @property SiteOperationalProgram[] $siteOperationalPrograms
 */
class ReportInterval extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'report_interval';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'interval_length', 'tolerance'], 'required'],
            [['name', 'interval_length', 'tolerance'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'interval_length' => 'Interval Length',
            'tolerance' => 'Tolerance',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSiteOperationalPrograms()
    {
        return $this->hasMany(SiteOperationalProgram::className(), ['report_interval_id' => 'id']);
    }
}
