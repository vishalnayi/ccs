<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "document_search_term".
 *
 * @property integer $id
 * @property integer $report_category_id
 * @property integer $report_type_id
 * @property string $term
 * @property string $created_at
 * @property string $updated_at
 */
class DocumentSearchTerm extends BaseModel
{
    const FROM_ADDRESS = 1;
    const SUBJECT = 2;
    const MESSAGE_HTML = 3;
    const MESSSAGE_TEXT = 4;
    const FILENAME = 5;
    const DOCUMENT_TEXT = 6;
    const IMAGE_FINGERPRINT = 7;
    const DOCUMENT_CROPPED_DOCUMENT_TEXT = 8;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'document_search_term';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['report_category_id', 'provider_id', 'report_type_id', 'weight', 'doctype_id', 'search_term'], 'required'],
            [['report_category_id', 'report_type_id', 'weight', 'enabled', 'search_section', 'x1', 'y1', 'x2', 'y2'], 'integer'],
            [['search_from_address', 'search_subject', 'search_message_html', 'search_message_text',
                    'search_filename', 'search_document_text', 'search_image_fingerprint'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['search_term'], 'string', 'max' => 255],
            [['search_term'], 'match', 'pattern' => '/^[a-z09 !@#$%^&*()-=_+]*$/i'],
            [['x1', 'y1'], 'integer', 'min' => 0, 'max' => 1000],
            [['x2'], 'x2_validation'],
            [['y2'], 'y2_validation'],
        ];
    }

    public function x2_validation($attribute, $params)
    {
        if ($this->x2 < $this->x1) {
            $this->addError('x2', 'x2 cannot be a lower value than x1');
            throw new \yii\web\HttpException(422, 'x2 cannot be less than x1. @todo');
            return false;
        } else {
            return true;
        }
    }

    public function y2_validation($attribute, $params)
    {
        if ($this->y2 < $this->y1) {
            $this->addError('y2', 'y2 cannot be a lower value than y1');
            throw new \yii\web\HttpException(422, 'y2 cannot be less than y1. @todo');
            return false;
        } else {
            return true;
        }
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'report_category_id' => Yii::t('app', 'Report Category ID'),
            'report_type_id' => Yii::t('app', 'Report Type ID'),
            'search_term' => Yii::t('app', 'Search Term'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getReportType()
    {
        return $this->hasOne(ReportType::class, ['id' => 'report_type_id']);
    }

    public function getReportCategory()
    {
		return $this->hasOne(ReportCategory::className(), ['id' => 'report_category_id']);
    }

    public function getProvider()
    {
		return $this->hasOne(Provider::className(), ['id' => 'provider_id']);
    }

    public function getDocType()
    {
        return ReportType::getDocType($this->doctype_id);
    }

    /**
     * Remove this
     */
    public function formatSearchResults($results)
    {
        $formattedResults = [];

        foreach ($results as $result) {
            $formattedResults[] = [
            ];    
        }
    }
}
