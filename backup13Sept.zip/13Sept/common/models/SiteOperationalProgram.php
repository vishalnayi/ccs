<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use common\models\ClientSiteReportCategory;
use common\models\ClientSite;
/**
 * This is the model class for table "site_report".
 *
 * @property integer $id
 * @property integer $site_id
 * @property integer $report_type_id
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property ReportType $reportType
 * @property ReportFrequency $reportFrequency
 */
class SiteOperationalProgram extends BaseModel
{
    const STATUS_ONTIME = 'on-time';
    const STATUS_TOLERANCE = 'tolerance';
    const STATUS_LATE = 'late';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'site_operational_program';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['site_id', 'report_type_id', 'report_interval_id', 'name'], 'required'],
            [['site_id', 'report_type_id', 'report_interval_id','secondary_interval_id','territory_interval_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['additional_emails','additional_emails_secondary','additional_emails_territory'], 'string'],
            [['start_date'], 'string'],
            [['provider_ids'],  'number', 'numberPattern' => '/^\s*[-+]?[0-9]*[,]?[0-9]+([eE][-+]?[0-9]+)?\s*$/'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'site_id' => 'Site',
            'report_type_id' => 'Report Type',
            'name' => 'Name',
            'start_date' => 'Start Date',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    public function getClientSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReportType()
    {
        return $this->hasOne(ReportType::className(), ['id' => 'report_type_id']);
    }

    public function getReportInterval()
    {
        return $this->hasOne(ReportInterval::className(), ['id' => 'report_interval_id']);
    }

    public static function getNodeReports($clientId, $siteId)
    {
        $reportList = [];

        $reports = SiteOperationalProgram::find()->where(['site_id' => $siteId])->all();
        foreach($reports as $report) {
            $reportList[] = ['id' => $report->id .'_report',
                           'text' => $report->name,
                           'icon' => '/img/pdf.png',
                           'children' => false,
            ];
        }

        return $reportList;
    }

    public function searchSiteDirectory($clientId, $parent, $reportCategory)
    {
        $list = [];

        $siteId = $parent['id'];
        $path = $parent['path'];
        $catId = $parent['catId'];
        $reportCategoryId = $reportCategory ? $reportCategory->id : 0;

        $site = ClientSite::findOne($siteId);

        $s3 = Yii::$app->s3Helper;
        $reportCategoryPath = $reportCategory ? $reportCategory->path : Report::REPORT_CATEGORY_OTHERS;
        $directory = $site->directory .'-'. $reportCategoryPath;
        $files = $s3->directoryListing($directory . $path, $this->bucket, true);

        foreach ($files as $file) {
            if(preg_match('/\.((pdf)|(xls)|(doc))$/i', $file)) {
                $filePath = $directory . $path .'/'. $file;
                $directoryPath = $directory . $path;
                $fileAttr = self::getReportAttributes($file);
                $link = '/document/move-document?Document[site_id]='. $siteId .
                        '&Document[existing_path]='. $directoryPath .
                        '&Document[existing_filename]='. $file;
                $title = '<h3>'. $file .'</h3><p><a href="'. $link .'">Rename/move</a></p>';
                $list[$fileAttr['8601'] . $file] = ['id' => $file,
                                    'text' => $file,
                                    'icon' => '/img/'. $fileAttr['file_extension'] .'.png',
                                    'children' => false,
                                    'a_attr' => ['href' => '/site-operational-program/load-file?document='. $filePath .'&filename='. $file,
                                                 'target' => '_blank',
                                                 'title' => $title,
                                                 'rel' => 'tooltip',
                                                 'data-html' => true,
                                                 'data-delay' => '{"show": 0, "hide": 2500 }',
                                    ],
                ];
            } else {
                $list[] = ['id' => 'site|'. $siteId .'|cat|'. $reportCategoryId .'|'. $path .'/'. $file,
                           'text' => $file,
                           'icon' => '/img/dir.png',  
                           'children' => true,
                ];
                // TODO: Children is not true on Ben's version. may have issues at another time if deploying.
            }
        }

        ksort($list);
        $list = self::removeKeys($list);

        return $list;
    }

    /**
     * Check if path has any directories within
     */
    protected function checkForContents($folder)
    {
        $dh = opendir($folder);
        while (($path = readdir($dh)) !== false) {
            if($path !== '.' && $path != '..') {
                return true;
            }

            return false;
        }
    }

    public static function removeKeys($list)
    {
        $newList = [];

        foreach($list as $key=>$value) {
            $newList[] = $value;
        }

        return $newList;
    }

    public static function getReportAttributes($filename)
    {
        $file = explode('_', $filename);

        // if(count($file) !== 3) {
        //     return false;
        // }

        $ext = substr($filename, strrpos($filename, '.')+1, strlen($filename));
        \Yii::error('filename: '. $filename);
        \Yii::error('extension: '. $ext);
        if(count($file) == 3 || count($file) == 6 || count($file) == 5  ){
        return [
                '8601' => $file[0] . $file[1],
                'date' => $file[0],
                'time' => $file[1],
                'report_id' => $file[2],
                'searchTerm_id' => (count($file)==6) ? (isset($file[3])?$file[3]:""):"",
                'provider_id' => (count($file)== 6)?(isset($file[4])?$file[4]:""):(isset($file[3])?$file[3]:""),
                'client_id' => isset($file[5])?$file[5]:"",
                'file_extension' => $ext,
        ];
        }else{
            return false;
        }
    }

    public function formatDateTo8601($date, $time)
    {
        list($year, $month, $day, $time) = [
            substr($date, 4, 4),
            substr($date, 2, 2),
            substr($date, 0, 2),
            $time,
        ];

        return $year . $month . $day . $time;
    }

    public static function trimFilename($file)
    {
        $file = substr($file, strrpos($file, '/')+1);
        /*$file = substr($file, 0, strrpos($file, '.'));*/
        if(strpos($file, '(')) {
            $file = substr($file, 0, strrpos($file, '('));
        }

        return $file;
    }

    public static function getReportFormModel()
    {
        $model = DynamicModel::validateData(
                    ['client_id','date_from',
                     'date_to',
                     'client_site',
                     'node',
                     'report_types',
        ]);
        $model->addRule(['client_id','client_site','node'], 'integer');
        $model->addRule(['report_types'], 'required');
        $model->addRule(['date_from','date_to'], 'string');
        $model->addRule(['client_site'], function($attribute, $params) use($model) {
            if(!empty($model->client_site) && !empty($model->node)) {
                $model->addError($attribute, 'You cannot select both Client and Node');
            }
        });

        return $model;
    }

    public static function getDynamicCreateModel()
    {
        $model = DynamicModel::validateData(['supplier_id','category','category_id']);
        $model->addRule(['supplier_id'], 'integer');
        $model->addRule(['category'], 'required');
        $model->addRule(['category_id'], 'required');
        $model->addRule(['supplier_id'], 'required');

        return $model;
    }

    /**
     * Find reports from S3 bucket for given path
     */
    public function findS3Reports($reportTypes, $clientSite, $dateRange)
    {
        $s3 = Yii::$app->s3Helper;
        // echo "report types ==== ";
        // echo "<pre>";
        // print_r($reportTypes);
        // die;
        // print_r($clientSite->directory);
        // print_r($this->bucket);
        // die;
        $files = $s3->directoryListing($clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }

    public function checkDishaDemo($site){
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        $files = self::filterDocs($files);
        
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);            
            list($path, $name) = self::splitPath($file);
            $fileReportType = ReportType::findReportTypeFromFilename($name);
            
            foreach ($site->reportCategories as $key => $categories) {
                if($categories->id == $fileReportType->report_category_id){
                    $clientSiteReportCategories = ClientSiteReportCategory::find()->where(['client_site_id' => $site->id,'report_category_id'=>$fileReportType->report_category_id])->asArray()->all();
                 
                    $supplier_id = array_unique(array_column($clientSiteReportCategories, 'provider_id'));
                    
                    $fileNameArr = explode('.', $name);
                    $ext = $fileNameArr[1];
                    if(isset($supplier_id) && count($supplier_id) == '1'){                        
                        $newFilename = $fileNameArr[0]."_".$supplier_id[0]."_".$site->client_id.".".$ext; 
                    }elseif(!isset($supplier_id) || count($supplier_id) > '1'){
                        $docSearchTermCount=count($site->searchTerms);
                        if($docSearchTermCount == '1' && $site->searchTerms[0]->report_category_id== $categories->id){
                           $newFilename = $fileNameArr[0]."_". $site->searchTerms[0]->provider_id."_".$site->client_id.".".$ext;  
                        }
                    }
                        try {
                                $s3->movePathUpdated($path .'/'. $name,
                                     $path .'/'. $newFilename,
                                     $site->bucket 
                                );
                                $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                     $site->getMirrorPath() .'/'. $newFilename,
                                     $site->bucket 
                                );
                                // echo "done";
                                // die;
                            } catch (\yii\base\ErrorException $e) {
                                echo "<pre>";
                                print_r($e->getMessage());
                                //die;        
                                //sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
                                // Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
                        }
                        
                    


                }
            }
           //   echo "<pre>";
           //  print_r($fileAttr);
           // echo "  name ===== "; print_r($report_type_id);
           //  die;
        }
        //die;
        // echo "<pre>";
        // print_r($files);
        // die;
        
        // $copy = $s3->clonePath('Ahmedabad-cooling_towers','Ahmedabad-cooling_towers_copy','nextcloud-prod');
        // $files = $s3->directoryListing('Ahmedabad-cooling_towers_copy','nextcloud-prod');

        // echo "<pre>";
        // print_r($files);
        // die;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        return $files;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterDocs($files)
    {
        $fileList = [];

        $docTypes = ['pdf', 'doc', 'xls'];

        foreach ($files as $file) {
            $ext = getFileExtension($file);
            if (in_array($ext, $docTypes)) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterForDocType($files, $docType)
    {
        $fileList = [];

        foreach ($files as $file) {
            if (preg_match("/${docType}/", $file) == 1) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Find files from local file system
     * @todo: This method can be removed once we're satisfied the call to s3 is working as required.
     */
    public function findReports($reportTypes, $clientSite, $dateRange)
    {
        $files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $clientSite->directory ." -iname '*.pdf' -or -iname '*.doc' -or -iname '*.xls'");
        $files = explode("\n", $files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }

    public function splitPath($file)
    {
        $path = substr($file, 0, strrpos($file, '/'));
        $filename = substr($file, strrpos($file, '/')+1);

        return [$path, $filename];
    }

    protected function filterFiles($reportTypes, $files, $clientSite, $dateRange)
    {
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            list($path, $name) = $this->splitPath($file);

            // Only add report if it belongs to a selected report type
            if(!array_key_exists($fileAttr['report_id'], $reportTypes)) {
                continue;
            }

            if(!$this->isWithinDates($fileAttr, $dateRange)) {
                continue;
            }

            $reportTypes[$fileAttr['report_id']]['reports'][$fileAttr['8601'].$fileShort] = 
                        array_merge($fileAttr, [
                            'string' => $fileShort,
                            'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                            'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                            'filePath' => $file,
                            'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                            'filename' => $name,
                            'path' => $path,
                            'clientSiteId' => $clientSite->id,
                        ]);
        }

        $reportTypes = $this->orderReportTypes($reportTypes);
        if (isset($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
            $reportTypes = $this->retrieveStatusData($clientSite->client_id, $reportTypes);
        }

        return $reportTypes;
    }

    public function buildOthersReportType($clientSite)
    {
        return [
                'name' => 'Others',
                'clientSite' => $clientSite->attributes,
                'reportInterval' => [
                    'id' => 1,
                    'name' => '',
                    'interval_length' => 'len',
                    'tolerance' => 'toler',
                ],
        ];
    }

    protected function retrieveStatusData($clientId, $reportTypes)
    {
        $reportTypesWithStatus = $reportTypes;

        foreach($reportTypes as $key=>$type) {

            $reportInfo = [self::STATUS_ONTIME => 0,
                           self::STATUS_TOLERANCE => 0,
                           self::STATUS_LATE => 0,
                           'total' => 0,
            ];

            $reportTypesWithStatus[$key]['statuses'] = [
                         'last_report_due' => '--2',
                         'last_report_class' => '--3',
                         'percentages' => '--p',
                         'status_bar' => ['status_string' => '', 'status_class' => ''],
            ];

            if(!isset($type['reports'])) {
                $reportTypesWithStatus[$key]['reports'] = [];
                continue;
            }

            foreach($type['reports'] as $report) {
                if(!isset($lastReportDate)) {
                    $lastReportDate = $report['date'];
                    $firstReport = true;
                }
                $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                $report['info'] = $statuses['info'];
                if (!isset($statuses['increment'])) dd($report);
                $reportInfo[$statuses['increment']]++;
                $reportInfo['total']++;
                $newReports[$report['date-8601']] = $report;
                $lastReportDate = $report['date'];
                $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentages($reportInfo);
                $firstReport = false;
            }
            if ($report['report_id'] != '9999') {
                $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
            }
            $reportTypesWithStatus[$key]['reports'] = $newReports;
            unset($newReports);
            unset($lastReportDate);
        }

        return $reportTypesWithStatus;
    }

    protected function buildReportPercentages($info)
    {
        if($info['total'] == 0) {
            return 'no totals to calculate';
        }

        $ontime = round(number_format($info[self::STATUS_ONTIME] / $info['total'] *100, 2));
        $tolerance = round(number_format($info[self::STATUS_TOLERANCE] / $info['total'] *100, 2));
        $late = round(number_format($info[self::STATUS_LATE] / $info['total'] *100, 2));

        return 'Ontime: '. $ontime .'%; Tolerance: '. $tolerance .'%; Late: '. $late .'%';
    }

    protected function buildReportStatusBarString($statuses, $tolerance)
    {
        $toleranceTime = strtotime('+'. $tolerance, $statuses['next_report_due']);
        if($statuses['next_report_due'] > time()) {
            $statusClass = self::STATUS_ONTIME; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        } elseif($toleranceTime < time()) {
            $statusClass = self::STATUS_LATE; 
            $statusString = 'Last report on '. date('j/m/Y', $statuses['next_report_due']) .' overdue';
        } else {
            $statusClass = self::STATUS_TOLERANCE; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        }

        return [
            'status_string' => $statusString,
            'status_class' => 'status-'. $statusClass,
        ];
    }

    /**
     * Determine if report is late
     *
     * @param string $report shortend filename
     * @param ReportInterval $interval
     * 
     * @return string
     */
    protected function determineIfLate($report, $interval,$start_date)
    {
        //echo "here"; die;
        //var_dump($start_date);
        // echo " interval ";
        // print_r($interval);
        //die;
        $is_calendar = $interval->is_calendar;
        $date = $this->convertDateFromFileFormat($report['date']);
        $time = $this->convertTimeFromFileFormat($report['time']);
        if($start_date != NULL){
            $reportDate = strtotime($start_date);
            // echo "start report date ";
            // var_dump($reportDate);
            // die;
        }else{
            $reportDate = strtotime($date .' '. $time);
        }
        
        $reportDueDate = strtotime('+'. $interval->interval_length, $reportDate);       
        if(isset($is_calendar) && $is_calendar == "1"){               
            $reportDueDate = strtotime(date("Y-m-t",$reportDueDate));               
        }
        $toleranceDate = strtotime('+'. $interval->tolerance, $reportDueDate);
        // echo " DATE : ".$date;
        // echo " TIME : ".$time;
        // echo " Report DATE : ".$reportDate;
        // echo " Report due DATE : ".$reportDueDate;
        // echo " tolerance : ". $interval->tolerance;
        // echo " interval length : ".  $interval->interval_length;
        // echo " Report tolerance DATE : ".$toleranceDate;
        // echo "<pre>";
        // print_r($report);
        // die;
        $now = time();
        if($reportDueDate > $now) {
            $status = self::STATUS_ONTIME;
        } elseif($toleranceDate > $now) {
            $status = self::STATUS_TOLERANCE;
        } else {
            $status = self::STATUS_LATE;
        }

        return ['status' => $status,
                'reportDate' => $this->convertTimeToStr($reportDate),
                'dueDate' => $this->convertTimeToStr($reportDueDate),
                'toleranceDate' => $this->convertTimeToStr($toleranceDate),
        ];
    }

    protected function getReportStatus($report, $type, $lastReportDate, $firstReport)
    {
        $is_calendar = isset($type['reportInterval']['is_calendar'])?$type['reportInterval']['is_calendar']:0;
        
        $attrs = self::getReportAttributes($report['string']);
        if ($attrs['report_id'] == '9999') {
            $status = 'N/A';    
            $delta = '';
            $increment = 'on-time';
            $reportDueDate = '';
            $nextReportDueDate = '';
        } else {
            if(isset($type['start_date']) && $type['start_date'] != NULL){
                //$reportDate = strtotime($type['start_date']);
                $reportDate = strtotime($report['date'] .' '. $report['time']);
            }else{
                $reportDate = strtotime($report['date'] .' '. $report['time']);
            }
            $lastReportDate = strtotime($lastReportDate);            
            $reportDueDate = isset($type['reportInterval']['interval_length'])?(strtotime('+'. $type['reportInterval']['interval_length'], $lastReportDate)):"";
           
            if(isset($is_calendar) && $is_calendar == "1" && $reportDueDate!=""){               
                $reportDueDate = strtotime(date("Y-m-t",$reportDueDate));               
            }
           
            $nextReportDueDate = isset($type['reportInterval']['interval_length'])?(strtotime('+'. $type['reportInterval']['interval_length'], $reportDate)):"";
            $toleranceDate = isset($type['reportInterval']['tolerance'])?(strtotime('+'. $type['reportInterval']['tolerance'], $reportDueDate)):"";
            $delta = $this->calculateDaysDifference($reportDate, $lastReportDate);
            if($firstReport) {
                $delta = 'N/A';
            }
                $last_report_due = ($reportDueDate!="")?date('Y-m-d',$reportDueDate):'';
               $next_report_due = ($nextReportDueDate!="")?date('Y-m-d',$nextReportDueDate):'';
               $toleranceDate1 = ($toleranceDate!="")?date('Y-m-d',$toleranceDate):'';
               $reportDate1 = ($reportDate!="")?date('Y-m-d',$reportDate):'';
            if($last_report_due != "" && $toleranceDate1 != ""){
                if($reportDate1 < $last_report_due) {
                    $status = self::STATUS_ONTIME;
                    $increment = self::STATUS_ONTIME;
                } elseif($reportDate1 < $toleranceDate1) {
                    $status = self::STATUS_TOLERANCE;
                    $increment = self::STATUS_TOLERANCE;
                } else {
                    $status = self::STATUS_LATE;
                    $increment = self::STATUS_LATE;
                }
            }else{
                $status = "";
                $increment = "";
            }
        }

        return ['info' => ['status' => $status,
                           'delta' => $delta,
                'status-class' => 'status-'. $status,
                'interval_length' => isset($type['reportInterval']['interval_length'])?$type['reportInterval']['interval_length']:'',
                'tolerance' => isset($type['reportInterval']['tolerance'])?$type['reportInterval']['tolerance']:'',
                'last_report_due' => ($reportDueDate!="")?date('Y-m-d',$reportDueDate):'',
               'next_report_due' => ($nextReportDueDate!="")?date('Y-m-d',$nextReportDueDate):'',
               'toleranceDate' => ( isset($toleranceDate) && $toleranceDate!="")?date('Y-m-d',$toleranceDate):'',
               'reportDate' => (isset($reportDate) && $reportDate!="")?date('Y-m-d',$reportDate):'',
               ],           
               'increment' => $increment, 
               'last_report_due' => $reportDueDate,
               'next_report_due' => $nextReportDueDate,
        ];
    }

    /**
     * Calculate in days the difference between two reports
     *
     * @param string $currentReport in epoch
     * @param string $lastReport in epoch
     *
     * @return string
     */
    protected function calculateDaysDifference($current, $last)
    {
        if ($current>$last) {
            $diff = $current - $last;
            $time = floor($diff / 86400);
        }else{
            $diff = $last - $current;
            $time = floor($diff / 86400);
        }

        return $time;
    }

    protected function orderReportTypes($reportTypes)
    {
        $orderedReportTypes = $reportTypes;

        foreach($reportTypes as $key=>$type) {
            if(!isset($type['reports'])) {
                continue;
            }
            foreach($type['reports'] as $report) {
                if(count($report) === 0) {
                    continue;
                }
                $newReports[$report['date-8601']] = $report;
            }
            ksort($newReports);
            $orderedReportTypes[$key]['reports'] = $newReports;
            unset($newReports);
        }

        return $orderedReportTypes;
    }

    protected function getReportInfo($reportId, $clientSiteId)
    {
        $report = SiteOperationalProgram::find()->where(['site_id' => $clientSiteId, 'report_type_id' => $reportTypeId]);
    }

    protected function isWithinDates($fileAttr, $dateRange)
    {
        if($dateRange['date_from'] == '' || $dateRange['date_to'] == '') {
            return true;
        }
    
        $date = $fileAttr['date'];
        $fileDate = $this->convertDateFromFileFormat($date);

        if($fileDate >= $dateRange['date_from'] &&
           $fileDate <= $dateRange['date_to']) {
            return true;
        }

        return false;
    }

    protected function convertDateFromFileFormat($date)
    {
        return substr($date, 0, 4) .'-'. substr($date, 4, 2) .'-'. substr($date, 6, 2);
    }

    protected function convertTimeFromFileFormat($time)
    {
        return substr($time, 0, 2) .':'. substr($time, 2, 2);
    }

    public static function findLateReports($MysiteAr=[])
    {
        $reports = array();
        if (!empty($MysiteAr)) {
            /*echo "string";exit;*/
            $sops = SiteOperationalProgram::find()->WHERE(['in', 'site_id',$MysiteAr])->all();
        }else{
            $sops = SiteOperationalProgram::find()->all();
        }
        /*echo "<pre>";print_r($sops);exit;*/
        //$sops = SiteOperationalProgram::find()->where(['site_id'=>163])->all();
        foreach($sops as $sop) {
            $clientSite = ClientSite::findOne($sop->site_id); 
            /*echo "<pre>";
            print_r($clientSite->client_id);
            echo "<br>";
            print_r($sop->site_id);exit;*/
            if($status = $sop->compileAlerts()) {
                if(!$status) {
                    continue;
                }
                $reports[$clientSite->client_id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,
                                                         
                ];
            }
        }
        /*echo "<pre>";print_r($reports);exit;*/
        return $reports;
    }

    


    public static function findSiteLateReports($id,$sid,$clientSite,$FromDate,$toDate)
    {
        $reports = [];

        //$sops = SiteOperationalProgram::find()->all();
        $sops = SiteOperationalProgram::find()->where(['site_id'=>$id,'provider_ids'=>$sid])->all();

        foreach($sops as $sop) {
            $result=array();
            // echo "<pre>";
            // print_r($sop);
            if($status = $sop->compileAlerts()) {
                if(!$status) {
                    continue;
                }
                /*$reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,
                                                         
                ];*/

                $docTypeIdArr = [];

                $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
                $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $id,
                                                                      'report_type_id' => $reportTypes,
                                                           ])->with(['reportType','reportInterval','clientSite'])
                                                             ->asArray()
                                                             ->all();
                $rts = [];
                $flag=5;
                $sop1 = new SiteOperationalProgram;
                $fArray = array(9,10);
                $clientSite = ClientSite::findOne($id); 
                if(!in_array($flag, $fArray)){
                    foreach($reportTypes as $type) {
                        if(isset($type['reportType'])) {
                            $rts[$type['reportType']['doctype_id']] = $type;
                        }
                    }
                }else{
                    $rts['9999'] = $sop1->buildOthersReportType($clientSite);               
                } 

                $dateRange = [
                    'date_from' => date('Y-m-d', strtotime('2018-01-01')),
                    'date_to' => date('Y-m-d', strtotime($toDate)),
                ];     

                $reports1 = $sop1->findS3ReportsDashboardStatics($rts, $clientSite, '5', $dateRange);

                foreach ($reports1 as $docTypeId => $re) {
                    if(!empty($re['reports'])){
                        if(in_array($docTypeId, $docTypeIdArr)){   

                         if(strtotime($result[$docTypeId]['lastReportDate']) < strtotime($re['lastReportDate'])){
                              $result[$docTypeId]['lastReportDate'] = date('d/m/Y',strtotime($re['lastReportDate']));
                          }  

                        }else{
                          array_push($docTypeIdArr, $docTypeId);
                          $reprotTypeData = ReportType::find()->where(['doctype_id'=>$docTypeId])->all();
                          if (isset($reprotTypeData[0]->name)) {
                              $reprotTypeDataName=$reprotTypeData[0]->name;
                          }else{
                              $reprotTypeDataName="";
                          }
                          $result[$docTypeId]['lastReportDate'] = date('d/m/Y',strtotime($re['lastReportDate']));
                        }
                    }
                }

                $reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,'lastreport'=>$result
                                                         
                ];
            }
        }

        return $reports;
    }


    public function compileAlerts()
    {
        if(!$this->clientSite || !$this->client) {
            return false;
        }

        // Prevent undetermined reports (9999) from being included
        if($this->reportType->doctype_id >= 9000) {
            return false;
        }

        $path = $this->clientSite->directory;
        // echo "<pre>";
        // print_r($this->client);
        $reportTypeStr = '_'. $this->reportType->doctype_id;
        //$files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf | grep '. $reportTypeStr); // @#todo Remove - user for when reading file system
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($this->clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterForDocType($files, $reportTypeStr);

        $fileList = [];
        //$files = explode("\n", $files); // @todo remove - Used for when reading file system
        if(!isset($files[0]) || $files[0] == '') { // Don't include SOPs that have no files associated
            return false;
        }
        foreach($files as $file) {
            if($file == "") { 
                continue;
            }
            $file = $this->trimFilename($file);
            $file = $this->getReportAttributes($file);
            $fileList[$file[8601]] = $file;
        }
        ksort($fileList);

        $reportInfo = $this->determineIfLate(end($fileList), $this->reportInterval,'');
        //var_dump($reportInfo);
        //die;
        if(isset($file['provider_id']) && !empty($file['provider_id'])){
            $pid = $file['provider_id'];
            $provider = Provider::find()->select(["name"])->where(['id'=>$pid])->all();
            $provider_name = $provider[0]->name;
        }else{
            $provider_name = "";
        }
        
        $reportInfo['providers'] = $provider_name;

        if($reportInfo['status'] == self::STATUS_LATE || $reportInfo['status'] == self::STATUS_TOLERANCE) {
            return $reportInfo;
        }else{
            $model = SiteOperationalProgram::findOne($this->id);

            $model->is_sent_primary = 0;
            $model->secondary_alarm_date = NULL;
            $model->is_sent_secondary = 0;
            $model->is_sent_territory = 0;
            $model->territory_alarm_date = NULL;   
            $model->save();

        }

        return false;
    }

    /**
     * Get client for this report
     *
     * @return Client
     */
    public function getClient()
    {
        if(isset($this->clientSite) 
            && isset($this->clientSite->node)
            && isset($this->clientSite->node->client)) {
                return $this->clientSite->node->client;
            } else {
                return false;
            }
    }

    public static function sendAlerts($reports)
    {
        foreach($reports as $client) {
            return $this->renderPartial('email-alerts', ['client' => $client]);
        }
    }

    // Dashboard Functions
    /**
     * Find reports from S3 bucket for given path same as findS3ReportsDashboard in this file just to get sorted data for getReportsStaticsDashboard from clientSite model
     */


    public function getTotalReports($reportTypes, $clientSite, $flag=5, $dateRange,$doc=[])
    {
        if(empty($reportTypes)){
            $canWihoutPrimaryAlarm = 1;
        }
        
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);       

        $files = $this->filterDocs($files);
        /*echo "<pre>";print_r($files);*/
        $totalFiles=count($files);

        return $totalFiles;
    }
    public function findS3ReportsDashboardStatics($reportTypes, $clientSite, $flag=5, $dateRange,$doc=[])
    {
        //echo $flag; die;
       /*echo $clientSite->id;exit;*/
        if(empty($reportTypes)){
            $canWihoutPrimaryAlarm = 1;
        }
        
        $s3 = Yii::$app->s3Helper;
        
        $files = $s3->directoryListing($clientSite->directory, $this->bucket);       

        $files = $this->filterDocs($files);
        if (!empty($files)) {
           // echo "<pre>";print_r($files);exit;
        }
        
        $totalFiles=count($files);
        $othersFile=0;
        $otherFileAr=[];
        $otherFilePathAr=[];
        //$files = $this->filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange);
        //filterFilesDashboard start ***************************************************** 
                foreach($files as $file) {
                     
                    $fileShort = self::trimFilename($file);
                    
                    $fileAttr = self::getReportAttributes($fileShort);
                    
                    list($path, $name) = $this->splitPath($file);
                    /*echo "<pre>";print_r($fileAttr);*/
                    $reportid=$fileAttr['report_id'];
                    if ($reportid=='9999.pdf') {
                        $reportid=str_replace('.pdf', '', $reportid);
                    }
                    $reportid=str_replace('.pdf', '', $reportid);
                    /*echo "<pre>";print_r($reportid);exit;*/
                    /*echo "<pre>";print_r($fileShort);*/
                    // Only add report if it belongs to a selected report type
                    if(!isset($canWihoutPrimaryAlarm)){
                       
                        if($reportid == 9999) {
                            $othersFile++;
                            $otherFileAr[]  =   $fileShort;
                            $otherFilePathAr[]  =   $file;
                           // continue;
                        }
                    }
                    if($reportid == 9999) {
                            $othersFile++;
                            $otherFileAr[]  =   $fileShort;
                            $otherFilePathAr[]  =   $file;
                           // continue;
                        }
                    if(($flag == 6) && (!in_array($reportid, $doc))){
                         //continue;
                    }
                    if(!$this->isWithinDates($fileAttr, $dateRange)) {
                        continue;
                    }
                    $site = ClientSite::findOne($clientSite->id);
                    $results = ArrayHelper::toArray($site);
                    $reportTypes[$reportid]['clientSite']=$results;
                    // echo "<pre>";print_r($dateRange);exit;
                   /* echo $reportid;
                    echo $fileAttr['8601'].$fileShort;
                    echo "<br>";*/
                    if (!empty($fileAttr) && is_array($fileAttr)) {
                        $dateHere=$this->convertDateFromFileFormat($fileAttr['date']);
                        /*echo $dateHere;echo "<br>";
                        echo "from -".$dateRange['date_from'];echo "<br>";
                        echo "to -".$dateRange['date_to'];echo "<br>";exit;*/
                        if (($dateHere >= $dateRange['date_from']) && ($dateHere <= $dateRange['date_to'])){
                        /*if (($dateRange['date_from'] >= $dateHere) && ($dateRange['date_to'] <= $dateHere)){*/
                            /*echo "<br>";
                            echo "string";exit;*/
                            $reportTypes[$reportid]['reports'][$fileAttr['8601'].$fileShort] = 
                                array_merge($fileAttr, [
                                    'string' => $fileShort,
                                    'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                                    'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                                    'filePath' => $file,
                                    'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                                    'filename' => $name,
                                    'path' => $path,
                                    'clientSiteId' => $clientSite->id,
                            ]);
                        }
                    }
                    
                    if ($reportid=='9999') {
                        /*echo "<pre>";print_r($reportTypes);*/
                    }
                               
                }
                /*exit;*/
            // echo "<pre>";print_r($reportTypes);
               
                $reportTypes = $this->orderReportTypes($reportTypes);  
                /*echo "<pre>";print_r($reportTypes);exit;*/

                if (isset($fileAttr) && is_array($fileAttr) &&  array_key_exists('report_id', $fileAttr)/* && $reportid != '9999'*/) {
                    /*echo "<pre>";print_r($reportTypes);*/
                    $clientId = $clientSite->client_id;
                   // $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
                    //*****************************************retrieveStatusDataDashboard*************************
                        //        protected function retrieveStatusDataDashboard($clientId,$reportTypes,$flag,$dateRange){
                        $reportTypesWithStatus = $reportTypes;        
                        $reportTypesWithStatus1 = $reportTypes;
                        $totalReports = 0;
                        $total = 0;
                        $rCount =  count($reportTypes);
                        $fDate = 1;
                        $AuditPeriod3['startdate'] = array();
                        $AuditPeriod3['enddate'] = array();
                        $AuditPeriod9['startdate'] = array();
                        $AuditPeriod9['enddate'] = array();
                        $AuditPeriod6 = array();
                        $AuditPeriod7 = array();
                        $AuditPeriod = array();
                        $Compliance = array();
                        $Compliance8 = array();

                foreach($reportTypes as $key=>$type) {
                /*echo "<pre>";print_r($type);exit;*/
                $reportInfo = [self::STATUS_ONTIME => 0,
                               self::STATUS_TOLERANCE => 0,
                               self::STATUS_LATE => 0,
                               'total' => 0,
                ];

                $reportTypesWithStatus[$key]['statuses'] = [
                             'last_report_due' => '--2',
                             'last_report_class' => '--3',
                             'percentages' => '--p',
                             'status_bar' => ['status_string' => '', 'status_class' => ''],
                ];

                if(!isset($type['reports'])) {
                    $reportTypesWithStatus[$key]['reports'] = [];
                    $reportTypesWithStatus[$key]['suppliers'] = [];
                    $reportTypesWithStatus[$key]['suppliersReports'] = [];
                    continue;
                }else{
                    $reportTypesWithStatus[$key]['percentages'] = 0;
                    $reportTypesWithStatus[$key]['supplier_percentages'] = 0;                    
                }
                        
                $OtherCount = 0;
                $supplier = []; 
                $supplierReportIds = [];    
                $supplierR = array();
                /*echo "<pre>";print_r($reportTypesWithStatus);*/
                foreach($type['reports'] as $key1=> $report) {

                    if(!isset($lastReportDate)) {
                        $lastReportDate = $report['date'];
                        $firstReport = true;
                        //$firstReportDate = $report['date'];
                    }
                    if(!isset($firstReportDate)){
                        $firstReportDate = $report['date'];
                    }

                    if(!in_array($report['provider_id'], $supplier) && !empty($report['provider_id'])){ 
                        array_push($supplier,$report['provider_id']);                           
                        $supplierR[$report['provider_id']] = array();   
                        array_push($supplierR[$report['provider_id']], $report);    
                    }elseif(!empty($report['provider_id'])){    
                        array_push($supplierR[$report['provider_id']], $report);    
                    }
                   
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                    /*echo "<pre>";print_r($statuses);exit;*/
                    $report['info'] = $statuses['info'];
                    $type['reports'][$key1]['info']=array();
                    //array_push($type['reports'][$key1]['info'], $statuses['info']);    
                    $type['reports'][$key1]['info']= $statuses['info'];
                    if (!isset($statuses['increment'])) dd($report);
                    if($statuses['increment'] != ""){
                        $reportInfo[$statuses['increment']]++;
                    }
                    /*echo "<pre>";print_r($report);exit;*/
                    $reportInfo['total']++;
                    $newReports[$report['date-8601']] = $report;            
                    
                    $lastReportDate = $report['date'];
                    /*echo "<pre>";
                    print_r($report);echo "<br>";
                    print_r($clientSite->name);echo "<br>";
                    print_r($reportInfo);echo "<br>";*/
                    $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo, $flag);

                   // ***************my addition*****************
                    $reportTypesWithStatus[$key]['lastReportDate'] = $lastReportDate;
                    $reportTypesWithStatus[$key]['firstReportDate'] = $firstReportDate;
                    $reportTypesWithStatus[$key]['info'] = $reportInfo;
                  //  ****************my addition end**********
                    $chkDate = strtotime($lastReportDate);
                    $firstReport = false;
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    $report_id=$report['report_id'];
                    if ($report_id=='9999.pdf') {
                        $report_id=str_replace('.pdf', '', $report_id);
                    }

                    if($report_id == '9999'){

                        if(!isset($OtherlastReportDate)) {
                            $OtherlastReportDate = $report['date'];
                            $OtherfirstReport = true;
                            //$firstReportDate = $report['date'];
                        }
                        if(!isset($OtherfirstReportDate)){
                            $OtherfirstReportDate = $report['date'];
                        }
                        $OtherlastReportDate = $report['date'];
                        if(isset($OtherfirstReportDate)){
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));
                        }
                        $OtherfirstReport = false;
                        $OtherCount++ ;
                    }
                    
                }
                /*echo "<pre>";print_r($type['reports']);exit;*/

                 if ($report_id != '9999') {
                    if(isset($type['reportInterval']['tolerance'])){
                        $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
             

                    }
                }

                //report type wise(for single report type i.e 1002) supplier and supplier reports                   
               $reportTypesWithStatus[$key]['reports'] = $type['reports'];    
               $reportTypesWithStatus[$key]['supplier'] = $supplier;    
               $reportTypesWithStatus[$key]['supplier_reports'] = isset($supplierR)?$supplierR:""; 
               $supplierDetailByReportType = $this->retriveStatusDataForSupplier($supplier,$supplierR,$type);   
               $reportTypesWithStatus[$key]['supplier_info'] = $supplierDetailByReportType;

               
               

               
                if($flag == 5 || $flag==6){
                    
                    $Compliance[$key] = $reportTypesWithStatus[$key]['percentages'];                 
                }

                unset($newReports);
                unset($firstReportDate);
                unset($lastReportDate);

            //}           
            $fDate = 0;   
               
        }
  
        
        if($flag==5 || $flag==6){
           // $reportTypes = $this->retrieveStatusDataDashboard() so $reportTypes = $reportTypesWithStatus
           $reportTypes = $reportTypesWithStatus;
          
          // return $reportTypesWithStatus;
        }
    }
                // files = filterFilesDashboard() so return reportTypes assigned to files
                $files = $reportTypes;       
                //return $reportTypes; from filterFilesDashboard function
           
        //filterFilesDashboard end *****************************************************    
         // echo " here ";
         // echo "<pre>";
         //            print_r($files);
         //            die;

        return $files;
    }

    protected function retriveStatusDataForSupplier($suppliers,$suppliersReports,$type){    
        $supplierWithStatus = array();  
        foreach($suppliers as $key=>$supplier) {    
                    
                $reportInfo = [self::STATUS_ONTIME => 0,    
                               self::STATUS_TOLERANCE => 0, 
                               self::STATUS_LATE => 0,  
                               'total' => 0,    
                ];  
                
                if(!isset($suppliersReports)) { 
                    $supplierWithStatus[$supplier]['reports'] = [];                     
                    continue;   
                }else{  
                    $supplierWithStatus[$supplier]['percentages'] = 0;                      
                }   
                            
                $OtherCount = 0;    
                
                   
                foreach($suppliersReports[$supplier] as $report) {  
                    if(!isset($lastReportDate)) {   
                        $lastReportDate = $report['date'];  
                        $lastReportfilePath = $report['filePath'];  
                        $lastReportstring = $report['string'];  
                        $firstReport = true;    
                        //$firstReportDate = $report['date'];   
                    }   
                    if(!isset($firstReportDate)){   
                        $firstReportDate = $report['date']; 
                    }                   
                    
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);  
                    $report['info'] = $statuses['info'];    
                    if (!isset($statuses['increment'])) dd($report);    
                    if($statuses['increment'] != ""){
                        $reportInfo[$statuses['increment']]++;
                    }
                    $reportInfo['total']++; 
                    $newReports[$report['date-8601']] = $report;                
                        
                    $lastReportDate = $report['date'];
                   // $lastReport['filePath']."&filename=".$lastReport['string']  
                    $lastReportfilePath = $report['filePath'];  
                    $lastReportstring = $report['string'];  
                    $supplierWithStatus[$supplier]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo,5);  
                   // ***************my addition*****************   
                    $supplierWithStatus[$supplier]['lastReportDate'] = $lastReportDate;             
                    $supplierWithStatus[$supplier]['filePath'] = $lastReportfilePath;             
                    $supplierWithStatus[$supplier]['string'] = $lastReportstring;             
                    $supplierWithStatus[$supplier]['info'] = $reportInfo;   
                  //  ****************my addition end********** 
                    $chkDate = strtotime($lastReportDate);  
                    $firstReport = false;   
                    if(isset($firstReportDate)){    
                        $fromDate = date('Y/m/d', strtotime($firstReportDate)); 
                    }   
                    if($report['report_id'] == '9999'){ 
                        if(!isset($OtherlastReportDate)) {  
                            $OtherlastReportDate = $report['date']; 
                            $OtherfirstReport = true;   
                            //$firstReportDate = $report['date'];   
                        }   
                        if(!isset($OtherfirstReportDate)){  
                            $OtherfirstReportDate = $report['date'];    
                        }   
                        $OtherlastReportDate = $report['date']; 
                        if(isset($OtherfirstReportDate)){   
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));   
                        }   
                        $OtherfirstReport = false;  
                        $OtherCount++ ; 
                    }   
                        
                }  
                        
                $Compliance[$supplier] = $supplierWithStatus[$supplier]['percentages'];                     
                
                unset($newReports); 
                unset($firstReportDate);    
                unset($lastReportDate); 
                unset($lastReportfilePath); 
                unset($lastReportstring); 
            //}             
            $fDate = 0;             
        }   
        return $supplierWithStatus; 
    }   
    private function getSupplierFromFileName($fileString){  
            $attr = explode($fileString,'_');   
            if(isset($attr[3])){    
                return $attr[3];    
            }else{  
                return "";  
            }   
    }

    /**
     * Find reports from S3 bucket for given path
     */
    public function findS3ReportsDashboard($reportTypes, $clientSite, $flag, $dateRange)
    {
        
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);
        
        $files = $this->filterDocs($files);

        $files = $this->filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange);
        /*print_r($files);exit;*/
        return $files;
    }


    protected function filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange)
    {
        /*print_r($files);exit;*/
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            list($path, $name) = $this->splitPath($file);

            $reportid=$fileAttr['report_id'];
            if ($reportid=='9999.pdf') {
                $reportid=str_replace('.pdf', '', $reportid);
            }
            // Only add report if it belongs to a selected report type
            if(!array_key_exists($reportid, $reportTypes)) {
                continue;
            }

            if(!$this->isWithinDates($fileAttr, $dateRange)) {
                continue;
            }
            /*echo "string";exit;*/
            $dateHere=$this->convertDateFromFileFormat($fileAttr['date']);
                        /*echo $dateHere;echo "<br>";
                        echo "from -".$dateRange['date_from'];echo "<br>";
                        echo "to -".$dateRange['date_to'];echo "<br>";exit;*/
            if (($dateHere >= $dateRange['date_from']) && ($dateHere <= $dateRange['date_to'])){
            $reportTypes[$reportid]['reports'][$fileAttr['8601'].$fileShort] = 
                        array_merge($fileAttr, [
                            'string' => $fileShort,
                            'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                            'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                            'filePath' => $file,
                            'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                            'filename' => $name,
                            'path' => $path,
                            'clientSiteId' => $clientSite->id,
                        ]);
            }
        }
        
        $reportTypes = $this->orderReportTypes($reportTypes);
        if($flag == 9 || $flag == 10){
            $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
        }else{

            if (isset($fileAttr) && is_array($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
                $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
            }
        }        
        return $reportTypes;
    }


    protected function retrieveStatusDataDashboard($clientId, $reportTypes, $flag, $dateRange)
    {
        $reportTypesWithStatus = $reportTypes;        
        $reportTypesWithStatus1 = $reportTypes;
        $totalReports = 0;
        $total = 0;
        $rCount =  count($reportTypes);
        $fDate = 1;
        $AuditPeriod3['startdate'] = array();
        $AuditPeriod3['enddate'] = array();
        $AuditPeriod9['startdate'] = array();
        $AuditPeriod9['enddate'] = array();
        $AuditPeriod6 = array();
        $AuditPeriod7 = array();
        $AuditPeriod = array();
        $Compliance = array();
        $Compliance8 = array();

        foreach($reportTypes as $key=>$type) {
            $AuditPeriod[$key] = array();
            $AuditPeriod[$key] = array();
            $AuditPeriod7[$key] = array();
            $Compliance[$key] = array();
            $Compliance8[$key] = array();


            $reportInfo = [self::STATUS_ONTIME => 0,
                           self::STATUS_TOLERANCE => 0,
                           self::STATUS_LATE => 0,
                           'total' => 0,
            ];

            $reportTypesWithStatus[$key]['statuses'] = [
                         'last_report_due' => '--2',
                         'last_report_class' => '--3',
                         'percentages' => '--p',
                         'status_bar' => ['status_string' => '', 'status_class' => ''],
            ];

            if(!isset($type['reports'])) {
                $reportTypesWithStatus[$key]['reports'] = [];
                continue;
            }else{
                $reportTypesWithStatus[$key]['percentages'] = 0;
            }
                        
            if($flag == 1){   
                $totalReports += count($type['reports']);
                $reportTypesWithStatus1 = $totalReports;
            }else{
                $OtherCount = 0;
                foreach($type['reports'] as $report) {

                    if(!isset($lastReportDate)) {
                        $lastReportDate = $report['date'];
                        $firstReport = true;
                        //$firstReportDate = $report['date'];
                    }
                    if(!isset($firstReportDate)){
                        $firstReportDate = $report['date'];
                    }
                   // echo $firstReportDate; echo " ==== "; echo $lastReportDate; die;
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                    /*echo "<pre>";print_r($statuses);exit;*/
                    $report['info'] = $statuses['info'];
                    if (!isset($statuses['increment'])) dd($report);
                    if (!isset($reportInfo[$statuses['increment']])) {
                        $reportInfo[$statuses['increment']]=0;
                    }
                    $reportInfo[$statuses['increment']]++;
                    $reportInfo['total']++;
                    $newReports[$report['date-8601']] = $report;
                   
                    $lastReportDate = $report['date'];
                    $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo, $flag);

                    $chkDate = strtotime($lastReportDate);
                    $firstReport = false;
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    /*echo $report['report_id'];exit;*/
                    if ($report['report_id']=='9999.pdf') {
                        $report['report_id'] = '9999';
                    }
                    if($report['report_id'] == '9999'){

                        if(!isset($OtherlastReportDate)) {
                            $OtherlastReportDate = $report['date'];
                            $OtherfirstReport = true;
                            //$firstReportDate = $report['date'];
                        }
                        if(!isset($OtherfirstReportDate)){
                            $OtherfirstReportDate = $report['date'];
                        }
                        $OtherlastReportDate = $report['date'];
                        if(isset($OtherfirstReportDate)){
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));
                        }
                        $OtherfirstReport = false;
                        $OtherCount++ ;
                    }
                    
                }

              
                if ($report['report_id'] != '9999') {
                    $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
                }
                
                if($flag == 3){
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    //$reportTypesWithStatus1 = $fromDate."-".$toDate;                   
                    array_push($AuditPeriod3['startdate'], $fromDate);
                    array_push($AuditPeriod3['enddate'], $toDate);   
                    $reportTypesWithStatus1 = $AuditPeriod3;                   
                }elseif($flag == 4){
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod[$key], $fromDate);
                    array_push($AuditPeriod[$key], $toDate); 
                }elseif($flag == 5){
                    
                    $Compliance[$key] = $reportTypesWithStatus[$key]['percentages'];
                    
                }elseif($flag == 6){
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod6, $toDate); 
                }elseif($flag == 7){
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod7[$key], $fromDate);
                    array_push($AuditPeriod7[$key], $toDate);
                }elseif($flag == 8){
                    $Compliance8[$key] = $reportTypesWithStatus[$key]['percentages'];
                }elseif($flag == 9){
                    $toDate = date('d/m/Y', strtotime($OtherlastReportDate));
                    $reportTypesWithStatus1 = $OtherfromDate."-".$toDate;                   
                    /*array_push($AuditPeriod9['startdate'], $OtherfromDate);
                    array_push($AuditPeriod9['enddate'], $toDate);   
                    $reportTypesWithStatus1 = $AuditPeriod9;*/                   
                }elseif($flag == 10){
                    $reportTypesWithStatus1 = $OtherCount;
                }elseif($flag == 11){
                    $reportTypesWithStatus1 = $reportTypesWithStatus[$key]['percentages'];
                }else{
                    $reportTypesWithStatus1= $reportTypesWithStatus[$key]['percentages'];
                }
                unset($newReports);
                unset($firstReportDate);
                unset($lastReportDate);
                if($flag == 9){
                    unset($OtherfirstReportDate);
                    unset($OtherlastReportDate);

                }
            }

            if($flag == 2 || $flag == 0 || $flag == 11 || $flag == 12){  
                $total += $reportTypesWithStatus1;                 
            }
            $fDate = 0;
            
        }

        if($flag == 2 || $flag == 0 || $flag == 11 || $flag == 12){
            if($total>0){
                return $total/$rCount;
            }else{
                return 0;
            }
        }
        if($flag == 4){
            return $AuditPeriod;
        }
        if($flag==5){
           return $Compliance;
        }
        if($flag==6){
           return $AuditPeriod6;
        }
        if($flag==7){
           return $AuditPeriod7;
        }
        if($flag==8){
           return $Compliance8;
        }
        return $reportTypesWithStatus1;
    }


    protected function buildReportPercentagesDashboard($info, $flag)
    {   

        if($info['total'] == 0) {
            return 'no totals to calculate';
        }

        $ontime = round(number_format($info[self::STATUS_ONTIME] / $info['total'] *100, 2));
        $tolerance = round(number_format($info[self::STATUS_TOLERANCE] / $info['total'] *100, 2));
        $late = round(number_format($info[self::STATUS_LATE] / $info['total'] *100, 2));
        if($flag == 8 || $flag == 5){
            $percentage = round(number_format(($info[self::STATUS_ONTIME]+$info[self::STATUS_TOLERANCE]) / $info['total'] *100, 2));
        }
        //return 'Ontime: '. $ontime .'%; Tolerance: '. $tolerance .'%; Late: '. $late .'%';
        if($flag == 1){
            return $info['total'];
        }else if($flag == 11){
            return $tolerance;
        }else if($flag == 12){
            return $late;
        }else if($flag == 8 || $flag == 5){
            return $percentage;
        }else{
            return  $ontime;
        }
    }

    public static function findLateReportsDashboard($mySiteId)
    {
        $reports = [];

        $sops = SiteOperationalProgram::find()->where(['site_id'=>$mySiteId])->all();
        foreach($sops as $sop) {
            if($status = $sop->compileAlertsDashboard()) {
                if(!$status) {
                    continue;
                }
                $reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,
                ];
            }
        }

        return $reports;
    }

    public function compileAlertsDashboard()
    {
        //var_dump($this->start_date);   

        if(!$this->clientSite || !$this->client) {
            return false;
        }

        // Prevent undetermined reports (9999) from being included
        if($this->reportType->doctype_id >= 9000) {
            return false;
        }

        $path = $this->clientSite->directory;
        $reportTypeStr = '_'. $this->reportType->doctype_id;
        //$files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf | grep '. $reportTypeStr); // @#todo Remove - user for when reading file system
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($this->clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterForDocType($files, $reportTypeStr);

        $fileList = [];
        //$files = explode("\n", $files); // @todo remove - Used for when reading file system
        if(!isset($files[0]) || $files[0] == '') { // Don't include SOPs that have no files associated
            return false;
        }
        foreach($files as $file) {
            if($file == "") { 
                continue;
            }
            $file = $this->trimFilename($file);
            $file = $this->getReportAttributes($file);
            $fileList[$file[8601]] = $file;
        }
        ksort($fileList);

        $reportInfo = $this->determineIfLate(end($fileList), $this->reportInterval,$this->start_date);
        
        if($reportInfo['status'] == self::STATUS_LATE) {
            return $reportInfo;
        }

        return false;
    }
}
