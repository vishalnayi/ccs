<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "document".
 *
 * @property integer $id
 * @property integer $report_type_id
 * @property integer $site_id
 * @property integer $provider_id
 * @property string $filepath
 * @property string $filename
 * @property string $extension
 * @property string $date
 * @property string $created_at
 * @property string $updated_at
 */
class Document extends \common\models\BaseModel
{
    public $site_id;
    public $provider_id;
    public $existing_path;
    public $existing_filename;
    public $report_type_id;
    public $new_filename;
    public $datetime;

    public function attributes()
    {
        return array_merge(
            ['existing_path',
             'provider_id',
             'existing_filename',
             'new_path',
             'new_filename',
             'new_datetime',
        ]);
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'document';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['report_type_id', 'provider_id', 'site_id'], 'integer'],
            [['date','existing_path','existing_filename','new_path','new_filename','site_id', 'new_datetime'], 'safe'],
            [['filepath', 'filename', 'extension'], 'string', 'max' => 255],
        ];
    }

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios['move-document'] = ['existing_path', 'existing_filename', 'new_path', 'new_filename', 'new_datetime'];
        $scenarios['delete-document'] = ['existing_path', 'existing_filename'];

        return $scenarios;
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'report_type_id' => Yii::t('app', 'Report Type ID'),
            'site_id' => Yii::t('app', 'Site ID'),
            'provider_id' => Yii::t('app', 'Supplier ID'),
            'filepath' => Yii::t('app', 'Filepath'),
            'filename' => Yii::t('app', 'Filename'),
            'extension' => Yii::t('app', 'Extension'),
            'date' => Yii::t('app', 'Date'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    // @todo - move this method to models/Report and remove this class
    public function getReportPath($reportTypeDirectory)
    {
        return $reportTypeDirectory .'/'. date('F_Y', strtotime($this->new_datetime));
    }
}
