<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "client_site_report_category".
 *
 * @property integer $id
 * @property integer $client_site_id
 * @property integer $report_category_id
 * @property integer $provider_id
 * @property string $created_at
 * @property string $updated_at
 */
class ClientSiteReportCategory extends BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'client_site_report_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_site_id', 'report_category_id', 'provider_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'client_site_id' => Yii::t('app', 'Client Site ID'),
            'report_category_id' => Yii::t('app', 'Report Category ID'),
            'provider_id' => Yii::t('app', 'Provider ID'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getClientSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'client_site_id']);
    }

    public function getProvider()
    {
        return $this->hasOne(Provider::className(), ['id' => 'provider_id']);
    }

    public function getReportCategory()
    {
        return $this->hasOne(ReportCategory::className(), ['id' => 'report_category_id']);
    }
}
