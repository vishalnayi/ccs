<?php
namespace common\models;

use yii\base\Model;
/**
 * ClientListForm is the model for dropdown box for Client selection.
 */
class ClientListForm extends Model
{
    /**
     * @var UploadedFile file attribute
     */
    public $client_list_id;
    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['client_list_id'], 'required'],            
        ];
    }
}
