<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "document_discover_log_section".
 *
 * @property integer $id
 * @property integer $document_discover_log_id
 * @property string $filepath
 * @property string $text
 * @property string $created_at
 * @property string $updated_at
 */
class DocumentDiscoverLogSection extends \yii\db\ActiveRecord
{
    const S3_PATH = 'document-discover-log-section';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->appBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'document_discover_log_section';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['document_discover_log_id'], 'integer'],
            [['filepath'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'document_discover_log_id' => Yii::t('app', 'Document Discover Log ID'),
            'filepath' => Yii::t('app', 'Filepath'),
            'text' => Yii::t('app', 'Text'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function generatePath()
    {
        return self::S3_PATH .'/'. date('Y-m') .'/'. md5(microtime() . rand(1000,99999999)) .'.png';
    }
}
