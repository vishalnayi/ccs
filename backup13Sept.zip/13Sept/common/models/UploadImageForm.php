<?php
namespace common\models;

use yii\base\Model;
use yii\web\UploadedFile;
use yii\helpers\Url;

/**
 * UploadForm is the model behind the upload form.
 */
class UploadImageForm extends Model
{
    /**
     * @var UploadedFile file attribute
     */
    public $file;

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['file'], 'file',], 
        ];
    }
    public function upload()
    {
        if ($this->validate()) {
            // var_dump($this->file->basename);
            // var_dump($this->file->extension);
            // die;
            $name = $this->file->baseName . rand(1,10);
            $path = Url::to('@frontend/web/images/')  .$name .'.' . $this->file->extension;
            $p = Url::to('/images/',true)  .$name .'.' . $this->file->extension;
            $this->file->saveAs($path);
            return $p;
        } else {
            return false;
        }
    }
}
