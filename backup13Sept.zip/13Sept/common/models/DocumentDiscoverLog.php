<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "document_discover_log".
 *
 * @property integer $id
 * @property integer $report_type_id
 * @property string $from_address
 * @property string $subject
 * @property string $message_html
 * @property string $message_text
 * @property string $message_filename
 * @property string $message_document_text
 * @property string $created_at
 * @property string $updated_at
 */
class DocumentDiscoverLog extends BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'document_discover_log';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['report_type_id'], 'integer'],
            [['from_address'], 'string', 'max' => 255],
            [['subject', 'message_html', 'message_text', 'document_text'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'report_type_id' => Yii::t('app', 'Report Type ID'),
            'from_address' => Yii::t('app', 'From Address'),
            'subject' => Yii::t('app', 'Subject'),
            'message_html' => Yii::t('app', 'Message Html'),
            'message_text' => Yii::t('app', 'Message Text'),
            'message_filename' => Yii::t('app', 'Message Filename'),
            'message_document_text' => Yii::t('app', 'Message Document Text'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getReportType()
    {
        return $this->hasOne(ReportType::className(), ['id' => 'report_type_id']);
    }

    public function getProvider()
    {
        return $this->hasOne(Provider::className(), ['id' => 'provider_id']);
    }

    public function getSectionLogs()
    {
        return $this->hasMany(DocumentDiscoverLogSection::className(), ['document_discover_log_id' => 'id']);
    }
}
