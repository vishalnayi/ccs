<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use common\behaviors\SetClientBehavior;
use common\models\UserSiteAccess;
/**
 * This is the model class for table "node".
 *
 * @property integer $id
 * @property integer $parent_id
 * @property integer $client_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Client $client
 * @property Site[] $sites
 */
class Node extends BaseModel
{
    protected $bucket;
    protected $siteList;
    protected $existing_parent_id; // parent id before update

    public function behaviors()
    {
        return ArrayHelper::merge([
            SetClientBehavior::className(),
        ], parent::behaviors());
    }

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'node';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['parent_id'], 'integer'],
            /*[['name'], 'string', 'length' => [2 => 255]],*/
            [['name'], 'required', 'on' => 'create'],
            [['name'], 'match', 'pattern' => '/^[a-z0-9_-]+$/i','message' => 'Name limited to \'a-z 0-9 -_\' (no spaces or quotes)'],
            [['parent_id'], 'checkParent'],
        ];
    }

    public function checkParent($attribute, $params)
    {
        if($this->$attribute == null) {
            return true;
        }

        // @todo: remove call to user->id in this manner
        $parentNode = Node::find()->where(['id' => (int)$this->$attribute])->one();
        if ($this->id == $this->$attribute) {
            $this->addError($attribute, 'A node cannot be its own parent.');
        }
        if ($parentNode->client_id != Yii::$app->user->identity->client_id) {
            $this->addError($attribute, 'Cannot save this parent');
        }
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'parent_id' => 'Parent',
            'client_id' => 'Client ID',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    public function getParent()
    {
        if($this->parent_id == 0) {
            return null;
        }

        return $this->hasOne(Node::className(), ['id' => 'parent_id']);
    }

    public function getChildren()
    {
        return $this->hasMany(Node::className(), ['parent_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientSites()
    {
        return $this->hasMany(ClientSite::className(), ['node_id' => 'id']);
    }

    public function beforeSave($insert)
    {
        $this->parent_id = $this->parent_id != '' ? $this->parent_id : 0;

        parent::beforeSave($insert);

        return true;
    }

    public function findClientSites()
    {
        $this->addToSiteList($this->clientSites);

        $this->findClientSitesRecursive($this);

        return $this->siteList ? $this->siteList : [];
    }

     public function addToSiteList($sites)
    {
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
       
        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
        }
        foreach($sites as $site) {
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                if(in_array($site->id,$forceSites)){
                    $this->siteList[] = $site;
                }
            }else{
                $this->siteList[] = $site;
            }
        }
    }

    public function findClientSitesRecursive($node)
    {
        foreach($node->children as $child) {
            $this->addToSiteList($child->clientSites);
            $this->findClientSitesRecursive($child);
        }
    }

    public static function getNodeChildren($clientId, $parentId=0)
    {
        $nodetree = [];
        $nodes = Node::find()->where(['parent_id' => $parentId, 'client_id' => $clientId])->all();
        foreach($nodes as $node) {
            $nodetree[] = ['id' => 'node|'. $node->id,
                           'text' => $node->name,
                           'children' => $node->children != null || $node->clientSites ? true : false,
                           'type' => $node->parent_id == 0 ? 'root' : 'child',
            ];
        }
        $sites = ClientSite::getNodeChildren($clientId, $parentId);
        foreach($sites as $site) {
            $nodetree[] = $site;
        }
        return $nodetree;
    }

    /**
     * Get mirror path. In order to do this we need to recursively 
     * check parent's directories.
     *
     * @param Node $node
     * @param Node $includeThis - In some cases we want to include the originating node
     * @return array of nodes
     */
    public function getMirrorPath($node, $includeThis=null)
    {
        $path = 'RMP_mirror/';
        $path .= str_replace(' ', '_', $this->client->name) .'/';

        $thisNode[] = $node;
        $nodes = $this->getParentNode($node, []);
        $nodes = array_merge($thisNode, $nodes);
        $nodes = array_reverse($nodes);

        foreach ($nodes as $node) {
            if (!$node) {
                continue;
            }
            if (!isset($node->name)) dd($node);
            $path .= str_replace(' ', '_', $node->name) .'/';
        }

        if ($includeThis) {
            $path .= str_replace(' ', '_', $includeThis->name) .'/';
        }

        return $path;
    }

    protected function getParentNode($object, $nodes)
    {
        if (isset($object->parent_id) && $object->parent_id != 0) {
            $parent = Node::find()->where(['id' => $object->parent_id])->one();
            $nodes[] = $parent;
            $nodes = $this->getParentNode($object->parent, $nodes);
        }

        return $nodes;
    }

    public function afterSave($update, $changedAttributes)
    {
        $existingParentId = Yii::$app->request->post('Node')['existing_parent_id'];
        if ($this->parent_id != $existingParentId) {
            $s = ClientSite::findOne($this->id); // Need to reinstantiate
            $s3 = Yii::$app->s3Helper;
            $newInstance = ClientSite::findOne($this->id);
            $existingParentNode = Node::findOne($existingParentId);
            $existingPath = $this->getMirrorPath($existingParentNode, $this);
            $newPath = $this->getMirrorPath($this);
            $s3->movePathUpdated($existingPath,
                                 $newPath,
                                 $this->bucket
            );
        }
        parent::afterSave($update, $changedAttributes);
    }
}
