<?php 
namespace common\models;
use yii\base\Model;
use yii\web\UploadedFile;
use yii\helpers\Url;

class UploadDocument extends Model
{
    /**
     * @var UploadedFile[]
     */
    public $clientId;
    public $file;
    public $imageFiles;

    public function rules()
    {
        return [
        [['clientId'], 'required'],
        [['file'], 'file'], 
        ];
    }
    
    public function upload()
    {
        if ($this->validate()) { 
            foreach ($this->imageFiles as $file) {
                $file->saveAs('uploads/' . $file->baseName . '.' . $file->extension);
            }
            return true;
        } else {
            return false;
        }
    }
}
?>