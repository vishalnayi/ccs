<?php
namespace common\models;

use yii\base\Model;
use yii\web\UploadedFile;

/**
 * UploadForm is the model behind the upload form.
 */
class UploadForm extends Model
{
    /**
     * @var UploadedFile file attribute
     */
    public $file;
    public $report_category_id;
    public $provider_id;
    public $date;

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['file'], 'file','maxSize'=>12582912,'tooBig' => 'You can not upload file larger than 12MB'],
            [['report_category_id', 'provider_id'], 'integer'],
            [['report_category_id', 'provider_id'], 'required'],
        ];
    }
}
