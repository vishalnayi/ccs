<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "contacts".
 *
 * @property integer $id
 * @property integer $report_category_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class SiteContact extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'site_contact';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id','contact_id','site_id','sequence_no'], 'integer'],            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),         
            'contact_id' => Yii::t('app', 'Contact'),
            'site_id' => Yii::t('app', 'Site'),
            'sequence_no' => Yii::t('app', 'Sequence'),
            'display_dashboard' => Yii::t('app', 'On Dashboard'),
            'display_pdf' => Yii::t('app', 'On Pdf'),            
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    public function getSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    public function getContact()
    {
        return $this->hasOne(Contact::className(), ['id' => 'contact_id']);
    }

       
}
