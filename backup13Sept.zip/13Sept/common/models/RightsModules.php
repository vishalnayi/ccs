<?php
namespace common\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

/**
 * User model
 *
 * @property integer $id
 * @property string $module_name
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 */

class RightsModules extends BaseModel
{
    /*const STATUS_DELETED = 0;
    const STATUS_ACTIVE = 10;

    const ROLE_SUPER = 10;
    const ROLE_ADMIN = 9;
    const ROLE_USER = 6;*/

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'rights_modules';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['module_name'], 'string', 'length' => [3,255]],
            [['module_name'], 'unique', 'message' => 'The module name already exists'],
    //        [['terms_accepted']]
        ];
    }

    public function beforeSave($insert)
    {
        parent::beforeSave($insert);
        return parent::beforeSave($insert);
        //return true;
    }
}
