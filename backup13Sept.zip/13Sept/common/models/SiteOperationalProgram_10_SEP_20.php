<?php

namespace common\models;

use Yii;
use yii\base\DynamicModel;
use common\models\ClientSiteReportCategory;
use common\models\DocumentSearchTerm;
use common\models\Provider;

/**
 * This is the model class for table "site_report".
 *
 * @property integer $id
 * @property integer $site_id
 * @property integer $report_type_id
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property ReportType $reportType
 * @property ReportFrequency $reportFrequency
 */
class SiteOperationalProgram extends BaseModel
{
    const STATUS_ONTIME = 'on-time';
    const STATUS_TOLERANCE = 'tolerance';
    const STATUS_LATE = 'late';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'site_operational_program';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['site_id', 'report_type_id', 'report_interval_id', 'name','provider_ids'], 'required'],
            [['site_id', 'report_type_id', 'report_interval_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['additional_emails'], 'string'],
            [['start_date'], 'string'],            
            [['provider_ids'],  'number', 'numberPattern' => '/^\s*[-+]?[0-9]*[,]?[0-9]+([eE][-+]?[0-9]+)?\s*$/'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'site_id' => 'Site',
            'report_type_id' => 'Report Type',
            'name' => 'Name',
            'start_date' => 'Start Date',            
            'provider_ids'=>'Supplier',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    public function getClientSite()
    {
        return $this->hasOne(ClientSite::className(), ['id' => 'site_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReportType()
    {
        return $this->hasOne(ReportType::className(), ['id' => 'report_type_id']);
    }

    public function getReportInterval()
    {
        return $this->hasOne(ReportInterval::className(), ['id' => 'report_interval_id']);
    }

    public static function getNodeReports($clientId, $siteId)
    {
        $reportList = [];

        $reports = SiteOperationalProgram::find()->where(['site_id' => $siteId])->all();
        foreach($reports as $report) {
            $reportList[] = ['id' => $report->id .'_report',
                           'text' => $report->name,
                           'icon' => '/img/pdf.png',
                           'children' => false,
            ];
        }

        return $reportList;
    }

    public function searchSiteDirectory($clientId, $parent, $reportCategory)
    {
        $list = [];

        $siteId = $parent['id'];
        $path = $parent['path'];
        $catId = $parent['catId'];
        $reportCategoryId = $reportCategory ? $reportCategory->id : 0;

        $site = ClientSite::findOne($siteId);

        $s3 = Yii::$app->s3Helper;
        $reportCategoryPath = $reportCategory ? $reportCategory->path : Report::REPORT_CATEGORY_OTHERS;
        $directory = $site->directory .'-'. $reportCategoryPath;
        $files = $s3->directoryListing($directory . $path, $this->bucket, true);

        foreach ($files as $file) {
            if(preg_match('/\.((pdf)|(xls)|(doc))$/i', $file)) {
                $filePath = $directory . $path .'/'. $file;
                $directoryPath = $directory . $path;
                $fileAttr = self::getReportAttributes($file);
                $link = '/document/move-document?Document[site_id]='. $siteId .
                        '&Document[existing_path]='. $directoryPath .
                        '&Document[existing_filename]='. $file;
                $title = '<h3>'. $file .'</h3><p><a href="'. $link .'">Rename/move</a></p>';
                $list[$fileAttr['8601'] . $file] = ['id' => $file,
                                    'text' => $file,
                                    'icon' => '/img/'. $fileAttr['file_extension'] .'.png',
                                    'children' => false,
                                    'a_attr' => ['href' => '/site-operational-program/load-file?document='. $filePath .'&filename='. $file,
                                                 'target' => '_blank',
                                                 'title' => $title,
                                                 'rel' => 'tooltip',
                                                 'data-html' => true,
                                                 'data-delay' => '{"show": 0, "hide": 2500 }',
                                    ],
                ];
            } else {
                $list[] = ['id' => 'site|'. $siteId .'|cat|'. $reportCategoryId .'|'. $path .'/'. $file,
                           'text' => $file,
                           'icon' => '/img/dir.png',  
                           'children' => true,
                ];
                // TODO: Children is not true on Ben's version. may have issues at another time if deploying.
            }
        }

        ksort($list);
        $list = self::removeKeys($list);

        return $list;
    }

    /**
     * Check if path has any directories within
     */
    protected function checkForContents($folder)
    {
        $dh = opendir($folder);
        while (($path = readdir($dh)) !== false) {
            if($path !== '.' && $path != '..') {
                return true;
            }

            return false;
        }
    }

    public static function removeKeys($list)
    {
        $newList = [];

        foreach($list as $key=>$value) {
            $newList[] = $value;
        }

        return $newList;
    }

    public static function getReportAttributes($filename)
    {
        $file = explode('_', $filename);

        // if(count($file) !== 3) {
        //     return false;
        // }

        $ext = substr($filename, strrpos($filename, '.')+1, strlen($filename));
        \Yii::error('filename: '. $filename);
        \Yii::error('extension: '. $ext);

        if(count($file) == 3 || count($file) == 6 || count($file) == 5  ){
            return [
                '8601' => $file[0] . $file[1],
                'date' => $file[0],
                'time' => $file[1],
                'report_id' => $file[2],
                'searchTerm_id' => (count($file)==6) ? (isset($file[3])?$file[3]:""):"",
                'provider_id' => (count($file)== 6)?(isset($file[4])?$file[4]:""):(isset($file[3])?$file[3]:""),
                'client_id' => isset($file[5])?$file[5]:"",
                'file_extension' => $ext,
            ];
        }else{
            return false;
        }
    }

    public function formatDateTo8601($date, $time)
    {
        list($year, $month, $day, $time) = [
            substr($date, 4, 4),
            substr($date, 2, 2),
            substr($date, 0, 2),
            $time,
        ];

        return $year . $month . $day . $time;
    }

    public static function trimFilename($file)
    {
        $file = substr($file, strrpos($file, '/')+1);
        $file = substr($file, 0, strrpos($file, '.'));
        if(strpos($file, '(')) {
            $file = substr($file, 0, strrpos($file, '('));
        }

        return $file;
    }

    public static function getReportFormModel()
    {
        $model = DynamicModel::validateData(
                    ['client_id','date_from',
                     'date_to',
                     'client_site',
                     'node',
                     'report_types',
        ]);
        $model->addRule(['client_id','client_site','node'], 'integer');
        $model->addRule(['report_types'], 'required');
        $model->addRule(['date_from','date_to'], 'string');
        $model->addRule(['client_site'], function($attribute, $params) use($model) {
            if(!empty($model->client_site) && !empty($model->node)) {
                $model->addError($attribute, 'You cannot select both Client and Node');
            }
        });

        return $model;
    }

    // public static function getDynamicCreateModel()
    // {
    //     $model = DynamicModel::validateData(['supplier_id','category','category_id']);
    //     $model->addRule(['supplier_id'], 'integer');
    //     $model->addRule(['category'], 'required');
    //     $model->addRule(['category_id'], 'required');
    //     $model->addRule(['supplier_id'], 'required');

    //     return $model;
    // }

    /**
     * Find reports from S3 bucket for given path
     */
    public function findS3Reports($reportTypes, $clientSite, $dateRange)
    {
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }
  public function checkDishaDemo($site){
        echo "<pre>";
        print_r($site->getMirrorPath());
        die;
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        $files = self::filterDocs($files);
        // echo "<pre>";
        // print_r($files);
        // die;
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);    
                
            list($path, $name) = self::splitPath($file);
            $fileReportType = ReportType::findReportTypeFromFilename($name);

            $fileNameArr = explode('.', $name);
            $ext = $fileNameArr[1];
            $found = 0;
            //old file structure date_time_reporttype
           // count(explode('_', $fileNameArr[0])); 
            if(count(explode('_', $fileNameArr[0])) == 3) {     
                foreach ($site->reportCategories as $key => $categories) {
                    if($categories->id == $fileReportType->report_category_id){
                        $clientSiteReportCategories = ClientSiteReportCategory::find()->where(['client_site_id' => $site->id,'report_category_id'=>$fileReportType->report_category_id])->asArray()->all();
                     
                        $supplier_id = array_unique(array_column($clientSiteReportCategories, 'provider_id'));
                        
                        
                        if(isset($supplier_id) && count($supplier_id) == '1'){                        
                            $newFilename = $fileNameArr[0]."_".$supplier_id[0]."_".$site->client_id.".".$ext; 
                            $found = 1;
                        }else{
                            if(!isset($supplier_id) || count($supplier_id) > '1'){
                                
                                $docSearchTermCount=count($site->searchTerms);
                                if($docSearchTermCount == '1' && $site->searchTerms[0]->report_category_id== $categories->id){
                                  //  die('2');
                                   $newFilename = $fileNameArr[0]."_". $site->searchTerms[0]->provider_id."_".$site->client_id.".".$ext;  
                                   $found = 1;
                                }else{
                                    
                                    $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                        $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                        $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                        $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                        $data = file_get_contents($tmpFile);
                                        unlink($tmpFile);
                                        unlink($savefile);
                                        
                                        foreach ($site->searchTerms as $key => $dst) {
                                            
                                            if(strpos($data, $dst->search_term) !== FALSE)
                                            {
                                                $found = 1;
                                                 // found 'searchterm' assign provider
                                                $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                                break;
                                            }
                                           
                                        }
                                       if($found == 0){
                                        die('878');
                                       }

                                }
                            }else{
                                die('kai karo');
                            }
                        }
                      // echo " 6666 ";echo $newFilename;
                       // die;
                            try {
                                    $s3->movePathUpdated($path .'/'. $name,
                                         $path .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                         $site->getMirrorPath() .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    // echo "done";
                                    // die;
                                } catch (\yii\base\ErrorException $e) {
                                    echo "<pre>";
                                    print_r($e->getMessage());
                                    die;        
                                    //sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
                                    // Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
                            }
                            
                        


                    }else{
                        
                        $filesplitArr = explode('/',$file);
                        
                        if(isset($filesplitArr) && !empty($filesplitArr[0])){
                           
                            $category_name = explode('-', $filesplitArr[0]);
                            $reportCategory = ReportCategory::find()->where(['name'=>str_replace("_"," ",$category_name[1])])->all(); 
                          // echo "<pre>";
                          // print_r($category_name[1]);
                          // die;
                            $documentSearchTerm = DocumentSearchTerm::find()->where(['report_type_id'=>$fileReportType->id,'report_category_id'=>$reportCategory[0]->id])->all();
                            if(isset($documentSearchTerm) && !empty($documentSearchTerm)){
                                if(count($documentSearchTerm) == 1){
                                    $newFilename = $fileNameArr[0]."_".$documentSearchTerm[0]['provider_id']."_".$site->client_id.".".$ext; 
                                    $found = 1;
                                }else{
                                     //if count one then have provider from result else run foreach searchterm and find string from file content and decide for provider 
                                    $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                    $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                    $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                    $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                    $data = file_get_contents($tmpFile);
                                    unlink($tmpFile);
                                    unlink($savefile);
                                    $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                    foreach ($documentSearchTerm as $key => $dst) {
                                        
                                        if(strpos($data, $dst->search_term) !== FALSE)
                                        {
                                             // found 'searchterm' assign provider
                                            $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                            break;
                                        }
                                       
                                    }
                                }
                                

                            }else{
                                $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                $data = file_get_contents($tmpFile);
                                unlink($tmpFile);
                                unlink($savefile);
                                $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                foreach ($documentSearchTerm as $key => $dst) {
                                    
                                    if(strpos($data, $dst->search_term) !== FALSE)
                                    {
                                         // found 'searchterm' assign provider
                                        $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                        break;
                                    }
                                   
                                }
                            }
                            echo " 7777 "; echo $newFilename;
                        die;
                            try {
                                    $s3->movePathUpdated($path .'/'. $name,
                                         $path .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                         $site->getMirrorPath() .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    // echo "done";
                                    // die;
                                } catch (\yii\base\ErrorException $e) {
                                    echo "<pre>";
                                    print_r($e->getMessage());
                                    die;        
                                    //sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
                                    // Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
                                }
                           
                        }
                     
                    }
                }
            }else{
               // die('here');
            } 
           //   echo "<pre>";
           //  print_r($fileAttr);
           // echo "  name ===== "; print_r($report_type_id);
           //  die;
        }
        //die;
        // echo "<pre>";
        // print_r($files);
        // die;
        
        // $copy = $s3->clonePath('Ahmedabad-cooling_towers','Ahmedabad-cooling_towers_copy','nextcloud-prod');
        // $files = $s3->directoryListing('Ahmedabad-cooling_towers_copy','nextcloud-prod');

        // echo "<pre>";
        // print_r($files);
        // die;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        return $files;
    }
    public function renameCBREClient($site,$client_id){
        $s3 = Yii::$app->s3Helper;
        $dirs = $s3->listDirs($site->bucket);
        echo "<pre>";
            print_r(array_keys($dirs));
        die;        
        $files = $s3->directoryListing($site->directory,$site->bucket);
        $files = self::filterDocs($files);
        
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            // echo $file." ======";  
            $fileArr =  explode('_',$fileShort); 
            $file_report_id = $fileArr[2];
            // echo "<pre>"; 
            // print_r($fileAttr);
            //die;
            $report_ids = [];   
            list($path, $name) = self::splitPath($file);
            $fileReportType = ReportType::findReportTypeFromFilename($name);
           
                $fileNameArr = explode('.', $name);
                $ext = $fileNameArr[1];
                $found = 0;
               
            //old file structure date_time_reporttype
           // count(explode('_', $fileNameArr[0])); 
               // if(count(explode('_', $fileNameArr[0])) == 3) {  
                $newNameArr = [];
                $newNameArr = explode('_', $fileNameArr[0]);
                $report_ids = ['1001'];
                if(in_array($file_report_id, $report_ids)){
                    $newFilename = $newNameArr[0].'_'.$newNameArr[1].'_'.$newNameArr[2]."_31_".$client_id.".".$ext;
                //}
                // else{
                //     $newFilename = $newNameArr[0].'_'.$newNameArr[1].'_'.$newNameArr[2]."_7_".$client_id.".".$ext;
                // } 
                    
                    try {
                            $s3->movePathUpdated($path .'/'. $name,
                                 $path .'/'. $newFilename,
                                 $site->bucket 
                            );
                            $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                 $site->getMirrorPath() .'/'. $newFilename,
                                 $site->bucket 
                            );
                            // echo "done";
                            // die;
                        } catch (\yii\base\ErrorException $e) {
                            echo "<pre>";
                            print_r($e->getMessage());
                            die;  
                        }
                //}
        }
    }
    //die;
        return $files;
     }
      public function checkDishaDemo_new($site){
        // echo "<pre>";
        // print_r($site->bucket);
        // die;
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        $files = self::filterDocs($files);
        
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);    
                
            list($path, $name) = self::splitPath($file);
            $fileReportType = ReportType::findReportTypeFromFilename($name);

            $fileNameArr = explode('.', $name);
            $ext = $fileNameArr[1];
            $found = 0;
            //old file structure date_time_reporttype
           // count(explode('_', $fileNameArr[0])); 
            if(count(explode('_', $fileNameArr[0])) == 3) {     
                foreach ($site->reportCategories as $key => $categories) {
                    if($categories->id == $fileReportType->report_category_id){
                        $clientSiteReportCategories = ClientSiteReportCategory::find()->where(['client_site_id' => $site->id,'report_category_id'=>$fileReportType->report_category_id])->asArray()->all();
                     
                        $supplier_id = array_unique(array_column($clientSiteReportCategories, 'provider_id'));
                        
                        // echo "<pre>";
                        // print_r($supplier_id);
                        // die;
                        if(isset($supplier_id) && count($supplier_id) == '1'){                        
                            $newFilename = $fileNameArr[0]."_".$supplier_id[0]."_".$site->client_id.".".$ext; 
                             $found = 1;
                        }else{
                            if(!isset($supplier_id) || count($supplier_id) > '1'){
                                
                                $docSearchTermCount=count($site->searchTerms);
                                if($docSearchTermCount == '1' && $site->searchTerms[0]->report_category_id== $categories->id){
                                   // die('2');
                                   $newFilename = $fileNameArr[0]."_". $site->searchTerms[0]->provider_id."_".$site->client_id.".".$ext;  
                                    $found = 1;
                                }else{
                                    
                                    $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                        $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                        $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                        $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                        $data = file_get_contents($tmpFile);
                                        unlink($tmpFile);
                                        unlink($savefile);
                                        
                                        foreach ($site->searchTerms as $key => $dst) {
                                            
                                            if(strpos($data, $dst->search_term) !== FALSE)
                                            {
                                                $found = 1;
                                                 // found 'searchterm' assign provider
                                                $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                                break;
                                            }
                                           
                                        }

                                }
                            }else{
                                die('kai karo');
                            }
                        }
                        //-----------------------------------------------------------
                        if($found == 0){
                        $filesplitArr = explode('/',$file);
                        
                        if(isset($filesplitArr) && !empty($filesplitArr[0])){
                           
                            $category_name = explode('-', $filesplitArr[0]);
                            //echo "<pre>"; print_r($category_name); die;
                            if(str_replace("_"," ",$category_name[1]) == 'Other rc'){
                                continue;
                            }
                            $reportCategory = ReportCategory::find()->where(['name'=> str_replace("_"," ",$category_name[1])])->all();
                            //->createCommand()->getRawSql();
                            //->all();
                            //
                          // echo "<pre>";
                          // print_r($reportCategory);
                          // die;
                            $documentSearchTerm = DocumentSearchTerm::find()->where(['report_type_id'=>$fileReportType->id,'report_category_id'=>$reportCategory[0]->id])->all();
                            if(isset($documentSearchTerm) && !empty($documentSearchTerm)){
                                if(count($documentSearchTerm) == 1){
                                    $newFilename = $fileNameArr[0]."_".$documentSearchTerm[0]['provider_id']."_".$site->client_id.".".$ext; 
                                }else{
                                     //if count one then have provider from result else run foreach searchterm and find string from file content and decide for provider 
                                    //die('here');
                                    $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                    $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                    $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                    $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                    $data = file_get_contents($tmpFile);

                                    unlink($tmpFile);
                                    unlink($savefile);
                                    $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                    
                                    foreach ($documentSearchTerm as $key => $dst) {
                                        
                                        if(strpos($data, $dst->search_term) !== FALSE)
                                        {
                                             // found 'searchterm' assign provider
                                            $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                            break;
                                        }
                                       
                                    }
                                }
                                

                            }else{
                                $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                $data = file_get_contents($tmpFile);

                                unlink($tmpFile);
                                unlink($savefile);
                                $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                foreach ($documentSearchTerm as $key => $dst) {
                                    
                                    if(strpos($data, $dst->search_term) !== FALSE)
                                    {
                                         // found 'searchterm' assign provider
                                        $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                        break;
                                    }
                                   
                                }
                            }
                         
                            
                           
                        }
                    }
                        //-----------------------------------------------------------
                     // echo $file; die;
                      if(!isset($newFilename)){
                        // store file to local storage convert it to image and then find text from image
                        $savefile = '/tmp/'. md5(microtime()) .'.'.$ext;
                        $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                        $savefile = $savefile."[0]";
                        // echo "<pre>";
                        // print_r($savefile);
                        // die;
                         $image = new \Imagick();
                        $image->setResolution(300, 300);
                $image->readImage($savefile);
                $image->setImageAlphaChannel(\Imagick::ALPHACHANNEL_REMOVE);
                $image->adaptiveResizeImage(1080, 1920);
                $image->setImageFormat('png');
                // if ($docType == 'doc') {
                //     $image->setIteratorIndex(0); // Load first page - defaults to last - Seems to increase resulting image size
                // }
                //$image->writeImage('writeImage.jpg');
                file_put_contents('/tmp/writeImage', $image);
                        // $im = new \Imagick($savefile); $im->setImageFormat('jpg');  header('Content-Type: image/jpeg');
                        // $image = '/tmp/writeImage.jpg';
                        // file_put_contents($image, $im);
                        // //$im->writeImage('/tmp/writeImage.jpg');
                        $documentRetriever = Yii::$app->documentRetriever;
                        $data = $documentRetriever->extractTextFromImage('/tmp/writeImage.png');
                        
                        echo "<pre>";
                        print_r($data);
                        die;
                       
                       // unlink($outputFilename);
                        $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                        foreach ($documentSearchTerm as $key => $dst) {
                            
                            if(strpos($data, $dst->search_term) !== FALSE)
                            {
                                 // found 'searchterm' assign provider
                                $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                break;
                            }
                           
                        }


                      }
                            try {
                                    $s3->movePathUpdated($path .'/'. $name,
                                         $path .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                         $site->getMirrorPath() .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    // echo "done";
                                    // die;
                                } catch (\yii\base\ErrorException $e) {
                                    echo "<pre>";
                                    print_r($e->getMessage());
                                    die;        
                                    //sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
                                    // Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
                            }
                            
                        


                    }else{
                        //--------------------------------------------------------------
                        $filesplitArr = explode('/',$file);
                        
                        if(isset($filesplitArr) && !empty($filesplitArr[0])){
                           
                            $category_name = explode('-', $filesplitArr[0]);
                            $reportCategory = ReportCategory::find()->where(['name'=> str_replace('_', ' ', $category_name[1])])->all(); 

                            if(str_replace("_"," ",$category_name[1]) == 'Other rc'){
                                continue;
                            }

                            $documentSearchTerm = DocumentSearchTerm::find()->where(['report_type_id'=>$fileReportType->id,'report_category_id'=>$reportCategory[0]->id])->all();
                            if(isset($documentSearchTerm) && !empty($documentSearchTerm)){
                                if(count($documentSearchTerm) == 1){
                                    $newFilename = $fileNameArr[0]."_".$documentSearchTerm[0]['provider_id']."_".$site->client_id.".".$ext; 
                                }else{
                                     //if count one then have provider from result else run foreach searchterm and find string from file content and decide for provider 
                                    $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                    $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                    $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                    $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                    $data = file_get_contents($tmpFile);
                                    unlink($tmpFile);
                                    unlink($savefile);
                                    $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                    foreach ($documentSearchTerm as $key => $dst) {
                                        
                                        if(strpos($data, $dst->search_term) !== FALSE)
                                        {
                                             // found 'searchterm' assign provider
                                            $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                            break;
                                        }
                                       
                                    }
                                }
                                

                            }else{
                                $savefile = '/tmp/'. md5(microtime()) .'.txt';
                                $doc = $s3->saveFiletoLocal($file, $site->bucket,$savefile);
                                $tmpFile = '/tmp/'. md5(microtime()) .'.txt';
                                $text = system('pdf2txt -o '. $tmpFile .' "'. $savefile .'"');
                                $data = file_get_contents($tmpFile);
                                unlink($tmpFile);
                                unlink($savefile);
                                $documentSearchTerm = DocumentSearchTerm::find()->where(['report_category_id'=>$reportCategory[0]->id])->all();
                                foreach ($documentSearchTerm as $key => $dst) {
                                    
                                    if(strpos($data, $dst->search_term) !== FALSE)
                                    {
                                         // found 'searchterm' assign provider
                                        $newFilename = $fileNameArr[0]."_".$dst->provider_id."_".$site->client_id.".".$ext; 
                                        break;
                                    }
                                   
                                }
                            }
                        //     echo " 7777 "; echo $newFilename;
                        // die;
                            try {
                                    $s3->movePathUpdated($path .'/'. $name,
                                         $path .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    $s3->movePathUpdated($site->getMirrorPath() .'/'. $name,
                                         $site->getMirrorPath() .'/'. $newFilename,
                                         $site->bucket 
                                    );
                                    // echo "done";
                                    // die;
                                } catch (\yii\base\ErrorException $e) {
                                    echo "<pre>";
                                    print_r($e->getMessage());
                                    die;        
                                    //sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
                                    // Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
                                }
                           
                        }
                    //------------------------------------------------------------------ 
                    }
                }
            }else{
               // die('here');
            } 
           //   echo "<pre>";
           //  print_r($fileAttr);
           // echo "  name ===== "; print_r($report_type_id);
           //  die;
        }
        //die;
        // echo "<pre>";
        // print_r($files);
        // die;
        
        // $copy = $s3->clonePath('Ahmedabad-cooling_towers','Ahmedabad-cooling_towers_copy','nextcloud-prod');
        // $files = $s3->directoryListing('Ahmedabad-cooling_towers_copy','nextcloud-prod');

        // echo "<pre>";
        // print_r($files);
        // die;
        $files = $s3->directoryListing($site->directory,$site->bucket);
        return $files;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterDocs($files)
    {
        $fileList = [];

        $docTypes = ['pdf', 'doc', 'xls'];

        foreach ($files as $file) {
            $ext = getFileExtension($file);
            if (in_array($ext, $docTypes)) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Only return paths that have valid document types
     */
    protected function filterForDocType($files, $docType)
    {
        $fileList = [];

        foreach ($files as $file) {
            if (preg_match("/${docType}/", $file) == 1) {
                $fileList[] = $file;
            }
        }

        return $fileList;
    }

    /**
     * Find files from local file system
     * @todo: This method can be removed once we're satisfied the call to s3 is working as required.
     */
    public function findReports($reportTypes, $clientSite, $dateRange)
    {
        $files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $clientSite->directory ." -iname '*.pdf' -or -iname '*.doc' -or -iname '*.xls'");
        $files = explode("\n", $files);
        $files = $this->filterFiles($reportTypes, $files, $clientSite, $dateRange);

        return $files;
    }

    public function splitPath($file)
    {
        $path = substr($file, 0, strrpos($file, '/'));
        $filename = substr($file, strrpos($file, '/')+1);

        return [$path, $filename];
    }

    protected function filterFiles($reportTypes, $files, $clientSite, $dateRange)
    {
        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            list($path, $name) = $this->splitPath($file);

            // Only add report if it belongs to a selected report type
            if(!array_key_exists($fileAttr['report_id'], $reportTypes)) {
                continue;
            }

            if(!$this->isWithinDates($fileAttr, $dateRange)) {
                continue;
            }

            $reportTypes[$fileAttr['report_id']]['reports'][$fileAttr['8601'].$fileShort] = 
                        array_merge($fileAttr, [
                            'string' => $fileShort,
                            'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                            'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                            'filePath' => $file,
                            'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                            'filename' => $name,
                            'path' => $path,
                            'clientSiteId' => $clientSite->id,
                        ]);
        }

        $reportTypes = $this->orderReportTypes($reportTypes);
        if (isset($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
            $reportTypes = $this->retrieveStatusData($clientSite->client_id, $reportTypes);
        }

        return $reportTypes;
    }

    public function buildOthersReportType($clientSite)
    {
        return [
                'name' => 'Others',
                'clientSite' => $clientSite->attributes,
                'reportInterval' => [
                    'id' => 1,
                    'name' => '',
                    'interval_length' => 'len',
                    'tolerance' => 'toler',
                ],
        ];
    }

    protected function retrieveStatusData($clientId, $reportTypes)
    {
        $reportTypesWithStatus = $reportTypes;

        foreach($reportTypes as $key=>$type) {

            $reportInfo = [self::STATUS_ONTIME => 0,
                           self::STATUS_TOLERANCE => 0,
                           self::STATUS_LATE => 0,
                           'total' => 0,
            ];

            $reportTypesWithStatus[$key]['statuses'] = [
                         'last_report_due' => '--2',
                         'last_report_class' => '--3',
                         'percentages' => '--p',
                         'status_bar' => ['status_string' => '', 'status_class' => ''],
            ];

            if(!isset($type['reports'])) {
                $reportTypesWithStatus[$key]['reports'] = [];
                continue;
            }

            foreach($type['reports'] as $report) {
                if(!isset($lastReportDate)) {
                    $lastReportDate = $report['date'];
                    $firstReport = true;
                }
                $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                $report['info'] = $statuses['info'];
                if (!isset($statuses['increment'])) dd($report);
                $reportInfo[$statuses['increment']]++;
                $reportInfo['total']++;
                $newReports[$report['date-8601']] = $report;
                $lastReportDate = $report['date'];
                $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentages($reportInfo);
                $firstReport = false;
            }
            if ($report['report_id'] != '9999') {
                $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
            }
            $reportTypesWithStatus[$key]['reports'] = $newReports;
            unset($newReports);
            unset($lastReportDate);
        }

        return $reportTypesWithStatus;
    }

    protected function buildReportPercentages($info)
    {
        if($info['total'] == 0) {
            return 'no totals to calculate';
        }

        $ontime = round(number_format($info[self::STATUS_ONTIME] / $info['total'] *100, 2));
        $tolerance = round(number_format($info[self::STATUS_TOLERANCE] / $info['total'] *100, 2));
        $late = round(number_format($info[self::STATUS_LATE] / $info['total'] *100, 2));

        return 'Ontime: '. $ontime .'%; Tolerance: '. $tolerance .'%; Late: '. $late .'%';
    }

    protected function buildReportStatusBarString($statuses, $tolerance)
    {
        $toleranceTime = strtotime('+'. $tolerance, $statuses['next_report_due']);
        if($statuses['next_report_due'] > time()) {
            $statusClass = self::STATUS_ONTIME; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        } elseif($toleranceTime < time()) {
            $statusClass = self::STATUS_LATE; 
            $statusString = 'Last report on '. date('j/m/Y', $statuses['next_report_due']) .' overdue';
        } else {
            $statusClass = self::STATUS_TOLERANCE; 
            $statusString = 'Next report due '. date('j/m/Y', $statuses['next_report_due']);
        }

        return [
            'status_string' => $statusString,
            'status_class' => 'status-'. $statusClass,
        ];
    }

    /**
     * Determine if report is late
     *
     * @param string $report shortend filename
     * @param ReportInterval $interval
     * 
     * @return string
     */
    protected function determineIfLate($report, $interval)
    {
        $date = $this->convertDateFromFileFormat($report['date']);
        $time = $this->convertTimeFromFileFormat($report['time']);
        $reportDate = strtotime($date .' '. $time);
        $reportDueDate = strtotime('+'. $interval->interval_length, $reportDate);
        $toleranceDate = strtotime('+'. $interval->tolerance, $reportDueDate);
        $now = time();
        if($reportDueDate > $now) {
            $status = self::STATUS_ONTIME;
        } elseif($toleranceDate > $now) {
            $status = self::STATUS_TOLERANCE;
        } else {
            $status = self::STATUS_LATE;
        }

        return ['status' => $status,
                'reportDate' => $this->convertTimeToStr($reportDate),
                'dueDate' => $this->convertTimeToStr($reportDueDate),
                'toleranceDate' => $this->convertTimeToStr($toleranceDate),
        ];
    }

    protected function getReportStatus($report, $type, $lastReportDate, $firstReport)
    {
        $attrs = self::getReportAttributes($report['string']);
        if ($attrs['report_id'] == '9999') {
            $status = 'N/A';    
            $delta = '';
            $increment = 'on-time';
            $reportDueDate = '';
            $nextReportDueDate = '';
        } else {
            $reportDate = strtotime($report['date'] .' '. $report['time']);
            $lastReportDate = strtotime($lastReportDate);

            if($firstReport && isset($type['start_date']) && $type['start_date'] != NULL) {
                $start_date = strtotime($type['start_date']);

                $reportDueDate = strtotime('+'. $type['reportInterval']['interval_length'], $start_date);

            }else{                
                $reportDueDate = isset($type['reportInterval']['interval_length'])?strtotime('+'. $type['reportInterval']['interval_length'], $lastReportDate):"";
            }
            $nextReportDueDate = isset($type['reportInterval']['interval_length'])? strtotime('+'. $type['reportInterval']['interval_length'], $reportDate):"";
            $toleranceDate = isset($type['reportInterval']['tolerance'])?strtotime('+'. $type['reportInterval']['tolerance'], $reportDueDate):"";
            $delta = $this->calculateDaysDifference($reportDate, $lastReportDate);
            // echo "<pre>";
            // echo " Report Date " .$reportDate. " ============= ";
            // echo " Last Report Date " .$lastReportDate. " ============= ";
            // echo " Report Due Date " .$reportDueDate. " ============= ";
            // echo " Next Report Date " .$nextReportDueDate. " ============= ";
            // echo " Tolerance Date " .$toleranceDate. " ============= ";
            // echo " Delta " .$delta. " ============= ";
            // die;
            if($firstReport) {
                $delta = 'N/A';
            }
            if($reportDueDate != "" && $toleranceDate != ""){
                if($reportDate < $reportDueDate) {
                    $status = self::STATUS_ONTIME;
                    $increment = self::STATUS_ONTIME;
                } elseif($reportDate < $toleranceDate) {
                    $status = self::STATUS_TOLERANCE;
                    $increment = self::STATUS_TOLERANCE;
                } else {
                    $status = self::STATUS_LATE;
                    $increment = self::STATUS_LATE;
                }
            }else{
                $status = "";
                $increment = "";
                $delta = "N/A";
            }
        }

        return ['info' => ['status' => $status,
                           'delta' => $delta,
                'status-class' => 'status-'. $status,
               ],           
               'increment' => $increment, 
               'last_report_due' => $reportDueDate,
               'next_report_due' => $nextReportDueDate,
        ];
    }

    /**
     * Calculate in days the difference between two reports
     *
     * @param string $currentReport in epoch
     * @param string $lastReport in epoch
     *
     * @return string
     */
    protected function calculateDaysDifference($current, $last)
    {
        $diff = $current - $last;
        $time = floor($diff / 86400);

        return $time;
    }

    protected function orderReportTypes($reportTypes)
    {
        $orderedReportTypes = $reportTypes;

        foreach($reportTypes as $key=>$type) {
            if(!isset($type['reports'])) {
                continue;
            }
            foreach($type['reports'] as $report) {
                if(count($report) === 0) {
                    continue;
                }
                $newReports[$report['date-8601']] = $report;
            }
            ksort($newReports);
            $orderedReportTypes[$key]['reports'] = $newReports;
            unset($newReports);
        }

        return $orderedReportTypes;
    }

    protected function getReportInfo($reportId, $clientSiteId)
    {
        $report = SiteOperationalProgram::find()->where(['site_id' => $clientSiteId, 'report_type_id' => $reportTypeId]);
    }

    protected function isWithinDates($fileAttr, $dateRange)
    {
        if($dateRange['date_from'] == '' || $dateRange['date_to'] == '') {
            return true;
        }
    
        $date = $fileAttr['date'];
        $fileDate = $this->convertDateFromFileFormat($date);

        if($fileDate >= $dateRange['date_from'] &&
           $fileDate <= $dateRange['date_to']) {
            return true;
        }

        return false;
    }

    protected function convertDateFromFileFormat($date)
    {
        return substr($date, 0, 4) .'-'. substr($date, 4, 2) .'-'. substr($date, 6, 2);
    }

    protected function convertTimeFromFileFormat($time)
    {
        return substr($time, 0, 2) .':'. substr($time, 2, 2);
    }

    public static function findLateReports()
    {
        $reports = [];

        $sops = SiteOperationalProgram::find()->all();
        //$sops = SiteOperationalProgram::find()->where(['site_id'=>163])->all();

        foreach($sops as $sop) {
            
            if($status = $sop->compileAlerts()) {
                if(!$status) {
                    continue;
                }
                $reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status
                ];
            }
        }

        return $reports;
    }

    public function compileAlerts()
    {
        // echo " 1 ";
        // echo "<pre>";
        // print_r($this->client);
        // die;
        if(!$this->clientSite || !$this->client) {
            return false;
        }
       // echo " 2 ";
        // Prevent undetermined reports (9999) from being included
        if($this->reportType->doctype_id >= 9000) {
            return false;
        }
        // echo " 3 ";
        // $path = $this->clientSite->directory;
        // echo  $path;
        // die;
        $reportTypeStr = '_'. $this->reportType->doctype_id;
        //$files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf | grep '. $reportTypeStr); // @#todo Remove - user for when reading file system
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($this->clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterForDocType($files, $reportTypeStr);
        // echo "<pre>";
        // print_r($this->clientSite->directory);
        // die;
        $fileList = [];
        //$files = explode("\n", $files); // @todo remove - Used for when reading file system
        if(!isset($files[0]) || $files[0] == '') { // Don't include SOPs that have no files associated
            return false;
        }
        foreach($files as $file) {
            if($file == "") { 
                continue;
            }
            $file = $this->trimFilename($file);
            $file = $this->getReportAttributes($file);
            $fileList[$file[8601]] = $file;
        }
        ksort($fileList);

        $reportInfo = $this->determineIfLate(end($fileList), $this->reportInterval);
        //var_dump($this->clientSite->id);
        //var_dump($reportInfo);
        //die;
        if(isset($file['provider_id']) && !empty($file['provider_id'])){
            $pid = $file['provider_id'];
            $provider = Provider::find()->select(["name"])->where(['id'=>$pid])->all();
            $provider_name = $provider[0]->name;
        }else{
            $provider_name = "";
        }
        
        $reportInfo['providers'] = $provider_name;
        
        if($reportInfo['status'] == self::STATUS_LATE || $reportInfo['status'] == self::STATUS_TOLERANCE) {
            return $reportInfo;
        }else{
            $model = SiteOperationalProgram::findOne($this->id);

            $model->is_sent_primary = 0;
            $model->secondary_alarm_date = NULL;
            $model->is_sent_secondary = 0;
            $model->is_sent_territory = 0;
            $model->territory_alarm_date = NULL;   
            $model->save();

        }

        return false;
    }

    /**
     * Get client for this report
     *
     * @return Client
     */
    public function getClient()
    {
        if(isset($this->clientSite) 
            && isset($this->clientSite->node)
            && isset($this->clientSite->node->client)) {
                return $this->clientSite->node->client;
            } else {
                return false;
            }
    }

    public static function sendAlerts($reports)
    {
        foreach($reports as $client) {
            return $this->renderPartial('email-alerts', ['client' => $client]);
        }
    }

    // Dashboard Functions
 /**
     * Find reports from S3 bucket for given path same as findS3ReportsDashboard in this file just to get sorted data for getReportsStaticsDashboard from clientSite model
     */
    public function findS3ReportsDashboardStatics($reportTypes, $clientSite, $flag=5, $dateRange)
    {
        if(empty($reportTypes)){
            $canWihoutPrimaryAlarm = 1;
        }
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);       

        $files = $this->filterDocs($files);

        //$files = $this->filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange);
        //filterFilesDashboard start ***************************************************** 
                foreach($files as $file) {
                    $fileShort = self::trimFilename($file);
                    $fileAttr = self::getReportAttributes($fileShort);

                    list($path, $name) = $this->splitPath($file);

                    // Only add report if it belongs to a selected report type
                    if(!isset($canWihoutPrimaryAlarm)){
                        if(!array_key_exists($fileAttr['report_id'], $reportTypes)) {
                            continue;
                        }
                    }

                    if(!$this->isWithinDates($fileAttr, $dateRange)) {
                        continue;
                    }

                    $reportTypes[$fileAttr['report_id']]['reports'][$fileAttr['8601'].$fileShort] = 
                                array_merge($fileAttr, [
                                    'string' => $fileShort,
                                    'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                                    'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                                    'filePath' => $file,
                                    'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                                    'filename' => $name,
                                    'path' => $path,
                                    'clientSiteId' => $clientSite->id,
                                ]);
                }
                
                
                $reportTypes = $this->orderReportTypes($reportTypes);                
                if (isset($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
                    $clientId = $clientSite->client_id;
                   // $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
                    //*****************************************retrieveStatusDataDashboard*************************
                        //        protected function retrieveStatusDataDashboard($clientId,$reportTypes,$flag,$dateRange){
                        $reportTypesWithStatus = $reportTypes;        
                        $reportTypesWithStatus1 = $reportTypes;
                        $totalReports = 0;
                        $total = 0;
                        $rCount =  count($reportTypes);
                        $fDate = 1;
                        $AuditPeriod3['startdate'] = array();
                        $AuditPeriod3['enddate'] = array();
                        $AuditPeriod9['startdate'] = array();
                        $AuditPeriod9['enddate'] = array();
                        $AuditPeriod6 = array();
                        $AuditPeriod7 = array();
                        $AuditPeriod = array();
                        $Compliance = array();
                        $Compliance8 = array();

                foreach($reportTypes as $key=>$type) {
          
                $reportInfo = [self::STATUS_ONTIME => 0,
                               self::STATUS_TOLERANCE => 0,
                               self::STATUS_LATE => 0,
                               'total' => 0,
                ];

                $reportTypesWithStatus[$key]['statuses'] = [
                             'last_report_due' => '--2',
                             'last_report_class' => '--3',
                             'percentages' => '--p',
                             'status_bar' => ['status_string' => '', 'status_class' => ''],
                ];

                if(!isset($type['reports'])) {
                    $reportTypesWithStatus[$key]['reports'] = [];
                    $reportTypesWithStatus[$key]['suppliers'] = [];
                    $reportTypesWithStatus[$key]['suppliersReports'] = [];
                    continue;
                }else{
                    $reportTypesWithStatus[$key]['percentages'] = 0;
                    $reportTypesWithStatus[$key]['supplier_percentages'] = 0;  
                }
                        
                $OtherCount = 0;
                $supplier = []; 
                $supplierReportIds = [];    
                $supplierR = array();
                foreach($type['reports'] as $report) {

                    if(!isset($lastReportDate)) {
                        $lastReportDate = $report['date'];
                        $firstReport = true;
                        //$firstReportDate = $report['date'];
                    }
                    if(!isset($firstReportDate)){
                        $firstReportDate = $report['date'];
                    }

                    if(!in_array($report['provider_id'], $supplier) && !empty($report['provider_id'])){ 
                        array_push($supplier,$report['provider_id']);                           
                        $supplierR[$report['provider_id']] = array();   
                        array_push($supplierR[$report['provider_id']], $report);    
                    }elseif(!empty($report['provider_id'])){    
                        array_push($supplierR[$report['provider_id']], $report);    
                    }
                   
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);

                    $report['info'] = $statuses['info'];
                    if (!isset($statuses['increment'])) dd($report);
                    if(isset($reportInfo[$statuses['increment']])){
                        $reportInfo[$statuses['increment']]++  ;
                    }
                    $reportInfo['total']++;
                    $newReports[$report['date-8601']] = $report;            
                    
                    $lastReportDate = $report['date'];
                    $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo, $flag);
                   // ***************my addition*****************
                    $reportTypesWithStatus[$key]['lastReportDate'] = $lastReportDate;
                    $reportTypesWithStatus[$key]['info'] = $reportInfo;
                  //  ****************my addition end**********
                    $chkDate = strtotime($lastReportDate);
                    $firstReport = false;
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }

                    if($report['report_id'] == '9999'){

                        if(!isset($OtherlastReportDate)) {
                            $OtherlastReportDate = $report['date'];
                            $OtherfirstReport = true;
                            //$firstReportDate = $report['date'];
                        }
                        if(!isset($OtherfirstReportDate)){
                            $OtherfirstReportDate = $report['date'];
                        }
                        $OtherlastReportDate = $report['date'];
                        if(isset($OtherfirstReportDate)){
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));
                        }
                        $OtherfirstReport = false;
                        $OtherCount++ ;
                    }
                    
                }

                //report type wise(for single report type i.e 1002) supplier and supplier reports                   
                $reportTypesWithStatus[$key]['supplier'] = $supplier;    
                $reportTypesWithStatus[$key]['supplier_reports'] = isset($supplierR)?$supplierR:""; 
                $supplierDetailByReportType = $this->retriveStatusDataForSupplier($supplier,$supplierR,$type);   
                $reportTypesWithStatus[$key]['supplier_info'] = $supplierDetailByReportType;

               
                if ($report['report_id'] != '9999') {
                    if(isset($type['reportInterval']['tolerance'])){
                        $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
                    }else{
                        $reportTypesWithStatus[$key]['status_bar'] = "";
                    }
                }
               
                if($flag == 5){
                    
                    $Compliance[$key] = $reportTypesWithStatus[$key]['percentages'];                 
                }
                unset($newReports);
                unset($firstReportDate);
                unset($lastReportDate);

            //}           
            $fDate = 0;            
        }
        // if($clientSite->id == "190"){
        //     echo "<pre>";
        //     print_r($reportTypesWithStatus);
        //     die;
        // }
        
        if($flag==5){
           // $reportTypes = $this->retrieveStatusDataDashboard() so $reportTypes = $reportTypesWithStatus
           $reportTypes = $reportTypesWithStatus;
          // return $reportTypesWithStatus;
        }
        
        //return $reportTypesWithStatus1;
    //}
       //*****************************************************************************************
                }
                // files = filterFilesDashboard() so return reportTypes assigned to files
                $files = $reportTypes;       
                //return $reportTypes; from filterFilesDashboard function
           
        //filterFilesDashboard end *****************************************************    
        return $files;
    }

    protected function retriveStatusDataForSupplier($suppliers,$suppliersReports,$type){    
        $supplierWithStatus = array();  
        foreach($suppliers as $key=>$supplier) {    
                    
                $reportInfo = [self::STATUS_ONTIME => 0,    
                               self::STATUS_TOLERANCE => 0, 
                               self::STATUS_LATE => 0,  
                               'total' => 0,    
                ];  
                
                if(!isset($suppliersReports)) { 
                    $supplierWithStatus[$supplier]['reports'] = [];                     
                    continue;   
                }else{  
                    $supplierWithStatus[$supplier]['percentages'] = 0;                      
                }   
                            
                $OtherCount = 0;    
                
                   
                foreach($suppliersReports[$supplier] as $report) {  
                    if(!isset($lastReportDate)) {   
                        $lastReportDate = $report['date'];  
                        $lastReportfilePath = $report['filePath'];  
                        $lastReportstring = $report['string'];  
                        $firstReport = true;    
                        //$firstReportDate = $report['date'];   
                    }   
                    if(!isset($firstReportDate)){   
                        $firstReportDate = $report['date']; 
                    }                   
                    
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);  
                    $report['info'] = $statuses['info'];    
                    if (!isset($statuses['increment'])) dd($report);    
                    if($statuses['increment'] != ""){
                        $reportInfo[$statuses['increment']]++;  
                    }
                    $reportInfo['total']++; 
                    $newReports[$report['date-8601']] = $report;                
                        
                    $lastReportDate = $report['date'];
                   // $lastReport['filePath']."&filename=".$lastReport['string']  
                    $lastReportfilePath = $report['filePath'];  
                    $lastReportstring = $report['string'];  
                    $supplierWithStatus[$supplier]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo,5);  
                   // ***************my addition*****************   
                    $supplierWithStatus[$supplier]['lastReportDate'] = $lastReportDate;             
                    $supplierWithStatus[$supplier]['filePath'] = $lastReportfilePath;             
                    $supplierWithStatus[$supplier]['string'] = $lastReportstring;             
                    $supplierWithStatus[$supplier]['info'] = $reportInfo;   
                  //  ****************my addition end********** 
                    $chkDate = strtotime($lastReportDate);  
                    $firstReport = false;   
                    if(isset($firstReportDate)){    
                        $fromDate = date('Y/m/d', strtotime($firstReportDate)); 
                    }   
                    if($report['report_id'] == '9999'){ 
                        if(!isset($OtherlastReportDate)) {  
                            $OtherlastReportDate = $report['date']; 
                            $OtherfirstReport = true;   
                            //$firstReportDate = $report['date'];   
                        }   
                        if(!isset($OtherfirstReportDate)){  
                            $OtherfirstReportDate = $report['date'];    
                        }   
                        $OtherlastReportDate = $report['date']; 
                        if(isset($OtherfirstReportDate)){   
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));   
                        }   
                        $OtherfirstReport = false;  
                        $OtherCount++ ; 
                    }   
                        
                }  
                        
                $Compliance[$supplier] = $supplierWithStatus[$supplier]['percentages'];                     
                
                unset($newReports); 
                unset($firstReportDate);    
                unset($lastReportDate); 
                unset($lastReportfilePath); 
                unset($lastReportstring); 
            //}             
            $fDate = 0;             
        }   
        return $supplierWithStatus; 
    }   
    private function getSupplierFromFileName($fileString){  
            $attr = explode($fileString,'_');   
            if(isset($attr[3])){    
                return $attr[3];    
            }else{  
                return "";  
            }   
    }

    /**
     * Find reports from S3 bucket for given path
     */
    public function findS3ReportsDashboard($reportTypes, $clientSite, $flag, $dateRange)
    {
        
        $s3 = Yii::$app->s3Helper;

        $files = $s3->directoryListing($clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);

        $files = $this->filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange);

        return $files;
    }


    protected function filterFilesDashboard($reportTypes, $files, $clientSite, $flag, $dateRange)
    {

        foreach($files as $file) {
            $fileShort = self::trimFilename($file);
            $fileAttr = self::getReportAttributes($fileShort);
            list($path, $name) = $this->splitPath($file);

            // Only add report if it belongs to a selected report type
            if(!array_key_exists($fileAttr['report_id'], $reportTypes)) {
                continue;
            }

            if(!$this->isWithinDates($fileAttr, $dateRange)) {
                continue;
            }

            $reportTypes[$fileAttr['report_id']]['reports'][$fileAttr['8601'].$fileShort] = 
                        array_merge($fileAttr, [
                            'string' => $fileShort,
                            'date' => $this->convertDateFromFileFormat($fileAttr['date']),
                            'time' => $this->convertTimeFromFileFormat($fileAttr['time']),
                            'filePath' => $file,
                            'date-8601' => $fileAttr['8601'] .'-'. $fileShort,
                            'filename' => $name,
                            'path' => $path,
                            'clientSiteId' => $clientSite->id,
                        ]);
        }
        
        $reportTypes = $this->orderReportTypes($reportTypes);
        if($flag == 9 || $flag == 10){
            $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
        }else{

            if (isset($fileAttr) && array_key_exists('report_id', $fileAttr) && $fileAttr['report_id'] != '9999') {
                $reportTypes = $this->retrieveStatusDataDashboard($clientSite->client_id, $reportTypes, $flag, $dateRange);
            }
        }        
        return $reportTypes;
    }


    protected function retrieveStatusDataDashboard($clientId, $reportTypes, $flag, $dateRange)
    {
        
        $reportTypesWithStatus = $reportTypes;        
        $reportTypesWithStatus1 = $reportTypes;
        $totalReports = 0;
        $total = 0;
        $rCount =  count($reportTypes);
        $fDate = 1;
        $AuditPeriod3['startdate'] = array();
        $AuditPeriod3['enddate'] = array();
        $AuditPeriod9['startdate'] = array();
        $AuditPeriod9['enddate'] = array();
        $AuditPeriod6 = array();
        $AuditPeriod7 = array();
        $AuditPeriod = array();
        $Compliance = array();
        $Compliance8 = array();

        foreach($reportTypes as $key=>$type) {
            $AuditPeriod[$key] = array();
            $AuditPeriod[$key] = array();
            $AuditPeriod7[$key] = array();
            $Compliance[$key] = array();
            $Compliance8[$key] = array();


            $reportInfo = [self::STATUS_ONTIME => 0,
                           self::STATUS_TOLERANCE => 0,
                           self::STATUS_LATE => 0,
                           'total' => 0,
            ];

            $reportTypesWithStatus[$key]['statuses'] = [
                         'last_report_due' => '--2',
                         'last_report_class' => '--3',
                         'percentages' => '--p',
                         'status_bar' => ['status_string' => '', 'status_class' => ''],
            ];

            if(!isset($type['reports'])) {
                $reportTypesWithStatus[$key]['reports'] = [];
                continue;
            }else{
                $reportTypesWithStatus[$key]['percentages'] = 0;
            }
            //echo "==>".count($type['reports']);
            
            if($flag == 1){   
                $totalReports += count($type['reports']);
                $reportTypesWithStatus1 = $totalReports;
            }else{
                $OtherCount = 0;
                foreach($type['reports'] as $report) {

                    if(!isset($lastReportDate)) {
                        $lastReportDate = $report['date'];
                        $firstReport = true;
                        //$firstReportDate = $report['date'];
                    }
                    if(!isset($firstReportDate)){
                        $firstReportDate = $report['date'];
                    }
                    
                    $statuses = $this->getReportStatus($report, $type, $lastReportDate, $firstReport);
                    $report['info'] = $statuses['info'];
                    if (!isset($statuses['increment'])) dd($report);
                    $reportInfo[$statuses['increment']]++;
                    $reportInfo['total']++;
                    $newReports[$report['date-8601']] = $report;
                    $lastReportDate = $report['date'];
                    $reportTypesWithStatus[$key]['percentages'] = $this->buildReportPercentagesDashboard($reportInfo, $flag);
                    $chkDate = strtotime($lastReportDate);
                    $firstReport = false;
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }

                    if($report['report_id'] == '9999'){

                        if(!isset($OtherlastReportDate)) {
                            $OtherlastReportDate = $report['date'];
                            $OtherfirstReport = true;
                            //$firstReportDate = $report['date'];
                        }
                        if(!isset($OtherfirstReportDate)){
                            $OtherfirstReportDate = $report['date'];
                        }
                        $OtherlastReportDate = $report['date'];
                        if(isset($OtherfirstReportDate)){
                            $OtherfromDate = date('d/m/Y', strtotime($OtherfirstReportDate));
                        }
                        $OtherfirstReport = false;
                        $OtherCount++ ;
                    }
                    
                }
               
                if ($report['report_id'] != '9999') {
                    $reportTypesWithStatus[$key]['status_bar'] = $this->buildReportStatusBarString($statuses, $type['reportInterval']['tolerance']);
                }
                //$reportTypesWithStatus[$key]['reports'] = $reportTypesWithStatus[$key]['percentages'];

                if($flag == 3){
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    //$reportTypesWithStatus1 = $fromDate."-".$toDate;                   
                    array_push($AuditPeriod3['startdate'], $fromDate);
                    array_push($AuditPeriod3['enddate'], $toDate);   
                    $reportTypesWithStatus1 = $AuditPeriod3;                   
                }elseif($flag == 4){
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod[$key], $fromDate);
                    array_push($AuditPeriod[$key], $toDate); 
                }elseif($flag == 5){
                    $Compliance[$key] = $reportTypesWithStatus[$key]['percentages'];
                    //print_r($reportTypesWithStatus[$key]['percentages']);
                    //$reportTypesWithStatus1= $reportTypesWithStatus[$key]['percentages'];
                }elseif($flag == 6){
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod6, $toDate); 
                }elseif($flag == 7){
                    if(isset($firstReportDate)){
                        $fromDate = date('Y/m/d', strtotime($firstReportDate));
                    }
                    $toDate = date('Y/m/d', strtotime($lastReportDate));
                    array_push($AuditPeriod7[$key], $fromDate);
                    array_push($AuditPeriod7[$key], $toDate);
                }elseif($flag == 8){
                    $Compliance8[$key] = $reportTypesWithStatus[$key]['percentages'];
                }elseif($flag == 9){
                    $toDate = date('d/m/Y', strtotime($OtherlastReportDate));
                    $reportTypesWithStatus1 = $OtherfromDate."-".$toDate;                   
                    /*array_push($AuditPeriod9['startdate'], $OtherfromDate);
                    array_push($AuditPeriod9['enddate'], $toDate);   
                    $reportTypesWithStatus1 = $AuditPeriod9;*/                   
                }elseif($flag == 10){
                    $reportTypesWithStatus1 = $OtherCount;
                }elseif($flag == 11){
                    $reportTypesWithStatus1 = $reportTypesWithStatus[$key]['percentages'];
                }else{
                    $reportTypesWithStatus1= $reportTypesWithStatus[$key]['percentages'];
                }
                unset($newReports);
                unset($firstReportDate);
                unset($lastReportDate);
                if($flag == 9){
                    unset($OtherfirstReportDate);
                    unset($OtherlastReportDate);

                }
            }

            if($flag == 2 || $flag == 0 || $flag == 11 || $flag == 12){                
                $total += $reportTypesWithStatus1;                 
            }
            $fDate = 0;
            
        }

        if($flag == 2 || $flag == 0 || $flag == 11 || $flag == 12){
            if($total>0){
                return $total/$rCount;
            }else{
                return 0;
            }
        }
        if($flag == 4){
            return $AuditPeriod;
        }
        if($flag==5){
           return $Compliance;
        }
        if($flag==6){
           return $AuditPeriod6;
        }
        if($flag==7){
           return $AuditPeriod7;
        }
        if($flag==8){
           return $Compliance8;
        }
        return $reportTypesWithStatus1;
    }


    protected function buildReportPercentagesDashboard($info, $flag)
    {   

        if($info['total'] == 0) {
            return 'no totals to calculate';
        }

        $ontime = round(number_format($info[self::STATUS_ONTIME] / $info['total'] *100, 2));
        $tolerance = round(number_format($info[self::STATUS_TOLERANCE] / $info['total'] *100, 2));
        $late = round(number_format($info[self::STATUS_LATE] / $info['total'] *100, 2));

        //return 'Ontime: '. $ontime .'%; Tolerance: '. $tolerance .'%; Late: '. $late .'%';
        if($flag == 1){
            return $info['total'];
        }else if($flag == 11){
            return $tolerance;
        }else if($flag == 12){
            return $late;
        }elseif($flag == 8){
            return $ontime+$tolerance;
        }else{
            return  $ontime;
        }
    }

    public static function findLateReportsDashboard($mySiteId)
    {
        $reports = [];

        $sops = SiteOperationalProgram::find()->where(['site_id'=>$mySiteId])->all();
        foreach($sops as $sop) {
            if($status = $sop->compileAlertsDashboard()) {
                if(!$status) {
                    continue;
                }
                $reports[$sop->client->id][$status['status']][] = ['sop' => $sop,
                                                         'info' => $status,
                ];
            }
        }

        return $reports;
    }

    public function compileAlertsDashboard()
    {   

        if(!$this->clientSite || !$this->client) {
            return false;
        }

        // Prevent undetermined reports (9999) from being included
        if($this->reportType->doctype_id >= 9000) {
            return false;
        }

        $path = $this->clientSite->directory;
        $reportTypeStr = '_'. $this->reportType->doctype_id;
        //$files = shell_exec('find '. ClientSite::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf | grep '. $reportTypeStr); // @#todo Remove - user for when reading file system
        $s3 = Yii::$app->s3Helper;
        $files = $s3->directoryListing($this->clientSite->directory, $this->bucket);
        $files = $this->filterDocs($files);
        $files = $this->filterForDocType($files, $reportTypeStr);

        $fileList = [];
        //$files = explode("\n", $files); // @todo remove - Used for when reading file system
        if(!isset($files[0]) || $files[0] == '') { // Don't include SOPs that have no files associated
            return false;
        }
        foreach($files as $file) {
            if($file == "") { 
                continue;
            }
            $file = $this->trimFilename($file);
            $file = $this->getReportAttributes($file);
            $fileList[$file[8601]] = $file;
        }
        ksort($fileList);
        // echo "<pre>"; 
        // print_r($fileList);
        // die;
        $reportInfo = $this->determineIfLate(end($fileList), $this->reportInterval);
        //var_dump($reportInfo);

        if($reportInfo['status'] == self::STATUS_LATE) {
            return $reportInfo;
        }

        return false;
    }
}
