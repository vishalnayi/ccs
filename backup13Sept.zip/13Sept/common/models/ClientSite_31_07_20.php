<?php

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;
use common\behaviors\SetClientBehavior;
use common\models\SiteOperationalBehavior;
use common\models\UserSiteAccess;

/**
 * This is the model class for table "client_site".
 *
 * @property integer $id
 * @property integer $node_id
 * @property integer $client_id
 * @property string $name
 * @property string $directory
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Node $node
 * @property Client $client
 */
class ClientSite extends BaseModel
{
    const OWNCLOUD_DIRECTORY = __DIR__ .'/../../owncloud_files/s3';

    const SCENARIO_UPDATE_EMAIL_CREDENTIALS = 'update-email-credentials';

    public $bucket;

    protected $existingMirrorPath; // Mirror path before update
    protected $beforeNodeId; // Node id before update

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    public function behaviors()
    {
        return ArrayHelper::merge([
            SetClientBehavior::className(),
        ], parent::behaviors());
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'client_site';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        $rules = [
            [['node_id'], 'integer'],
            [['name'], 'string', 'length' => [3,255]],
            ['name', 'match', 'pattern' => '/^[a-z0-9 _-]+$/i', 
                'message' => 'Name limited to \'a-z 0-9 -_\''],
            ['directory', 'match', 'pattern' => '/^[a-z0-9_]+$/i', 
                'message' => 'Name limited to \'a-z0-9_\''],
            [['name', 'node_id', 'client_id'], 'required'],
            [['email_address'], 'email'],
            [['site_address'],'string'],
            [['manager_name'],'string', 'length' => [3,255]],
            [['contact_number'],'string'],
            [['name','directory'], 'unique'],
            [['node_id'], 'nodeClientRelation'],
            [['comment'], 'string'],
        ];

        $superRules = [
            ['reportCategories', 'each', 'rule' => [
                'exist', 'targetClass', ReportCategory::className(), 'targetAttribute' => 'id',
            ]]
        ];

        if (Yii::$app->user->identity->role == User::ROLE_SUPER) {
            $rules = ArrayHelper::merge($rules, $superRules);
        }

        return $rules;
    }

    public function nodeClientRelation($attribute, $params)
    {
        if ($this->node_id == 0) {
            return true;
        }

        $node = Node::find()->where(['id' => $this->node_id])->one();

        if (!$node) {
            throw new \yii\web\HttpException(422, 'Node not found');
        }

        if ($this->client_id !== $node->client_id) {
            if (Yii::$app->user->identity->role != User::ROLE_SUPER) {
                throw new \yii\web\HttpException(422, 'Node access denied');
            }
        }
    }

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios['super-user'] = ['client_id', 'directory', 'name', 'email_address', 'email_username', 'email_password', 'download_documents'];

        return $scenarios;
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'node_id' => 'Node',
            'client_id' => 'Client ID',
            'name' => 'Name',
            'directory' => 'Directory',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNode()
    {
        return $this->hasOne(Node::className(), ['id' => 'node_id']);
    }

    /**
     * Get parent node - for use in getting node path
     */
    public function getParent()
    {
        return $this->hasOne(Node::className(), ['id' => 'node_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    public function getReportInterval()
    {
        return $this->hasOne(ReportInterval::className(), ['id' => 'report_interval_id']);
    }

    public function getReports()
    {
        return $this->hasMany(SiteOperationalProgram::className(), ['site_id' => 'id']);
    }

    public function getProvider()
    {
        return $this->hasOne(Provider::className(), ['id' => 'provider_id']);
    }

    public function getReportCategories()
    {
        return $this->hasMany(ReportCategory::className(), ['id' => 'report_category_id'])
             ->viaTable('client_site_report_category', ['client_site_id' => 'id']);
    }

    public function getClientSiteReportCategories()
    {
        return $this->hasMany(ClientSiteReportCategory::className(), ['client_site_id' => 'id']);
    }

    /**
     * Get search terms associated with client site per client_site_report_category
     */
    public function getSearchTerms()
    {
        $firstCat = true;

        $reportCategories = $this->clientSiteReportCategories;

        if (count($reportCategories) < 1) {
            return [];
        }

        $query = "SELECT * FROM document_search_term WHERE enabled=1 AND (";

        foreach ($reportCategories as $category) {
            if ($firstCat) {
                $firstCat = false;
            } else {
                $query .= ' OR ';
            }
            $query .= "(report_category_id={$category->report_category_id} AND provider_id={$category->provider_id}) ";
        }
        $query .= ')';

        $conn = Yii::$app->getDb();
        $command = $conn->createCommand($query);

        $result = $command->queryAll();

        $terms = [];

        // Raw queries return an array - but we need them as objects
        foreach ($result as $term) {
            $termObj = DocumentSearchTerm::find()->where(['id' => $term['id']])->one();
            $terms[] = $termObj;
        }

        return $terms;
    }

    public static function getNodeChildren($clientId, $nodeId)
    {
        $siteList = [];

        $sites = ClientSite::find()->where(['client_id' => $clientId, 'node_id' => $nodeId])->all();
        foreach($sites as $site) {
           foreach ($site->reportCategories as $cat) {
                $siteList[] = ['id' => 'site|'. $site->id .'|cat|'. $cat->id,
                               'text' => $site->name .' - '. $cat->name,
                               'icon' => '/img/s.png',
                               'children' => true,
                               'type' => $site->reports ? true : false,
                       ];
            }
        }

        return $siteList;
    }

    public function findNewSites()
    {
        $newSites = 0;

        if(!$fp = opendir(self::OWNCLOUD_DIRECTORY)) {
            throw new Exception('Unable to open path');
        }

        while (($path = readdir($fp)) !== false) {
            if(in_array($path, $this->ignoredPaths())
                || !is_dir(self::OWNCLOUD_DIRECTORY .'/'. $path)) {
                continue;
            }

            $site = ClientSite::find()->where(['directory' => $path])->one();

            if(!$site) {
                $site = new ClientSite;
                $site->name = $path;
                $site->client_id = 0; // Do not auto-assign client $this->findClientFromFile($path);
                $site->directory = $path;
                $site->node_id = 0;
                if(!$site->save()) {
                    var_dump($site->getErrors());
                }
                $newSites++;
            }
        }

        return $newSites;
    }

    protected function findClientFromFile($path)
    {
        $file = exec('find '. self::OWNCLOUD_DIRECTORY .'/'. $path .' -iname \*pdf');
        $file = SiteOperationalProgram::trimFilename($file);
        $file = SiteOperationalProgram::getReportAttributes($file);

        $client = Client::find()->where(['client_id' => $file['client_id']])->one();

        return $client ? $client->id : null;
    }

    protected function ignoredPaths()
    {
        return ['.',
                '..',
                '.gitignore',
                '.csync_journal.db',
                'RMP_mirror',
        ];
    }

    public function beforeSave($insert)
    {
        parent::beforeSave($insert);

        if ($this->node_id == null) {
            $this->node_id = 0;
        }

        if ($this->client_id == null) {
            $this->client_id = 0;
        }

        return true;
    }

    public function s3PathListing()
    {
        $s3 = Yii::$app->s3Helper;

        return $s3->directoryListing($this->directory);
    }

    public function node()
    {
        return $this->hasOne(Node::className(), ['node_id' => 'id']);
    }

    public function getMirrorPath()
    {
        if (!isset($this->client)) {
            return 'no-client';
        }

        $path = 'RMP_mirror/';
        $path .= str_replace(' ', '_', $this->client->name) .'/';

        $nodes = $this->getParentNode($this, []);
        $nodes = array_reverse($nodes);

        foreach ($nodes as $node) {
            $path .= str_replace(' ', '_', $node->name) .'/';
        }

        //$path .= str_replace(' ', '_', $this->name) .'/';

        return $path;
    }

    /**
     * Traverse through site and its nodes. Both have a 
     * getParent() relationship method.
     *
     * @param mixed $object - Either ClientSite or Node
     * @param array $nodes
     * @return array
     */
    protected function getParentNode($object, $nodes)
    {
        if ($object->parent) {
            $nodes[] = $object->parent;
            $nodes = $this->getParentNode($object->parent, $nodes);
        }

        return $nodes;
    }

    public function processNewDocuments()
    {
        $documentRetriever = Yii::$app->documentRetriever;
        $reportType = new ReportType;

        if ($this->download_documents == 1) {

            $documentGroup = $documentRetriever->getNewDocuments($this->email_username, $this->email_password);

            foreach ($documentGroup as $documents) {
                foreach ($documents as $document) {
                    $document['time_start'] = time();
                    // echo "<pre>";
                    // print_r($this->searchTerms);
                    // die;
                    $document = $reportType->findReportType($document, $this->searchTerms);
                    $document['time_report_discovery_end'] = time();
                    list($filename, $rootPath, $mirrorPath, $timeCreatePathEnd) = $this->saveFile($document);
                    $document['time_create_paths_end'] = $timeCreatePathEnd;
                    $document['time_file_saved_end'] = time();
                    $this->log($document, $rootPath, $mirrorPath, $filename);                    
                    $documentExtension = $document['documentExtension'];
                    if($documentExtension == 'jpg' || $documentExtension == 'jpeg' || $documentExtension == 'png'){
                        unlink($document['documentImagePath']);
                    }
                }
            }
        }
    }

    public function saveFile($document)
    {
        $report = new Report;

        list($rootPath, $mirrorPath) = $report->getReportPaths($this->directory,
                                                               $this->getMirrorPath(),
                                                                $document['reportTypeId'],
                                                               $document['date']
                       );
        $filename = $report->getFilename($document, $rootPath,$this->client_id);

        echo "===  ". $rootPath ."\n";
        echo "=== Saving file:  $filename\n";
        
        // Save to S3 root and mirror
        list($rootPath, $mirrorPath, $timeCreatePathEnd) = $report->saveReport($document,
                                                                               $filename,
                                                                               $rootPath,
                                                                               $mirrorPath
        );
        return [$filename, $rootPath, $mirrorPath, $timeCreatePathEnd];        
    }

    /**
     * @todo - remove this
     */
    protected function createFilePath($path)
    {
        if (!file_exists($path)) {
            if (!mkdir($path, 0777, true)) {
                throw Exception('Unable to create path: '. $path);
            }
        }
    }

    protected function getLogTimes($document)
    {
        $timeTotal = $document['time_debug_images_upload'] - $document['time_start'];
        $timeDiscovery = $document['time_report_discovery_end'] - $document['time_start'];
        $timeCreatePaths = $document['time_create_paths_end'] - $document['time_report_discovery_end'];
        $timeSaveFile = $document['time_file_saved_end'] - $document['time_create_paths_end'];
        $timeDebugImagesUpload = $document['time_debug_images_upload'] - $document['time_file_saved_end'];

        return ['timeTotal' => $timeTotal,
                'timeCreatePaths' => $timeCreatePaths,
                'timeDiscovery' => $timeDiscovery,
                'timeSaveFile' => $timeSaveFile,
                'timeDebugImagesUpload' => $timeDebugImagesUpload,
        ];
    }

    /**
     * Save result to log
     *
     * @param array $document
     * @param array $s3Paths - Not valid during a test
     */
    public function log($document, $rootPath, $mirrorPath, $filename)
    {
        $ddl = new DocumentDiscoverLog();

        $ddl->report_type_id = $document['reportTypeId'];
        $ddl->provider_id = $this->provider_id ?? 0;
        $ddl->date = $document['date'] ?? 'unknown';
        $ddl->from_address = $document['from'] ?? 'unknown';
        $ddl->subject = $document['subject'] ?? 'unknown';
        $ddl->subject_formatted = $document['subjectFormatted'] ?? 'unknown';
        $ddl->message_html = $document['messageHtml'] ?? 'unknown';
        $ddl->message_text = $document['messageText'] ?? 'unknown';
        $ddl->root_path = $rootPath .'/'. $filename;
        $ddl->mirror_path = $mirrorPath .'/'. $filename;
        $ddl->document_text = $document['documentText'] ?? 'unknown';
        $ddl->document_text_formatted = $document['documentTextFormatted'] ?? 'unknown';

        if (!$ddl->save()) {
            dd($ddl->getErrors());
        }

        $s3 = Yii::$app->s3Helper;
        foreach ($document['section'] as $section) {

            $sectionLog = new DocumentDiscoverLogSection;
            $sectionLog->document_discover_log_id = $ddl->id;
            $sectionLog->text = $section['croppedDocumentText'];
            $sectionPath = $sectionLog->generatePath();
            $sectionLog->filepath = $sectionPath;
            $s3->saveFile($section['croppedLogFile'], $sectionPath, $sectionLog->bucket);
            unlink($section['croppedLogFile']);

            if (!$sectionLog->save()) {
                dd($sectionLog->getErrors());
            }
        }

        $document['time_debug_images_upload'] = time();
        $logTimes = $this->getLogTimes($document);

        $ddl->debug_images_number = count($document['section']);
        $ddl->time_total = $logTimes['timeTotal'];
        $ddl->time_discover = $logTimes['timeDiscovery'];
        $ddl->time_create_paths = $logTimes['timeCreatePaths'];
        $ddl->time_debug_images_upload  =$logTimes['timeDebugImagesUpload'];
        $ddl->time_save_file = $logTimes['timeSaveFile'];
        $ddl->save();

        echo 'Total time: '. $logTimes['timeTotal'] ."\n";
        echo 'Discovery time: '. $logTimes['timeDiscovery'] ."\n";
        echo 'Create Paths time: '. $logTimes['timeCreatePaths'] ."\n";
        echo 'Save file time: '. $logTimes['timeSaveFile'] ."\n";
        echo 'debug images upload time: '. $logTimes['timeDebugImagesUpload'] ."\n";
        echo "Log entry id: ". $ddl->id ."\n";

        return $ddl;
    }

    public function afterFind()
    {
        $this->existingMirrorPath = $this->getMirrorPath();
        $this->beforeNodeId = $this->attributes['node_id'];
    }

    public function afterSave($update, $changedAttributes)
    {
        parent::afterSave($update, $changedAttributes);

        if ($this->node_id != $this->beforeNodeId) {
            $s = ClientSite::findOne($this->id); // Need to reinstanciate
            $s3 = Yii::$app->s3Helper;
            $newInstance = ClientSite::findOne($this->id);
            $existingPath = $this->existingMirrorPath . $this->directory .'-';
            $newPath = $newInstance->getMirrorPath() . $this->directory .'-';
            $s3->movePathUpdated($existingPath,
                                 $newPath,
                                 $this->bucket
            );
        }
    }

    /**
     * Get site from directory
     *
     * @param string $path
     * @return ClientSite
     */
    static public function getSiteFromDocumentPath($path)
    {
        $path = explode('/', $path);
        $path = explode('-', $path[0]);

        $site = ClientSite::find()->where(['directory' => $path[0]])->one();

        return $site;
    }

    public function syncReportCategories($variables)
    {
        if (!is_array($variables)) {
            $variables = [];
        }

        $currentCats = $this->getReportCategories()->all();
        foreach ($currentCats as $catId) {
            $model = ClientSiteReportCategory::find()->where([
                        'client_site_id' => $this->id,
                        'report_category_id' => $catId,
                    ])->one();

            $model->delete();
        }

        foreach ($variables as $key=>$value) {
            $model = new ClientSiteReportCategory;
            $model->client_site_id = $this->id;
            $model->report_category_id = $value;
            $model->save();
        }
    }

    public function syncReportCategoriesFAIL($variables)
    {
        $currentCategories = [];

        if (!is_array($variables)) {
            $variables = [];
        }

        var_dump($variables);
        echo "==================<br />\n";
        $currentCats = $this->getReportCategories()->all();
        foreach ($currentCats as $cat) {
            $currentCategories[] = $cat->id;
        }
        var_dump($currentCategories);
        foreach ($variables as $key=>$value) {
            if (!in_array($value, $currentCategories)) {
                $model = new ClientSiteReportCategory;
                $model->client_site_id = $this->id;
                $model->report_category_id = $value;
                $model->save();
            }

            $index = array_search($value, $currentCategories);
            unset($currentCategories[$index]);
        }
        echo "=================<br />\n";
        var_dump($currentCategories);
        //die('ere');
        //dd($variables);

        foreach ($currentCategories as $cat) {
            $model = ClientSiteReportCategory::find()->where([
                        'client_site_id' => $this->id,
                        'report_category_id' => $cat,
                    ])->one();

            $model->delete();
        }
    }

    // Dashboard functions

    public function getMySitesReportsOld($clientId="")
    {
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
       
        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
       
            if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                $qry = " WHERE cs.client_id in (".implode(',', $clientId).") and cs.id in (".implode(',', $forceSites).")";                 
            }elseif($clientId!=""){
                $qry = " WHERE cs.client_id='".$clientId."' and cs.id in (".implode(',', $forceSites).")";
            }else{
                $qry = " WHERE cs.id in (".implode(',', $forceSites).")";
            }
        }else{
            if($clientId!=""){
                $qry = " WHERE cs.client_id='".$clientId."'";
            }else{
                $qry = '';
            }
        }

        $query = "SELECT sop.name AS report_type,rt.doctype_id AS doctype_id,p.name AS provider_name FROM site_operational_program AS sop LEFT JOIN client_site AS cs ON cs.id=sop.site_id LEFT JOIN client_site_report_category AS csrc ON  csrc.client_site_id=sop.site_id LEFT JOIN report_type AS rt ON rt.id=sop.report_type_id LEFT JOIN provider AS p ON csrc.provider_id=p.id $qry GROUP BY sop.report_type_id ORDER BY sop.id ASC";
        $conn = Yii::$app->getDb();
        $command = $conn->createCommand($query);

        $data = $command->queryAll();

        return $data;
    }

    public function getMySitesReports($clientId="")
    {
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
       
        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
       
            if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                if(!empty($clientId)){
                    $qry = " WHERE cs.client_id in (".implode(',', $clientId).") and cs.id in (".implode(',', $forceSites).")";
                }else{
                    $qry = " WHERE cs.id in (".implode(',', $forceSites).")";
                }
            }elseif($clientId!=""){
                $qry = " WHERE cs.client_id='".$clientId."' and cs.id in (".implode(',', $forceSites).")";
            }else{
                $qry = " WHERE cs.id in (".implode(',', $forceSites).")";
            }
        }else{
            if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                if(!empty($clientId)){
                    $qry = " WHERE cs.client_id in (".implode(',', $clientId).")"; 
                }else{
                    $qry = '';
                }                    
            }elseif($clientId!=""){
                $qry = " WHERE cs.client_id='".$clientId."'";
            }else{
                $qry = '';
            }
        }
        
        $query = "SELECT rt.name AS report_type,sop.report_interval_id,cs.name as site_name,sop.provider_ids,sop.site_id,sop.id as sop_id,sop.report_type_id,rt.doctype_id AS doctype_id,rt.report_category_id,f.name as frequency FROM site_operational_program AS sop LEFT JOIN client_site AS cs ON cs.id=sop.site_id  LEFT JOIN report_interval as f on f.id=sop.report_interval_id LEFT JOIN report_type AS rt ON rt.id=sop.report_type_id  $qry GROUP BY sop.report_type_id,sop.report_interval_id,sop.provider_ids ORDER BY sop.id ASC";
        
        // $query = "SELECT sop.name AS report_type,rt.name as actual_report_type,sop.provider_ids,sop.site_id,sop.id as sop_id,sop.report_type_id,rt.doctype_id AS doctype_id,rt.report_category_id FROM site_operational_program AS sop LEFT JOIN client_site AS cs ON cs.id=sop.site_id LEFT JOIN report_type AS rt ON rt.id=sop.report_type_id  $qry  ORDER BY sop.id ASC";
       
        $conn = Yii::$app->getDb();
        $command = $conn->createCommand($query);
        $dataSOP = $command->queryAll(); 
        
        if(!empty($dataSOP)){
          foreach ($dataSOP as $key => $sop) {
            if($sop['provider_ids'] != ""){
                $queryProvider  = "SELECT GROUP_CONCAT(p.name) as provider_name FROM `provider` as p where p.id IN (".$sop['provider_ids'].")";            
                $conn = Yii::$app->getDb();
                $command = $conn->createCommand($queryProvider);
                $dataProvider = $command->queryAll();
                $dataSOP[$key]['providers'] = isset($dataProvider[0]['provider_name'])?$dataProvider[0]['provider_name']:"";
          
            }else{
                $dataSOP[$key]['providers'] = "";
            }

          }  
        }
       
        return $dataSOP;
    }


    public function getClientSitesOld($clientId="",$flag)
    {
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
       
        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
        }

        if($flag==1){
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                if($clientId!=""){
                    $sites = ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all();
                }else{
                    $sites = ClientSite::find()->where(['in','id',$forceSites])->all();
                }
            }else{
                if($clientId!=""){
                    $sites = ClientSite::find()->where(['client_id' => $clientId])->all();
                }else{
                    $sites = ClientSite::find()->all();
                }
            }
            
            $data = count($sites);
        }else{
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                   $query = "SELECT * FROM client_site WHERE client_id in (".implode(',', $clientId).")  and id in (".implode(',', $forceSites).")"; 
                }elseif($clientId!=""){
                    $query = "SELECT * FROM client_site WHERE client_id='".$clientId."' and id in (".implode(',', $forceSites).")";
                }else{
                    $query = "SELECT * FROM client_site WHERE id in (".implode('glue', pieces).")";
                } 
            }else{
                if($clientId!=""){
                    $query = "SELECT * FROM client_site WHERE client_id='".$clientId."'";
                }else{
                    $query = "SELECT * FROM client_site";
                } 
            }
            $conn = Yii::$app->getDb();
            $command = $conn->createCommand($query);

            $data = $command->queryAll();
        }
        return $data;
    }

    public function getClientSites($clientId="",$flag,$allowAll=0)
    {
        //for site access user wise. use common\models\UserSiteAccess;
        if($allowAll != 1){
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
            }
        }

        if($flag==1){
            if(isset($allowedSites) && !empty($allowedSites) && (isset(Yii::$app->user->identity->role) && (Yii::$app->user->identity->role != User::ROLE_SUPER))){
                if($clientId!=""){
                    $sites = ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all();
                }else{
                    $sites = ClientSite::find()->where(['in','id',$forceSites])->all();
                }
            }else{
                if($clientId!=""){
                    $sites = ClientSite::find()->where(['client_id' => $clientId])->all();
                }else{
                    $sites = ClientSite::find()->all();
                }
            }
            
            $data = count($sites);
        }else{
            if(!empty($allowedSites) && isset(Yii::$app->user->identity->role) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                   $query = "SELECT * FROM client_site WHERE client_id in (".implode(',', $clientId).")  and id in (".implode(',', $forceSites).")"; 
                }elseif($clientId!=""){
                    $query = "SELECT * FROM client_site WHERE client_id='".$clientId."' and id in (".implode(',', $forceSites).")";
                }else{
                    $query = "SELECT * FROM client_site WHERE id in (".implode('glue', pieces).")";
                } 
            }else{
                if(is_array($clientId) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                   $query = "SELECT * FROM client_site WHERE client_id in (".implode(',', $clientId).") "; 
                }elseif($clientId!=""){
                    $query = "SELECT * FROM client_site WHERE client_id='".$clientId."'";
                }else{
                    $query = "SELECT * FROM client_site";
                } 
            }
            $conn = Yii::$app->getDb();
            $command = $conn->createCommand($query);

            $data = $command->queryAll();
        }
        return $data;
    }

    public function getClientSiteDetail($clientId,$siteId)
    {
        $data = ClientSite::find()->where(['client_id'=>$clientId,'id' => $siteId])->one();
        return $data;
    }

    public function getClientSitesReports($siteId)
    {
        //$query = "SELECT sop.name AS report_type,rt.doctype_id AS doctype_id,rt.id AS report_id,p.name AS provider_name FROM site_operational_program AS sop LEFT JOIN client_site AS cs ON cs.id=sop.site_id LEFT JOIN client_site_report_category AS csrc ON  csrc.client_site_id=sop.site_id LEFT JOIN report_type AS rt ON rt.id=sop.report_type_id LEFT JOIN provider AS p ON csrc.provider_id=p.id WHERE sop.site_id='".$siteId."' GROUP BY sop.report_type_id ORDER BY sop.id ASC";
        $query = "SELECT rt.name AS report_type,rt.doctype_id AS doctype_id,rt.id AS report_id,f.name as frequency,(SELECT GROUP_CONCAT(p.name) FROM provider as p where FIND_IN_SET(p.id,sop.provider_ids)) as provider_name FROM site_operational_program AS sop LEFT JOIN client_site AS cs ON cs.id=sop.site_id LEFT JOIN report_interval as f on f.id=sop.report_interval_id LEFT JOIN report_type AS rt ON rt.id=sop.report_type_id WHERE sop.site_id='".$siteId."' GROUP BY sop.report_type_id ORDER BY sop.id ASC";
        $conn = Yii::$app->getDb();
        $command = $conn->createCommand($query);

        $data = $command->queryAll();

        return $data;
    }

    public function getDashboardComplianceOld($FromDate,$toDate,$clientId="",$flag,$SiteId="",$docTypeId="")
    {   

         //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
       
        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
            $forceSites = [];

            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }

            if($SiteId != "" && !in_array($SiteId, $forceSites)){
                $SiteId = "";
            }
        }

        $reportList = [];
        $model = new ClientSite();
        $sites = [];
        if(($flag == 2 && $SiteId!="") || ($flag == 3 && $SiteId!="") || ($flag == 7) || ($flag == 8) || ($flag == 9 && $SiteId!="") || ($flag == 10 && $SiteId!="")){
            $clientSites = ArrayHelper::map(ClientSite::find()->where(['id' => $SiteId])->all(), 'id', 'id');
        }else{
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                if($clientId!=""){
                    $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                }else{
                    $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                }
            }else{
               if($clientId!=""){
                    $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                }else{
                    $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                } 
            }
            
        }
        
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];  



        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');

            
        $i = 0;
        foreach($clientSites as $Csite) {
        /*if($model->load(Yii::$app->request->get()) && $model->validate()) {*/
            $clientSite = ClientSite::findOne($Csite);
            $node = Node::findOne($model->node);
            
            if($node) {
                $sites = $node->findClientSites();
            } elseif($clientSite) {
                $sites[] = $clientSite;
            }
                
            $reportList[] = $model->gatherSiteReportInfoDashboard($clientSite, $reportTypes,$flag,$dateRange);
        /*}*/

            if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                $i++;
                if($i>5){
                    break;
                }
            }
            
        }

        
        $total = 0;
        $count = count($reportList);
        if($flag == 0){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }elseif($flag == 1){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }
               
            }
            $finalCompliance = $total;
        }elseif($flag == 2){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $total = $total + 0;    
                    }else{                    
                        $total = $total + $finalReports;
                    }
                }
            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
            $finalCompliance = $finalCompliance;
        }elseif($flag == 3){
            $startD = array();
            $endD = array();
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {

                    if($key1 == 'startdate'){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                array_push($startD,$mdate);
                                $i++;
                            }
                        }
                    }else{
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                array_push($endD,$mdate);
                                $i++;
                            }
                        }
                    }
                }
            }
            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }                
                
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }

        }elseif($flag == 4){
            $startD = array();
            $endD = array();

            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                if(($key2 == $i) && ($i == 0)){
                                    array_push($startD,$mdate);
                                }elseif(($key2 == $i) && ($i == 1)){
                                    array_push($endD,$mdate);
                                }
                                $i++;
                            }
                        }
                    }
                }
            }

            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }
            
            
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }
        }elseif($flag == 5){
            $TotalCompliance = 0;
            $RCount = 0; 
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        if(!isset($value['id'])){
                            if(!empty($value)){
                                $TotalCompliance = $TotalCompliance + $value;
                                $RCount++;
                            }else{
                                $TotalCompliance = $TotalCompliance + 0;
                            }
                        }else{
                            $TotalCompliance = $TotalCompliance + 0;
                        }
                    }
                }
            }
            if($TotalCompliance>0){
                $finalCompliance = number_format($TotalCompliance/$RCount,2);
            }else{
                $finalCompliance = number_format(0,2);                
            }
        }elseif($flag ==6){ 
            $LastD = array();
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if(!isset($value['id'])){
                        array_push($LastD,$value);
                    }
                }
            }           

            if(!empty($LastD)){

                $mostRecent= 0;
                foreach($LastD as $dates){
                    $curDate = strtotime($dates);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }
                $finalCompliance = date('F Y', $mostRecent);
            }else{
                $finalCompliance = "-";
            }
        }elseif($flag == 7){
            $startD = array();
            $endD = array();

            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                if(($key2 == $i) && ($i == 0)){
                                    array_push($startD,$mdate);
                                }elseif(($key2 == $i) && ($i == 1)){
                                    array_push($endD,$mdate);
                                }
                                $i++;
                            }
                        }
                    }
                }
            }

            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }

        }elseif($flag == 8){
            $TotalCompliance = 0;
            $RCount = 0; 
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        if(!isset($value['id'])){
                            if(!empty($value)){
                                $TotalCompliance = $TotalCompliance + $value;
                                $RCount++;
                            }else{
                                $TotalCompliance = $TotalCompliance + 0;
                            }
                            
                        }else{
                            $TotalCompliance = $TotalCompliance + 0;
                        }
                    }
                }
            }
            if($TotalCompliance>0){
                $finalCompliance = number_format($TotalCompliance/$RCount,2);
            }else{
                $finalCompliance = number_format(0,2);                
            }
        }elseif($flag == 9){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $OtherReportAudit = "-";
                    }else{
                        $OtherReportAudit = $finalReports;
                    }
                }else{
                    $OtherReportAudit = "-";
                }
            }
            $finalCompliance = $OtherReportAudit;
        }elseif($flag == 10){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $totalReport = 0;
                    }else{
                        $totalReport = $finalReports;
                    }
                }else{
                    $totalReport = 0;
                }
            }
            $finalCompliance = $totalReport;
        }elseif($flag == 11){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }elseif($flag == 12){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }
        return $finalCompliance;
    }

    public function getTotalReportsBySites($FromDate,$toDate,$clientId="",$flag,$Csite,$allowAll=0){ 
        $reportList = [];
        $model = new ClientSite();
        $sites = [];
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];
        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id'); 
        $clientSite = ClientSite::findOne($Csite);
        $node = Node::findOne($model->node);
        
        if($node) {
            $sites = $node->findClientSites();
        } elseif($clientSite) {
            $sites[] = $clientSite;
        }
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all(); 

        $rts = [];
        $sop = new SiteOperationalProgram;       
               
        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                $rts[$type['reportType']['doctype_id']] = $type;                    
            }
        }
             
        $reports = $sop->findS3ReportsDashboard($rts, $clientSite, $flag, $dateRange);
        if(isset($reports)){
           $reportList[] = $reports;    
        }else{
            $reportList[] = array();
        }
          
        foreach($reportList as $finalReports) {           
            if(is_array($finalReports)){
               return 0;    
            }else{                    
                return $finalReports;
            }             
        }          
       
    }

    public function getFrequencyForReport($clientSite,$FromDate,$toDate,$docTypeId ){ 
        
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['site_id'=> $clientSite])->all(), 'report_type_id', 'report_type_id');   
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];
        
        $clientSite = ClientSite::findOne($clientSite);
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $clientReportArr,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        
        $rts = [];
        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                $rts[$type['reportType']['doctype_id']] = $type;
            }
        }
        
        $sop = new SiteOperationalProgram;
        $rts['9999'] = $sop->buildOthersReportType($clientSite);
     
        $reports = $sop->findS3Reports($rts, $clientSite, $dateRange);
        $frequency = '-';
       
        foreach ($reports as $key => $report) {
        
            if($key == $docTypeId && isset($report['reportInterval'])){ 
                $frequency = $report['reportInterval']['name'];
            }
        }  
            
        return $frequency;         
       
    }

    public function getDashboardComplianceStatistic($FromDate,$toDate,$clientId,$flag,$allowAll = 1){
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
                if($SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if(($flag == 2 && $SiteId!="") || ($flag == 3 && $SiteId!="") || ($flag == 7) || ($flag == 8) || ($flag == 9 && $SiteId!="") || ($flag == 10 && $SiteId!="")){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['id' => $SiteId])->all(), 'id', 'id');
            }else{
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            }
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }

        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];     

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');

            $finalOnTime = 0;
            $finalTolerance = 0;
            $finalLate = 0;
            $finalTotal = 0;

            $result['ontime-percentage'] = 0.0;
            $result['tolerance-percentage'] = 0.0;
            $result['late-percentage'] = 0.0;

        foreach($clientSites as $Csite) {
            //$this->getSitesComplianceStaticsDashboard($FromDate,$toDate,$Csite,$flag);            
            $i = 0;
            
            $result['total'] = 0;
            $result['on-time'] = 0; 
            $result['percentage'] = 0.0;

            $clientSite = ClientSite::findOne($Csite); 
            $sites[] = $clientSite;                

            $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                                  'report_type_id' => $reportTypes,
                                                       ])->with(['reportType','reportInterval','clientSite'])
                                                         ->asArray()
                                                         ->all();

            
            $rts = [];
            $sop = new SiteOperationalProgram;
            $fArray = array(9,10);
            if(!in_array($flag, $fArray)){
                foreach($reportTypes as $type) {
                    if(isset($type['reportType'])) {
                        $rts[$type['reportType']['doctype_id']] = $type;
                    }
                }
            }else{
                $rts['9999'] = $sop->buildOthersReportType($clientSite);            
            }       
            $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, $flag, $dateRange);
            $result_on_time = 0;
            $result_tolerance = 0;
            $result_late = 0;
            $result_total = 0; 
            foreach ($reports as $key => $report) {
               $result_on_time += isset($report['info']['on-time'])?$report['info']['on-time']:0;
               $result_tolerance += isset($report['info']['tolerance'])?$report['info']['tolerance']:0;
               $result_late += isset($report['info']['late'])?$report['info']['late']:0;
               $result_total += isset($report['info']['total'])?$report['info']['total']:0;
            }
            $finalOnTime += $result_on_time;
            $finalTolerance += $result_tolerance;
            $finalLate += $result_late;
            $finalTotal += $result_total;        
            
        }
        if($finalTotal != 0){
            $result['ontime-percentage'] = round(number_format(($finalOnTime/$finalTotal)*100,2));
            $result['tolerance-percentage'] = round(number_format(($finalTolerance/$finalTotal)*100,2));
            $result['late-percentage'] = round(number_format(($finalLate/$finalTotal)*100,2));
        }

        return $result;
    }
    public function getSitesComplianceStaticsDashboard($FromDate,$toDate,$Csite,$flag){
       
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];     

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
            
        $i = 0;
        
        $result['total'] = 0;
        $result['on-time'] = 0; 
        $result['tolerance'] = 0; 
        $result['percentage'] = 0.0;

        $clientSite = ClientSite::findOne($Csite); 
        $sites[] = $clientSite;                

        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();

        if($clientSite->id == "190"){
            // echo "<pre>";
            // print_r($reportTypes);
            // die;
        }

        
        $rts = [];
        $sop = new SiteOperationalProgram;
        $fArray = array(9,10);
        if(!in_array($flag, $fArray)){
            foreach($reportTypes as $type) {
                if(isset($type['reportType'])) {
                    $rts[$type['reportType']['doctype_id']] = $type;
                }
            }
        }else{
            $rts['9999'] = $sop->buildOthersReportType($clientSite);            
        }       
        $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, $flag, $dateRange);
        // if($clientSite->id == "190"){
        //    // echo "<pre>";
        //    //  print_r($rts);
        //    //  die;
        //     $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, $flag, $dateRange);
        // }
       
        foreach ($reports as $key => $report) {
            $info = isset($report['info'])?$report['info']:[];
            $result['on-time'] += isset($report['info']['on-time'])?$report['info']['on-time']:0;
            $result['tolerance'] += !empty($info)?(isset($info['tolerance'])?$info['tolerance']:0):0;
           $result['total'] += isset($report['info']['total'])?$report['info']['total']:0;
        }
    
        if($result['total'] != 0){
            //$result['percentage'] = round(number_format(($result['on-time']/$result['total'])*100,2));
            $result['on-time_percentage'] = round(number_format(($result['on-time']/$result['total'])*100,2));
            $result['tolerance_percentage'] = round(number_format(($result['tolerance']/$result['total'])*100,2));
            
            $result['percentage'] = $result['on-time_percentage'] + $result['tolerance_percentage'];
            // if($result['tolerance_percentage'] != 0){
            //     echo " tolerance : ". $result['tolerance']; 
            //     echo " ontme :" . $result['on-time_percentage'];
            //     echo " tp :" . $result['tolerance_percentage'];
            //     echo " total : ". $result['total']; 
            //     echo " percentage : ". $result['percentage']; die;
            //  }
        }

        return $result['percentage'];

    }
    public function getSupplierDataBySite($Csite,$FromDate,$toDate,$flag=5){
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
        $clientSite = ClientSite::findOne($Csite);
        $sites[] = $clientSite;
            
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();

        
            $rts = [];
            $sop = new SiteOperationalProgram;
            $fArray = array(9,10);
            if(!in_array($flag, $fArray)){
                foreach($reportTypes as $type) {
                    if(isset($type['reportType'])) {
                        $rts[$type['reportType']['doctype_id']] = $type;
                    }
                }
            }else{
                $rts['9999'] = $sop->buildOthersReportType($clientSite);               
            } 
           
            $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, '5', $dateRange);
            
            $siteSuppliers = array();
            $siteSuppliersInfo = array();
            
            // //get site wise supplier here 
             $supplierReportIds = array();
             $finalSuppliersBySite = array();
             foreach ($reports as $key => $r) {
                if(isset($r['supplier_info']) && !empty($r['supplier'])){
                    $siteSuppliers = array_unique(array_merge($siteSuppliers,$r['supplier']));
                    
                    foreach ($r['supplier'] as $k => $supplier) {
                        if(isset($supplierReportIds[$supplier])){
                            if(!in_array($key, $supplierReportIds[$supplier])){
                                array_push($supplierReportIds[$supplier],$key);
                            }
                        }else{
                            $supplierReportIds[$supplier] = array();
                            array_push($supplierReportIds[$supplier],$key);
                        }
                    }
                }
            }
            
            $suppliers = array();
            if(isset($siteSuppliers)){
                
                foreach ($siteSuppliers as $key => $supplier) {
                    // get total ontime and tolerance report type wise and then sum up report types to get total ontime and tolerance for site
                    $lastDateArr = array();
                    $finalHref = array();
                        $total_reports = 0;
                        $ontime_reports = 0;
                        $tolerance_reports = 0;
                        $late_reports = 0;
                        $reports_key = array_keys($reports);   
                        
                        foreach ($reports_key as $key => $docTypeId) {
                            
                            if(isset($reports[$docTypeId]['supplier_info'])){
                               $strLastDate = isset($reports[$docTypeId]['supplier_info'][$supplier])?str_replace('-', '',  $reports[$docTypeId]['supplier_info'][$supplier]['lastReportDate']):"";
                               // $strLastDate = str_replace('-', '',  $reports[$docTypeId]['supplier_info'][$supplier]['lastReportDate']);
                                $arr = array();
                                if($strLastDate!=""){
                                $arr[$strLastDate] = "/site-operational-program/load-file?document=".$reports[$docTypeId]['supplier_info'][$supplier]['filePath']."&filename=".$reports[$docTypeId]['supplier_info'][$supplier]['string']."&type=inline"; 
                                 }
                                //array_push($finalHref,$arr);

                                if(isset($reports[$docTypeId]['supplier_info'][$supplier])){array_push($lastDateArr, $reports[$docTypeId]['supplier_info'][$supplier]['lastReportDate']);
                                }

                                $ontime_reports += isset($reports[$docTypeId]['supplier_info'][$supplier]['info']['on-time'])?$reports[$docTypeId]['supplier_info'][$supplier]['info']['on-time']:0;
                                $tolerance_reports += isset($reports[$docTypeId]['supplier_info'][$supplier]['info']['tolerance'])?$reports[$docTypeId]['supplier_info'][$supplier]['info']['tolerance']:0;
                                $late_reports += isset($reports[$docTypeId]['supplier_info'][$supplier]['info']['late'])?$reports[$docTypeId]['supplier_info'][$supplier]['info']['late']:0;
                                $total_reports += isset($reports[$docTypeId]['supplier_info'][$supplier]['info']['total'])?$reports[$docTypeId]['supplier_info'][$supplier]['info']['total']:0;
                                
                            }


                        }
                        $provider = Provider::findOne($supplier);                        
                        $suppliers['supplier_id'] = $supplier;
                        $suppliers['supplier_name'] = $provider->name;
                        $suppliers['supplier_report_ids'] = $supplierReportIds[$supplier];
                        $suppliers['lastReportDateStr'] = date('Y-m-d',max(array_map('strtotime', $lastDateArr)));
                        $suppliers['lastReportDate'] = date('d/m/Y',max(array_map('strtotime', $lastDateArr)));
                        $supplierLastReportDateStr = str_replace('-', '',$suppliers['lastReportDateStr']);
                        $suppliers['href'] = isset($arr[$supplierLastReportDateStr])?$arr[$supplierLastReportDateStr]:"";
                        $suppliers['info']['on-time'] = $ontime_reports;
                        $suppliers['info']['tolerance'] = $tolerance_reports;
                        $suppliers['info']['late'] = $late_reports;
                        $suppliers['info']['total'] = $total_reports;
                       $suppliers['info']['percentage'] = ($total_reports != 0)?(round(number_format(($ontime_reports/$total_reports)*100,2)) + round(number_format(($tolerance_reports/$total_reports)*100,2))):0;
                       array_push($finalSuppliersBySite,$suppliers);
                }
            }
            return $finalSuppliersBySite;
    }

    public function getSupplierDataByClient($FromDate,$toDate,$clientId="",$flag=5,$allowAll=0){
       
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
                if(isset($SiteId) && $SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }
        
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
        $supplierIds = array();
        $finalsupplier = array();
        foreach ($clientSites as $key => $Csite) {
            $siteSuppliers = ClientSite::getSupplierDataBySite($Csite,$FromDate,$toDate);
            foreach ($siteSuppliers as $key => $supplier) {
                if(!in_array($supplier['supplier_id'],$supplierIds)){
                    array_push($supplierIds, $supplier['supplier_id']);
                    $finalsupplier[$supplier['supplier_id']] = $supplier;                    
                }else{
                    if(isset($finalsupplier[$supplier['supplier_id']])){
                        // echo $finalsupplier[$supplier['supplier_id']]['lastReportDate'];
                        // echo " @@ ".strtotime($finalsupplier[$supplier['supplier_id']]['lastReportDate'])."  @@  ";
                        // echo " ==== ";
                        // echo " @@ ".strtotime($supplier['lastReportDate'])."  @@  ";
                        // echo " ***** ";

                        if(strtotime(implode('/',array_reverse(explode('/',$finalsupplier[$supplier['supplier_id']]['lastReportDate'])))) < strtotime(implode('/', array_reverse(explode('/',$supplier['lastReportDate']))))){
                            //echo " ++ here ++ ";
                            $finalsupplier[$supplier['supplier_id']]['lastReportDate'] = $supplier['lastReportDate'];
                            $finalsupplier[$supplier['supplier_id']]['href'] = $supplier['href'];
                        }
                        $finalsupplier[$supplier['supplier_id']]['info']['on-time'] += $supplier['info']['on-time'];
                        $finalsupplier[$supplier['supplier_id']]['info']['tolerance'] += $supplier['info']['tolerance'];
                        $finalsupplier[$supplier['supplier_id']]['info']['late'] += $supplier['info']['late'];
                        $finalsupplier[$supplier['supplier_id']]['info']['total'] += $supplier['info']['total'];
                        $finalsupplier[$supplier['supplier_id']]['info']['on-time_percentage'] = ($finalsupplier[$supplier['supplier_id']]['info']['total'] != 0)?(round(number_format(($finalsupplier[$supplier['supplier_id']]['info']['on-time']/$finalsupplier[$supplier['supplier_id']]['info']['total'])*100,2))):0;
                        $finalsupplier[$supplier['supplier_id']]['info']['tolerance_percentage'] = ($finalsupplier[$supplier['supplier_id']]['info']['total'] != 0)?(round(number_format(($finalsupplier[$supplier['supplier_id']]['info']['tolerance']/$finalsupplier[$supplier['supplier_id']]['info']['total'])*100,2))):0;
                        $finalsupplier[$supplier['supplier_id']]['info']['percentage'] = $finalsupplier[$supplier['supplier_id']]['info']['on-time_percentage'] +$finalsupplier[$supplier['supplier_id']]['info']['tolerance_percentage'];
                       //array_push($finalSuppliersBySite,$suppliers);

                    }
                   
                }
            }

        }
         
        return $finalsupplier;
                    
    }

    public function getReportsStaticsDashboard($FromDate,$toDate,$clientId="",$flag,$provider_ids,$report_interval_id,$docTypeId="",$SiteId="",$allowAll=0){
       
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
                if($SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if(($flag == 2 && $SiteId!="") || ($flag == 3 && $SiteId!="") || ($flag == 7) || ($flag == 8) || ($flag == 9 && $SiteId!="") || ($flag == 10 && $SiteId!="")){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['id' => $SiteId])->all(), 'id', 'id');
            }else{
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            }
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }
        
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
            
        $i = 0;
        $result = [];
      
        foreach($clientSites as $Csite) {
       
            $clientSite = ClientSite::findOne($Csite);
            $node = Node::findOne($model->node);
            
            if($node) {
                $sites = $node->findClientSites();
            } elseif($clientSite) {
                $sites[] = $clientSite;
            } 
            
            //gatherSiteReportInfoDashboard start *******************************************************
            $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();

        
            $rts = [];
            $sop = new SiteOperationalProgram;
            $fArray = array(9,10);
            if(!in_array($flag, $fArray)){
                foreach($reportTypes as $type) {
                    if(isset($type['reportType'])) {
                        $rts[$type['reportType']['doctype_id']] = $type;
                    }
                }
            }else{
                $rts['9999'] = $sop->buildOthersReportType($clientSite);               
            }      

            $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, '5', $dateRange);
            // echo "<pre>";
            // print_r($reports);
            // die;
           
            //my addition for showing all reports even if primary alarm not set
          
            //end code
            $finalResult['total'] = 0;
            $finalResult['on-time'] = 0;
            $finalResult['tolerance'] = 0;
            $finalResult['lastReportDate']='-';
            $finalResult['nextDate']='-';
            $finalResult['percentage'] = 0;
            if(isset($reports[$docTypeId]) && isset($reports[$docTypeId]['report_interval_id']) && $reports[$docTypeId]['report_interval_id']== $report_interval_id && $reports[$docTypeId]['provider_ids'] == $provider_ids){
                
                if($finalResult['lastReportDate'] == ''){
                    $finalResult['lastReportDate']=isset($reports[$docTypeId]['lastReportDate'])?date('d/m/Y',strtotime($reports[$docTypeId]['lastReportDate'])):"";                
                    
                }else{
                    if(isset($reports[$docTypeId]['lastReportDate']) && ($finalResult['lastReportDate'] < $reports[$docTypeId]['lastReportDate'])){
                        $finalResult['lastReportDate']=date('d/m/Y',strtotime($reports[$docTypeId]['lastReportDate']));
                    }
                }
                if(isset($reports[$docTypeId]['reports'])){
                    $lastReport = end($reports[$docTypeId]['reports']);
                    if(isset($lastReport['filePath'])){
                     $href = "/site-operational-program/load-file?document=".$lastReport['filePath']."&filename=".$lastReport['string']."&type=inline";
                    }else{
                        $href = "";
                    }
                }else{
                    $href = "";
                }
                if(isset($reports[$docTypeId]['info']['total'])){
                    $finalResult['total'] += $reports[$docTypeId]['info']['total'];
                }
                if(isset($reports[$docTypeId]['info']['on-time'])){
                    $finalResult['on-time'] += $reports[$docTypeId]['info']['on-time'];
                }
                if(isset($reports[$docTypeId]['info']['tolerance'])){
                    $finalResult['tolerance'] += $reports[$docTypeId]['info']['tolerance'];
                }

                $finalResult['href'] = $href;
                if(isset($reports[$docTypeId]['status_bar']['status_string'])){ 
                
                    if (strpos($reports[$docTypeId]['status_bar']['status_string'], 'Last report on ') !== false) {                   
                        $nextReport = str_replace("Last report on","", $reports[$docTypeId]['status_bar']['status_string']); 
                        $nextReport = str_replace(" overdue","", $nextReport); 
                    }else{
                        $nextReport = str_replace("Next report due ","", $reports[$docTypeId]['status_bar']['status_string']);
                    } 

                }
                $finalResult['nextDate'] = isset($nextReport)?$nextReport:"-";
            }            
            //gatherSiteReportInfoDashboard end  *******************************************************

            if($finalResult['total'] != 0){
                $finalResult['on-time_percentage'] = round(number_format(($finalResult['on-time']/$finalResult['total'])*100,2));
                $finalResult['tolerance_percentage'] = round(number_format(($finalResult['tolerance']/$finalResult['total'])*100,2));
                
                $finalResult['percentage'] = $finalResult['on-time_percentage'] + $finalResult['tolerance_percentage'];
                // $finalResult['percentage'] = round(number_format(($finalResult['on-time']/$finalResult['total'])*100,2));
            }
      

         }
         // echo "<pre>";
         // print_r($finalResult);
         // die;
         return $finalResult;

    }

     public function getReportsStaticsWithoutAlarmsDashboard($FromDate,$toDate,$clientId="",$flag,$provider_ids,$report_interval_id,$docTypeId="",$SiteId="",$allowAll=0){
       
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
                if($SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if(($flag == 2 && $SiteId!="") || ($flag == 3 && $SiteId!="") || ($flag == 7) || ($flag == 8) || ($flag == 9 && $SiteId!="") || ($flag == 10 && $SiteId!="")){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['id' => $SiteId])->all(), 'id', 'id');
            }else{
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            }
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }
        
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
            
        $i = 0;
        $result = [];
      
        foreach($clientSites as $Csite) {
       
            $clientSite = ClientSite::findOne($Csite);
            $node = Node::findOne($model->node);
            
            if($node) {
                $sites = $node->findClientSites();
            } elseif($clientSite) {
                $sites[] = $clientSite;
            } 
            
            //gatherSiteReportInfoDashboard start *******************************************************
            $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        // echo "<pre>";
        // print_r($reportTypes);
        // die;

        
            $rts = [];
            $sop = new SiteOperationalProgram;
            $fArray = array(9,10);
            if(!in_array($flag, $fArray)){
                foreach($reportTypes as $type) {
                    if(isset($type['reportType'])) {
                        $rts[$type['reportType']['doctype_id']] = $type;
                    }
                }
            }else{
                $rts['9999'] = $sop->buildOthersReportType($clientSite);               
            }      

            $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite, '5', $dateRange);
           

         }
         // echo "<pre>";
         // print_r($reports);
         // die;
        // return $finalResult;

    }


    public function getDashboardCompliance($FromDate,$toDate,$clientId="",$flag,$SiteId="",$docTypeId="",$allowAll=0)
    {   
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];

                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }

                if($SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if(($flag == 2 && $SiteId!="") || ($flag == 3 && $SiteId!="") || ($flag == 7) || ($flag == 8) || ($flag == 9 && $SiteId!="") || ($flag == 10 && $SiteId!="")){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['id' => $SiteId])->all(), 'id', 'id');
            }else{
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            }
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }
        
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];        

        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'id');
       
            
        $i = 0;
        foreach($clientSites as $Csite) {
        
            $clientSite = ClientSite::findOne($Csite);
            $node = Node::findOne($model->node);
            
            if($node) {
                $sites = $node->findClientSites();
            } elseif($clientSite) {
                $sites[] = $clientSite;
            }
                
            $reportList[] = $model->gatherSiteReportInfoDashboard($clientSite, $reportTypes,$flag,$dateRange);
    
            if(isset(Yii::$app->user->identity->role) && Yii::$app->user->identity->role == User::ROLE_AUDITOR){
                $i++;
                if($i>5){
                    break;
                }
            }
            
        }
        
        $total = 0;
        $count = count($reportList);
        if($flag == 0){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }elseif($flag == 1){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }
            }
            $finalCompliance = $total;
        }elseif($flag == 2){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $total = $total + 0;    
                    }else{                    
                        $total = $total + $finalReports;
                    }
                }
            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
            $finalCompliance = $finalCompliance;
        }elseif($flag == 3){
            $startD = array();
            $endD = array();
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {

                    if($key1 == 'startdate'){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                array_push($startD,$mdate);
                                $i++;
                            }
                        }
                    }else{
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                array_push($endD,$mdate);
                                $i++;
                            }
                        }
                    }
                }
            }
            
            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }                
                
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }

        }elseif($flag == 4){
            $startD = array();
            $endD = array();

            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                if(($key2 == $i) && ($i == 0)){
                                    array_push($startD,$mdate);
                                }elseif(($key2 == $i) && ($i == 1)){
                                    array_push($endD,$mdate);
                                }
                                $i++;
                            }
                        }
                    }
                }
            }

            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }
            
            
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }
        }elseif($flag == 5){
            $TotalCompliance = 0;
            $RCount = 0; 
            
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        if(!isset($value['id'])){
                            if(!empty($value)){
                                $TotalCompliance = $TotalCompliance + $value;
                                $RCount++;
                            }else{
                                $TotalCompliance = $TotalCompliance + 0;
                            }
                        }else{
                            $TotalCompliance = $TotalCompliance + 0;
                        }
                    }
                }
            }
            if($TotalCompliance>0){
                $finalCompliance = number_format($TotalCompliance/$RCount,2);
            }else{
                $finalCompliance = number_format(0,2);                
            }
        }elseif($flag ==6){ 
            $LastD = array();
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if(!isset($value['id'])){
                        array_push($LastD,$value);
                    }
                }
            }           

            if(!empty($LastD)){

                $mostRecent= 0;
                foreach($LastD as $dates){
                    $curDate = strtotime($dates);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }
                
                $finalCompliance = date('F Y', $mostRecent);
            }else{
                $finalCompliance = "-";
            }
        }elseif($flag == 7){
            $startD = array();
            $endD = array();

            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        $i = 0; 
                        if(!isset($value['id'])){
                            foreach ($value as $key2 => $mdate) {
                                if(($key2 == $i) && ($i == 0)){
                                    array_push($startD,$mdate);
                                }elseif(($key2 == $i) && ($i == 1)){
                                    array_push($endD,$mdate);
                                }
                                $i++;
                            }
                        }
                    }
                }
            }

            if(!empty($startD) || !empty($endD)){
                $mostRecent= 0;
                foreach($endD as $date){
                    $curDate = strtotime($date);
                    if ($curDate > $mostRecent) {
                        $mostRecent = $curDate;
                    }
                }

                $Earliest = strtotime($startD[0]);
                foreach($startD as $date){
                    if(strtotime($date) < $Earliest){
                        $Earliest = strtotime($date);
                    }
                }
                
                
                $finalCompliance = date('d/m/Y',$Earliest).' - '.date('d/m/Y',$mostRecent);
            }else{
                $finalCompliance = "-";
            }

        }elseif($flag == 8){
            $TotalCompliance = 0;
            $RCount = 0; 
            foreach($reportList as $finalReports) {

                foreach ($finalReports as $key1 => $value) {
                    if($key1 == $docTypeId){
                        if(!isset($value['id'])){
                            if(!empty($value)){
                                $TotalCompliance = $TotalCompliance + $value;
                                $RCount++;
                            }else{
                                $TotalCompliance = $TotalCompliance + 0;
                            }
                            
                        }else{
                            $TotalCompliance = $TotalCompliance + 0;
                        }
                    }
                }
            }
            if($TotalCompliance>0){
                $finalCompliance = number_format($TotalCompliance/$RCount,2);
            }else{
                $finalCompliance = number_format(0,2);                
            }
        }elseif($flag == 9){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $OtherReportAudit = "-";
                    }else{
                        $OtherReportAudit = $finalReports;
                    }
                }else{
                    $OtherReportAudit = "-";
                }
            }
            $finalCompliance = $OtherReportAudit;
        }elseif($flag == 10){
            foreach($reportList as $finalReports) {
                if(!empty($finalReports)){
                    if(is_array($finalReports)){
                        $totalReport = 0;
                    }else{
                        $totalReport = $finalReports;
                    }
                }else{
                    $totalReport = 0;
                }
            }
            $finalCompliance = $totalReport;
        }elseif($flag == 11){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }elseif($flag == 12){
            foreach($reportList as $finalReports) {
            
                if(is_array($finalReports)){
                    $total = $total + 0;    
                }else{                    
                    $total = $total + $finalReports;
                }

            }
            if($total>0 && $count>0){
                $finalCompliance = number_format($total/$count,2);
            }else{
                $finalCompliance = number_format(0,2);
            }
        }
        return $finalCompliance;
    }

    // to get client from site id (when we dont have clientsite model to fetch client)
    public function getClientInfo($id){
        return Client::findOne($id);
    }

    public function getReportCountForMyReports($clientSite,$FromDate,$toDate,$docTypeId ){
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['site_id'=> $clientSite])->all(), 'report_type_id', 'report_type_id');   
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];
        
        $clientSite = ClientSite::findOne($clientSite);
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $clientReportArr,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        $rts = [];
        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                $rts[$type['reportType']['doctype_id']] = $type;
            }
        }
        
        $sop = new SiteOperationalProgram;
        $rts['9999'] = $sop->buildOthersReportType($clientSite);
     
        $reports = $sop->findS3Reports($rts, $clientSite, $dateRange);
        $count = 0;
      
        foreach ($reports as $key => $report) {
            
            if($key == $docTypeId && isset($report['reports'])){ 
                 $count = count($report['reports']);              
            }
        }  
     
        return $count;
    }

    public function getReportsForSuppliers($supplier,$clientId,$FromDate,$toDate,$docTypeId,$allowAll=0){
        if($allowAll != 1){
             //for site access user wise. use common\models\UserSiteAccess;
            $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();           
            if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                $forceSites = [];
                foreach ($allowedSites as $key => $value) {
                   array_push($forceSites,$value['site_id']);
                }
                if(isset($SiteId) && $SiteId != "" && !in_array($SiteId, $forceSites)){
                    $SiteId = "";
                }
            }

            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            
                if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
                    if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$forceSites])->all(), 'id', 'id');
                    }
                }else{
                   if($clientId!=""){
                        $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
                    }else{
                        $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
                    } 
                }
                
            
        }else{
            $reportList = [];
            $model = new ClientSite();
            $sites = [];
            if($clientId!=""){
                $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');
            }else{
                $clientSites = ArrayHelper::map(ClientSite::find()->all(), 'id', 'id');
            }
        }

        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];

        $reportTypes = ArrayHelper::map(ReportType::find()->where(['doctype_id'=> $docTypeId])->asArray()->all(), 'id', 'id');
        $final_result = array();
        foreach ($clientSites as $key => $Csite) {
           
            $clientSite = ClientSite::findOne($Csite);
            $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reportTypes,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
            $rts = [];
            foreach($reportTypes as $type) {
                if(isset($type['reportType'])) {
                    $rts[$type['reportType']['doctype_id']] = $type;
                }
            }
        
            $sop = new SiteOperationalProgram;
            
            $reports = $sop->findS3ReportsDashboardStatics($rts, $clientSite,5, $dateRange);
            
            $href = '';
         
        if(isset($reports[$docTypeId]['supplier_reports']) && !empty($reports[$docTypeId]['supplier_reports'])){    
           
            $final_result[$Csite] =  array();
            $result =  array();
            
            $provider = Provider::findOne($supplier); 
            $result['supplier_name'] = $provider->name;
            $result['site_name'] = $clientSite->name;            
            $result['count'] = isset($reports[$docTypeId]['supplier_reports'][$supplier])? count($reports[$docTypeId]['supplier_reports'][$supplier]):0; 
            $lastReport = end($reports[$docTypeId]['supplier_reports'][$supplier]);
            $result['lastReportData'] = $lastReport;
            $result['frequency'] = $reports[$docTypeId]['reportInterval']['name'];
            $result['name'] = $reports[$docTypeId]['reportType']['name'];
            $result['percentage'] = isset($reports[$docTypeId]['supplier_info'][$supplier]['percentages'])? ($reports[$docTypeId]['supplier_info'][$supplier]['percentages']):0; 
            $result['lastReportDate'] = date('d/m/Y',strtotime($lastReport['date']));
            $result['href'] = "/site-operational-program/load-file?document=".$lastReport['filePath']."&filename=".$lastReport['string']."&type=inline"; 
            $result['nextReportDate'] = date('d/m/Y',strtotime('+'. $reports[$docTypeId]['reportInterval']['interval_length'], strtotime($lastReport['date'])));
            $final_result[$Csite]=$result;           
        }

        }
     
       return $final_result;
        
    }

    public function getNextReportDateMyReports($clientSite,$FromDate,$toDate,$docTypeId ){
       
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['site_id'=> $clientSite])->all(), 'report_type_id', 'report_type_id');   
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];
        
        $clientSite = ClientSite::findOne($clientSite);
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $clientReportArr,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        $rts = [];
        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                $rts[$type['reportType']['doctype_id']] = $type;
            }
        }
        
        $sop = new SiteOperationalProgram;
        $rts['9999'] = $sop->buildOthersReportType($clientSite);
     
        $reports = $sop->findS3Reports($rts, $clientSite, $dateRange);
        $nextReport = '-';
      
        foreach ($reports as $key => $report) {
        
            if($key == $docTypeId && isset($report['status_bar']['status_string'])){ 
                
                if (strpos($report['status_bar']['status_string'], 'Last report on ') !== false) {                   
                    $nextReport = str_replace("Last report on","", $report['status_bar']['status_string']); 
                    $nextReport = str_replace(" overdue","", $nextReport); 
                }else{
                    $nextReport = str_replace("Next report due ","", $report['status_bar']['status_string']);
                } 

            }
        }  
            
        return $nextReport;
    }

    public function gatherSiteReportInfoForLoadFile($clientSite,$FromDate,$toDate,$lastReceived='',$docTypeId = ''){
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['site_id'=> $clientSite])->all(), 'report_type_id', 'report_type_id');   
        $dateRange = [
            'date_from' => date('Y-m-d', strtotime($FromDate)),
            'date_to' => date('Y-m-d', strtotime($toDate)),
        ];
 
        $ldate = str_replace('/', '-', $lastReceived);
        $lastReceivedDate = date('Y-m-d', strtotime($ldate));        
        
        $clientSite = ClientSite::findOne($clientSite);
        // if($clientSite->id == "175"){
        //     echo "<pre>";
        //     print_r($clientSite->directory);
        //     die;
        // }
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $clientReportArr,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        $rts = [];
        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                $rts[$type['reportType']['doctype_id']] = $type;
            }
        }
        
        $sop = new SiteOperationalProgram;
        $rts['9999'] = $sop->buildOthersReportType($clientSite);
        //dd($rts);
        $reports = $sop->findS3Reports($rts, $clientSite, $dateRange);
        $href = '';
       
        foreach ($reports as $key => $report) {
        
            if($key != '9999' && isset($report['reports'])){
                if($docTypeId != ""){                 
                    if($docTypeId == $key){
                       $lastReport = end($report['reports']);
                       if($lastReport['date'] == $lastReceivedDate){
                            $href = "/site-operational-program/load-file?document=".$lastReport['filePath']."&filename=".$lastReport['string']."&type=inline";  
                            break;
                        }else{
                            $href = "";
                        }
                    }
                }else{                   
                    $lastReport = end($report['reports']);
                    
                    if($lastReport['date'] == $lastReceivedDate){                       
                        $href = "/site-operational-program/load-file?document=".$lastReport['filePath']."&filename=".$lastReport['string']."&type=inline"; 
                        break;
                    }else{                        
                        $href = "";
                    }   
                      
                }
                               
            }elseif($key == '9999' && isset($report['reports']) && $docTypeId = '9999'){
                $lastReport = end($report['reports']);                    
                if($lastReport['date'] == $lastReceivedDate){                       
                    $href = "/site-operational-program/load-file?document=".$lastReport['filePath']."&filename=".$lastReport['string']."&type=inline"; 
                    break;
                }else{                        
                    $href = "";
                }  
            }
        }  
     
        return $href;
    }
    
    protected function gatherSiteReportInfoDashboard($clientSite, $reporttype, $flag, $dateRange)
    {

        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $reporttype,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();

        $rts = [];
        $sop = new SiteOperationalProgram;
        $fArray = array(9,10);
        if(!in_array($flag, $fArray)){
            foreach($reportTypes as $type) {
                if(isset($type['reportType'])) {
                    $rts[$type['reportType']['doctype_id']] = $type;
                }
            }
        }else{
            $rts['9999'] = $sop->buildOthersReportType($clientSite);            
        }
        $reports = $sop->findS3ReportsDashboard($rts, $clientSite, $flag, $dateRange);
        if(isset($reports)){
            return $reports;    
        }else{
            return $reports = array();
        }

    }
}
