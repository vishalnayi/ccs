<?php

use yii\helpers\Html;
use fedemotta\datatables\DataTables;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use common\models\User;
use common\models\UserClientAccess;
use common\models\Client;
use common\models\ClientSite;
use common\models\ImportForm;
use common\models\ClientListForm;
use common\components\CheckPermissionHelper;
use kartik\select2\Select2;
/* @var $this yii\web\View */
/* @var $searchModel common\models\ClientSiteSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Archive Sites');
$this->params['currentPage'] = 'Sites';
$this->params['currentChild'] = 'Modify Sites';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="caption font-dark">
                            <i class="icon-users font-dark"></i>
                            <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="portlet-body">
                <?php 
                $create = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','create',Yii::$app->user->identity->role);                  
                    if ($userRole == User::ROLE_SUPER || $userRole == User::ROLE_AUDITOR) : ?>
                    <div class="row">  
                     <?php
                        if($userRole == User::ROLE_AUDITOR){
                            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
                            $client = array_column($allowedClients, 'client_id'); 
                            $clientsData = ArrayHelper::map(Client::find()->where(['in','id',$client])->orderBy(['name'=>'SORT_ASC'])->asArray()->all(), 'id', 'name');
                        }
                        else{
                            $clientsData = ArrayHelper::map(Client::find()->orderBy(['name'=>'SORT_ASC'])->asArray()->all(), 'id', 'name');}   

                        $modelClient = New ClientListForm;
                        $form = ActiveForm::begin([
                            'id' => 'client-list-form',                                     
                            'action' =>['/client-site-archive/index'],
                        ]); ?>                     
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                            <div class="Import-client text-left">
                                <?php 
                                    echo $form->field($modelClient, 'client_list_id')->widget(Select2::classname(), [
                                        'data' => $clientsData,
                                        'options' => [
                                            'placeholder'=>'Search sites by client'],
                                            'pluginOptions' => [
                                                'allowClear' => false
                                            ],   
                                    ])->label(false); ?>
                            </div>   
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="Import-client text-right">
                                <button class="btn btn-success">Search</button>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="Import-client text-left">
                             <?= Html::a(Yii::t('app', 'Clear'), ['client-site-archive/index'], ['class' => 'btn btn-success']) ?>
                            </div>
                        </div>
                        <?php 
                            ActiveForm::end();
                        ?>
                           
                    </div>
                <?php endif ?>
               <?php  
                  $update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','update',Yii::$app->user->identity->role);
                  $view = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','view',Yii::$app->user->identity->role);
                  $delete = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','delete',Yii::$app->user->identity->role);
                   
                  if($view == 0 && $update == 0 &&  $delete== 0 ){
                    $visibleActionCol = 0;
                  }else{
                     $visibleActionCol = 1;
                  }

                  if(Yii::$app->user->identity->role == User::ROLE_SUPER){
                    $visibleCheckboxCol = 1;
                  }else{
                    $visibleCheckboxCol = 0;
                  }
                ?>

                <?php echo DataTables::widget([
                    'dataProvider' => $dataProvider,
                    'filterModel' => $searchModel,
                    'columns' => [
                        'id',
                        [
                            'label' => 'Node',
                            'value' => function($data) {
                                return $data->node ? $data->node->name : '';
                            },
                        ],
                        [
                            'label' => 'Client Name',
                            'value' => function($data) {
                                return $data->client->name ?? '';
                            },
                        ],
                        [
                            'label' => 'Site Name',
                            'value' => function($data) {
                                return $data->name ?? '';
                            },
                        ],
                        
                        'directory',
                        // 'created_at',
                        // 'updated_at',

                        [
                            'class' => 'yii\grid\ActionColumn',
        // removed delete function as a quick fix as delete functions aren't working OK
        //                    'template' => '{view} {update} {update-category-provider} {delete}',
                            'visible' => $visibleActionCol,
                            'template' => '{restore} {delete}',
                            'headerOptions' => ['class' => 'actions'],
                            'buttons' => [
                                //view button
                                'restore' => function ($url, $model, $key) {
                                    $view =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','restore',Yii::$app->user->identity->role);
                                   
                                    $visible = $view != 1 ? ' visible-false': '';
                                    return Html::a('<i class="fa fa-undo"></i>
', $url, [
                                        'title' => Yii::t('yii', 'Restore'),
                                        'aria-label' => Yii::t('yii', 'Restore'),
                                        'data-pjax' => '0',
                                        'class'=>'btn btn-icon-only btn-circle grey-salsa'.$visible,
                                    ]);
                                },                                
                                'delete' => function ($url, $model, $key) {
                                    $visible = Yii::$app->user->identity->role != User::ROLE_SUPER ? 'visible-false': '';
                                    //echo $visible; die;
                                    return Html::a('<i class="icon-trash"></i>', $url, [
                                        'title' => Yii::t('yii', 'Delete'),
                                        'aria-label' => Yii::t('yii', 'Delete'),
                                        'data-confirm' => Yii::t('yii', 'If you delete this site, you\'ll need to contact site administrators to add it back.'),
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                        'class'=>'btn red btn-icon-only btn-circle filter-cancel'. $visible,
                                    ]);

                                }
                            ],
                        ],
                    ],
                    'clientOptions' => [
                        "lengthMenu"=> [[10, 25, 50, -1], [10, 25, 50, Yii::t('app',"All")]],
                        "info"=>true,
                        "paging" => true,
                        "searching" => true,
                        "responsive"=>true,
                        "dom"=> 'lfTrtip',
                        "tableTools"=>[
                            "aButtons"=> []
                        ],
                    ],
                    'tableOptions' => [
                        "class"=> 'table table-striped table-bordered table-hover table-checkable order-column dataTable'
                    ],
                ]); ?>
            </div>
        </div>
    </div>
</div>
