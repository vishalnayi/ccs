<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use common\models\Client;
use common\models\ClientSite;
use common\models\ClientListForm;
use common\models\User;
use yii\helpers\ArrayHelper;
use freesoftwarefactory\select3\Select3Widget;
use kartik\select2\Select2; 
use common\models\UserClientAccess;
?>
    <?php $form = ActiveForm::begin([
    'id' => 'user-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);
                ?>

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Enter Email</h4>
      </div>
      <div class="modal-body">            
            <?php echo $form->field($model, 'email')->textInput();?>
            <?php echo $form->field($model, 'clientId')->hiddenInput()->label(false); ?>
      </div>
      <div class="modal-footer">
       <?php echo Html::submitButton(Yii::t('client', 'Send pdf'), ['class' => 'btn btn-primary']) ?>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>

<?php ActiveForm::end(); ?>