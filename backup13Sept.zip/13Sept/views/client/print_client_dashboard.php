<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use common\models\ClientContact;

use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use common\models\ReportType;
use common\models\ReportInterval;
use yii\widgets\ActiveForm;
use GuzzleHttp\Client;
use kartik\daterange\DateRangePicker;
use  yii\web\Session;
use common\components\CheckPermissionHelper;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use yii\helpers\Url;
$session = Yii::$app->session; 

AppAsset::register($this);
// $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
// $client = array_column($allowedClients, 'client_id');
// if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
//     $clientId = $client;
// }else{
//     $clientId = Yii::$app->user->identity->client_id;
// }
$allowAllSite = 0;
$userRole = Yii::$app->user->identity->role;
$vaultLink = Yii::$app->user->identity->vault_link;
if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}else{
    $CrDate = date('d-m-Y');
    if(date('L') == 1){
        $dateNew = strtotime($CrDate.' -365 days');        
    }else{
        $dateNew = strtotime($CrDate.' -364 days');   
    }
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromDate', $pastDate);
    $session->set('toDate', $CrDate);

    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}
$FromDate = $_SESSION['fromDate'];
$toDate = $_SESSION['toDate'];

$DashboardCompliance = ClientSite::getDashboardComplianceStatistic($FromDate,$toDate,$clientId,5);
$ToleranceComplianceRate = floor($DashboardCompliance['tolerance-percentage']);
$OntimeComplianceRate = floor($DashboardCompliance['ontime-percentage']);
$lateComplianceRate = floor($DashboardCompliance['late-percentage']);
$MySuppliers =  ClientSite::getSupplierDataByClient($FromDate,$toDate,$clientId); 
$SupplierCount =  count($MySuppliers); 

// $ToleranceComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,11));
// $OntimeComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,0));

// if($ToleranceComplianceRate == 0 && $OntimeComplianceRate == 0){
//     $lateComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,12));
// }else{
//     $lateComplianceRate = (100 - ($ToleranceComplianceRate + $OntimeComplianceRate));
// }

$totalSites = ClientSite::getClientSites($clientId,1);
$totalReports =ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,1); 
$lastReport = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,6);
$MySites =  ClientSite::getClientSites($clientId,2);
$MyReports =  ClientSite::getMySitesReports($clientId); 
$ReportCount =  count($MyReports);
$clientInfo = ClientSite::getClientInfo($clientId);
// echo "<pre>";
// print_r($clientInfo);
// die;
$reportGeneratedDate = date('d-M-Y');
?>
<table border="0" cellspacing="0" cellpadding="0" style="background:#FFFFFF;width: 100%;margin: 0;">
    <tr>
        <td colspan="2" style="-webkit-print-color-adjust: exact;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                <tr>
                    <td colspan="2" style="height: 190px;"></td>
                </tr>
                <tr>
                    <td style="width: 100%;text-align: center;">
                        <a href="http://rmp-app-demo-lb-1403640771.us-west-2.elb.amazonaws.com/site/login" target="_blank">
                            <img src="<?php echo Url::to('/images/login-logo.png', true); ?>" alt="" />
                        </a>
                    </td> 
                </tr>
                <tr>
                    <td colspan="2" style="height: 190px;"></td>
                </tr>
                <tr>
                    <td colspan="2" style="font-size: 60px;color: #595959;font-weight: bold;padding: 0 0 20px 0;border-bottom: 1px solid #9f9f9f;line-height: 60px;"><?php echo $clientInfo->name; ?></td>
                </tr>
                <tr>
                    <td colspan="2" style="font-size: 20px;text-transform: uppercase;font-weight: normal;padding: 20px 0 0 0;color: #44546a;">Compliance summary reports</td>
                </tr>
                <tr>
                    <td colspan="2" style="height: 150px;"></td>
                </tr>
                <tr>
                    <td style="width: 100%;text-align: center;">
                        <a href="#" target="_blank">
                            <img src="<?php echo Url::to($clientInfo->img_url, true); ?>" alt="" width="200" height="200" />
                        </a>
                    </td> 
                </tr>
                <tr>
                    <td colspan="2" style="height: 150px;"></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<pagebreak>
<table border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto 25px; width:1020px; background:#FFFFFF; font-size: 16px; color: #000; font-family:Arial, Helvetica, sans-serif;">
    <!-- <tr>
        <td colspan="2" style="background: #00B1DC; -webkit-print-color-adjust: exact; padding: 12px 15px; text-align: center;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                <tr>
                    <td style="width: 20%;">
                        <a href="http://rmp-app-demo-lb-1403640771.us-west-2.elb.amazonaws.com/site/login" target="_blank">
                            <img src="<?php echo Url::to('/images/logo-dash.jpg', true); ?>" alt="" />
                        </a>
                    </td> 
                    <td style="width: 80%;text-align: right;font-size: 10px;color: #fff;">
                        <h1><?php echo isset($clientInfo)?$clientInfo->name:""; ?></h1>
                        <h4><b> <?php echo $reportGeneratedDate; ?></b></h4>
                    </td>   
                </tr>
            </table>
        </td>
    </tr> -->
    <tr>
        <td colspan="2" style="-webkit-print-color-adjust: exact;">
            <table border="0" cellspacing="0" style="width:100%;">
                <tr>
                    <td style="width: 33%;text-align: left;">
                        <a href="http://rmp-app-demo-lb-1403640771.us-west-2.elb.amazonaws.com/site/login" target="_blank">
                            <img src="<?php echo Url::to('/images/login-logo.png', true); ?>" alt="" />
                        </a>
                    </td> 
                     <td style="text-align: center;font-size: 25px;width: 33%;">Compliance Report<br><?php echo $RangeValue; ?></td>
                    <td style="width: 33%;text-align: right;">
                        <a href="#" target="_blank">
                            <img src="<?php echo Url::to($clientInfo->img_url, true); ?>" alt="" width="150" height="150" />
                        </a>
                    </td>   
                </tr>
            </table>
        </td>
    </tr>
    <hr>
    <!-- <tr>
        <td colspan="2" style="text-align: center;font-size: 30px;font-weight: bold;">Compliance Report</td>
    </tr> -->
    <!-- <tr>
        <td colspan="2" style="height: 10px;"></td>
    </tr>
    <tr>
        <td colspan="2" style="text-align: center;font-size: 20px;font-weight: normal;"><?php //echo $RangeValue; ?></td>
    </tr> -->
    <tr>
        <td colspan="2" style="height: 35px;"></td>
    </tr>
    <tr>
        <td colspan="2" style="text-align: center;font-size: 30px;font-weight: bold;color: #2e74b5;">Client Summary</td>
    </tr>
    <tr>
        <td style="width: 150px; max-width: 150px; vertical-align: top; text-align: center; padding: 30px 20px 0 0;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                <tr>
                    <td style="color: #00A6DB; font-size: 19px; padding: 9px 0 22px 0;">Compliance</td>
                </tr>
            </table> 
            <table border="0" cellspacing="0" cellpadding="0" style="width:180px; max-width: 150px; padding: 20px 20px 20px 20px; background: #f5f5f5; margin: 0 0 30px 0;">
                <tr>
                    <td style="padding: 0 0 10px 0; ">
                        <table border="0" cellspacing="0" cellpadding="0" style="width:180px; background: #c5c7c9; margin: 0 0 10px 0;">
                            <tr>
                                <td style="background: #00b050; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $OntimeComplianceRate;?>%;"><?php echo $OntimeComplianceRate.'%';?></td>
                                <td style="background: #ffc000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $ToleranceComplianceRate;?>%;"><?php echo $ToleranceComplianceRate."%"; ?></td>
                                <td style="background: #ff0000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $lateComplianceRate; ?>%;"><?php echo $lateComplianceRate; ?>%</td>
                            </tr>
                        </table>                            
                    </td>                                                
                </tr>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:150px; text-align: left; margin: 0 0 18px 0;">
                            <tr>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                        <tr>                                                
                                            <td style="background: url('<?php echo Url::to('/images/color-mark1.jpg',true); ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Ontime
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                        <tr>                                                
                                            <td style="background: url('<?php echo Url::to('/images/color-mark2.jpg',true); ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Tolerance
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                        <tr>
                                        <?php $imgUrl = Url::to('/images/color-mark3.jpg', true);?>                                                
                                            <td style="background: url('<?php echo $imgUrl; ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Late
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr> 
               
            </table>
           
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
                <tr>
                    <td style="font-size: 40px; color: #8bc53f; padding: 0 0 15px 0;"><?php echo $totalSites; ?></td>
                </tr>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;">Sites Monitored</td>
                </tr>
            </table>
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
                <tr>
                    <td style="font-size: 40px; color: #8bc53f; padding: 0 0 15px 0;"><?php echo $totalReports;?></td>
                </tr>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;">Total Reports</td>
                </tr>
            </table>
            <?php 
                            $clientContacts = ClientContact::find()->select('contact_id')->with('contact')->where(['client_id'=>$clientId,'display_dashboard'=>1])->all();
                            if(!empty($clientContacts)){ ?>
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
            	<tr>
            		<td style="text-align: left;font-size: 25px;color: #000;margin: 36px 0 15px 0;font-weight: 900;">Primary Contact</td>
            	</tr>
                <?php
                $i=0; 
                    foreach ($clientContacts as $key => $contact) {
                        if($i>2){
                            break;
                        } ?>
            	<tr>
            		<td style="height: 15px;"></td>
            	</tr>
              
                <?php if($contact['contact']->name != ''){ ?>
            	<tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->name; ?></td>
                </tr>
                <?php } ?>
                <?php if($contact['contact']->job_title != ''){ ?>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->job_title; ?></td>
                </tr>
                <?php } ?>
                <?php if($contact['contact']->street != ''){ ?>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->street; ?></td>
                </tr>
                <?php } ?>
                
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->suburb." ".$contact['contact']->state." ".$contact['contact']->postcode; ?></td>
                </tr>
                
                <?php if($contact['contact']->phone != ''){ ?>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->phone;?></td>
                </tr>
                <?php } ?>
                <?php if($contact['contact']->mobile != ''){ ?>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->mobile;?></td>
                </tr>
                <?php } ?>
                <?php if($contact['contact']->email != ''){ ?>
                <tr>
                    <td style="color: #000; font-size: 16px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->email; ?></td>
                </tr>
                <?php } ?>
                <?php if($contact['contact']->website != ''){ ?>
                 <tr>
                    <td style="color: #000; font-size: 12px; line-height: 24px;text-align: left;"><?php echo $contact['contact']->website; ?></td>
                </tr> 
                <?php } ?>
                <?php if($contact['contact']->comment != ''){ ?>
                 <tr>
                    <td style="color: #000; font-size: 12px; line-height: 24px;text-align: left;border-bottom: 1px solid #ccc;padding: 0 0 10px 0;"><?php echo $contact['contact']->comment; ?></td>
                </tr>
                <?php } ?>
                <?php } ?>
            </table>
        <?php  } ?>
          
        </td>
        <td style="width: 800px; min-width: 800px; vertical-align: top; padding: 30px 0 0 10px;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 10px 0;">   
                            <tr>
                                <td style="font-size: 16px; color: #000; padding: 12px 10px; background: #f5f5f5; text-align: right;">
                                    Audit Period : <?php echo $RangeValue; ?>
                                </td>
                            </tr>    
                        </table>
                    </td>
                    
                </tr>                 
                <tr>
                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">My Sites</td>
                </tr>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">             
                        <?php if(!empty($MySites)){
                                            $LateSites = array();
                                            foreach ($MySites as $MySite) { 
                                                $mySiteId = $MySite['id'];
                                                $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                                if(!empty($lateReports)){                  
                                                    foreach ($lateReports as $client=>$reports) {
                                                        if(isset($reports['late'])){
                                                            foreach ($reports['late'] as $key => $report) {
                                                                $LatesiteID = $report['sop']['site_id'];
                                                                array_push($LateSites, $LatesiteID);
                                                            }
                                                        }
                                                    }
                                                }
                                            } }?>          
                            <tr>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Location</th> 
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No. of  <br/> Reports</th>                                  
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">First Report <br/> Received</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>
                                 
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall  <br/> Compliance</th>
                            </tr>
                            <?php if(!empty($MySites)){ 
                                $i=1;
                                $statusClass = '';
                                foreach ($MySites as $MySite) {
                                    $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                    $mySiteId = $MySite['id'];
                                    // $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,2,$mySiteId);
                                    $Compliance = ClientSite::getSitesComplianceStaticsDashboard($FromDate,$toDate,$mySiteId,5);
                                    $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,3,$mySiteId);
                                    $auditDate =  explode('-', $AuditPeriod);
                                    $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                    $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                    if($Compliance<90){
                                        $statusClass = '#EE402F';
                                    }elseif($Compliance>=90 && $Compliance<=99){
                                        $statusClass = '#F6921E';
                                    }elseif($Compliance==100){
                                        $statusClass = '#8BC53F';    
                                    }
                            ?>
                            <tr>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;<?php if(!empty($LateSites) && !in_array($mySiteId, $LateSites)) { ?> margin-left: 18px;<?php } ?>"><?php echo $MySite['name']; ?><?php          
                                                        if(!empty($LateSites) && in_array($mySiteId, $LateSites)){  ?>
                                                        <img src="<?php echo Url::to('/images/site-alaram-dash.jpg',true); ?>" alt="" />
                                                            
                                                    <?php  } ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo ClientSite::getTotalReportsBySites($FromDate,$toDate,$clientId,1,$mySiteId); ?></td> 
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $firstReceived; ?></td>
                                 <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td>
                                 
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: <?php echo $statusClass; ?>; "><?php echo $Compliance; ?>%</td>
                            </tr>
                            <?php $i++;
                                // if($i>5){
                                //     break;
                                // }
                            } }else{ ?>
                            <tr>
                                <td colspan='4' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No sites found.
                                </td>
                            </tr>
                            <?php } ?>
                        </table> 
                        <?php if($totalSites>5){ 
                            $url = Url::to(['site/list', 'client' =>$clientId],true);
                        ?>
                            <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                <tr>
                                    <td style="padding: 10px 0 0 0;">                                 
                                        <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                    </td>
                                </tr>
                            </table> -->
                        <?php } ?>          
                    </td>
                </tr>
            </table>
            
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
             <tbody>                    
                <tr>
                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">My Report Type(s)</td>
                </tr>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">  
                        <tbody>                 
                            <tr>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Report Type</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No of. <br/> Reports </th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Frequency </th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>
                             
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall  <br/> Compliance</th>
                            </tr>
                            <?php if(!empty($MyReports)){ 
                                $j=1;
                                $statusClass = '';
                                foreach ($MyReports as $MyReport) {
                                    $reports = ClientSite::getReportsStaticsDashboard($FromDate,$toDate,$clientId,5,$MyReport['provider_ids'],$MyReport['report_interval_id'],$MyReport['doctype_id']);
                                    $lastReceived = $reports['lastReportDate'];
                                
                                    $RCompliance = $reports['percentage'];
                                    if($RCompliance<90){
                                        $statusClass = '#EE402F';
                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                        $statusClass = '#F6921E';
                                    }elseif($RCompliance==100){
                                        $statusClass = '#8BC53F';    
                                    }
                                   
                                    $totalReports =$reports['total'];                             
                                    $nextReportDate = isset($reports['nextDate'])?$reports['nextDate']:"-";
                                    $frequency = $MyReport['frequency'];
                            ?>
                            <tr>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['report_type'];?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $totalReports; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $frequency; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td>
                                <!-- <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php //echo $nextReportDate; ?></td> 
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php //echo $MyReport['providers']; ?></td> -->
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; color:<?php echo $statusClass; ?>;"><?php echo $RCompliance; ?>%</td>
                            </tr>
                            <?php $j++;
                                // if($j>5){
                                //     break;
                                // }
                            }                                                
                            }else{ ?>                                
                            <!-- <tr> 
                                <td colspan='5' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No reports found.</td>
                            </tr>   -->
                            <?php } ?>                              
                        </tbody>
                        </table>      
                        <?php if($ReportCount>5){ 
                            $url = Url::to(['site/report1', 'client' =>$clientId],true);?>
                            <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                <tr>
                                    <td style="padding: 10px 0 0 0;">
                                        <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                    </td>
                                </tr>
                            </table> -->
                       
                            <!-- <div class="view-more"><a href="<?php //echo $url; ?>">View All</a></div> -->
                        <?php } ?>       
                    </td>
                </tr>
                 </tbody>
            </table>

            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
             <tbody>                    
                <tr>
                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">My Suppliers</td>
                </tr>
                <tr>
                    <td>
                        <?php if(!empty($MySuppliers)){ ?>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">  
                        <tbody>                 
                            <tr>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Supplier</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No of. <br/> Reports </th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>                                
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall  <br/> Compliance</th>
                            </tr>
                            <?php 
                                $j=1;
                                foreach ($MySuppliers as $MySupplier) {
                               
                                $RCompliance = $MySupplier['info']['percentage'];
                                    if($RCompliance<90){
                                        $statusClass = '#EE402F';
                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                        $statusClass = '#F6921E';
                                    }elseif($RCompliance==100){
                                        $statusClass = '#8BC53F';    
                                    }
                                    
                            ?>
                            <tr>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySupplier['supplier_name'];?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySupplier['info']['total']; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySupplier['lastReportDate']; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySupplier['info']['percentage']; ?></td>
                              
                            </tr>
                            <?php 
                            }  ?>                                              
                                                       
                        </tbody>
                        </table>      
                      <?php    }else{ ?>                                
                           <tr> 
                                <td colspan='4' style="font-size: 14px; line-height: 22px; padding:  5px 10px 5px 5px; ">No records found.</td>
                            </tr>  
                            <?php } ?>   
                    </td>
                </tr>
                 </tbody>
            </table>

            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">  
             <?php $MySites =  ClientSite::getClientSites($clientId,2); ?>                  
                <tr>
                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">Unknown Reports</td>
                </tr>
                <?php 
                    $flag = 0;
                    $totalOtherReports = 0;
                    if(!empty($MySites)){
                        $i=1;
                        $statusClass = '';

                        foreach ($MySites as $MySite) { 
                            $mySiteId = $MySite['id'];
                            $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
                            $auditDate =  explode('-', $AuditPeriod);
                            $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                            $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                            $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
                            $totalOtherReports = $totalOtherReports + $Compliance;
                            if($Compliance>20){
                                $statusClass = 'reject';
                            }elseif($Compliance>5 && $Compliance<=20){
                                $statusClass = 'pending';
                            }elseif($Compliance<5){
                                $statusClass = 'approve';    
                            }
                            if($Compliance != 0){
                                $flag = 1;
                                break;
                            }
                        } 
                    } ?>
                    <?php if($flag == 1){ ?>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">                    
                            <tr>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Location</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No. of <br/> Reports</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">First Report <br/> Received</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th> 
                                
                            </tr>
                            
                            <?php 
                                $totalOtherReports = 0;
                                if(!empty($MySites)){
                                    $i=1;
                                    $statusClass = '';
                                   
                                    foreach ($MySites as $MySite) { 
                                        $mySiteId = $MySite['id'];
                                        $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
                                        $auditDate =  explode('-', $AuditPeriod);
                                        $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                        $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                        $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
                                        $totalOtherReports = $totalOtherReports + $Compliance;
                                        if($Compliance>20){
                                            $statusClass = 'reject';
                                        }elseif($Compliance>5 && $Compliance<=20){
                                            $statusClass = 'pending';
                                        }elseif($Compliance<5){
                                            $statusClass = 'approve';    
                                        }
                            if($Compliance != 0){          
                                        ?>
                            <tr>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySite['name']; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: #8BC53F;"><?php echo $Compliance; ?></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $firstReceived; ?></td>
                               <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td> 
                                                                    
                            </tr>
                            <?php } ?>
                            <?php $i++;
                                // if($i>5){
                                //     break;
                                // }
                            } 
                        }else{?>
                            <tr>
                                <td colspan="4">No data found.</td>
                            </tr>
                        <?php }?>                               
                        </table>  
                        <?php if($totalSites>5){ 
                            //$url = Url::to(['site/report', 'client' =>$clientId],true); ?>
                            <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                <tr>
                                    <td style="padding: 10px 0 0 0;">
                                        <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                    </td>
                                </tr>
                            </table> -->
                        <?php } ?>          
                    </td>
                </tr>
                 <?php 
                 }else{ ?>
                    <tr> 
                        <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;">No reports found.</td>
                    </tr>
                  <?php  } ?>
            </table>
            <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 25px 0;">                    
                <tr>
                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 12px 0;">Sites with Alarms</td>
                </tr>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">  
                            <?php
                                $ArrayCount = 0;
                                if(!empty($MySites)){
                                    $LateSites = array();
                                    foreach ($MySites as $MySite) { 
                                        $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                        $mySiteId = $MySite['id'];
                                        $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                        if(!empty($lateReports)){
                                            foreach ($lateReports as $client=>$reports) {
                                                if(isset($reports['late'])){
                                                    foreach ($reports['late'] as $key => $report) {
                                                        $LatesiteName = $report['sop']['clientSite']['name'];
                                                        array_push($LateSites, $LatesiteName);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if(!empty($LateSites)){
                                        $FinalArray = array_unique($LateSites);
                                        $ArrayCount = count($FinalArray);
                                        $i=1;
                                        foreach ($FinalArray as $key => $site) { ?>                  
                            <tr>
                                <td style="width: 30px; padding: 5px 0;"><img src="/var/www/frontend/web/images/site-alaram-dash.jpg" alt=""/></td>
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;"><?php echo $i.'. '.$site."(".$clientInfo->name.")"; ?></td>
                            </tr>
                            <?php 
                                $i++;
                                // if($i>5){
                                //     break;
                                // }
                            }
                        }else{?>

                            <tr>
                               <!--  <td style="width: 30px; padding: 5px 0;"></td> 
                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;">No alarms found.</td>
                            </tr>
                            <?php }
                            }
                            ?>                            
                        </table>  
                        <?php if($ArrayCount>5){ ?>
                            <!-- <div class="view-more"><a href="#getSitesWithLateReport" data-toggle="modal" >View All</a></div> 
                        <?php } ?>          
                    </td>
                </tr>
            </table> -->                 
        </td>
    </tr>
    <tr>
        <td colspan="2" style="height: 320px;"></td>
    </tr>
</table>
<pagebreak>
<!-- <table border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto 25px; width:1020px; background:#FFFFFF; font-size: 16px; color: #000; font-family:Arial, Helvetica, sans-serif;"> -->
<table border="0" cellspacing="0" style="width:100%;">
    <tr>
        <td colspan="2" style="-webkit-print-color-adjust: exact;">
            <table border="0" cellspacing="0" style="width:100%;">
                <tr>
                    <td style="width: 33%;text-align: left;">
                        <a href="http://rmp-app-demo-lb-1403640771.us-west-2.elb.amazonaws.com/site/login" target="_blank">
                            <img src="<?php echo Url::to('/images/login-logo.png', true); ?>" alt="" />
                        </a>
                    </td> 
                     <td style="text-align: center;font-size: 25px;width: 33%;">Compliance Report<br><?php echo $RangeValue; ?></td>
                    <td style="width: 33%;text-align: right;">
                        <a href="#" target="_blank">
                            <img src="<?php echo Url::to($clientInfo->img_url, true); ?>" alt="" width="150" height="150" />
                        </a>
                    </td>   
                </tr>
            </table>
        </td>
    </tr>
    <hr>
    
    <tr>
        <td colspan="2" style="height: 35px;"></td>
    </tr>
    <tr>
        <td colspan="2" style="text-align: center;font-size: 25px;font-weight: bold;color: #2e74b5;">Site Summaries</td>
    </tr>
     <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2,$allowAllSite);
                        ?>
                        <?php 
                        if(!empty($MySites)){
                            $LateSites = array();
                            foreach ($MySites as $MySite) { 
                                $mySiteId = $MySite['id'];
                                $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                if(!empty($lateReports)){                  
                                    foreach ($lateReports as $client=>$reports) {
                                        if(isset($reports['late'])){
                                            foreach ($reports['late'] as $key => $report) {
                                                $LatesiteID = $report['sop']['site_id'];
                                                array_push($LateSites, $LatesiteID);
                                            }
                                        }
                                    }
                                }
                            }
                            $i=1;
                            $statusClass = '';
                            foreach ($MySites as $MySite) { 
                                $mySiteId = $MySite['id'];
                                $Compliance = ClientSite::getSitesComplianceStaticsDashboard($FromDate,$toDate,$mySiteId,5);
                                $MySiteReports =  ClientSite::getClientSitesReports($mySiteId); ?> 
    <tr>
    	<td style="width: 200px; max-width: 200px; vertical-align: top; padding: 40px 10px 0 0;">
    		<table border="0" cellspacing="0" cellpadding="0" style="width:100px; max-width: 100px; padding: 20px 20px 20px 20px; background: #f5f5f5; margin: 0 0 10px 0;">
                <tr>
                    <td style="padding: 0 0 10px 0; ">
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100px; background: #c5c7c9; margin: 0 0 10px 0;">
                            <tr>
                                <td style="background: #00b050; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $Compliance; ?>%;"><?php echo $Compliance.'%';?></td>
                                <!-- <td style="background: #ffc000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $ToleranceComplianceRate;?>%;"><?php echo $ToleranceComplianceRate."%"; ?></td>
                                <td style="background: #ff0000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $lateComplianceRate; ?>%;"><?php echo $lateComplianceRate; ?>%</td> -->
                            </tr>
                        </table>                            
                    </td>                                                
                </tr>
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:150px; text-align: left; margin: 0 0 5px 0;">
                            <tr>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:<?php echo $Compliance; ?>%;">
                                        <tr>                                                
                                            <td style="background: url('<?php echo Url::to('/images/color-mark1.jpg',true); ?>') 0 center no-repeat; font-size: 14px; padding: 0 40px;"> Overall Compliance Rate
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr> 
            </table>
    		<table border="0" cellspacing="0" cellpadding="0" style="margin: 0 0 30px 0;">
    			<!-- <tr>
        			<td style="height: 35px;"></td>
    			</tr> -->
                <tr>
                    <td style="padding: 0; ">
                        <table border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style="color: #00A6DB;font-size: 20px;font-weight: 400;"><?php echo $MySite['name']; ?></td>
                            </tr>
                            <!-- <tr>
                                <td style="height: 20px;"></td>
                            </tr> -->
                            <tr>
                                <td style="color: #000;font-size: 20px;font-weight: 400;"><?php echo $MySite['site_address']; ?></td>
                            </tr>
                        </table>                            
                    </td>                                                
                </tr>
            </table>
            <table border="0" cellspacing="0" cellpadding="0" style="margin: 0 0 30px 0;">
                <tr>
                    <td style="padding: 0; ">
                        <table border="0" cellspacing="0" cellpadding="0">
                           <!--  <tr>
                                <td style="color: #00A6DB;font-size: 20px;font-weight: 400;">Site Contact</td>
                            </tr> -->
                            <!-- <tr>
                                <td style="height: 20px;"></td>
                            </tr> -->
                            <!-- <tr>
                                <td style="color: #000;font-size: 20px;font-weight: 400;"><?php echo $MySite['manager_name']; ?></td>
                            </tr> -->
                            <!-- <tr>
                                <td style="height: 10px;"></td>
                            </tr> -->
                            <!-- <tr>
                                <td style="color: #000;font-size: 23px;font-weight: bold;">Tower Manager</td>
                            </tr>
                            <tr>
                                <td style="height: 10px;"><?php echo $MySite['contact_number']; ?></td>
                            </tr>
                            <tr>
                                <td><a href="#" style="color: #000;font-size: 25px;font-weight: 400;text-decoration: underline;"><?php echo $MySite['email_address']; ?></a></td>
                            </tr> -->
                           <!--  <tr>
                                <td style="height: 10px;"></td>
                            </tr> -->
                            <!-- <tr>
                                <td><a href="#" style="color: #000;font-size: 25px;font-weight: 400;text-decoration: underline;">25pryorstreet@cleancloudsystems.com</a></td>
                            </tr> -->
                        </table>                            
                    </td>                                                
                </tr>
            </table>
            <table border="0" cellspacing="0" cellpadding="0" style="margin: 0;">
                <tr>
                    <td style="padding: 0 0 5px 0; ">
                        <!-- <table border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style="color: #00A6DB;font-size: 20px;font-weight: 400;">Additional Comment</td>
                            </tr>
                            <tr><td><?php //echo $MySite['comment']; ?></td></tr>
                        </table> -->                            
                    </td>                                                
                </tr>
            </table>
    	</td>
        
        <td style="width: 670px; min-width: 670px; vertical-align: top; padding: 40px 0 0 0px;">
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
             	<tbody>                    
                	<tr>
                    	<td>
                        	<table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">	
                        		<tbody>                 
		                            <tr>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Report Type</th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No of. <br/> Reports </th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Frequency </th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Next Report</th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Supplier</th>
		                                <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall  <br/> Compliance</th>
		                            </tr>
		                            <?php 
                                    $sitesWithoutPrimaryAlarmSet = array();
                                                        array_push($sitesWithoutPrimaryAlarmSet, $mySiteId);
                                    if(!empty($sitesWithoutPrimaryAlarmSet)){ 

		                                $j=1;
		                               $reports = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,'','','');
                                        foreach ($reports as $key => $MyReport) { 
                                                            if($key != 'clientTotal'){  
		                                    $RCompliance = $MyReport['percentage'];
                                                                if($RCompliance != '-'){
                                                                    if($RCompliance<90){
                                                                        $statusClass = 'reject';
                                                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                                                        $statusClass = 'pending';
                                                                    }elseif($RCompliance==100){
                                                                        $statusClass = 'approve';    
                                                                    }
                                                                    $RCompliance = $RCompliance.'%';
                                                                }else{
                                                                   $statusClass = ''; 
                                                                }     
                                                                $loadFileHrefReport = isset($MyReport['href'])?$MyReport['href']:"";
                                                                
		                            ?>
		                            <tr>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['name'];?></td>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['total']; ?></td>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['frequency']; ?></td>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['lastReportDate']; ?></td>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo ($MyReport['frequency'] == "-")?"-":$MyReport['nextDate']; ?></td> 
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['supplier']; ?></td>
		                                <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; color:<?php echo $statusClass; ?>;"><?php echo $RCompliance; ?></td>
		                            </tr>
		                            <?php $j++;
		                                // if($j>5){
		                                //     break;
		                                // }
                                }
		                            }                                                
                            		}else{ ?>                                
		                            <!-- <tr> 
		                                <td colspan='5' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No reports found.</td>
		                            </tr>  --> 
                            		<?php } ?>                              
                        		</tbody>
                        	</table>      
	                        <?php if($ReportCount>5){ 
	                            $url = Url::to(['site/report1', 'client' =>$clientId],true);?>
	                          
                        	<?php } ?>       
                    	</td>
                	</tr>
                </tbody>
            </table>
            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">  
	            <?php $MySites =  ClientSite::getClientSites($clientId,2); ?>                  
	                <!-- <tr>
	                    <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">Unknown Reports</td>
	                </tr> -->
	                <?php 
	                    $flag = 0;
	                    $totalOtherReports = 0;
	                    if(!empty($MySites)){
	                        $i=1;
	                        $statusClass = '';

	                        foreach ($MySites as $MySite) { 
	                            $mySiteId = $MySite['id'];
	                            $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
	                            $auditDate =  explode('-', $AuditPeriod);
	                            $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
	                            $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
	                            $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
	                            $totalOtherReports = $totalOtherReports + $Compliance;
	                            if($Compliance>20){
	                                $statusClass = 'reject';
	                            }elseif($Compliance>5 && $Compliance<=20){
	                                $statusClass = 'pending';
	                            }elseif($Compliance<5){
	                                $statusClass = 'approve';    
	                            }
	                            if($Compliance != 0){
	                                $flag = 1;
	                                break;
	                            }
	                        } 
	                    } ?>
                    <?php if($flag == 1){ ?>

                 <?php 
                 }else{ ?>
                    <!-- <tr> 
                        <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;">No reports found.</td>
                    </tr> -->
                  <?php  } ?>
            </table>
            <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">  
                <tr>
                    <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">    <tr>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Name</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Job Title</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Street</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">City</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">State</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Postcode</th> 
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Phone</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Mobile</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Email</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Website</th>
                                <th style="background: #f5f5f5; font-size: 15px; line-height: 30px; padding: 15px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Comment</th>
                            </tr>
                            <tr>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">Kinnal</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: #8BC53F;">ABC</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;">Elite</td>
                               <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;">Ahmedabad</td>
                               <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">Gujarat</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: #8BC53F;">360005</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;">9874569852</td>
                               <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;">9874569852</td>
                               <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">abc@gmail.com</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: #8BC53F;">www.google.com</td>
                                <td style="font-size: 14px; line-height: 22px; padding: 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;">ABCDEFAE</td>
                            </tr>
                        </table>  
                    </td>
                </tr>
            </table> -->
        </td>
    </tr>
    
<?php } } ?>
</table>

