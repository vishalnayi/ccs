<?php

use yii\helpers\Html;
use fedemotta\datatables\DataTables;
use yii\widgets\ActiveForm;
use yii\base\DynamicModel;
use common\models\ImportForm;
use common\models\User;
use yii\helpers\Url;
use kartik\daterange\DateRangePicker;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ClientSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Clients');
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'Client';
$this->params['breadcrumbs'][] = $this->title;

?>
<style>
    .kv-drp-dropdown .right-ind {
        right: 12px;
        top: 8px;
    }  
    .kv-drp-dropdown .left-ind {
        left: 11px;
        top: 8px;
        /* padding: 0 5px 0 0; */
    }
    .kv-drp-dropdown .right-ind.kv-clear{ 
        display: none;  
    }
    .kv-drp-dropdown .range-value {
        padding-left: 3rem;    
    }
    .print-report-client form .kv-drp-container .kv-drp-dropdown { 
        display: inline-block;
        float: left;
        width: 80%;
     }
     .print-report-client form .back-button { float: unset; }
     .print-report-client form .back-button .bluebtn{float: left;margin: 0 10px; }
     .portlet-body .print-report-div {margin-bottom: 25px}

</style>
<?php
$session = Yii::$app->session; 
if(isset($_SESSION['fromPrintDate']) && isset($_SESSION['toPrintDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toPrintDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromPrintDate']));
    $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
}else{
    $CrDate = date('d-m-Y');

    if(date('L') == 1){
       $dateNew = strtotime($CrDate.' -365 days');        
    }else{
        $dateNew = strtotime($CrDate.' -364 days');   
    }
    
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromPrintDate', $pastDate);
    $session->set('toPrintDate', $CrDate);

     $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
}
$this->registerJs(
    "$(document).on('ready',(function(){         
    $(document).on('click', '.showModalButton11', function () {       
        if ($('#mailModal').data('bs.modal').isShown) {
            $('#mailModal').find('#modalContent11')
                    .load($(this).attr('value'));                           
        } else {
            $('#mailModal').modal('show');
            $('#mailModal').find('#modalContent11')
                    .load($(this).attr('value'));
            
        }
    });
 }));"
);
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="caption font-dark">
                            <i class="icon-users font-dark"></i>
                            <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                        </div>
                    </div>
                    <?php if(Yii::$app->user->identity->role == User::ROLE_SUPER) { ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="text-right">
                            <a href="/import_clients_sample_data.csv">Download Sample file</a> 
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
            <div class="portlet-body">
            <div class="row print-report-div">
                        <div class="col-md-12">
                            <div class="main-date-range">
                                <label>Select Audit Period :</label>
                                <div class="drp-container print-report-client">
                                <?php 
                                    /*$modelD = DynamicModel::validateData(
                                                ['filter_date_range',
                                    ]);*/
                                    $form = ActiveForm::begin([
                                        'id' => 'dashboard-filter-form',
                                        'fieldConfig' => [
                                            'options' => [
                                                'tag' => 'span',
                                                'style' =>'margin: 0 0 20px 0;',
                                            ],
                                        ],
                                        'method' => 'post',
                                        'action' =>['/client-site/print-filter'],
                                    ]);

                                    echo DateRangePicker::widget([
                                        'name'=>'filter_date_range',
                                        'value'=> $RangeValue,                                
                                        'startAttribute' => $pastDate,
                                        'endAttribute' => $CrDate,
                                        'presetDropdown'=>true,
                                        'hideInput'=>true,
                                        'pluginOptions'=>[
                                            'format'=>'d-m-Y',
                                            'locale' => [
                                                'format' => 'DD-MM-YYYY',
                                                'separator'=>' to ',
                                            ],
                                        ]
                                    ]);
                                ?>
                                
                                <div class="back-button">
                                    <?= Html::submitButton(Yii::t('app', 'Apply'), ['class' => 'btn bluebtn']);
                                    ActiveForm::end();

                                    $form = ActiveForm::begin([
                                        'id' => 'clear-filter-form',
                                        'fieldConfig' => [
                                            'options' => [
                                                'tag' => 'span',
                                            ],
                                        ],
                                        'method' => 'post',
                                        'action' =>['/client-site/clear-print-filter'],
                                    ]);
                                    echo Html::submitButton(Yii::t('app', 'Clear'), ['class' => 'btn bluebtn']) ?>
                                    <?php ActiveForm::end(); ?>
                                    <?php //echo Html::a('Clear', ['/client-site/clear-filter'], ['class' => 'btn bluebtn']) ?>
                                </div>
                                </div>
                            </div>
                        </div>                        
            </div>
            <?php if(Yii::$app->user->identity->role == User::ROLE_SUPER) { ?>
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <p><?php echo Html::a(Yii::t('app', 'Create Client'), ['create'], ['class' => 'btn btn-success']) ?></p>        
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                         <div class="Import-client text-right">
                            <?php 
                                $modelF = New ImportForm;
                                $form = ActiveForm::begin([
                                    'id' => 'import-client-form',
                                    'fieldConfig' => [
                                        'options' => [
                                            'enctype' => 'multipart/form-data',
                                        ],
                                    ],
                                    'action' =>['/client/import'],
                                ]);

                                //$form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]);

                                echo $form->field($modelF, 'file')->fileInput(); ?>

                                <button class="btn btn-success">Submit</button>
                            <?php 
                                ActiveForm::end();
                            ?>
                        </div>   
                    </div>
                </div>
                <?php } ?>

                <?php echo DataTables::widget([
                    'dataProvider' => $dataProvider,
                    'filterModel' => $searchModel,
                    'columns' => [
                        'id',
                        'name',
                        'created_at',
                        'updated_at',

                        [
                            'class' => 'yii\grid\ActionColumn',
                            'template' => '{view} {update} {delete} {print} {mailreport}',
                            'headerOptions' => ['class' => 'actions'],
                            'buttons' => [
                                //view button
                                'view' => function ($url, $model, $key) {
                                    return Html::a('<i class="icon-magnifier"></i>', $url, [
                                        'title' => Yii::t('yii', 'View'),
                                        'aria-label' => Yii::t('yii', 'View'),
                                        'data-pjax' => '0',
                                        'class'=>'btn btn-icon-only btn-circle grey-salsa',
                                    ]);
                                },
                                'update' => function ($url, $model, $key) {
                                    return Html::a('<i class="icon-pencil"></i>', $url, [
                                        'title' => Yii::t('yii', 'Update'),
                                        'aria-label' => Yii::t('yii', 'Update'),
                                        'data-pjax' => '0',
                                        'class'=>'btn green btn-icon-only btn-circle filter-submit',
                                    ]);
                                },
                                'delete' => function ($url, $model, $key) {
                                    return Html::a('<i class="icon-trash"></i>', $url, [
                                        'title' => Yii::t('yii', 'Delete'),
                                        'aria-label' => Yii::t('yii', 'Delete'),
                                        'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                        'class'=>'btn red btn-icon-only btn-circle filter-cancel',
                                    ]);

                                },
                                'print' => function ($url, $model, $key) {
                                    return Html::a('<i class="fa fa-download"></i>', $url, [
                                        'title' => Yii::t('yii', 'Download Report'),
                                        'aria-label' => Yii::t('yii', 'Preview Report'),                                      
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                        'target'=>'_blank',
                                        'class'=>'btn btn-icon-only btn-circle grey-salsa',
                                    ]);

                                },
                                'mailreport' => function ($url, $model, $key) {
                                    return Html::a('<i class="fa fa-envelope"></i>', FALSE, [
                                        'title' => Yii::t('yii', 'Mail Report'),
                                        'aria-label' => Yii::t('yii', 'Mail Report'),  
                                        'data-toggle'=>'modal',
                                        'data-target'=>'#mailModal',
                                        'data-pjax' => '0',   
                                        'value' => Url::to(['client/mailreport', 'id' =>$key],true), 
                                        'href' => $url,                                   
                                        'class'=>'showModalButton11 loadMainContent btn btn-icon-only btn-circle grey-salsa',
                                    ]);

                                },
                            ],
                        ],
                    ],
                    'clientOptions' => [
                        "lengthMenu"=> [[10, 25, 50, -1], [10, 25, 50, Yii::t('app',"All")]],
                        "info"=>true,
                        "paging" => true,
                        "searching" => true,
                        "responsive"=>true,
                        "dom"=> 'lfTrtip',
                        "tableTools"=>[
                            "aButtons"=> []
                        ],
                    ],
                    'tableOptions' => [
                        "class"=> 'table table-striped table-bordered table-hover table-checkable order-column dataTable'
                    ]
                ]); ?>
            </div>
        </div>
    </div>
</div>
<div class="modal remote fade" id="mailModal">
        <div class="modal-dialog">
            <div class="modal-content loader-lg content" id= "modalContent11">
             
            </div>
        </div>
</div>