<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\Client */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'client-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'client_id', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($modelF, 'file')->fileInput(); 
?>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
