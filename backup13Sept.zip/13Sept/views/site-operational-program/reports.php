<?php

use yii\helpers\Html;
use common\models\User;
use common\components\CheckPermissionHelper;

$update =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Print Reports','update',Yii::$app->user->identity->role);
foreach($siteListReports as $reports) :

    foreach($reports as $key=>$reportList) :
        $this->title = isset($reportList['name'])?$reportList['name']:"- " . ' Reports';
        echo $this->render('@app/views/partials/_portlet-start'); ?>
        <p><strong><?php echo isset($reportList['name'])?$reportList['name']:"- ";  ?></strong> - <?php echo isset($reportList['name'])?$reportList['name']:"- ";  ?> (Reports: <?php echo isset($reportList['reportInterval']['interval_length'])?$reportList['reportInterval']['interval_length']:" - " ?>)</p>
        <table class="table table-striped table-bordered"> 
            <tr><th>Date</th><th>Time</th><th>Filename</th><th>Days</th><th>Status</th> <?php if($update == '1'){ ?><th>Actions</th><?php } ?></tr>
            <?php if (isset($reportList['reports'])) : ?>
                <?php foreach($reportList['reports'] as $report) : ?>
                    <tr>
                        <td><?= $report['date'] ?></td>
                        <td><?= $report['time'] ?></td>
                        <td><a href="/site-operational-program/load-file?document=<?= $report['filePath'] ?>&filename=<?= $report['string'] ?>"><?= $report['string'] ?></a></td>
                        <td><?= $report['info']['delta'] ?? null ?></td>
                        <td class="<?= $report['info']['status-class']  ?? null ?>"><?= $report['info']['status']  ?? null  ?></td>
                        <?php if($update == '1'){ ?>
                        <td><a href="/document/move-document?Document[site_id]=<?= $report['clientSiteId'] ?>&Document[existing_path]=<?= $report['path'] ?>&Document[existing_filename]=<?= $report['filename'] ?>">Rename/move</a><?php if(Yii::$app->user->identity->role == User::ROLE_SUPER){?>
                            &nbsp;&nbsp;<a href="/document/delete-document?Document[site_id]=<?= $report['clientSiteId'] ?>&Document[existing_path]=<?= $report['path'] ?>&Document[existing_filename]=<?= $report['filename'] ?>">Delete</a>
                        <?php }?></td>

                        <?php } ?>
                    </tr>
                <?php endforeach ?>
            <?php endif ?>
            <?php if(isset($reportList['status_bar'])) : ?>
            <tr class="status-bar">
                <td colspan="6" class="<?= $reportList['status_bar']['status_class'] ?>"><?= $reportList['status_bar']['status_string'] ?></td>
            </tr>
            <tr class="percentages-bar">
                <td colspan="6" class=""><?= $reportList['percentages'] ?></td>
            </tr>
            <?php endif ?>
        </table>
        <hr />
        <?php echo $this->render('@app/views/partials/_portlet-end');
    endforeach;
endforeach;
