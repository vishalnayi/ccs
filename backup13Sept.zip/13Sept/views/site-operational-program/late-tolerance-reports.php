<?php

use yii\helpers\Html;
use common\models\User;
use common\models\Client;
use common\components\CheckPermissionHelper;

//$this->title = Yii::t('app', 'Late Tolerance Reports');


$update =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Print Reports','update',Yii::$app->user->identity->role);
foreach($reports as $client=>$reports):

    foreach($reports as $key=>$reportList) :
         $client = Client::findOne($client);
        // echo "<pre>";
        // print_r($reportList);
        // die;
        if(Yii::$app->user->identity->role == User::ROLE_ADMIN){
                if($client->id != Yii::$app->user->identity->client_id){
                    continue;
                }
         }
        if(Yii::$app->user->identity->role == User::ROLE_AUDITOR && isset($allowedClients) && !empty($allowedClients)){
                if(!in_array($model->client_id, $clients)){
                    continue;
                }
         }
        $this->title = 'Client '.$client->name;
        echo $this->render('@app/views/partials/_portlet-start'); ?>
        
        <table class="table table-striped table-bordered"> 
            <tr>
                <?php if(Yii::$app->user->identity->role !=  User::ROLE_ADMIN){ ?>
                        <th>ID</th>
                        <th>Client ID</th>
                <?php } ?>
                
                
                <th>Site</th>
                <th>Report Name</th>
                <th>Report Type</th>
                <th>Frequency</th>
                <th>Due</th>
                <th>Supplier</th>
                 </tr>
            <?php if (isset($reportList)) : ?>
                <?php foreach($reportList as $report) :

                 ?>
                    <tr>
                        <?php if(Yii::$app->user->identity->role != User::ROLE_ADMIN){ ?>
                        <td><?= $client->id ?></td>
                        <td><?= $client->client_id ?></td>
                    <?php } ?>
                        <td><?= $report['sop']->clientSite->name ?></td>
                        <td><?= $report['sop']->name ?></td>
                        <td><?= $report['sop']->reportType->name ?></td>
                        <td><?= $report['sop']->reportInterval->name ?></td>
                        <td><?= $report['info']['dueDate'] ?></td>
                        <td><?= $report['info']['providers'] ?></td>
                        
                    </tr>
                <?php endforeach ?>
            <?php endif ?>
            <?php if(isset($reportList['status_bar'])) : ?>
            <tr class="status-bar">
                <td colspan="6" class="<?= $reportList['status_bar']['status_class'] ?>"><?= $reportList['status_bar']['status_string'] ?></td>
            </tr>
            <tr class="percentages-bar">
                <td colspan="6" class=""><?php //$reportList['percentages']; ?></td>
            </tr>
            <?php endif ?>
        </table>
        
        <?php echo $this->render('@app/views/partials/_portlet-end');
    endforeach;
    endforeach;
  $this->title = 'Late Tolerance Reports';
  $this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = 'Late Tolerance Reports';
  
?>