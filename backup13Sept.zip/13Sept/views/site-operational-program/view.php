<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use common\components\CheckPermissionHelper;

/* @var $this yii\web\View */
/* @var $model common\models\SiteReport */

$this->title = $model->name;
$this->params['currentPage'] = 'Sites';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Site Reports'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

$update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Site Reports','update',Yii::$app->user->identity->role);
$delete = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Site Reports','delete',Yii::$app->user->identity->role);
?>
<div class="portlet-body form">
    <?php echo DetailView::widget([
    'model' => $model,
    'attributes' => [
        'id',
        [
            'label' => 'Site',
            'value' => isset($model->clientSite) ? $model->clientSite->name : null,
        ],
        [
            'label' => 'Report Type',
            'value' => $model->reportType->name,
        ],
        [
            'label' => 'Report Interval',
            'value' => $model->reportInterval->name,
        ],
        'name',
        'start_date',
        'additional_emails',
        'created_at',
        'updated_at',
    ],
]); ?>
<?php if($update || $delete){ ?>
        <div class="form-actions">
            <div class="col-xs-12">
            <?php if($update){ echo Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']); } ?>
            <?php if($delete){ echo Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger',
                'data' => [
                    'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                    'method' => 'post',
                ],
            ]); } ?>
            </div>
        </div>
    <?php } ?>
</div>
