<?php

use yii\helpers\Html;   
use yii\helpers\Url;    
use common\models\Provider; 
use yii\widgets\ActiveForm; 
use common\models\Client;   
use common\models\ClientSite;   
use common\models\ClientListForm;   
use common\models\User; 
use yii\helpers\ArrayHelper;    
use kartik\select2\Select2; 
use freesoftwarefactory\select3\Select3Widget;  
use common\models\ReportType;   
use common\models\ReportInterval;   
use common\models\UserSiteAccess;   
use yii\base\DynamicModel;

/* @var $this yii\web\View */
/* @var $model common\models\SiteReport */
/* @var $form yii\widgets\ActiveForm */
if($model->isNewRecord){
    $providerData = ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name');
}
$form = ActiveForm::begin([
    'id' => 'node-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ],
]);
 //for site access user wise. use common\models\UserSiteAccess;
$allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
    $forceSites = [];
    foreach ($allowedSites as $key => $value) {
        array_push($forceSites,$value['site_id']);
    }
}
echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){
    echo $form->field($model, 'site_id', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
    ])->dropDownList(ArrayHelper::map(ClientSite::find()->where(['client_id' => $client->id])->andWhere(['in','id',$forceSites])->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Site --','onchange'=>'
        $.get( "'.Url::toRoute('/site-operational-program/getproviderbysite').'", { id: $(this).val() } )
        .done(function( data ) { 
            console.log(data);
            var options = jQuery.parseJSON(data);
            $("#siteoperationalprogram-provider_ids").multiselect("dataprovider", options
            );
            $("#siteoperationalprogram-provider_ids").multiselect("rebuild");
           
        });']);
}else{
    echo $form->field($model, 'site_id', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
    ])->dropDownList(ArrayHelper::map(ClientSite::find()->where(['client_id' => $client->id])->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Site --','onchange'=>'
        $.get( "'.Url::toRoute('/site-operational-program/getproviderbysite').'", { id: $(this).val() } )
        .done(function( data ) { 
            console.log(data);
            var options = jQuery.parseJSON(data);
            $("#siteoperationalprogram-provider_ids").multiselect("dataprovider", options
            );
            $("#siteoperationalprogram-provider_ids").multiselect("rebuild");
           
        });']);
}

echo $form->field($model, 'report_type_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --'
// ,'onchange'=>'   
//         $.get( "'.Url::toRoute('/site-operational-program/getcat').'", { id: $(this).val() } )  
//         .done(function( data ) {                
//             $("#dynamicmodel-category").disabled = true;    
//             $("#dynamicmodel-category").val(JSON.parse(data).name);     
//             $("#dynamicmodel-category_id").val(JSON.parse(data).id);        
//         });'
        ]); 

echo $form->field($model, 'provider_ids', [         
    'template' => '<div class="form-group form-md-line-input ">{input}{label}{error}</div>',    
    ])->dropDownList($providerData,array('multiple'=>true))->label('Supplier');
echo $form->field($model, 'start_date', [       
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->widget(\yii\jui\DatePicker::className(), ['dateFormat' => 'yyyy-MM-dd','options' => ['class' => 'form-control']])->label('Start Date');

echo $form->field($model, 'report_interval_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportInterval::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --']);

if( ($model->isNewRecord) || (!$model->isNewRecord && empty($model->additional_emails)) ){
    echo $form->field($model, 'additional_emails', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{hint}</div>',     
    ])->textInput( ['id' => 'additional_emails','value'=>'alerts@cleancloudsystems.com,','data-initial'=>'alerts@cleancloudsystems.com,'])->hint('you can enter comma seperated emails (Ex. test@test.com,abc@demo.com)');

}else{
    echo $form->field($model, 'additional_emails', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{hint}</div>',     
    ])->textInput( ['id' => 'additional_emails','data-initial'=>'alerts@cleancloudsystems.com,'])->hint('you can enter comma seperated emails (Ex. test@test.com,abc@demo.com)');   
}

 ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
<?php 
$this->registerJs(" 
    $('#additional_emails').on('keyup', function() {
    var value = $(this).val();
    $(this).val($(this).data('initial') + value.substring(29));
  });

   $('#siteoperationalprogram-provider_ids').multiselect({           
        enableFiltering: true,           
        maxHeight: 250, 
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true
    });
  ");

if(!$model->isNewRecord){

    $this->registerJs(" 
     $('#siteoperationalprogram-provider_ids').multiselect('select', [".$model->provider_ids."]);");
}
 ?>