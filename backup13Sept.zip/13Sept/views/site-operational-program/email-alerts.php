<h1>Late Report for <?= $client->name ?></h1>
<p>This email contains a list of reports that are overdue or in the tolerance period.</p>
<?php

echo $this->render('@app/../frontend/views/partials/_portlet-start');

foreach($reports as $status=>$reportList) : ?>

    <h2><?= strtoupper($status) ?> Reports</h2>

    <table border="1">
        <thead><th>Site</th><th>Report Name</th><th>Report Type</th><th>Due</th><th>Providers</th></thead>
    <?php foreach($reportList as $report) : ?>
        <tr>
            <td style="padding: 5px;"><?= $report['sop']->clientSite->name ?></td>
            <td style="padding: 5px;"><?= $report['sop']->name ?></td>
            <td style="padding: 5px;"><?= $report['sop']->reportType->name ?></td>
            <td style="padding: 5px;"><?= $report['info']['dueDate'] ?></td>
            <td style="padding: 5px;"><?= $report['info']['providers'] ?></td>
        </tr>
    <?php endforeach ?>
    </table>

<?php endforeach;

echo $this->render('@app/../frontend/views/partials/_portlet-end');
