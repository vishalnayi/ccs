<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use common\models\Client;
use common\models\ClientSite;
use common\models\ClientListForm;
use common\models\User;
use yii\helpers\ArrayHelper;
use freesoftwarefactory\select3\Select3Widget;
use kartik\select2\Select2; 
use common\models\UserClientAccess;
/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'user-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($model, 'username', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($model, 'email', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

if(Yii::$app->user->identity->role != User::ROLE_USER):
    if(Yii::$app->user->identity->role == User::ROLE_ADMIN || Yii::$app->user->identity->role == User::ROLE_AUDITOR){
        echo $form->field($model, 'role', [
            'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->dropDownList(User::getUserRoles());
    }elseif(Yii::$app->user->identity->role == User::ROLE_SUPER){
        echo $form->field($model, 'role', [
            'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->dropDownList(User::getRoles(),array('onchange'=>'
        if($("#user-role").val() != 8){
          $("#user-client_id").attr("name", "User[client_id]"); 
          $("#user-client_id").removeAttr("multiple");
          $("#user-client_id").multiselect("rebuild");
          $("#user-client_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            enableCaseInsensitiveFiltering: true
          });
          $.get( "'.Url::toRoute('/client-site/lists').'", { id: $("#user-client_id").val() } )
            .done(function( data ) {                            
              $.fn.select3load($("#clientSiteListId") , JSON.parse(data));                          
            }
          );
        }else{  
          $("#user-client_id").attr("name", "User[client_id][]");         
          $("#user-client_id").attr("multiple", "multiple");
          $("#user-client_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });
          $("#user-client_id").multiselect("rebuild");
        }'));
    }
endif;

if($superUser):
    echo $form->field($model, 'vault_link', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}</div>',
    ])->textInput();
   
endif;

//if($model->isNewRecord):
if($superUser || Yii::$app->user->identity->role == User::ROLE_ADMIN || Yii::$app->user->identity->role == User::ROLE_AUDITOR):
    if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
    $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
    $client = array_column($allowedClients, 'client_id');   
    $clientsData = ArrayHelper::map(Client::find()->where(['in','id',$client])->orderBy([
                          'name' => SORT_ASC      
                        ])->asArray()->all(), 'id', 'name');
    }else{
        $clientsData = ArrayHelper::map(Client::find()->orderBy([
                        'name' => SORT_ASC      
                      ])->asArray()->all(), 'id', 'name');
    }
  if(!$model->isNewRecord && $model->role == User::ROLE_AUDITOR){
    echo $form->field($model, 'client_id', ['template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',])->dropDownList($clientsData,array('multiple'=>true,'onchange'=>'
                    $.get( "'.Url::toRoute('/client-site/lists').'", { id: $(this).val() } )
                    .done(function( data ) {                            
                      $.fn.select3load($("#clientSiteListId") , JSON.parse(data));                          
                    });' ))->label(false);
  }else{
    echo $form->field($model, 'client_id', [       
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->dropDownList($clientsData,array('onchange'=>'
        $.get( "'.Url::toRoute('/client-site/lists').'", { id: $(this).val() } )
        .done(function( data ) {                            
            $.fn.select3load($("#clientSiteListId") , JSON.parse(data));                          
        }
        );'))->label(false);
  }
    ?>
    <div class='row'>
    <div class='col-md-3'>
    <?php
      $modelClient = New ClientListForm;
      echo  $form->field($modelClient, 'client_list_id')
          ->widget(Select3Widget::className(), 
          [
              'id'=>'clientSiteListId',
              'prompt' => 'Select Sites',
              'options' => $clientSites,
              'autoSelectOptions'=>$selectedOptions,
              'allSelectable' => true,
              'allSelectableLabel' => "",
              'visibleAtStartup' => false,
          ])->label('Site'); 
    ?>
    </div>
    </div>
     <?php   echo $form->field($model, 'password_hash', [
            'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->passwordInput(['value'=>'']);
endif;
    /*echo $form->field($model, 'password_hash', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->passwordInput();*/
//endif;
?>
<div class="form-group">
    <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       <?php if(isset($model->client_id)){ //FOR EDIT USER FUNCTION?> 
         if($('#user-role').val()!= '8'){ //8=AUDITOR USER
            $("#user-client_id").attr("name", "User[client_id]");
            $("#user-client_id").removeAttr("multiple");   
          }     
          $("#user-client_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });  
          $('#user-client_id').multiselect('select', [<?php echo is_array($model->client_id)?implode(',', $selectedClients):$model->client_id; ?>]);
          $("#user-client_id").multiselect("rebuild");
        <?php }else{ //FOR CREATE USER FUNCTION ?> 
          if($('#user-role').val()!= '8'){ //8=AUDITOR USER
            $("#user-client_id").attr("name", "User[client_id]");       
            $("#user-client_id").removeAttr("multiple");            
            //$("#user-client_id").val(149);
            $("#user-client_id").trigger("change");
          }
          $('#user-client_id').multiselect({           
            enableFiltering: true,           
            maxHeight: 250, 
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });
        <?php }?>
    });
</script>
<?php ActiveForm::end(); ?>
