<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\User;
use common\components\CheckPermissionHelper;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = $model->username;
$this->params['currentPage'] = 'Users';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Users'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','update',Yii::$app->user->identity->role);
echo $this->render('@app/views/partials/_portlet-start'); ?>
<div class="portlet-body form">
    <?php echo DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'label' => 'Client Name',
                'value' => $model->client->name,
            ],
            'username',
            [
                'label' => 'role',
                'value' => User::getRole($model->role),
            ],
            'email:email',
            'vault_link',
            'status',
            'created_at',
            'updated_at',
        ],
    ]) ?>
    <div class="form-actions">
        <div class="col-xs-12">
            <?php if($update){ echo Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']); } ?>
            <?php if(Yii::$app->user->identity->role == User::ROLE_SUPER){ echo Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger',
                'data' => [
                    'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                    'method' => 'post',
                ],
            ]); } ?>
            <?php if(Yii::$app->user->identity->role == User::ROLE_SUPER){ 
                echo Html::a('Back', ['user/index'], ['class' => 'btn btn-info']);
            } ?>
        </div>
    </div>
</div>
<?php echo $this->render('@app/views/partials/_portlet-end');
