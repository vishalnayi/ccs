<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\Client;
use common\models\User;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'user-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($model, 'username', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($model, 'email', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

if(Yii::$app->user->identity->role != User::ROLE_USER):
    if(Yii::$app->user->identity->role == User::ROLE_ADMIN){
        echo $form->field($model, 'role', [
            'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->dropDownList(User::getUserRoles());
    }elseif(Yii::$app->user->identity->role == User::ROLE_SUPER){
        echo $form->field($model, 'role', [
            'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->dropDownList(User::getRoles());
    }
endif;

if($superUser):

    echo $form->field($model, 'vault_link', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}</div>',
    ])->textInput();
    echo $form->field($model, 'client_id', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->dropDownList(ArrayHelper::map(Client::find()->asArray()->all(), 'id', 'name'));
endif;
if($superUser || Yii::$app->user->identity->role == User::ROLE_ADMIN):
    echo $form->field($model, 'password_hash', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->passwordInput(['value'=>'']);
endif;
/*if($model->isNewRecord):
    echo $form->field($model, 'password_hash', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->passwordInput();
endif;*/
?>
<div class="form-group">
    <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
