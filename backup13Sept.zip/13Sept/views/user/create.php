<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Create User');
$this->params['currentPage'] = 'Users';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Users'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
    'clientSites' => $clientSites,
    'selectedOptions' =>$selectedOptions,
    'superUser' => $superUser,
]);

echo $this->render('@app/views/partials/_portlet-end');
