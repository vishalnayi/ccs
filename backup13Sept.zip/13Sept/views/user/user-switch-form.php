<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;
use common\models\User;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Switch User');
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'Switch User';
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start'); ?>
    <div class="portlet-body form">
    <?php echo Html::beginForm(); ?>
        <div class="form-group form-md-line-input form-md-floating-label has-info">
            <?php echo Html::dropDownList(
                Url::to('id'),
                '',
                ArrayHelper::map(
                    User::find()->all(),
                    'id', 'username'
                ),
                [
                    'class' => 'form-control'
                ]); ?>
            <label for="<?php echo Url::to('id') ?>">Select a User</label>
        </div>
        <p><?php echo Html::submitButton('Switch', ['class' => 'btn btn-primary']); ?></p>
    <?php echo Html::endForm(); ?>
    </div>
<?php echo $this->render('@app/views/partials/_portlet-end');
