<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\User;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Switch User');
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'Switch User';
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start'); ?>

<p>You have now switched to user: <strong><?= $user->username ?></strong></p>

<?php echo $this->render('@app/views/partials/_portlet-end'); ?>
