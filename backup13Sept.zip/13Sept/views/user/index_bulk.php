<?php

use yii\helpers\Html;
use common\models\User;
use fedemotta\datatables\DataTables;
use kartik\grid\GridView;
use common\components\CheckPermissionHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Users');
$this->params['currentPage'] = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">                
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="caption font-dark">
                        <i class="icon-users font-dark"></i>
                        <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                    </div>
                </div>
                <?php if ($userRole == User::ROLE_SUPER) : ?>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="text-right">
                        <?= Html::a('Back', ['user/index'], ['class' => 'btn btn-info','style'=>"float:right; padding-bottom:5px"]) ?>
                    </div>
                </div>

                <?php endif ?>
            </div>
           <?php     
          $update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','update',Yii::$app->user->identity->role);
          $view = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','view',Yii::$app->user->identity->role);
          $delete = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','delete',Yii::$app->user->identity->role);
           $create = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','create',Yii::$app->user->identity->role);
          if($view == 0 && $update == 0 &&  $delete== 0 ){
            $visibleActionCol = 0;
          }else{
             $visibleActionCol = 1;
          }

          if(Yii::$app->user->identity->role == User::ROLE_SUPER){
            $visibleCheckboxCol = 1;
          }else{
            $visibleCheckboxCol = 0;
          }
     
          ?> 
            <div class="portlet-body">
                <p>
                    <?=Html::beginForm(['user/bulkdelete'],'post');?>
                    <?php if($visibleCheckboxCol){ ?>
                        <?=Html::submitButton('Delete Selected', ['class' => 'btn btn-danger','data-confirm' => 'Are you sure you want to delete selected items?']);?>
                    <?php } ?>
                </p>
                
                <!-- Kartik Grid view-->
               
                <?php $gridColumns = [                    
                    ['class' => 'kartik\grid\CheckboxColumn','visible'=>$visibleCheckboxCol],
                    'username',
                    'client.name',
                    [
                            'label' => 'Role',
                            'value' => function($data) {
                                return User::getRole($data->role);
                            },
                    ],
                    'email:email',
                    [
                        'class' => 'kartik\grid\ActionColumn',
                        'dropdown' => false,
                        'visible' => $visibleActionCol,
                        'vAlign'=>'middle',
                        'buttons' => [
                                //view button
                                'view' => function ($url, $model, $key) {
                                    
                                     $view =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','view',Yii::$app->user->identity->role);
                                   
                                     $visible = $view != 1 ? ' visible-false': '';
                                    return Html::a('<i class="icon-magnifier"></i>', $url, [
                                        'title' => Yii::t('yii', 'View'),
                                        'aria-label' => Yii::t('yii', 'View'),
                                        'data-pjax' => '0',
                                        'class'=>'btn btn-icon-only btn-circle grey-salsa'. $visible,
                                    ]);
                                },
                                'update' => function ($url, $model, $key) use ($userRole){                                    
                                    $update =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Users','update',Yii::$app->user->identity->role);
                                    $visible = $update != 1 ? ' visible-false': '';
                                    return Html::a('<i class="icon-pencil"></i>', $url, [
                                        'title' => Yii::t('yii', 'Update'),
                                        'aria-label' => Yii::t('yii', 'Update'),
                                        'data-pjax' => '0',
                                        'class'=>'btn green btn-icon-only btn-circle filter-submit'. $visible,
                                    ]);
                                },
                                'delete' => function ($url, $model, $key) use ($userRole) {
                                    $visible = $userRole != User::ROLE_SUPER ? 'visible-false': '';
                                    return Html::a('<i class="icon-trash"></i>', $url, [
                                        'title' => Yii::t('yii', 'Delete'),
                                        'aria-label' => Yii::t('yii', 'Delete'),
                                        'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                        'class'=>'btn red btn-icon-only btn-circle filter-cancel '. $visible,
                                    ]);

                                }
                            ],
                    ],
                  
                ];
                echo GridView::widget([
                    'id' => 'kv-grid-demo',
                    'dataProvider' => $dataProvider,
                    'filterModel' => $searchModel,
                    'columns' => $gridColumns,    
                    'pjax' => false,
                    'bordered' => true,
                    'export'=>false,
                    'striped' => false,                 
                    'toggleData' =>false,
                    'condensed' => true,
                    'responsive' => true,
                    'hover' => true,                    
                    'showPageSummary' => false,
                   // 'panel'=>false,
                    'panel' => [
                        'type' => GridView::TYPE_PRIMARY
                    ],

                ]); ?>
                 <?= Html::endForm();?> 
                <!-- End Kartik Grid view -->
            </div>
        </div>
    </div>
</div>
<?php

?>