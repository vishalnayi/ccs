<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Assign {modelClass}: ', [
    'modelClass' => 'User Permission',
]) . ' ' . $model->id;
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'User Permissions';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Permissions'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Assign');

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
    'modelUser'=>$modelUser,
    'superUser' => $superUser,
]);

echo $this->render('@app/views/partials/_portlet-end');

