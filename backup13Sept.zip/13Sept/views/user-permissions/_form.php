<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\Client;
use common\models\User;
use common\models\RightsModules;
use yii\helpers\ArrayHelper;
use common\models\UserPermissions;
use yii\base\DynamicModel;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'user-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($modelUser, 'username', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($modelUser, 'user_role', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['value'=>User::getRole($modelUser->role)]);

?>

    <div class="table-responsive">
        <table class="table cms-table">
            <thead>
                <tr>
                  <th>Module Name</th>
                  <th>View</th>
                  <th>Add</th>                                          
                  <th>Edit</th>                                          
                  <th>Delete</th>                                          
                </tr>
            </thead>
            <tbody>
            </tbody>
            <?php

                $allModules = ArrayHelper::map(RightsModules::find()->all(), 'id', 'module_name');         
                foreach ($allModules as $moduleId => $ModuleName) : 
                    $i=1;
                ?>
                     <tr>
                        <td><?php echo $ModuleName; ?></td>
                        <?php while($i <= 4){ ?>
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                    <?php 
                                    $proPeople=UserPermissions::find()->where(['user_rights_id'=>$moduleId ,'user_id'=>$modelUser->id])->all();                   
                                    $data = ArrayHelper::toArray($proPeople, [
                                        'common\models\UserPermissions' => [
                                            'id',
                                            'user_id',
                                            'user_rights_id',
                                            'p_field_1',
                                            'p_field_2',
                                            'p_field_3',
                                            'p_field_4',
                                            'status',
                                            'created_at',
                                            'updated_at',
                                        ],
                                    ]);                                 
                                    if(!empty($data))
                                    {
                                        $dyModel = new DynamicModel(compact('p_field_1', 'p_field_2','p_field_3','p_field_4'));                                        
                                        $dyModel->defineAttribute('p_field_1', $data[0]['p_field_1']);
                                        $dyModel->defineAttribute('p_field_2', $data[0]['p_field_2']);
                                        $dyModel->defineAttribute('p_field_3', $data[0]['p_field_3']);
                                        $dyModel->defineAttribute('p_field_4', $data[0]['p_field_4']);


                                       echo $form->field($dyModel, 'p_field_'.$i)->checkbox(array('label'=>'','value'=>'1','name'=>'txt_permission['.$moduleId.']['.$i.']','id'=>'txt_permission'.$moduleId.$i));

                                    }else {

                                       echo $form->field($model, 'p_field_'.$i)->checkbox(array('label'=>'','value'=>'1','name'=>'txt_permission['.$moduleId.']['.$i.']','id'=>'txt_permission'.$moduleId.$i)); 

                                    } ?>
                                    <span class="checkmark"></span>
                                    </label>
                                </div>
                            </td>                            
                            <script type="text/javascript">
                                $('#txt_permission<?php echo $moduleId; ?>2').click(function() {
                                    if ($(this).is(':checked')) {
                                        $('#txt_permission<?php echo $moduleId; ?>1').prop('checked' ,true);
                                        doEnableButton = true;
                                        if (doEnableButton) {
                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('disabled', 'checked')
                                        }else {
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                        }

                                    } else {
                                        if ($('#txt_permission<?php echo $moduleId; ?>3').is(':checked') || $('#txt_permission<?php echo $moduleId; ?>4').is(':checked')) {

                                        }else{
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('checked', false);
                                        }
                                    }
                                });

                                $('#txt_permission<?php echo $moduleId; ?>3').click(function() {
                                    if ($(this).is(':checked')) {
                                        $('#txt_permission<?php echo $moduleId; ?>1').prop('checked' ,true);
                                        doEnableButton = true;
                                        if (doEnableButton) {

                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('disabled', 'disabled')
                                            $('.txt_permission<?php echo $moduleId; ?>1').val('1');

                                        }else {
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                        }

                                    } else {
                                        if ($('#txt_permission<?php echo $moduleId; ?>2').is(':checked') || $('#txt_permission<?php echo $moduleId; ?>4').is(':checked')) {

                                        }else{
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('checked', false);
                                        }
                                    }
                                });

                                $('#txt_permission<?php echo $moduleId; ?>4').click(function() {
                                    if ($(this).is(':checked')) {
                                        $('#txt_permission<?php echo $moduleId; ?>1').prop('checked', true);
                                        doEnableButton = true;
                                        if (doEnableButton) {
                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('disabled', 'disabled')
                                        }else {
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                        }

                                    } else {
                                        if ($('#txt_permission<?php echo $moduleId; ?>2').is(':checked') || $('#txt_permission<?php echo $moduleId; ?>3').is(':checked')) {

                                        }else{
                                            $('#txt_permission<?php echo $moduleId; ?>1').removeAttr("disabled");
                                            $('#txt_permission<?php echo $moduleId; ?>1').prop('checked', false);
                                        }
                                    }
                                });
                            </script>
                    <?php $i++; } ?>                    
                    </tr>
            <?php endforeach;
            ?>

            </tbody>
        </table>
    </div>
<div class="form-group">
    <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
