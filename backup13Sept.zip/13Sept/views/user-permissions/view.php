<?php

use yii\helpers\Html;
use common\models\User;
use fedemotta\datatables\DataTables;
use kartik\grid\GridView;
/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Permissions for '.$model->username.' ( '.User::getRole($model->role).' )');
$this->params['currentPage'] = 'UserPermissions';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-users font-dark"></i>
                    <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                </div>
            </div>
            <div class="portlet-body">
                <!-- Add checkbox to all row-->
              
                <?php echo DataTables::widget([
                    'dataProvider' => $dataProvider,
                    'filterModel' => $searchModel,          
                    'columns' => [                       
                        ['class' => 'yii\grid\SerialColumn'],                   
                       
                        [
                            'label'=>'Module Name',
                            'value'=>function ($data){
                                return $data->moduledata->module_name;
                            },
                        ],
                        [
                            'label'=>'View',
                            'format' => 'html',
                             'value'=>function ($data){
                                if($data->p_field_1 == '1'){
                                    return Html::tag('i','',['class'=>'fa fa-check','style'=>'color:#35ce35;']);
                                }else{
                                    return Html::tag('i','',['class'=>'fa fa-times','style'=>'color:#e44e36;']);
                                }
                            },
                        ],
                        [
                            'label'=>'Add',
                            'format' => 'html',
                            'value'=>function ($data){
                                if($data->p_field_2 == '1'){
                                    return Html::tag('i','',['class'=>'fa fa-check','style'=>'color:#35ce35;']);
                                }else{
                                    return Html::tag('i','',['class'=>'fa fa-times','style'=>'color:#e44e36;']); 
                                }
                            },
                        ],
                        [
                            'label'=>'Edit',
                            'format' => 'html',
                            'value'=>function ($data){
                                if($data->p_field_3 == '1'){
                                    return Html::tag('i','',['class'=>'fa fa-check','style'=>'color:#35ce35;']);
                                }else{
                                    return Html::tag('i','',['class'=>'fa fa-times','style'=>'color:#e44e36;']);
                                }
                            },
                        ],
                        [
                            'label'=>'Delete',
                            'format' => 'html',
                            'value'=>function ($data){
                                if($data->p_field_4 == '1'){
                                    return Html::tag('i','',['class'=>'fa fa-check','style'=>'color:#35ce35;']);
                                }else{
                                    return Html::tag('i','',['class'=>'fa fa-times','style'=>'color:#e44e36;']); 
                                }
                            },
                        ],                      
                    ],
                    'clientOptions' => [
                        "lengthMenu"=> [[10, 25, 50, -1], [10, 25, 50, Yii::t('app',"All")]],
                        "info"=>true,
                        "paging" => true,
                        "searching" => true,
                        "responsive"=>true,
                        "dom"=> 'lfTrtip',
                        'sorting'=>false,
                        "tableTools"=>[
                            "aButtons"=> []
                        ],
                    ],
                    'tableOptions' => [
                        "class"=> 'table table-striped table-bordered table-hover table-checkable order-column dataTable'
                    ]
                ]); ?>

<!--End Add checkbox to all row-->                
            </div>
        </div>
    </div>
</div>
