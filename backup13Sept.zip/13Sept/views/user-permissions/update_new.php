<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\RightsModules;
/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = 'demo';
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'User Permissions';
// $this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Permissions'), 'url' => ['index']];
// $this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
// $this->params['breadcrumbs'][] = Yii::t('app', 'Assign');

echo $this->render('@app/views/partials/_portlet-start');
$form = ActiveForm::begin();
  $allModules = ArrayHelper::map(RightsModules::find()->all(), 'id', 'module_name');
foreach ($allModules as $moduleId => $ModuleName) : 
foreach ($model as $index => $setting) {
	if($setting->user_rights_id == $moduleId){
    echo $form->field($setting, "[$index]p_field_1")->label('View');
    echo $form->field($setting, "[$index]p_field_2")->label('Add');
    echo $form->field($setting, "[$index]p_field_3")->label('Edit');
    echo $form->field($setting, "[$index]p_field_4")->label('Delete');
    for($i=1;$i<=4;$i++){
    	 echo $form->field($setting, 'p_field_'.$i)->checkbox(array('label'=>'','value'=>'1','name'=>'txt_permission['.$moduleId.']['.$i.']','id'=>'txt_permission'.$moduleId.$i)); 
    	}  
    }else{
      for($i=1;$i<=4;$i++){
    	echo $form->field($setting, 'p_field_'.$i)->checkbox(array('label'=>'','value'=>'1','name'=>'txt_permission['.$moduleId.']['.$i.']','id'=>'txt_permission'.$moduleId.$i)); ?>
        <span class="checkmark"></span> 
    <?php }  } 

}
 endforeach;
        
ActiveForm::end();

echo $this->render('@app/views/partials/_portlet-end');