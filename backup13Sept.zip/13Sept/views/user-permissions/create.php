<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'User Permissions');
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'User Permissions';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Permissions'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
     'modelUser'=>$modelUser,
]);

echo $this->render('@app/views/partials/_portlet-end');
