<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\User;
use yii\console\widgets\Table;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = 'Permissions for '.$model[0]->user->username;
$this->params['currentPage'] = 'System Admin';
$this->params['currentChild'] = 'Users Permissions';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Permissions'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
echo $this->render('@app/views/partials/_portlet-start'); ?>

<?php
    $attr =[
                [  
                    'label' => 'User Name',
                    'value' => $model[0]->user->username,
                ],
                [  
                    'label' => 'Email',
                    'value' => $model[0]->user->email,
                ],
                [  
                    'label' => 'Role',
                    'value' => User::getRole($model[0]->user->role),
                ],
                [
                    'label' => 'Permissions',               
                     'value' => 'View Add Edit Delete ',      
                ],
    ];
    foreach ($model as $key => $m) {
        $Permissions = [];
        for($i = 1;$i<=4;$i++){
            $j = 'p_field_'.$i;
            if($m->$j == '1'){
                array_push($Permissions, 'Yes');
            }else{
                array_push($Permissions, ' No ');
            }
        }
        $value = implode('  ', $Permissions);
            $arr =  [
                    'label' => $m->moduledata->module_name,
                    'value' => $value
            ];
            array_push($attr,$arr);
    }


?>
<div class="portlet-body form">
    <?php echo DetailView::widget([
        'model' => $model,
        'attributes' => $attr,
    ]) ?>

</div>
<?php echo $this->render('@app/views/partials/_portlet-end');
