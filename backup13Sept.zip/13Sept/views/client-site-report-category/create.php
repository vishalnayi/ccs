<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ClientSiteReportCategory */

$this->title = Yii::t('app', 'Create Client Site Report Category');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Client Site Report Categories'), 'url' => ['index', 'clientSiteId' => $clientSite->id]];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title;
?>
<div class="client-site-report-category-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'clientSite' => $clientSite,
    ]) ?>

</div>
