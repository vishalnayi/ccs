<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use common\models\Provider;
use common\models\ReportCategory;

/* @var $this yii\web\View */
/* @var $model common\models\ClientSiteReportCategory */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="client-site-report-category-form">

    <?php $form = ActiveForm::begin(); ?>

    <h3><?= $clientSite->client->name ?> - <?= $clientSite->name ?></h3>

    <?= $form->field($model, 'client_site_id')->hiddenInput() ?>

    <?= $form->field($model, 'report_category_id')->dropDownList(ArrayHelper::map(ReportCategory::find()->asArray()->all(), 'id', 'name')); ?>

    <?= $form->field($model, 'provider_id')->dropDownList(ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name'))->label('Supplier Id');; ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
