<?php

use yii\helpers\Html;
use common\models\User;
use common\models\ImportForm;
use yii\widgets\ActiveForm;
use common\models\ClientListForm;
use yii\grid\GridView;
use fedemotta\datatables\DataTables;

/* @var $this yii\web\View */
/* @var $searchModel common\models\ClientSiteReportCategorySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Client Site Report Categories');
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title;
?>
<div class="client-site-report-category-index">

    <h1 style="display:inline-block;"><?= Html::encode($this->title) ?></h1>
    <?php if (Yii::$app->user->identity->role == User::ROLE_SUPER) : ?> 
            <a style="float:right;" class="nav-link" href="/import_client_site_report_category_sample_data.csv">Download Sample file</a>       
    <?php endif ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
   <div class="container">
    <div class="row" style="margin-bottom:30px;">
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="padding: 0;"> 
        <?= Html::a(Yii::t('app', 'Create Client Site Report Category'), ['create', 'clientSiteId' => $clientSiteId], ['class' => 'btn btn-success']) ?>
      </div> 
      <?php if (Yii::$app->user->identity->role == User::ROLE_SUPER) :  ?>
                   
          <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <div class="Import-client text-right">
              <?php 
                $modelF = New ImportForm;
                $form = ActiveForm::begin([
                    'id' => 'import-client-sites-form',
                    'fieldConfig' => [
                        'options' => [
                            'enctype' => 'multipart/form-data',
                        ],
                    ],
                    'action' =>['/client-site-report-category/import'],
                ]);

                //$form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]);

                echo $form->field($modelF, 'file')->fileInput();
                echo $form->field($modelF, 'site_id',['options' => ['style' => 'display:none;']])->hiddenInput(['value'=>$clientSiteId])->label(false); ?>

                <button class="btn btn-success" >Submit</button>
                <?php 
                    ActiveForm::end();
                ?>
            </div>   
          </div>
        <?php endif ?>
    </div>
  </div>
    <?= DataTables::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'label' => 'Client Site',
                'value' => function ($data) {
                    return $data->clientSite->name;
                },
            ],
            [
                'label' => 'Report Category',
                'value' => function ($data) {
                    return $data->reportCategory->name;
                },
            ],
            [
                'label' => 'Supplier',
                'value' => function ($data) {
                    return $data->provider->name;
                },
            ],
            'created_at',
            [
            'class' => 'yii\grid\ActionColumn',
            'template' => '{view} {update} {delete}',
            'headerOptions' => ['class' => 'actions'],
            'buttons' => [
              //view button
              'view' => function ($url, $model, $key) {
                return Html::a('<i class="icon-magnifier"></i>', $url, [
                  'title' => Yii::t('yii', 'View'),
                  'aria-label' => Yii::t('yii', 'View'),
                  'data-pjax' => '0',
                  'class' => 'btn btn-icon-only btn-circle grey-salsa',
                ]);
              },
              'update' => function ($url, $model, $key) {
                return Html::a('<i class="icon-pencil"></i>', $url, [
                  'title' => Yii::t('yii', 'Update'),
                  'aria-label' => Yii::t('yii', 'Update'),
                  'data-pjax' => '0',
                  'class' => 'btn green btn-icon-only btn-circle filter-submit',
                ]);
              },
              'delete' => function ($url, $model, $key) {
                return Html::a('<i class="icon-trash"></i>', $url, [
                  'title' => Yii::t('yii', 'Delete'),
                  'aria-label' => Yii::t('yii', 'Delete'),
                  'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                  'data-method' => 'post',
                  'data-pjax' => '0',
                  'class' => 'btn red btn-icon-only btn-circle filter-cancel',
                ]);

              }
            ],
                  ],
        ],
    ]); ?>
</div>
