<?php
    /**
     * Display the introduction for a light portlet
     *
     */

    use yii\helpers\Html;
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                </div>
            </div>