<?php
    /**
     * Display the closing Divs for a light portlet
     *
     */
?>
        </div>
    </div>
</div>
