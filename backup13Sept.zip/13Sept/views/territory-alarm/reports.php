<?php

use yii\helpers\Html;


foreach($siteListReports as $reports) :

    foreach($reports as $key=>$reportList) :
        $this->title = $reportList['name'] . ' Reports';
        echo $this->render('@app/views/partials/_portlet-start'); ?>
        <p><strong><?= $reportList['name'] ?></strong> - <?= $reportList['clientSite']['name'] ?> (Reports: <?= $reportList['reportInterval']['interval_length'] ?>)</p>
        <table class="table table-striped table-bordered"> 
            <tr><th>Date</th><th>Time</th><th>Filename</th><th>Delta</th><th>Status</th><th>Actions</th></tr>
            <?php if (isset($reportList['reports'])) : ?>
                <?php foreach($reportList['reports'] as $report) : ?>
                    <tr>
                        <td><?= $report['date'] ?></td>
                        <td><?= $report['time'] ?></td>
                        <td><a href="/site-operational-program/load-file?document=<?= $report['filePath'] ?>&filename=<?= $report['string'] ?>"><?= $report['string'] ?></a></td>
                        <td><?= $report['info']['delta'] ?? null ?></td>
                        <td class="<?= $report['info']['status-class']  ?? null ?>"><?= $report['info']['status']  ?? null  ?></td>
                        <td><a href="/document/move-document?Document[site_id]=<?= $report['clientSiteId'] ?>&Document[existing_path]=<?= $report['path'] ?>&Document[existing_filename]=<?= $report['filename'] ?>">Rename/move</a></td>
                    </tr>
                <?php endforeach ?>
            <?php endif ?>
            <?php if(isset($reportList['status_bar'])) : ?>
            <tr class="status-bar">
                <td colspan="6" class="<?= $reportList['status_bar']['status_class'] ?>"><?= $reportList['status_bar']['status_string'] ?></td>
            </tr>
            <tr class="percentages-bar">
                <td colspan="6" class=""><?= $reportList['percentages'] ?></td>
            </tr>
            <?php endif ?>
        </table>
        <hr />
        <?php echo $this->render('@app/views/partials/_portlet-end');
    endforeach;
endforeach;
