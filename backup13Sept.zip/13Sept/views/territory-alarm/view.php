<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\SiteReport */

$this->title = $model->name;
$this->params['currentPage'] = 'Sites';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Territory Alarm'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start'); ?>
<div class="portlet-body form">
    <?php echo DetailView::widget([
    'model' => $model,
    'attributes' => [
        'id',
        [
            'label' => 'Site',
            'value' => isset($model->clientSite) ? $model->clientSite->name : null,
        ],
        [
            'label' => 'Report Type',
            'value' => $model->reportType->name,
        ],
        [
            'label' => 'Alarm Interval',
            'value' => (($model->territory_interval_id) > 0 ? $model->reportInterval->name : null),
        ],
        'name',
        'additional_emails',
        'created_at',
        'updated_at',
    ],
]); ?>
    <div class="form-actions">
        <div class="col-xs-12">
        <?php echo Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?php echo Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ]) ?>
        </div>
    </div>
</div>
