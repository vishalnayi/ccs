<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use common\models\ClientSite;
use common\models\ReportType;
use common\models\ReportInterval;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\SiteReport */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'node-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ],
]);

echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true, 'disabled' => true]);

echo $form->field($model, 'site_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ClientSite::find()->where(['client_id' => $client->id])->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Site --','disabled' => 'disabled']);

echo $form->field($model, 'report_type_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --','disabled' => 'disabled']);

echo $form->field($model, 'territory_interval_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportInterval::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --']);

echo $form->field($model, 'additional_emails', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{hint}</div>',
])->textInput()->hint('you can enter comma seperated emails (Ex. test@test.com,abc@demo.com)');

echo $form->field($model, 'territory_alarm')->hiddenInput(['value'=> 1])->label(false);

 ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
