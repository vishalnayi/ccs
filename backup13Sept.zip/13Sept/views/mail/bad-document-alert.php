
<h1>Bad document found by DPE</h1>

<p>A document was discovered by the DPE and could not be processed.'<p>

<table>
    <tr><th style="text-align:left">Subject: </th><td><?= $subject ?></td></tr>
    <tr><th style="text-align:left">date: </th><td><?= $date ?></td></tr>
    <tr><th style="text-align:left">From: </th><td><?= $from ?></td></tr>
    <tr><th style="text-align:left">To: </th><td><?= $to ?></td></tr>
</table>
