<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
<p>Hello,</p></br>
<p><?= $body ?></p>
<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use common\models\ReportType;
use common\models\ReportInterval;
use yii\widgets\ActiveForm;
use GuzzleHttp\Client;
use kartik\daterange\DateRangePicker;
use  yii\web\Session;
use common\components\CheckPermissionHelper;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use yii\helpers\Url;
$session = Yii::$app->session; 

AppAsset::register($this);
// $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
// $client = array_column($allowedClients, 'client_id');
// if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
//     $clientId = $client;
// }else{
//     $clientId = Yii::$app->user->identity->client_id;
// }

$userRole = Yii::$app->user->identity->role;
$vaultLink = Yii::$app->user->identity->vault_link;
if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}else{
    $CrDate = date('d-m-Y');
    if(date('L') == 1){
        $dateNew = strtotime($CrDate.' -365 days');        
    }else{
        $dateNew = strtotime($CrDate.' -364 days');   
    }
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromDate', $pastDate);
    $session->set('toDate', $CrDate);

    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}
$FromDate = $_SESSION['fromDate'];
$toDate = $_SESSION['toDate'];

$DashboardCompliance = ClientSite::getDashboardComplianceStatistic($FromDate,$toDate,$clientId,5);
$ToleranceComplianceRate = floor($DashboardCompliance['tolerance-percentage']);
$OntimeComplianceRate = floor($DashboardCompliance['ontime-percentage']);
$lateComplianceRate = floor($DashboardCompliance['late-percentage']);

// $ToleranceComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,11));
// $OntimeComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,0));

// if($ToleranceComplianceRate == 0 && $OntimeComplianceRate == 0){
//     $lateComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,12));
// }else{
//     $lateComplianceRate = (100 - ($ToleranceComplianceRate + $OntimeComplianceRate));
// }

$totalSites = ClientSite::getClientSites($clientId,1);
$totalReports =ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,1); 
$lastReport = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,6);
$MySites =  ClientSite::getClientSites($clientId,2);
$MyReports =  ClientSite::getMySitesReports($clientId); 
$ReportCount =  count($MyReports);
$clientInfo = ClientSite::getClientInfo($clientId);
$reportGeneratedDate = date('d-M-Y');
?>
<table border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto 25px; width:1020px; background:#FFFFFF; font-size: 16px; color: #000; font-family:Arial, Helvetica, sans-serif;">
        <tr>
            <td colspan="2" style="background: #00B1DC; -webkit-print-color-adjust: exact; padding: 12px 15px; text-align: center;">
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                    <tr>
                        <td style="width: 20%;">
                            <a href="http://ccsit.cleancloudsystems.com/site/login" target="_blank">
                                <img src="/var/www/frontend/web/images/logo-dash.jpg" alt="" />
                            </a>
                        </td> 
                        <td style="width: 80%;text-align: right;font-size: 10px;color: #fff;">
                            <h1><?php echo isset($clientInfo)?$clientInfo->name:""; ?></h1>
                            <h4><b> <?php echo $reportGeneratedDate; ?></b></h4>
                        </td>   
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td style="width: 150px; max-width: 150px; vertical-align: top; text-align: center; padding: 30px 20px 0 0;">
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                    <tr>
                        <td style="color: #00A6DB; font-size: 19px; padding: 9px 0 22px 0;">Compliance</td>
                    </tr>
                </table> 
                <table border="0" cellspacing="0" cellpadding="0" style="width:180px; max-width: 150px;  background: #f5f5f5; margin: 0 0 30px 0;">
                    <tr>
                        <td style="padding: 0 0 10px 0; ">
                            <table border="0" cellspacing="0" cellpadding="0" style="width:180px; background: #c5c7c9; margin: 0 0 10px 0;">
                                <tr>
                                    <td style="background: #00b050; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $OntimeComplianceRate;?>%;"><?php echo $OntimeComplianceRate.'%';?></td>
                                    <td style="background: #ffc000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $ToleranceComplianceRate;?>%;"><?php echo $ToleranceComplianceRate."%"; ?></td>
                                    <td style="background: #ff0000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $lateComplianceRate; ?>%;"><?php echo $lateComplianceRate; ?>%</td>
                                </tr>
                            </table>                            
                        </td>                                                
                    </tr>
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:150px; text-align: left; margin: 0 0 18px 0;">
                                <tr>
                                    <td>
                                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                            <tr>                                                
                                                <td style="background: url('<?php echo Url::to('/images/color-mark1.jpg',true); ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Ontime
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td>
                                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                            <tr>                                                
                                                <td style="background: url('<?php echo Url::to('/images/color-mark2.jpg',true); ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Tolerance
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td>
                                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                            <tr>      
                                                <?php $imgUrl = Url::to('/images/color-mark3.jpg', true);?>
                                                <td style="background: url('<?php echo $imgUrl; ?>') 0 center no-repeat; font-size: 13px; padding: 0 0 0 18px;"> Late
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr> 
                    <!-- <tr>
                        <td style="padding: 0 0 10px 0; ">
                            <table border="0" cellspacing="0" cellpadding="0" style="width:240px; background: #f5f5f5;">
                                <tr>
                                    <?php if($ToleranceComplianceRate != 0){ ?> 
                                    <td style="background: #f1921f; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $ToleranceComplianceRate; ?>%;">                                        
                                    </td>
                                    <?php } if($ToleranceComplianceRate != 100){?>    
                                    <td style="background: #c5c7c9; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo (100-$ToleranceComplianceRate); ?>%;">     
                                                                   
                                    </td>
                                    <?php } ?>
                                </tr>
                            </table>                                                       
                        </td>                        
                    </tr>
                    <tr>
                        <td style="color: #f1921f; font-size: 25px; font-weight: bold; padding: 0 0 10px 0;">
                            <?php echo $ToleranceComplianceRate."%"; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="color: #000; font-size: 16px; line-height: 24px;">Tolerance Compliance rate average across all my sites</td>
                    </tr> -->
                </table>
                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px; background: #f5f5f5; margin: 0 0 30px 0;">
                    <tr>
                        <td style="padding: 0 0 10px 0; ">
                            <table border="0" cellspacing="0" cellpadding="0" style="width:240px; background: #c5c7c9;">
                                <tr>
                                    <?php if($OntimeComplianceRate != 0){ ?> 
                                    <td style="background: #8bc53f; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $OntimeComplianceRate;?>%;"></td>
                                    <?php } if($OntimeComplianceRate != 100){?>
                                    <td style="background: #c5c7c9; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo (100-$OntimeComplianceRate);?>%;">                                        
                                    </td> 
                                    <?php } ?>                                   
                                </tr>
                            </table>                            
                        </td>                        
                    </tr>
                    <tr>
                        <td style="color: #8bc53f; font-size: 25px; font-weight: bold; padding: 0 0 10px 0;">
                            <?php echo $OntimeComplianceRate.'%';?>
                        </td>
                    </tr>
                    <tr>
                        <td style="color: #000; font-size: 16px; line-height: 24px;">Ontime Compliance rate average across all my sites</td>
                    </tr>
                </table>  -->
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
                    <tr>
                        <td style="font-size: 40px; color: #8bc53f; padding: 0 0 15px 0;"><?php echo $totalSites; ?> </td>
                    </tr>
                    <tr>
                        <td style="color: #000; font-size: 16px; line-height: 24px;">Sites Monitored</td>
                    </tr>
                </table>
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">
                    <tr>
                        <td style="font-size: 40px; color: #8bc53f; padding: 0 0 15px 0;"><?php echo $totalReports;?></td>
                    </tr>
                    <tr>
                        <td style="color: #000; font-size: 16px; line-height: 24px;">Total Reports</td>
                    </tr>
                </table>
                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:100%; padding: 20px 20px 20px 20px;">                    
                    <tr>
                        <td style="color: #000; font-size: 15px; line-height: 23px;">Report last generated <?php echo $lastReport; ?> for the previous 12 months</td>
                    </tr>
                </table> -->
            </td>
            <td style="width: 800px; min-width: 800px; vertical-align: top; padding: 30px 0 0 10px;">
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 10px 0;">   
                                <tr>
                                    <td style="font-size: 16px; color: #000; padding: 12px 10px; background: #f5f5f5; text-align: right;">
                                        Audit Period : <?php echo $RangeValue; ?>
                                    </td>
                                </tr>    
                            </table>
                        </td>
                        
                    </tr>                 
                    <tr>
                        <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">My Sites</td>
                    </tr>
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;"> 
                            <?php if(!empty($MySites)){
                                                $LateSites = array();
                                                foreach ($MySites as $MySite) { 
                                                    $mySiteId = $MySite['id'];
                                                    $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                                    if(!empty($lateReports)){                  
                                                        foreach ($lateReports as $client=>$reports) {
                                                            if(isset($reports['late'])){
                                                                foreach ($reports['late'] as $key => $report) {
                                                                    $LatesiteID = $report['sop']['site_id'];
                                                                    array_push($LateSites, $LatesiteID);
                                                                }
                                                            }
                                                        }
                                                    }
                                                } }?>                       
                                <tr>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Location</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No. of <br/> Reports</th> 
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">First Report <br/> Received</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>
                                    <!-- <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;">Last Report Received</th> -->
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall <br/> Compliance</th>
                                </tr>
                                <?php if(!empty($MySites)){ 
                                    $i=1;
                                    $statusClass = '';
                                    foreach ($MySites as $MySite) {
                                        $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                        $mySiteId = $MySite['id'];
                                        //$Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,2,$mySiteId);
                                        $Compliance = ClientSite::getSitesComplianceStaticsDashboard($FromDate,$toDate,$mySiteId,5);
                                        $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,3,$mySiteId);
                                        $auditDate =  explode('-', $AuditPeriod);
                                        $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                        $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                        if($Compliance<50){
                                            $statusClass = '#EE402F';
                                        }elseif($Compliance>=50 && $Compliance<70){
                                            $statusClass = '#F6921E';
                                        }elseif($Compliance>=70){
                                            $statusClass = '#8BC53F';    
                                        }
                                ?>
                                <tr>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;<?php if(!empty($LateSites) && !in_array($mySiteId, $LateSites)) { ?> margin-left: 18px;<?php } ?>"><?php echo $MySite['name']; ?><?php          
                                                            if(!empty($LateSites) && in_array($mySiteId, $LateSites)){  ?>
                                                            <img src="<?php echo Url::to('/images/site-alaram-dash.jpg',true); ?>" alt="" />
                                                                
                                                        <?php  } ?></td>

                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo ClientSite::getTotalReportsBySites($FromDate,$toDate,$clientId,1,$mySiteId); ?></td> 
                                    
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $firstReceived; ?></td>
                                     <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: <?php echo $statusClass; ?>; "><?php echo $Compliance; ?>%</td>
                                </tr>
                                <?php $i++;
                                    // if($i>5){
                                    //     break;
                                    // }
                                } }else{ ?>
                                <tr>
                                    <td colspan='4' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No sites found.
                                    </td>
                                </tr>
                                <?php } ?>
                            </table> 
                            <?php if($totalSites>5){ 
                                $url = Url::to(['site/list', 'client' =>$clientId],true);
                            ?>
                                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                    <tr>
                                        <td style="padding: 10px 0 0 0;">                                 
                                            <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                        </td>
                                    </tr>
                                </table> -->
                            <?php } ?>          
                        </td>
                    </tr>
                </table>
                
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">   
                 <tbody>                    
                    <tr>
                        <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">My Report Type(s)</td>
                    </tr>
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">  
                            <tbody>                 
                                <tr>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Report Type</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No. of  <br/> Reports</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Frequency</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th>
                                    <!-- <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Next Report</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Supplier</th> -->
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Overall <br/> Compliance</th>
                                </tr>
                                <?php if(!empty($MyReports)){ 
                                    $j=1;
                                    $statusClass = '';
                                    foreach ($MyReports as $MyReport) {
                                        $reports = ClientSite::getReportsStaticsDashboard($FromDate,$toDate,$clientId,5,$MyReport['provider_ids'],$MyReport['report_interval_id'],$MyReport['doctype_id']);
                                        $lastReceived = $reports['lastReportDate'];
                                        $RCompliance = $reports['percentage'];
                                        $totalReports =$reports['total'];
                                        $nextReportDate = isset($reports['nextDate'])?$reports['nextDate']:"-";
                                        $frequency = $MyReport['frequency'];
                                        
                                        // $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,4,"",$MyReport['doctype_id']);
                                        // $auditDate =  explode('-', $AuditPeriod);
                                        // $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                        // $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                        // $RCompliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,5,"",$MyReport['doctype_id']);
                                        if($RCompliance<50){
                                            $statusClass = '#EE402F';
                                        }elseif($RCompliance>=50 && $RCompliance<70){
                                            $statusClass = '#F6921E';
                                        }elseif($RCompliance>=70){
                                            $statusClass = '#8BC53F';    
                                        }
                                        // $totalReports = ClientSite::getReportCountForMyReports($MyReport['site_id'],$FromDate,$toDate,$MyReport['doctype_id']);
                                        // $nextReportDate = ClientSite::getNextReportDateMyReports($MyReport['site_id'],$FromDate,$toDate,$MyReport['doctype_id']);
                                        // $frequency = ClientSite::getFrequencyForReport($MyReport['site_id'],$FromDate,$toDate,$MyReport['doctype_id']);
                                ?>
                                <tr>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MyReport['report_type'];?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $totalReports; ?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $frequency; ?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td> 
                                    <!-- <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php // echo $nextReportDate; ?></td> 
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php//  echo $MyReport['providers']; ?></td> -->
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; color:<?php echo $statusClass; ?>;"><?php echo $RCompliance; ?>%</td>
                                </tr>
                                <?php $j++;
                                    // if($j>5){
                                    //     break;
                                    // }
                                }                                                
                                }else{ ?>                                
                                <tr> 
                                    <td colspan='5' style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;">No reports found.</td>
                                </tr>  
                                <?php } ?>                              
                            </tbody>
                            </table>      
                            <?php if($ReportCount>5){ 
                                $url = Url::to(['site/report1', 'client' =>$clientId],true);?>
                                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                    <tr>
                                        <td style="padding: 10px 0 0 0;">
                                            <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                        </td>
                                    </tr>
                                </table> -->
                           
                                <!-- <div class="view-more"><a href="<?php //echo $url; ?>">View All</a></div> -->
                            <?php } ?>       
                        </td>
                    </tr>
                     </tbody>
                </table>
                <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 30px 0;">  
                 <?php $MySites =  ClientSite::getClientSites($clientId,2); ?>                  
                    <tr>
                        <td style="font-size: 19px; color: #00A6DB; padding: 0 0 22px 0;">Unknown Reports</td>
                    </tr>
                    <?php 
                        $flag = 0;
                        $totalOtherReports = 0;
                        if(!empty($MySites)){
                            $i=1;
                            $statusClass = '';

                            foreach ($MySites as $MySite) { 
                                $mySiteId = $MySite['id'];
                                $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
                                $auditDate =  explode('-', $AuditPeriod);
                                $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
                                $totalOtherReports = $totalOtherReports + $Compliance;
                                if($Compliance>20){
                                    $statusClass = 'reject';
                                }elseif($Compliance>5 && $Compliance<=20){
                                    $statusClass = 'pending';
                                }elseif($Compliance<5){
                                    $statusClass = 'approve';    
                                }
                                if($Compliance != 0){
                                    $flag = 1;
                                    break;
                                }
                            } 
                        } ?>
                        <?php if($flag == 1){ ?>
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">                    
                                <tr>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Location</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">No. of <br/> Reports</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">First Report <br/> Received</th>
                                    <th style="background: #f5f5f5; font-size: 15px; line-height: 23px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; border-top: 1px solid #ddd;text-align: left;">Last Report <br/> Received</th> 
                                    
                                </tr>
                                
                                <?php 
                                    $totalOtherReports = 0;
                                    if(!empty($MySites)){
                                        $i=1;
                                        $statusClass = '';
                                       
                                        foreach ($MySites as $MySite) { 
                                            $mySiteId = $MySite['id'];
                                            $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
                                            $auditDate =  explode('-', $AuditPeriod);
                                            $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                            $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                            $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
                                            $totalOtherReports = $totalOtherReports + $Compliance;
                                            if($Compliance>20){
                                                $statusClass = 'reject';
                                            }elseif($Compliance>5 && $Compliance<=20){
                                                $statusClass = 'pending';
                                            }elseif($Compliance<5){
                                                $statusClass = 'approve';    
                                            }
                                if($Compliance != 0){          
                                            ?>
                                <tr>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-left: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $MySite['name']; ?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;color: #8BC53F;"><?php echo $Compliance; ?></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $firstReceived; ?></td>
                                   <td style="font-size: 14px; line-height: 22px; padding: 5px 10px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd;"><?php echo $lastReceived; ?></td> 
                                                                        
                                </tr>
                                <?php } ?>
                                <?php $i++;
                                    // if($i>5){
                                    //     break;
                                    // }
                                } 
                            }else{?>
                                <tr>
                                    <td colspan="4">No data found.</td>
                                </tr>
                            <?php }?>                               
                            </table>  
                            <?php if($totalSites>5){ 
                                //$url = Url::to(['site/report', 'client' =>$clientId],true); ?>
                                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:auto; margin: 0 0 0 auto;">
                                    <tr>
                                        <td style="padding: 10px 0 0 0;">
                                            <a target="_blank" href="<?php //echo $url; ?>">View All</a>
                                        </td>
                                    </tr>
                                </table> -->
                            <?php } ?>          
                        </td>
                    </tr>
                     <?php 
                     }else{ ?>
                        <tr> 
                            <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;">No reports found.</td>
                        </tr>
                      <?php  } ?>
                </table>
                <!-- <table border="0" cellspacing="0" cellpadding="0" style="width:100%; margin: 0 0 25px 0;">                    
                    <tr>
                        <td style="font-size: 19px; color: #00A6DB; padding: 0 0 12px 0;">Sites with Alarms</td>
                    </tr>
                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left;">  
                                <?php
                                    $ArrayCount = 0;
                                    if(!empty($MySites)){
                                        $LateSites = array();
                                        foreach ($MySites as $MySite) { 
                                            $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                            $mySiteId = $MySite['id'];
                                            $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                            if(!empty($lateReports)){
                                                foreach ($lateReports as $client=>$reports) {
                                                    if(isset($reports['late'])){
                                                        foreach ($reports['late'] as $key => $report) {
                                                            $LatesiteName = $report['sop']['clientSite']['name'];
                                                            array_push($LateSites, $LatesiteName);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if(!empty($LateSites)){
                                            $FinalArray = array_unique($LateSites);
                                            $ArrayCount = count($FinalArray);
                                            $i=1;
                                            foreach ($FinalArray as $key => $site) { ?>                  
                                <tr>
                                    <td style="width: 30px; padding: 5px 0;"><img src="/var/www/frontend/web/images/site-alaram-dash.jpg" alt=""/></td>
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;"><?php echo $i.'. '.$site."(".$clientInfo->name.")"; ?></td>
                                </tr>
                                <?php 
                                    $i++;
                                    // if($i>5){
                                    //     break;
                                    // }
                                }
                            }else{?>

                                <tr>
                                   <!--  <td style="width: 30px; padding: 5px 0;"></td> 
                                    <td style="font-size: 14px; line-height: 22px; padding: 5px 10px 5px 5px;">No alarms found.</td>
                                </tr>
                                <?php }
                                }
                                ?>                            
                            </table>  
                            <?php if($ArrayCount>5){ ?>
                                <!-- <div class="view-more"><a href="#getSitesWithLateReport" data-toggle="modal" >View All</a></div> 
                            <?php } ?>          
                        </td>
                    </tr>
                </table>  -->                
            </td>
        </tr>
    </table>
</br><p>Thank you.</p>
</body>
</html>
