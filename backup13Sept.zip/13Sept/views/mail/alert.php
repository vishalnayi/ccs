
<h1>RMP Systems Application Alert</h1>

<p>An error has occured in the application.<p>

<p><?= $body ?></p>
