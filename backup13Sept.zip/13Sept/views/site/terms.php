<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use yii\filters\AccessControl;


$this->params['currentPage'] = 'Terms';
$this->title = 'Terms'; 


AppAsset::register($this);


$this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language ?>">
<head>
    <meta charset="<?php echo Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?php echo Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php
//    $this->registerCssFile('/css/layout.min.css');
//    $this->registerCssFile('/css/default.min.css');
    ?>
    <link href="/css/layout.min.css" rel="stylesheet">
    <link href="/css/default.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/responsive.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <link href="/css/terms.css" rel="stylesheet">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="page-container-bg-solid page-sidebar-closed-hide-logo page-md page-boxed">
<?php $this->beginBody();
 //   echo RedRocketAdminNav::widget();
?>
<div class="container">
    <div class="page-container">
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content">
                
            <?php
                foreach (Yii::$app->session->getAllFlashes() as $key => $message) :
                    echo '<div class="alert alert-' . $key . '">' . $message . '</div>';
                endforeach;
            ?>

            <h1>SOFTWARE AS A SERVICE agreement</h1>
<strong>THIS AGREEMENT IS MADE</strong> on the date of Execution

<strong>BETWEEN</strong>         <strong>RMP Systems PTY LTD</strong> (ACN 122 146 767), a company having its principal place of business at Level 27, 101 Collins Street, Melbourne, Victoria, Australia (<strong>RMP</strong>)

<strong>AND</strong>                   <strong>THE CLIENT </strong>the entity identified in Accepted Quote (<strong>the Client</strong>)
<h2>Recitals</h2>
<ol>
     <li>RMP supplies the document management system known as CleanCloudSystems (<strong>CCS Software</strong>) which relates to water consultancy, water auditing and/or water research.</li>
     <li>The Client has requested access to the CCS Software for the purposes of its business.</li>
     <li>The Parties have agreed that RMP will make the CCS Software available to the Client as a service and provide any related services on the terms of this Agreement.</li>
</ol>
<h2>THE PARTIES AGREE AS FOLLOWS</h2>
<ol>
     <li>Definitions and Interpretation
<ul>
     <li>In this Agreement (including the recitals), unless the context otherwise requires:</li>
</ul>
</li>
</ol>
<ul>
     <li><strong>Accepted Quote</strong> means the quotation for access to the CCS Software which has been provided by RMP and accepted by the Client.</li>
     <li><strong>Additional Service Charge</strong> means a charge to the Client in respect of work to be carried out by RMP in a manner and at a rate set out in a quote accepted by the Client.</li>
     <li><strong>Client Representative </strong>means the person who Executes this Agreement on behalf of the Client.</li>
     <li><strong>Business Day</strong> means:
<ul>
     <li>for receiving a Notice under clause 14, a day that is not a Saturday, Sunday, public holiday or bank holiday in the place where the Notice is received; and</li>
     <li>for all other purposes, a day that is not a Saturday, Sunday, public holiday or bank holiday in Melbourne, Victoria, Australia.</li>
</ul>
</li>
     <li><strong>CCS Output </strong>means all databases (and report templates created by the CCS Software excluding Client Data.</li>
     <li><strong>Client Access Facilities </strong>means telecommunications, networks, systems, software and any other facilities used or required by or on behalf of the Client for accessing and making use of the Services other than those provided by RMP under this Agreement.</li>
     <li><strong>Client Data </strong>means data to which RMP is provided access by the Client for the purpose of provision of the Services.</li>
     <li><strong>Confidential Information</strong> means
<ul>
     <li>All information (including technical and commercial information) concerning the Services or the CCS Software, including computer programs, inventions, samples, descriptions, systems, techniques, sketches, models, specifications, design drawings, photographs, manufacturing processes, costings.</li>
     <li>Client Data.</li>
     <li>Any other information which either Party identifies as confidential, whether verbally or in writing.</li>
     <li>Any other information disclosed by either Party, its officers, employees or independent contractors in circumstances in which they realise or ought to realise that the information has been provided on a confidential basis.</li>
</ul>
</li>
     <li>and includes, in relation to a Party (<strong>the Recipient</strong>), all information disclosed by the other Party (<strong>the Discloser</strong>) or its Personnel or predecessor(s) in business in connection with the provision of the Services or the provision of water consultancy, water auditing or water research services to the Client, but does not include information which the Recipient establishes:
<ul>
     <li>was lawfully known to or in the possession of the Recipient prior to its disclosure by the Discloser; or</li>
     <li>is or becomes generally available in the public domain, other than as a result of disclosure by the Recipient or its Personnel in breach of this Agreement, or in breach of any other obligation of confidence owed to the Discloser; or</li>
     <li>is in or enters the public domain other than by breach of this Agreement.</li>
</ul>
</li>
     <li><strong>Document </strong>includes films, tapes, disks, pictures, diagrams and any medium containing data in electronic or other machine readable form.</li>
     <li><strong>Entity</strong> includes an individual and an incorporated body.</li>
     <li><strong>Execution /Executes</strong> means when a Client Representative clicks on the “I Agree” box to accept the terms and conditions of this Agreement to enable use of the CCS Software.</li>
     <li><strong>Force Majeure Event</strong> means a natural disaster, fire, explosion, industrial dispute, legislative or government action, or any occurrence of a similar nature beyond the control of the Party in breach.</li>
     <li><strong>GST</strong>, <strong>input tax credit</strong>, <strong>supply</strong>, and <strong>tax invoice</strong> have the meanings given to those expressions in <em>the A New Tax System (Goods and Services Tax) Act</em> 1999 (Cth).</li>
     <li><strong>Intellectual Property </strong>means rights resulting from intellectual activity in the industrial, scientific, literary or artistic fields throughout the world, including copyright and neighbouring rights; rights in relation to inventions (including patents and patent applications); rights in relation to trade marks (including trade mark registrations and trade mark applications); rights in relation to designs (including design registrations); rights in relation to circuit layouts (including EL rights); and rights in relation to confidential information.</li>
     <li><strong>Modifications</strong> means any updates of, additions or modifications to and inventions in relation to the CCS Software or the CCS Output.</li>
     <li><strong>Notice </strong>includes a notification, request, consent, offer, acceptance, authorisation, approval or agreement.</li>
     <li><strong>Personnel</strong> means officers, agents, independent contractors and employees.</li>
     <li><strong>Services </strong>means access to the CCS Software and, subject to this Agreement, includes any support, training, updates and new releases provided by RMP.</li>
</ul>
Specified Purpose means the provision of the Services to the Client; and water consultancy, water auditing and/or water research.
<ul>
     <li><strong>Subscription Fee</strong> means the fee the Client pays for on-going access to the Services at the rate and in the manner set out in the Accepted Quote.</li>
     <li><strong>Writing</strong> includes any graphic representation of letters or numerals, including in electronic form.
<ul>
     <li>In this Agreement, unless the context requires otherwise:
<ul>
     <li>The singular includes the plural and vice versa.</li>
     <li>A reference to any gender includes all other genders.</li>
     <li>A reference to a statute means that statute as in force from time to time, and to any statute passed in substitution for that statute.</li>
     <li>The word includes means includes but is not limited to.</li>
     <li>Where one part of speech of a word is defined, other parts of speech of that word have corresponding meanings.</li>
     <li>A reference to A$, $A, dollar or $ is to Australian currency.</li>
     <li>A reference to a date or time for doing an act (including receipt of a Notice under clause 14 is to the time in the place where the act is done or the Notice is received).</li>
     <li>A reference to a Party includes that Party’s legal personal representatives, successors in title and permitted assigns (if any).</li>
     <li>If a day on or by which an obligation must be performed or an event must occur is not a Business Day, the obligation must be performed or the event must occur on or by the next Business Day.</li>
     <li>Headings are for ease of use and reference only, and do not affect interpretation.</li>
</ul>
</li>
</ul>
</li>
</ul>
<ol start="2">
     <li>TERM</li>
</ol>
<ul>
     <li>The Client may not have access to the CCS Software until it Executes this Agreement.</li>
     <li>The Agreement commences on the date of Execution. This Agreement continues for an initial term specified in the Accepted Quote.</li>
     <li>Upon payment of the Subscription Fee, the Agreement will continue for subsequent terms as specified in the Accepted Quote until the Agreement is terminated.</li>
</ul>
<ol start="3">
     <li>FEES AND PAYMENT</li>
</ol>
<ul>
     <li>The Client shall pay a Subscription Fee to RMP for ongoing access to the Services which will be charged at the rate and on the payment terms set out in the Accepted Quote.</li>
     <li>Additional Service Charges will be invoiced to the Client following the provision of the additional services specified by RMP and will be payable within 30 days of receipt of the invoice by the Client from RMP.</li>
     <li>RMP may in its sole discretion increase the Subscription Fee or the Additional Service Charge payable by giving 30 days’ notice to the Client in writing.</li>
     <li>The Client shall pay interest on any amount due but unpaid to RMP at the rate prescribed in accordance with the <em>Penalty Interest Rate Act </em>(Vic).</li>
</ul>
<ol start="4">
     <li>CLIENT ACCESS AND PROVISION OF THE SERVICES</li>
</ol>
<ul>
     <li>The Client will be provided with a user name and password (“<strong>Log In Details”</strong>) in order to access the CCS Software.</li>
     <li>Subject to this Agreement, the Client will continue to have access to the CCS Software provided it pays the Subscription Fee.</li>
     <li>Where the Client requests RMP modify the CCS Software to meet the Client’s requirements or to undertake work beyond the scope of the Services and RMP agrees to make such modifications, the Client will be charged an Additional Service Charge as negotiated with the Client.</li>
     <li>The Client is entirely responsible for maintaining the security of its account Log In Details, and will be liable for any unauthorised use of its Log In Details.</li>
     <li>RMP may from time to time without notice to the Client suspend the Services or disconnect or deny the Client access to the Services if:
<ul>
     <li>it is necessary to do so due to any technical failure of, or for the upgrading or preventative or remedial maintenance of RMP’s computer systems and software;</li>
     <li>in RMP’s reasonable opinion, it is required by law to do so; or</li>
     <li>in RMP’s reasonable opinion, the Client’s use of the Services adversely affects RMP’s server performance or the integrity of RMP’s computer network.</li>
</ul>
</li>
     <li>RMP may from time to time on giving two Business Days’ notice to the Client, suspend the Services or disconnect or deny the Client access to the Services if the Client breaches this Agreement.</li>
     <li>RMP may provide the Services from any locations, and/or through the use of contractors, worldwide.</li>
</ul>
<ol start="5">
     <li>CLIENT’S OBLIGATIONS</li>
</ol>
<ul>
     <li>By entering this Agreement, the Client agrees to comply with all reasonable directions from RMP in relation to the use of the Services and any policies RMP may notify to the Client from time to time in connection with the provision or use of or access to the Services.</li>
     <li>The Client is responsible for providing its own Client Access Facilities.</li>
     <li>The Client warrants and must ensure that all Client Access Facilities meet the security standards required by RMP and will remain free from any circumstances (including viruses) which may adversely affect RMP, the CCS Software or the Services and are otherwise appropriate for use in conjunction with the Services.</li>
     <li>The Client agrees that where any third party facilities including software programs are necessary for access to or for use with the CCS Software or the Services, that its right to make any use of these facilities is governed by the terms of the relevant third party licence/services agreement with the Client, and not by this Agreement.</li>
     <li>The Client must procure any consents which are required for RMP to provide the Services including but not limited to consents for RMP to access, use and store Client Data.</li>
     <li>The provision of the Services is conditional upon the Client procuring any of the consents required under clause 5 above.</li>
     <li>Upon RMP’s request, the Client must provide confirmation of the consents procured under clause 5 above.</li>
     <li>The Client agrees not to make or permit any use of the Services:
<ul>
     <li>to send unsolicited electronic messages;</li>
     <li>to engage in any activity that is illegal or would contravene the rights of a third party;</li>
     <li>to be involved in anything which is false, defamatory, harassing or obscene;</li>
     <li>which would involve the contravention of any person’s rights including Intellectual Property rights;</li>
     <li>to interfere with or disrupt RMP or its business, other Internet users or other services providers, or their computers, software or hardware including by propagation of computer worms and viruses;</li>
     <li>to access without authorisation any other computer accessible via the Services; or</li>
</ul>
</li>
</ul>
which would otherwise be regarded by RMP to be an unacceptable use of the Services and the CCS Software.
<ul>
     <li>The Client must not:
<ul>
     <li>remove or modify any CCS Software markings or notice of RMP’s rights;</li>
     <li>make programs resulting from the Services available to any third party for use in the third party’s business or allow any unauthorised use of the Services or the CCS Software by an unauthorised third party except as required by law; or</li>
     <li>tamper, change or access any software code that relates to the CCS Software.</li>
</ul>
</li>
     <li>The Client agrees to provide to RMP any information relevant to its use of the Services and the CCS Software.</li>
</ul>
&nbsp;
<ol start="6">
     <li>INTELLECTUAL PROPERTY</li>
</ol>
<ul>
     <li>All Intellectual Property in the CCS Software, the CCS Output and the Modifications will be the exclusive property of RMP, whether created by or on behalf of RMP or by or on behalf of the Client.</li>
     <li>The Client assigns to RMP absolutely, by way of assignment of future copyright, the entire copyright in any Modifications which come into existence after the date of this Agreement in every country that permits assignment of future copyright.</li>
     <li>The Client assigns to RMP absolutely all its rights (if any) in relation to the Intellectual Property throughout the world which subsists in any Modifications at the date of this Agreement. This assignment includes the right to bring legal proceedings and to obtain any relief to which the Client would have been entitled but for this paragraph, in respect of any infringement of its rights in relation to the Modifications which occurs before or after the date of this Agreement.</li>
     <li>The Client agrees to assign to RMP absolutely all its rights in relation to in the Intellectual Property throughout the world which come into existence in any Modifications after the date of this Agreement, and which is not assigned by clause 2.</li>
</ul>
<ol start="7">
     <li>SUB-LICENCE AND ASSIGNMENT</li>
</ol>
<ul>
     <li>The Client shall not sub-license the CCS Software or assign this Agreement without the prior written consent of RMP.</li>
     <li>RMP may assign the CCS Software and this Agreement without the consent of the Client. If requested, the Client shall execute an agreement novating the rights and obligations of RMP under this Agreement to a third party.</li>
</ul>
<ol start="8">
     <li>GST</li>
</ol>
<ul>
     <li>All amounts payable by either Party under this Agreement are exclusive of GST, and represent the value of the supply in respect of which they are payable, for the purpose of calculating GST payable (if any).</li>
     <li>If any supply made by a Party (<strong>Supplier</strong>) under this Agreement is subject to GST, the amount payable by the other Party (<strong>Recipient</strong>) in respect of that supply shall be increased by an amount equal to the amount of GST payable by the Supplier in respect of that supply.</li>
     <li>If a Recipient is required by this agreement to reimburse to a Supplier an amount paid by the Supplier, and the Supplier is entitled to an input tax credit in respect of part of the amount which it paid, the Recipient shall pay the Supplier the amount paid by the Supplier:
<ul>
     <li>less the amount of the input tax credit; and</li>
     <li>plus any amount of GST payable under clause 8.2.</li>
</ul>
</li>
     <li>Each Party agrees to provide any invoices or other documentation necessary to enable the other Party to claim or verify any input tax credit, set off, refund or rebate in relation to any amount paid by the other Party under clause 8.3 above.</li>
</ul>
<ol start="9">
     <li>CONFIDENTIALITY</li>
</ol>
<ul>
     <li>The Recipient may only use or permit the use of the Confidential Information for the Specified Purpose.</li>
     <li>The Recipient must not disclose the Confidential Information to any other Entity other than:
<ul>
     <li>to its Personnel (who have been made aware of its confidential nature) or the Personnel of the Discloser to the extent required for the Specified Purpose; or</li>
     <li>after obtaining the Discloser’s written consent.</li>
</ul>
</li>
     <li>The Recipient undertakes that it will not make a Document disclosing any Confidential Information or copy any Document disclosing Confidential Information, other than to the extent required for the Specified Purpose.</li>
     <li>Clause 9 does not prohibit disclosure of the Confidential Information required by law.</li>
</ul>
<ol start="10">
     <li>SECURITY AND RETURN OF CONFIDENTIAL INFORMATION</li>
</ol>
<ul>
     <li>The Recipient shall:
<ul>
     <li>take all reasonable steps (including doing all things reasonably required by the Discloser), to keep the Confidential Information and all Documents disclosing Confidential Information secure from copying, access, use or disclosure in circumstances not permitted under clause 9; and</li>
     <li>immediately notify the Discloser if the Recipient becomes aware of any copying, access to, use or disclosure of the Confidential Information in circumstances not permitted under clause 9.</li>
</ul>
</li>
     <li>The Recipient shall, when requested by the Discloser in writing, promptly:
<ul>
     <li>return to the Discloser all Documents or other material disclosing Confidential Information; and</li>
     <li>delete any computer program or data containing Confidential Information from any storage device,</li>
</ul>
</li>
     <li>in the possession of the Recipient or its Personnel at that time.
<ul>
     <li>Where, under clause 10.2, the Client requests the return of material disclosing Client Data, RMP may make an Additional Service Charge for the provision of such material.</li>
</ul>
</li>
</ul>
<ol start="11">
     <li>LIABILITY AND INDEMNITY</li>
</ol>
<ul>
     <li>RMP does not give any express warranties in relation to the Services or the CCS Software or make any representations concerning them, and excludes all implied warranties (other than warranties implied by statute which may not be lawfully excluded by agreement):
<ul>
     <li>that the supply, reproduction and use of the CCS Software or the Services, as contemplated by this Agreement, will not infringe the Intellectual Property of third parties;</li>
     <li>that the CCS Software or the Services will be error free; or</li>
     <li>in relation to the provision of any goods or services by RMP to the Client.</li>
</ul>
</li>
     <li>Subject to paragraph 4, RMP’s liability on any legal basis for all loss, damage, costs and expenses incurred by the Client arising out of or in connection with the provision of any goods or services, or delay in or failure to provide goods or services, by RMP shall be limited to the resupply of the goods or services, or the payment of the amount paid by the Client to RMP in respect of the supply of the goods or services, at RMP’s option. This limitation extends to:
<ul>
     <li>property damage (including damage to the Client’s property and the property of third parties);</li>
     <li>damage caused by any computer virus;</li>
     <li>the liability of the Client to third parties; and</li>
     <li>loss or damage incurred as a result of the negligence of RMP, its officers, employees or agents.</li>
</ul>
</li>
     <li>Client agrees to indemnify RMP fully against all liabilities, losses, costs and expenses which RMP may incur as a result of the use of the Services or the CCS Software or a breach of this Agreement by the Client or its Personnel, including legal costs on an indemnity basis, otherwise than arising from the negligence of RMP.</li>
     <li>Paragraphs 2 and 11.3 do not apply in circumstances where their inclusion would breach the <em>Australian Consumer Law </em>or any other applicable law.</li>
</ul>
<ol start="12">
     <li>TERMINATION</li>
</ol>
<ul>
     <li>Either Party may terminate this Agreement immediately in notice in writing if the other Party:
<ul>
     <li>is in breach of any term of this Agreement and such breach is not remedied within 30 days of it notifying the other Party;</li>
     <li>commits an act of bankruptcy, becomes insolvent or takes any step to enter into a scheme or arrangement or composition with creditors;</li>
     <li>being a company, has any step taken to place it under external administration or to wind it up (other than for the purposes of corporate reconstruction); or</li>
     <li>being a partnership is dissolved.</li>
</ul>
</li>
     <li>The Client may terminate this Agreement upon at least 30 days’ notice in writing if it does not wish to continue with the Agreement.</li>
     <li>The Client acknowledges that RMP has no obligation to retain information relating to the Client including Client Data following termination.</li>
     <li>RMP may destroy any Client Data and other Client information that it holds after the expiry of seven years from the date of receipt by RMP of the Client Data.</li>
     <li>Clauses 3.4, 6, 9, 10, 11, 12.3 and 15 of this Agreement will survive the termination of this Agreement.</li>
</ul>
<ol start="13">
     <li>FORCE MAJEURE</li>
</ol>
<ul>
     <li>If a Party is aware that it is or will be unable to carry out an obligation under this Agreement by reason of a Force Majeure Event, it shall notify the other Party as soon as practicable. The obligations that the Party affected is unable to carry out shall be suspended for the duration of the Force Majeure Event.</li>
     <li>If the Force Majeure Event continues for at least two months after the earliest date an obligation suspended under clause 13.1 above was due to be performed, the other Party may terminate this Agreement by giving 30 days’ notice to the Party affected.</li>
</ul>
<ol start="14">
     <li>NOTICES</li>
</ol>
<ul>
     <li>Any Notice pursuant to this Agreement shall be in writing. Notices may be delivered by hand, by receipted mail, by facsimile or by email to the addresses of the Parties set out in this Agreement, or such other addresses as the Parties may provide to each other in accordance with this clause.</li>
     <li>Notice will be treated as received :
<ul>
     <li>in the case of hand delivery, on the date of delivery;</li>
     <li>in the case of postal delivery, on the date of delivery recorded by the postal authority;</li>
     <li>in the case of facsimile, on receipt by the transmitting machine of a message indicating that the whole of the message has been successfully received by the answering machine;</li>
     <li>in the case of email, on the receipt by the sender of a message indicating either that the email has been delivered to the other Party’s email server, or that the email has come to the attention of the other Party;</li>
</ul>
</li>
     <li>but if the delivery or transmission is not on a Business Day or is after 5.00pm on a Business Day, the Notice is taken to be received at 9.00am on the next Business Day.</li>
</ul>
<ol start="15">
     <li>GENERAL
<ul>
     <li>This Agreement (and the validity and enforceability of this Agreement) is governed by and to be interpreted in accordance with the law of the State of Victoria in the Commonwealth of Australia, without reference to its conflict of laws rules. The Parties submit to the non-exclusive jurisdiction of the courts of the State of Victoria, and the federal courts of the Commonwealth of Australia.  The Parties irrevocably waive any right they may have to object to those courts exercising jurisdiction on the ground that the court is not a convenient forum.</li>
     <li>This Agreement may only be varied or amended by an instrument in writing signed by duly authorised representatives of the Parties.</li>
     <li>If any provision of this Agreement is illegal, unenforceable or void in any jurisdiction, then, with respect to that jurisdiction only:
<ul>
     <li>that provision shall be read down if possible so that it is no longer illegal, unenforceable or void in that jurisdiction; and</li>
     <li>if it is not possible to read down that provision, it shall be severed from the remaining provisions of this Agreement, with respect to that jurisdiction only.</li>
</ul>
</li>
     <li>No act or omission by a Party shall constitute a waiver of any of its rights under this Agreement, other than an express waiver of those rights in writing signed by the Party to be bound.</li>
     <li>Subject to any express provision to the contrary, each of the rights, powers and remedies of the Parties under this Agreement, and at common law or in equity in relation to the subject matter of this Agreement, are cumulative.</li>
     <li>The rights and obligations of the Parties under this Agreement do not merge on completion of any transaction contemplated by this Agreement.</li>
     <li>Each Party agrees to do all acts and execute all documents necessary to give full effect to this Agreement and the transactions contemplated by it at its own expense.</li>
     <li>This Agreement supersedes all prior agreements and understandings between the Parties, and constitutes the entire agreement between the Parties relating to the subject matter of this Agreement.</li>
</ul>
</li>
</ol>
<ol start="16">
     <li>AUTHORITY TO ENTER AGREEMENT</li>
</ol>
<ul>
     <li>Each of the Parties warrants its power to enter into this Agreement.</li>
     <li>Any individual Executing this Agreement on behalf of the Client warrants that he or she has been fully empowered to Execute this Agreement and that all necessary action to authorise Execution of this Agreement has been taken.</li>
</ul>
&nbsp;

<p>
        <span class="cancel-btn"><a href="/site/logout"><?php echo Html::submitButton('Cancel', ['name' => 'cancel-button',]) ?></a></span>
        <span class=cancel-txt></span>
        <?php 
        $user = Yii::$app->user->identity;
        $userid = $user->id;
        // $userid=1; ?>
                <span class="agree-btn"><a href="<?php echo "/user/update-terms?id=".$userid ?>"<?php echo Html::submitButton('I agree', ['class' => 'btn btn-primary', 'name' => 'agree-button',]) ?></a></span>
        </p>
        &nbsp;
     
            </div>
        </div>
        
    </div>
</div>




<!-- The Modal -->
<div id="myModal" class="modal">

<!-- The Modal header -->

  <!-- Modal content -->
  
  <div class="modal-content">
    <div class="modal-header">
        <span class="close" id="close">Close</span>
    <button id="btnCancel">Cancel</button>
    <h2>Modal Header</h2>
  </div>
    <p>Terms and conditions......
        
    </p>
  </div>

</div>


<?php $this->endBody() ?><!--[if lt IE 9]>
<script src="/js/plugins/respond.min.js"></script>
<script src="/js/plugins/excanvas.min.js"></script>
<![endif]-->

</body>
</html>
<?php $this->endPage() ?>
