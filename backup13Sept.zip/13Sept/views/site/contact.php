<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ContactForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;

$this->title = 'Contact';
$this->params['currentPage'] = $this->title;
$this->params['breadcrumbs'][] = $this->title;
?>
<link href="/css/style.css" rel="stylesheet">
<link href="/css/responsive.css" rel="stylesheet">
<div class="page_caption">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1><?= Html::encode($this->title) ?></h1>
            </div>
        </div>
    </div>
</div>
<div class="container static-content">
    <p>
        If you have business inquiries or other questions, please fill out the following form to contact us. Thank you.
    </p>
    <div class="portlet light bordered">
        <div class="portlet-body form">
            <div class="portlet-body form">
                <?php $form = ActiveForm::begin([
                    'id' => 'contact-form',
                    'options' => [
                        'class' => 'login-form'
                    ],
                        'fieldConfig' => [
                        'options' => [
                            'tag' => 'span',
                        ],
                    ],
                ]); ?>
                <div class="form-body">
                    <?php

                    echo $form->field($model, 'name', [
                        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
                    ]);

                    echo $form->field($model, 'email', [
                        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
                    ])->input('email');

                    echo $form->field($model, 'subject', [
                        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
                    ]);

                    echo $form->field($model, 'body', [
                        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
                    ])->textArea(['rows' => 4]);

                    echo $form->field($model, 'verifyCode')->widget(Captcha::className(), [
                        'template' => '<div class="row"><div class="col-lg-2">{image}</div><div class="col-lg-5 form-group form-md-line-input form-md-floating-label">{input}Verification Code (Click code to refresh)</div></div>',
                    ])->label(false); ?>

                    <?php echo Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'contact-button']) ?>

                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>

</div>
