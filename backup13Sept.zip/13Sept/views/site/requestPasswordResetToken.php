<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Request password reset';
$this->params['breadcrumbs'][] = $this->title;
?>
<section class="login-page">
    <div class="user-login-5 site-request-password-reset">            
        <div class="login-content">
            <div class="form-data">
                <img src="/img/login-logo.png" alt="Clean Cloud Systems" />
                <h2><?= Html::encode($this->title) ?></h2>
                <p>Please fill out your email. A link to reset password will be sent there.</p>

                <?php $form = ActiveForm::begin([
                    'id' => 'request-password-reset-form',
                    'options' => [
                        'class' => 'request-password-reset-form login-form'
                    ],
                    'fieldConfig' => [
                        'options' => [
                            'tag' => 'span',
                        ],
                    ],
                ]); ?>

                <div class="row">
                    <?php echo $form->field($model, 'email', [
                        'inputOptions' => [
                            'autocomplete' => 'off',
                            'placeholder' => 'Email',
                            'required' => ''
                        ],
                        'template' => '<div class="col-md-12"><div class="form-group">{input}{error}</div></div>',
                    ]) ?>
                    <div class="col-md-12">
                        <?= Html::submitButton('Send', ['class' => 'btn loginbtn', 'style' => 'margin-top: 20px']) ?>                            
                        <div class="account"><?php echo ''. Html::a('Login Here', ['site/login'], ['class' => 'registername']) ?></div> 
                    </div>
                </div>                
                <?php ActiveForm::end(); ?>
            </div>           
        </div>
    </div>
</section>
