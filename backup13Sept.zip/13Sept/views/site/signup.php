<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\SignupForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Signup';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-login-5">
    <div class="row bs-reset">
        <div class="col-md-6 bs-reset mt-login-5-bsfix">
            <div class="login-bg" style="background-image:url(/img/login.jpg)"></div>
        </div>
        <div class="col-md-6 login-container bs-reset mt-login-5-bsfix">
            <div class="login-content">
                <h1><?= Html::encode($this->title) ?></h1>
                <p>Please fill out the following fields to signup:</p>

                <?php $form = ActiveForm::begin([
                    'id' => 'form-signup',
                    'options' => [
                        'class' => 'login-form'
                    ],
                    'fieldConfig' => [
                        'options' => [
                            'tag' => 'span',
                        ],
                    ],
                ]); ?>
                <div class="row">
                    <?php echo $form->field($model, 'username', [
                        'inputOptions' => [
                            'class' => 'form-control form-control-solid placeholder-no-fix form-group',
                            'placeholder' => 'Username',
                            'autocomplete' => 'off',
                            'required' => ''
                        ],
                        'template' => '<div class="col-xs-6">{input}{error}</div>',
                    ])->label(false); ?>
                </div>
                <div class="row">
                    <?php echo $form->field($model, 'email', [
                        'inputOptions' => [
                            'class' => 'form-control form-control-solid placeholder-no-fix form-group',
                            'placeholder' => 'Email',
                            'required' => ''
                        ],
                        'template' => '<div class="col-xs-6">{input}{error}</div>',
                    ])->label(false)->input('email'); ?>
                </div>
                <div class="row">
                    <?php echo $form->field($model, 'password', [
                        'inputOptions' => [
                            'class' => 'form-control form-control-solid placeholder-no-fix form-group',
                            'placeholder' => 'Password',
                            'autocomplete' => 'off',
                            'required' => ''
                        ],
                        'template' => '<div class="col-xs-6">{input}{error}</div>'
                    ])->label(false)->passwordInput() ?>

                    <?php echo Html::submitButton('Signup', ['class' => 'btn btn-primary', 'name' => 'signup-button']) ?>
                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>