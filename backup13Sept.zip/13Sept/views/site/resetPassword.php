<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ResetPasswordForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Reset password';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="user-login-5 site-reset-password">
    <div class="row bs-reset">
        <div class="col-md-6 bs-reset mt-login-5-bsfix">
            <div class="login-bg" style="background-image:url(/img/login.jpg)"></div>
        </div>
        <div class="col-md-6 login-container bs-reset mt-login-5-bsfix">
            <div class="login-content">
                <h1><?= Html::encode($this->title) ?></h1>
                <p>Please choose your new password:</p>

                <?php $form = ActiveForm::begin([
                    'id' => 'reset-password-form',
                    'options' => [
                        'class' => 'reset-password-form login-form'
                    ],
                    'fieldConfig' => [
                        'options' => [
                            'tag' => 'span',
                        ],
                    ],
                ]); ?>

                <div class="row">
                    <?php echo $form->field($model, 'password', [
                        'inputOptions' => [
                            'autocomplete' => 'off',
                            'required' => ''
                        ],
                        'template' => '<div class="col-xs-9"><div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div></div>',
                    ])->passwordInput(); ?>

                    <?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
                </div>
            <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>
