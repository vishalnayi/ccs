<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;
?>
<section class="login-page">
    <div class="user-login-5">                    
        <div class="login-content">
            <div class="form-data">
                <img src="/img/login-logo.png" alt="Clean Cloud Systems" />
                <?php $form = ActiveForm::begin([
                    'id' => 'login-form',
                    'options' => [
                        'class' => 'login-form'
                    ],
                    'fieldConfig' => [
                        'options' => [
                            'tag' => 'span',
                        ],
                    ],
                ]); ?>
                <div class="row">                       
                    <?php echo $form->field($model, 'username', [
                        'inputOptions' => [
                            'autocomplete' => 'off',
                            'required' => '',
                            'placeholder'=>'Username'
                        ],
                        'template' => '<div class="col-md-12"><div class="form-group ">{input}{error}</div></div>',
                    ]) ?>

                    <?php echo $form->field($model, 'password', [
                        'inputOptions' => [
                            'autocomplete' => 'off',
                            'required' => '',
                            'type' => 'password',
                            'placeholder'=>'Password'
                        ],
                        'template' => '<div class="col-md-12 "><div class="form-group">{input}{error}</div></div>'
                    ]) ?>
                </div>
                <div class="row">
                    <?php echo $form->field($model, 'rememberMe', [
                        'inputOptions' => [
                            'class' => 'rem-password css-checkbox'

                        ],
                        'checkboxTemplate' => '
                                <div class="col-sm-6">
                                    <div class="md-checkbox">                                            
                                        <label class="checkbox" for="loginform-rememberme">
                                            {input}
                                            <span class="checkmark"></span>Remember me
                                        </label>
                                    </div>
                                </div>'
                                 /*'checkboxTemplate' => '<div class="col-sm-4"><div class="md-checkbox">{input}<label for="loginform-rememberme"><span class="inc"></span><span class="check"></span><span class="box"></span>Remember me</label></div></div>'*/
                    ])->checkbox() ?>
                    <div class="col-sm-6 text-right">
                        <div class="forgot-password">
                            <?php echo Html::a('Forgot Password?', ['site/request-password-reset'], ['class' => 'forget-password']) ?>
                        </div>                            
                    </div>                            
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo Html::submitButton('Login', ['class' => 'btn loginbtn', 'name' => 'login-button']) ?>
                        <!-- <div class="account"><?php echo 'Don’t have an Account? '. Html::a('Register', ['site/signup'], ['class' => 'registername']) ?></div> -->        
                    </div>
                </div>
                <?php ActiveForm::end(); ?>
            </div>
            <div class="description">
                <h1>See and control all your information, from anywhere in the world. <!-- <?= Html::encode($this->title) ?> --></h1>
                <p>Through the Clean Cloud Systems report and audit monitoring system</p>
            </div>

        </div>           
        <!-- <div id="login-footer">
            <div class="text-center">
                <a href="http://rmpsystems.com" target="_blank">
                    <img src="/img/logo_rmp.svg" width="120" height="66" alt="RMP. Water auditors &amp; Cleancloudsystems" /></a>
                <br/>&copy;<?php echo date('Y'); ?>&nbsp;<a href="http://rmpsystems.com" target="_blank\">RMP Systems</a>
                <br/>CleancloudSystems, a brand of RMP Systems Pty Ltd
            </div>
        </div> -->
    </div>
</section>

