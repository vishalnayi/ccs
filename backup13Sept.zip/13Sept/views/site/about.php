<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['currentPage'] = $this->title;
$this->params['breadcrumbs'][] = $this->title;
?>
<link href="/css/style.css" rel="stylesheet">
<link href="/css/responsive.css" rel="stylesheet">
<div class="page_caption">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1><?= Html::encode($this->title) ?></h1>
            </div>
        </div>
    </div>
</div>
<div class="container static-content">
    <p><strong>A robust management protocol, especially containing verifications and validations... that’s how we operate.</strong></p>
    <p>Victoria, Australia is the legislative pioneer in the field of rigorous systems based auditing of cooling towers.   The high standards of legislative requirements existing in Victoria, Australia based on the use of a comprehensive auditing process clearly demonstrate that the auditing process will increasingly become the singularly most effective strategy for cooling tower management in the 21st Century. Our experience internationally speaks likewise to the value of the auditing process as being one of the most efficient ways of managing most associated risks, be that physical contamination, public health issues, production interruption and at worst legal culpability.</p>
    <p>Cooling tower auditing is based on a simple approach; a well defined management plan that brings together and documents the associated monitoring and risk management that is in place. This documentation is audited every year to ensure both legislative compliance and operational rigor. Although seemingly sounding simple, at its heart it addresses many of the fundamental operational and risk issues associated with cooling towers.</p>
    <p>Auditing has many benefits for example it can lead to a more robust system especially if there are interlocking verifications such as independent microbiology testing and review of corrosion Key Performance Indicators (KPI’s).</p>
</div>
