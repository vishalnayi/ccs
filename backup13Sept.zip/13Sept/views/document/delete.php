<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
//use kartik\widgets\DateTimePicker;
use kartik\datetime\DateTimePicker;

use common\models\ReportCategory;
use common\models\Provider;

/* @var $this yii\web\View */
/* @var $searchModel common\models\DocumentDiscoverLogSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Document Delete');
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = 'Document Delete'; 
?>
<div class="document-rename-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin() ?>

    <?= $form->field($model, 'site_id')->hiddenInput()->label(false) ?>
    <h2>Site: <?= $siteName ?></h2>
    <br />

	<h4>Existing file</h4>

    <?= $form->field($model, 'existing_path')->textInput(['readOnly' => true]) ?>

    <?= $form->field($model, 'existing_filename')->textInput(['readOnly' => true]) ?>

    <br />

	<h4>Change file</h4>

    <?= $form->field($model, 'report_type_id')->dropdownList(ArrayHelper::map($reportType, 'id', 'name')) ?>

    <?= $form->field($model, 'new_datetime')->widget(DatetimePicker::classname(), [
          'value' => $model->datetime,
          'pluginOptions' => [
              'autoclose' => true
          ]
    ]); ?>

    <div class="form-group">
        <div class="col-lg-offset-1 col-lg-11">
            <?= Html::submitButton('delete', ['class' => 'btn btn-danger']) ?>
        </div>
    </div>

    <?php ActiveForm::end() ?>

</div>
