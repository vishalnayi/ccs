<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use yii\widgets\ActiveForm;
use  yii\web\Session;
use common\models\UserClientAccess;
$session = Yii::$app->session;

AppAsset::register($this);
$allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
$client = array_column($allowedClients, 'client_id');
if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
    $clientId = $client;
}else{
    $clientId = Yii::$app->user->identity->client_id;
}
//$clientId = Yii::$app->user->identity->client_id;
$userRole = Yii::$app->user->identity->role;


if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}else{
    $CrDate = date('d-m-Y');
    $dateNew = strtotime($CrDate.' -1 year');
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromDate', $pastDate);
    $session->set('toDate', $CrDate);

    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}

$this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language ?>">
<head>
    <meta charset="<?php echo Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?php echo Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php
//    $this->registerCssFile('/css/layout.min.css');
//    $this->registerCssFile('/css/default.min.css');
    ?>
    <link href="/css/layout.min.css" rel="stylesheet">
    <link href="/css/default.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/responsive.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="page-container-bg-solid page-sidebar-closed-hide-logo page-md page-boxed">
<?php $this->beginBody();
    echo RedRocketAdminNav::widget();
?>


    <link href="/assets/4234c4f1/themes/smoothness/jquery-ui.css" rel="stylesheet">
    <?php
        $FromDate = $_SESSION['fromDate'];
        $toDate = $_SESSION['toDate'];

    ?>
    
    <section class="manage-site">
    <div class="container">
        <div class="row">
            
            <div class="col-xs-12 col-md-9 col-md-offset-2">
                <div class="back-button">            
                    <a class="btn bluebtn" href="javascript:history.go(-1)">Back</a>
                </div>
                <h2 class="title">My Reports Overview</h2>
                <div class="overview-site">
                    <div class="scroll-bar">
                        <div class="site-listing">
                            <div class="row">
                                <div class="col-xs-12 col-md-12">
                                    <div class="report-list">                               
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th width="350" class="left-th">Report Type</th>
                                                        <!-- <th>Location</th> -->
                                                        <th>No of. <br/> Reports</th>
                                                        <th>Frequency</th>
                                                        <th>Last Report <br/> Received</th>
                                                        <!-- <th>Next Report </th>
                                                        <th>Supplier</th> -->
                                                        <th>Overall <br/> Compliance</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                <?php 
                                                    $MyReports =  ClientSite::getMySitesReports($clientId);
                                                    $sitesPrimaryAlarms =  ClientSite::getSitesWithPrimaryAlramSet($clientId); 
                            //$sitesWithPrimaryAlarmSet = array_unique(array_column($sitesPrimaryAlarms,'site_id'));  
                            $clientSites = array_column(ClientSite::getClientSites($clientId,0),'id');
                            $sitesWithoutPrimaryAlarmSet = $clientSites;
                            // $sitesWithoutPrimaryAlarmSet = array_diff($clientSites, $sitesWithPrimaryAlarmSet);

                            // //if there is no alarms set for all sites of client then we dont require diffrence
                            // if(empty($MyReports) && (count($clientSites)==count($sitesWithoutPrimaryAlarmSet)) && empty($sitesWithPrimaryAlarmSet)){
                            //     $sitesWithoutPrimaryAlarmSet = $clientSites;
                            // }
                            // $siteArr = array();
                            // array_push($siteArr,30);
                            // $sitesWithoutPrimaryAlarmSet = $siteArr;
                            // $MyReports = array();
                                                    // echo "<pre>";
                                                    // print_r($MyReports);
                                                    // die;
                                                ?>
                                                <?php 
                                                  $is_reports = 0;

                                                 $j=1;
                                               
                                                if(!empty($sitesWithoutPrimaryAlarmSet)){
                                                    $reports = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,'','','');
                                               
                                                    foreach ($reports as $key => $MyReport) {
                                                    if($key != 'clientTotal'){ 
                                                    $is_reports = 1;

                                                        $loadFileHrefReport = isset($MyReport['href'])?$MyReport['href']:"";

                                                        $RCompliance = $MyReport['percentage'];
                                                    if($RCompliance != '-'){
                                                        if($RCompliance<90){
                                                            $statusClass = 'reject';
                                                        }elseif($RCompliance>=90 && $RCompliance<=99){
                                                            $statusClass = 'pending';
                                                        }elseif($RCompliance==100){
                                                            $statusClass = 'approve';    
                                                        }
                                                        $RCompliance = $RCompliance.'%';
                                                    }else{
                                                       $statusClass = ''; 
                                                    }
                                                        
                                                    ?>
                                                 
                                                    <tr>
                                                        <td class="left-th"><?php echo $MyReport['name'];?></td>       
                                                        <td><?php echo $MyReport['total']; ?> </td>
                                                        <td><?php echo $MyReport['frequency'];?></td>
                                                        <?php if(isset($loadFileHrefReport) && $loadFileHrefReport!=''){ ?>
                                                        <td class="view-unknown"><a href="<?php echo $loadFileHrefReport; ?>" title="see report" target = "_blank"> <?php echo $MyReport['lastReportDate']; ?> </a></td>
                                                        <?php }else{ ?> 
                                                        <td><?php echo $MyReport['lastReportDate']; ?></td>
                                                        <?php } ?>  
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $RCompliance; ?></td>
                                                    </tr>
                                                <?php 
                                                 }
                                                } 
                                            }if($is_reports = 0){?>
                                                    <tr>
                                                        <td colspan="5">No data found...</td>
                                                    </tr>
                                                <?php } ?>                                
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>          
        </div>
        <div class="row" style="display: none;">
            <div class="col-md-12">             
                <div class="site-bottom">
                    <h2 class="title">Contact details of suppliers</h2>
                    <ul>
                        <li>RMP Systems</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                        <li>Supplier Name Here</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                        <li>Another Supplier Name</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<div id="bottom-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12"><?php echo Html::a('rmpsystems.com', 'http://rmpsystems.com', ['class' => 'btn btn-link']) ?></div>
        </div>
    </div>
</div>

<?php $this->endBody() ?><!--[if lt IE 9]>
<script src="/js/plugins/respond.min.js"></script>
<script src="/js/plugins/excanvas.min.js"></script>
<![endif]-->

</body>
</html>
<?php $this->endPage() ?>
