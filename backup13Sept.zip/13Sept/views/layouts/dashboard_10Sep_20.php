<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\ClientContact;
use common\models\SiteOperationalProgram;
use common\models\ReportType;
use common\models\ReportInterval;
use yii\widgets\ActiveForm;
use GuzzleHttp\Client;
use kartik\daterange\DateRangePicker;
use  yii\web\Session;
use common\components\CheckPermissionHelper;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use yii\helpers\Url;
$session = Yii::$app->session;

//$session->open(); // open a session


AppAsset::register($this);
$allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
$client = array_column($allowedClients, 'client_id');
if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
    $clientId = $client;
}else{
    $clientId = Yii::$app->user->identity->client_id;
}
$userRole = Yii::$app->user->identity->role;
$vaultLink = Yii::$app->user->identity->vault_link;
if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}else{
    $CrDate = date('d-m-Y');
    if(date('L') == 1){
        $dateNew = strtotime($CrDate.' -365 days');        
    }else{
        $dateNew = strtotime($CrDate.' -364 days');   
    }
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromDate', $pastDate);
    $session->set('toDate', $CrDate);

    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}
$this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language ?>">
<head>
    <meta charset="<?php echo Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?php echo Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php
//    $this->registerCssFile('/css/layout.min.css');
//    $this->registerCssFile('/css/default.min.css');
    ?>
    <link href="/css/layout.min.css" rel="stylesheet">
    <link href="/css/default.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/responsive.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="page-container-bg-solid page-sidebar-closed-hide-logo page-md page-boxed">
<style type="text/css">
.kv-drp-dropdown .right-ind {
    right: 12px;
    top: 8px;
}  

.kv-drp-dropdown .left-ind {
    left: 11px;
    top: 8px;
    /* padding: 0 5px 0 0; */
}

.kv-drp-dropdown .right-ind.kv-clear{ 
    display: none;  
}

.kv-drp-dropdown .range-value {
    padding-left: 3rem;    
}

.download-button{
    position:fixed;
    right:0;
    top:75%;
    margin:-34px 0 0 0;
    background:#fff;
    padding:10px 10px 10px 16px;
    box-shadow:0 0 10px rgba(0,0,0,0.2);
    border-radius:25px 0 0 24px;
}

</style>
<?php $this->beginBody();
    echo RedRocketAdminNav::widget();
?>
<?php $viewDashboard = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Dashboard','view',Yii::$app->user->identity->role);   ?>    
<?php 
if($this->params['currentPage'] == 'Dashboard'){      
    if($viewDashboard == '1'){      
?>

    <link href="/assets/4234c4f1/themes/smoothness/jquery-ui.css" rel="stylesheet">
    <?php
        $FromDate = $_SESSION['fromDate'];
        $toDate = $_SESSION['toDate'];

        $DashboardCompliance = ClientSite::getDashboardComplianceStatistic($FromDate,$toDate,$clientId,5);
        $ToleranceComplianceRate = floor($DashboardCompliance['tolerance-percentage']);
        $OntimeComplianceRate = floor($DashboardCompliance['ontime-percentage']);
        $lateComplianceRate = floor($DashboardCompliance['late-percentage']);

        // $ToleranceComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,11));
        // $OntimeComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,0));
        // if($ToleranceComplianceRate == 0 && $OntimeComplianceRate == 0){
        //     $lateComplianceRate = floor(ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,12));
        // }else{
        //     $lateComplianceRate = (100 - ($ToleranceComplianceRate + $OntimeComplianceRate));
        // }

    ?>
    <section class="dashboard">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-3">
                    <div class="left-side">
                        <h2 class="title">Compliance</h2>

                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; ">
                            <tbody>
                                <tr>
                                    <td style="padding: 0 0 10px 0; ">
                                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; background: #c5c7c9; margin: 0 0 10px 0;">
                                            <tbody>
                                                <tr>
                                                    <td style="background: #00b050; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $OntimeComplianceRate;?>%;"><?php echo $OntimeComplianceRate;?>%</td>
                                                    <td style="background: #ffc000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $ToleranceComplianceRate;?>%;"><?php echo $ToleranceComplianceRate;?>%</td>
                                                    <td style="background: #ff0000; -webkit-print-color-adjust: exact; height: 30px; width: <?php echo $lateComplianceRate; ?>%;"><?php echo $lateComplianceRate; ?>%</td>
                                                </tr>
                                            </tbody>
                                        </table>                            
                                    </td>                                                
                                </tr>
                                <tr>
                                    <td>
                                        <table border="0" cellspacing="0" cellpadding="0" style="width:100%; text-align: left; margin: 0 0 18px 0;">
                                            <tbody><tr>
                                                <td>
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                                        <tbody><tr>                                                
                                                            <td style="background: url('images/color-mark1.jpg') 0 center no-repeat; font-size: 14px; padding: 0 0 0 15px;">
                                                                Ontime
                                                            </td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                                <td>
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                                        <tbody><tr>                                                
                                                            <td style="background: url('images/color-mark2.jpg') 0 center no-repeat; font-size: 14px; padding: 0 0 0 15px;">
                                                                Tolerance
                                                            </td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                                <td>
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;">
                                                        <tbody><tr>                                                
                                                            <td style="background: url('images/color-mark3.jpg') 0 center no-repeat; font-size: 14px; padding: 0 0 0 15px;">
                                                                Late
                                                            </td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>                 
                        </tbody>
                </table>

                        <div class="site">
                            <?php $totalSites = ClientSite::getClientSites($clientId,1); ?>
                            <h3><?php echo $totalSites; ?> </h3>
                            <p>Sites Monitored</p>
                        </div>
                        <div class="total-audite">
                            <h3><?php echo ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,1); ?></h3>
                            <p>Total Reports</p>
                        </div>

                        <!-- <div class="last-report">
                            <?php $lastReport = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,6); ?>
                            <p>Report last generated <?php echo $lastReport; ?> for the previous 12 months</p>
                           <!--  <a href="#">View Metric Report</a>
                        </div> -->

                        
                        <?php if($vaultLink!=""){ ?>
                            <div class="vault-button">        
                                <a target="_blank" href="<?php echo $vaultLink;?>" class="btn bluebtn">Go to Vault</a>
                            </div>
                        <?php } ?>
                       <!--  <a href="#">View Metric Report</a> -->
                        <div class="client_contact"> 
                            <?php 
                            $clientContacts = ClientContact::find()->select('contact_id')->with('contact')->where(['client_id'=>$clientId,'display_dashboard'=>1])->all();
                            if(!empty($clientContacts)){ ?>
                            <h2 class="title" style="text-align: left; ">Primary Contact</h2>
                            
                              <?php
                              $i=0; 
                                foreach ($clientContacts as $key => $contact) {
                                    if($i>2){
                                        break;
                                    }
                                   echo "<ul class='custom-contact'><li>".$contact['contact']->name."</li>";
                                   if($contact['contact']->job_title != ""){
                                    echo "<li>".$contact['contact']->job_title."</li>";
                                   }
                                   if($contact['contact']->street != ""){
                                   echo "<li>".$contact['contact']->street."</li>";}
                                   echo "<li>".$contact['contact']->suburb." ".$contact['contact']->state." ".$contact['contact']->postcode."</li>";
                                   if($contact['contact']->phone != ""){
                                   echo "<li>".$contact['contact']->phone."</li>";}
                                   if($contact['contact']->mobile != ""){
                                   echo "<li>".$contact['contact']->mobile."</li>";}
                                   if($contact['contact']->email != ""){
                                   echo "<li style='font-size:12px;'>".$contact['contact']->email."</li>";}
                                   if($contact['contact']->website != ""){
                                   echo "<li style='font-size:12px;'>".$contact['contact']->website."</li>";}
                                   if($contact['contact']->comment != ""){
                                   echo "<li>".$contact['contact']->comment."</li></ul>";}
                                   $i++;
                               }
                               if(count($clientContacts) > 3){
                               ?>
                               <a href="#" class="client-link"> <?php echo $i.'/'. count($clientContacts); ?></a>
                               <?php
                               }
                            }
                          
                         ?>
                         
                        </div>

                    </div>
                </div>
                <?php 
                    $MySites =  ClientSite::getClientSites($clientId,2);
                ?>
                <div class="col-xs-12 col-md-9">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="main-date-range">
                                <label>Select Audit Period :</label>
                                <div class="drp-container">
                                <?php 
                                    /*$modelD = DynamicModel::validateData(
                                                ['filter_date_range',
                                    ]);*/
                                    $form = ActiveForm::begin([
                                        'id' => 'dashboard-filter-form',
                                        'fieldConfig' => [
                                            'options' => [
                                                'tag' => 'span',
                                            ],
                                        ],
                                        'method' => 'post',
                                        'action' =>['/client-site/dashboard-filter'],
                                    ]);

                                    echo DateRangePicker::widget([
                                        'name'=>'filter_date_range',
                                        'value'=> $RangeValue,                                
                                        'startAttribute' => $pastDate,
                                        'endAttribute' => $CrDate,
                                        'presetDropdown'=>true,
                                        'hideInput'=>true,
                                        'pluginOptions'=>[
                                            'format'=>'d-m-Y',
                                            'locale' => [
                                                'format' => 'DD-MM-YYYY',
                                                'separator'=>' to ',
                                            ],
                                        ]
                                    ]);
                                ?>
                                </div>
                                <div class="back-button">
                                    <?= Html::submitButton(Yii::t('app', 'Apply'), ['class' => 'btn bluebtn']);
                                    ActiveForm::end();

                                    $form = ActiveForm::begin([
                                        'id' => 'clear-filter-form',
                                        'fieldConfig' => [
                                            'options' => [
                                                'tag' => 'span',
                                            ],
                                        ],
                                        'method' => 'post',
                                        'action' =>['/client-site/clear-filter'],
                                    ]);
                                    echo Html::submitButton(Yii::t('app', 'Clear'), ['class' => 'btn bluebtn']) ?>
                                    <?php ActiveForm::end(); ?>
                                    <?php //echo Html::a('Clear', ['/client-site/clear-filter'], ['class' => 'btn bluebtn']) ?>
                                </div>
                            </div>
                        </div>                        
                    </div>
                    <div class="right-side-content">
                        <div class="row">
                            <?php if(Yii::$app->user->identity->role != User::ROLE_AUDITOR){
                                $clientInfo = ClientSite::getClientInfo($clientId);
                             ?> 
                            <div class="col-xs-12 col-sm-12 col-md-9">
                                <h2 class="title" style="font-weight: 900;">Client : 
                                <?php echo isset($clientInfo->name)?$clientInfo->name:""; ?></h2>
                            </div>
                            <?php } ?>
                            <div class="col-xs-12 col-sm-12 col-md-9">
                                <h2 class="title">My Sites</h2>
                                <div class="report-list" style="position: relative;">    
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <?php if(!empty($MySites)){
                                                $LateSites = array();
                                                foreach ($MySites as $MySite) { 
                                                    $mySiteId = $MySite['id'];
                                                    $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                                    if(!empty($lateReports)){                  
                                                        foreach ($lateReports as $client=>$reports) {
                                                            if(isset($reports['late'])){
                                                                foreach ($reports['late'] as $key => $report) {
                                                                    $LatesiteID = $report['sop']['site_id'];
                                                                    array_push($LateSites, $LatesiteID);
                                                                }
                                                            }
                                                        }
                                                    }
                                                } }?>
                                                <tr>
                                                    <?php if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){ ?>
                                                    <th class="left-th">Client</th> <?php } ?>
                                                    <th class="left-th">Location</th>
                                                    <th>No. of <br/> Reports</th>
                                                    <th>First Report <br/> Received</th>
                                                    <th>Last Report <br/> Received</th>
                                                    <th>Overall <br/> Compliance <sup href="#" data-toggle="tooltip" title="Sum of Ontime and Tolerance compliance" data-placement="right" style="position: absolute;top:0.5em;cursor: pointer;"><img src="images/info.svg" /></sup></th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            if(!empty($MySites)){
                                                $i=1;
                                                $statusClass = '';
                                                foreach ($MySites as $MySite) { 
                                                    $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                                    $mySiteId = $MySite['id'];
                                                    $Compliance = ClientSite::getSitesComplianceStaticsDashboard($FromDate,$toDate,$mySiteId,5);
                                                    //$Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,2,$mySiteId);
                                                    $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,3,$mySiteId);
                                                    $auditDate =  explode('-', $AuditPeriod);
                                                    $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                                    $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                                    if($lastReceived != "-"){
                                                       $loadFileHref = ClientSite::gatherSiteReportInfoForLoadFile($mySiteId,$FromDate,$toDate,$lastReceived);
                                                    }else{
                                                        $loadFileHref = "";
                                                    }
                                                    if($Compliance<90){
                                                        $statusClass = 'reject';
                                                    }elseif($Compliance>=90 && $Compliance<=99){
                                                        $statusClass = 'pending';
                                                    }elseif($Compliance==100){
                                                        $statusClass = 'approve';    
                                                    }
                                                    ?>
                                                    <tr>
                                                    <?php if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){ ?>
                                                        <td class="left-th"><?php echo $clientInfo->name; ?></td><?php } ?>
                                                        <td class="view-unknown left-th"><a href="site-detailview?sid=<?php echo $mySiteId; ?>" title=""><?php echo $MySite['name']; ?><?php          
                                                            if(!empty($LateSites) && in_array($mySiteId, $LateSites)){  ?>
                                                                <img src="images/site-alaram.svg" alt="" style="width:8%;">
                                                        <?php  } ?></a></td>
                                                        <td><?php echo ClientSite::getTotalReportsBySites($FromDate,$toDate,$clientId,1,$mySiteId); ?></td>
                                                        <td><?php echo $firstReceived; ?> </td>
                                                        <?php if(isset($loadFileHref) && $loadFileHref!=''){ ?>
                                                           <td class="view-unknown"><a href="<?php echo $loadFileHref; ?>" title="see report" target = "_blank"> <?php echo $lastReceived; ?> </a></td>
                                                        <?php }else{ ?> 
                                                            <td><?php echo $lastReceived; ?> </td>
                                                        <?php } ?>
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $Compliance; ?>%</td>
                                                        <?php if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){ ?><td class="view-unknown"><a href="#myModal" data-toggle="modal" onclick="getReportAuditor(<?php echo $mySiteId;?>,<?php echo $MySite['client_id'];?>,'<?php echo Url::toRoute('/client-site/lists-html');?>');"> View Report</a></td>
                                                         <?php   }else{ ?>
                                                        <td class="view-unknown"><a href="#myModal" data-toggle="modal" onclick="getReport(<?php echo $mySiteId;?>,<?php echo $MySite['client_id'];?>);"> View Report</a></td>
                                                        <?php } ?>
                                                    </tr>
                                                <?php $i++;
                                                    if($i>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <?php if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){ ?>
                                                        <td colspan="7">No sites found.</td>
                                                    <?php }else{ ?> 
                                                        <td colspan="6">No sites found.</td>
                                                     <?php } ?>
                                                </tr>
                                            <?php }?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php if($totalSites>5){ ?>
                                        <div class="view-more"><a href="/site-overview">5/<?php echo $totalSites; ?></a></div>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-3">
                                <h2 class="title">Manage Late Report Alarms</h2>
                                <div class="alarm-buttons">
                                    <ul>
                                        <li><a href="/site-operational-program/index" class="primaryalarm">Primary Alarm</a></li>
                                        <li><a href="/secondary-alarm" class="secondaryalarm">Secondary Alarm</a></li>
                                        <li><a href="/territory-alarm" class="overdue">Tertiary Alarm</a></li>
                                    </ul>
                                </div>      
                            </div>
                        </div>
                        <hr>
                        <?php 
                            $MyReports =  ClientSite::getMySitesReports($clientId);          
                            $sitesWithPrimaryAlarmSet = array_unique(array_column($MyReports,'site_id')); 
                            $clientSites = array_column(ClientSite::getClientSites($clientId,0),'id');
                            $sitesWithoutPrimaryAlarmSet = array_diff($clientSites, $sitesWithPrimaryAlarmSet);
                            //if there is no alarms set for all sites of client then we dont require diffrence
                            if(empty($MyReports) && (count($clientSites)==count($sitesWithoutPrimaryAlarmSet)) && empty($sitesWithPrimaryAlarmSet)){
                                $sitesWithoutPrimaryAlarmSet = $clientSites;
                            }
                            $ReportCount =  count($MyReports); 
                        ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="title">My Report Type(s)</h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th class="left-th">Report Type</th>
                                                    <th>No of. <br/> Reports</th>
                                                    <th>Frequency</th>
                                                    <th>Last Report <br/> Received</th>
                                                    <!-- <th>Next Report </th>
                                                    <th>Supplier</th> -->
                                                    <th>Overall <br/> Compliance  <sup href="#" data-toggle="tooltip" title="Sum of Ontime and Tolerance compliance" data-placement="right" style="position: absolute;top:0.5em;cursor: pointer;"><img src="images/info.svg" /></sup></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php                                          
                                             $j=1;
                                            if(!empty($MyReports)){
                                                $statusClass = '';
                                                foreach ($MyReports as $MyReport) {

                                                       $reports = ClientSite::getReportsStaticsDashboard($FromDate,$toDate,$clientId,5,$MyReport['provider_ids'],$MyReport['report_interval_id'],$MyReport['doctype_id']); 

                                                    $loadFileHrefReport = isset($reports['href'])?$reports['href']:"";
                                                    
                                                    $RCompliance = $reports['percentage'];
                                                    if($RCompliance<90){
                                                        $statusClass = 'reject';
                                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                                        $statusClass = 'pending';
                                                    }elseif($RCompliance==100){
                                                        $statusClass = 'approve';    
                                                    }

                                                ?>                   
                                                    <tr>
                                                        <!-- <td title="<?php echo $MyReport['report_type'];?>"><?php echo $j.'. '.substr($MyReport['report_type'], 0,8); if(strlen($MyReport['report_type'])>8){ echo "..."; }?></td> -->
                                                        <td class="left-th"><?php echo $j.'. '.$MyReport['report_type'];?></td>
                                                       <td><?php echo $reports['total']; ?> </td>
                                                        <td><?php echo $MyReport['frequency'];?></td>
                                                        <?php if(isset($loadFileHrefReport) && $loadFileHrefReport!=''){ ?>
                                                        <td class="view-unknown"><a href="<?php echo $loadFileHrefReport; ?>" title="see report" target = "_blank"> <?php echo $reports['lastReportDate']; ?> </a></td>
                                                        <?php }else{ ?> 
                                                        <td><?php echo $reports['lastReportDate']; ?></td>
                                                        <?php } ?>
                                                         <!-- <td><?php //echo isset($reports['nextDate'])?$reports['nextDate']:"-";//$nextReportDate; ?></td>
                                                        <td><?php //echo $MyReport['providers']; ?> </td> -->

                                                        <td class="<?php echo $statusClass; ?>"><?php echo $RCompliance; ?>%</td>
                                                    </tr>
                                                <?php $j++;
                                                    if($j>5){
                                                        break;
                                                    }
                                                } 
                                            }
                                            if(!empty($sitesWithoutPrimaryAlarmSet)){
                                                 $reports = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,'','','');
                                                $ReportCount += count($reports);
                                                 foreach ($reports as $key => $MyReport) { 
                                                        if($j>5){
                                                            break;
                                                        }
                                                        $loadFileHrefReport = isset($reports['href'])?$reports['href']:"";
                                                    ?>
                                                   <?php 
                                                ?> 
                                                 <tr>
                                                        <td class="left-th"><?php echo $j.'. '.$MyReport['name'];?></td>       
                                                        <td><?php echo $MyReport['total']; ?> </td>
                                                        <td><?php echo $MyReport['frequency'];?></td>
                                                        <?php if(isset($loadFileHrefReport) && $loadFileHrefReport!=''){ ?>
                                                        <td class="view-unknown"><a href="<?php echo $loadFileHrefReport; ?>" title="see report" target = "_blank"> <?php echo $MyReport['lastReportDate']; ?> </a></td>
                                                        <?php }else{ ?> 
                                                        <td><?php echo $MyReport['lastReportDate']; ?></td>
                                                        <?php } ?>  
                                                        <td><?php echo $MyReport['percentage']; ?></td>
                                                    </tr>
                                                <?php $j++;
                                                    if($j>5){
                                                        break;
                                                    }
                                                } 
                                            }
                                            if(empty($sitesWithoutPrimaryAlarmSet) && empty($MyReports)){?>
                                                <tr>
                                                    <td colspan="5" class="left-th">No reports found.</td>
                                                </tr>
                                            <?php } 
                                            ?>
                                          </tbody>
                                        </table>
                                    </div>                                   
                                    <?php if($ReportCount>5){ ?>
                                        <div class="view-more"><a href="/reports-overview">5/<?php echo $ReportCount; ?></a></div>
                                    <?php } ?>                                    
                                    <!-- <div class="view-more"><a href="javascript:void(0);">View More</a></div> -->
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php 
                            $MySuppliers =  ClientSite::getSupplierDataByClient($FromDate,$toDate,$clientId); 
                            $SupplierCount =  count($MySuppliers); 
                           
                        ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="title">My Suppliers</h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th class="left-th">Supplier</th>                       
                                                    <th>No of. <br/> Reports</th>          
                                                    <th>Last Report <br/> Received</th>   
                                                    <th>Overall  <br/> Compliance  <sup href="#" data-toggle="tooltip" title="Sum of Ontime and Tolerance compliance" data-placement="right" style="position: absolute;top:0.5em;cursor: pointer;"><img src="images/info.svg" /></sup></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            if(!empty($MySuppliers)){
                                                $j=1;
                                                $statusClass = '';                                               
                                                foreach ($MySuppliers as $MySupplier) { 
                                                    $RCompliance = $MySupplier['info']['percentage'];
                                                    if($RCompliance<90){
                                                        $statusClass = 'reject';
                                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                                        $statusClass = 'pending';
                                                    }elseif($RCompliance==100){
                                                        $statusClass = 'approve';    
                                                    }
                                                    ?>                    <tr>
                                                    <td class="view-unknown left-th"> <a   href="supplier-detailview?sid=<?php echo $MySupplier['supplier_id']; ?>" title="">
                                                                <?php echo $MySupplier['supplier_name']; ?></a></td>
                                                                
                                                                <td><?php echo $MySupplier['info']['total']; ?></td>
                                                                <?php if(isset($MySupplier['href']) && $MySupplier['href']!=''){ ?>
                                                                        <td class="view-unknown"><a href="<?php echo $MySupplier['href']; ?>" title="see report" target = "_blank"> <?php echo $MySupplier['lastReportDate']; ?> </a></td>
                                                                <?php }else{ ?> 
                                                                        <td><?php echo $MySupplier['lastReportDate']; ?></td>
                                                                <?php } ?>
                                                                <td class="<?php echo $statusClass; ?>"><?php echo $MySupplier['info']['percentage']; ?>%</td>
                                                            </tr>                               

                                                              
                                                    
                                                <?php $j++;
                                                    if($j>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <td colspan="5" class="left-th">No supplier found.</td>
                                                </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    </div>                                   
                                    <?php if($SupplierCount>5){ ?>
                                        <div class="view-more"><a href="/supplier-overview">5/<?php echo $SupplierCount; ?></a></div>
                                    <?php } ?> 
                                </div>
                            </div>
                        </div>
                        <hr>

                        <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2);
                            
                        ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="title">Unknown Reports</h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                          <thead>
                                            <tr>
                                             <!--  <th>Client</th> -->
                                              <th class="left-th">Location</th>
                                              <th>No. of <br/> Reports</th>
                                              <th>First Report <br/> Received</th>
                                              <th>Last Report <br/> Received</th>
                                              
                                              <th>Action</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <?php 
                                            $totalOtherReports = 0;
                                            if(!empty($MySites)){
                                                $i=1;
                                                $statusClass = '';
                                                //$totalOtherReports = 0;
                                                foreach ($MySites as $MySite) { 
                                                    $clientInfo = ClientSite::getClientInfo($MySite['client_id']);
                                                    $mySiteId = $MySite['id'];
                                                    $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,9,$mySiteId);
                                                    $auditDate =  explode('-', $AuditPeriod);
                                                    $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                                    $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                                    if($lastReceived != "-"){
                                                       $loadFileHrefUnknownReport = ClientSite::gatherSiteReportInfoForLoadFile($mySiteId,$FromDate,$toDate,$lastReceived,'9999');   
                                                    }else{
                                                        $loadFileHrefUnknownReport = "";
                                                    }
                                                    $Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,10,$mySiteId);
                                                    $totalOtherReports = $totalOtherReports + $Compliance;
                                                    if($Compliance>20){
                                                        $statusClass = 'reject';
                                                    }elseif($Compliance>5 && $Compliance<=20){
                                                        $statusClass = 'pending';
                                                    }elseif($Compliance<5){
                                                        $statusClass = 'approve';    
                                                    }
                                                    ?>
                                                    <tr>
                                                        <!-- <td><?php //echo $i.'. '.substr($clientInfo->name, 0,8); if(strlen($clientInfo->name)>8){ echo "...";} ?></td> -->
                                                        <td class="left-th"><a href="client-site/print-reports?DynamicModel%5Bclient_site%5D=<?php echo $mySiteId; ?>&DynamicModel%5Breport_types%5D%5B%5D=9" title=""><?php echo  $i.". ".$MySite['name']; ?></a></td>
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $Compliance; ?></td>
                                                        <td><?php echo $firstReceived; ?> </td>
                                                        <?php if(isset($loadFileHrefUnknownReport) && $loadFileHrefUnknownReport!=''){ ?>
                                                        <td class="view-unknown"><a href="<?php echo $loadFileHrefUnknownReport; ?>" title="see report" target = "_blank"> <?php echo $lastReceived; ?> </a></td>
                                                        <?php }else{ ?> 
                                                        <td><?php echo $lastReceived; ?></td>
                                                        <?php } ?>
                                                        
                                                        <td class="view-unknown" style="padding-right: 10px;"><a href="client-site/print-reports?DynamicModel%5Bclient_site%5D=<?php echo $mySiteId; ?>&DynamicModel%5Breport_types%5D%5B%5D=9" title="">View Report</a></td>
                                                    </tr>
                                                <?php $i++;
                                                    if($i>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <td colspan="5">No reports found.</td>
                                                </tr>
                                            <?php }?>
                                            <input type="hidden" id="hiddenTotal" value="<?php echo $totalOtherReports; ?>">
                                          </tbody>
                                        </table>
                                    </div>                                    
                                    <?php if($totalSites>5){ ?>
                                        <div class="view-more"><a href="/report-type-list">5/<?php echo $totalSites; ?></a></div>
                                    <?php } ?>
                                    <!-- <div class="view-more"><a href="/report-type-list">View More</a></div> -->
                                </div>
                            </div>
                            <!-- <div class="col-md-5">
                                <h2 class="title">Sites with alarms</h2>
                                <div class="site-alaram">
                                    <ul class="list-unstyled">
                                    <?php
                                    $ArrayCount = 0;
                                    if(!empty($MySites)){
                                        $LateSites = array();
                                        foreach ($MySites as $MySite) { 
                                            $mySiteId = $MySite['id'];
                                            $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                            if(!empty($lateReports)){
                                                foreach ($lateReports as $client=>$reports) {
                                                    if(isset($reports['late'])){
                                                        foreach ($reports['late'] as $key => $report) {
                                                            $LatesiteName = $report['sop']['clientSite']['name'];
                                                            array_push($LateSites, $LatesiteName);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if(!empty($LateSites)){
                                            $FinalArray = array_unique($LateSites);
                                            $ArrayCount = count($FinalArray);
                                            $i=1;
                                            foreach ($FinalArray as $key => $site) { ?>
                                                <li><a href="#" title=""><img src="images/site-alaram.svg" alt=""><?php echo $i.'. '.$site; ?></a></li>
                                            <?php 
                                                $i++;
                                                if($i>5){
                                                    break;
                                                }
                                            }
                                        }else{?>
                                            <li>No alarms found.</li>
                                        <?php }
                                    }
                                    ?>
                                        <!-- <li><a href="#" title=""><img src="images/site-alaram.svg" alt="">1. 739 Bourke Street</a></li>
                                        <li><a href="#" title=""><img src="images/site-alaram2.svg" alt="">2. Melbourne City Tower</a></li>                                  
                                    </ul>
                                </div>
                                <?php if($ArrayCount>5){ ?>
                                    <div class="view-more"><a href="#getSitesWithLateReport" data-toggle="modal" >View All</a></div>
                                <?php } ?>
                            </div> -->
                        </div>
                        <?php 
                            $url = Url::to(['client/print', 'id' =>$clientId]);
                            $mailurl = Url::to(['client/mailreport', 'id' =>$clientId]);
                        
                        if(Yii::$app->user->identity->role != User::ROLE_AUDITOR){ ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="download-button" style="text-align: right;">
                                    <a class="btn btn-icon-only btn-circle bluebtn" href="<?php echo $url; ?>" title="Download Report" aria-label="Download Report" data-method="post" data-pjax="0" target="_blank"><i class="fa fa-download"></i></a>
                                    <a class="showModalButton11 loadMainContent btn btn-icon-only btn-circle bluebtn" value="<?php echo $mailurl; ?>" title="Mail Report" aria-label="Mail Report" data-toggle="modal" data-target="#mailModal" data-pjax="0"><i class="fa fa-envelope"></i></a>
                                </div>
                            </div>
                            <div class="modal remote fade" id="mailModal">
                                <div class="modal-dialog">
                                    <div class="modal-content loader-lg content" id= "modalContent11">
                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                      <?php  } ?>
                        <!-- <hr>
                        <div class="row">
                            <div class="col-xs-12 col-md-7">
                                <h2 class="title">Unknown Reports</h2>
                                <div class="unknown-reports">
                                    <ul class="list-unstyled">
                                        <li><a href="#" title=""><img src="images/virus.svg" alt="">Detected Virus</a></li>
                                        <li><a href="#" title="">Fault and follow up log</a></li>
                                        <li><a href="#" title="">Other alarms</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-5">
                                <h2 class="title">Sites with alarms</h2>
                                <div class="site-alaram">
                                    <ul class="list-unstyled">
                                        <li><a href="#" title=""><img src="images/site-alaram.svg" alt="">1. 739 Bourke Street</a></li>
                                        <li><a href="#" title=""><img src="images/site-alaram2.svg" alt="">2. Melbourne City Tower</a></li>                                 
                                    </ul>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <?php 
            //require_once ('vendor/autoload.php'); 
            /*$client = new Client([
                        'base_uri' => 'https://ccsvault.cleancloudsystems.com/ocs/v1.php/apps/files_sharing/api/v1/',
                    ]);

            try {
                $response = $client->get('shares?path=/RMP_mirror/Vrinsoft_testing&reshares=true', [
                    'auth' => ['admin', 'rmpsystems2016'],
                    'debug' => true,
                ]);
                print $response->getBody()->getContents();
            } catch (\GuzzleHttp\Exception\ClientException $e) {
                print $e->getMessage();
            }*/

        ?>
    </section>
    <div class="modal fade site-report-modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">View Reports</h4>
          </div>
          <div class="modal-body">
               <div class="portlet-body form">
                    <?php 
                        
                        if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){

                            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['in','client_id', $clientId])->all(), 'id', 'id');
                        }else{
                            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->all(), 'id', 'id');                            
                        }
                        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['IN', 'site_id', $clientSitesArr])->all(), 'report_type_id', 'report_type_id');
                        $model = DynamicModel::validateData(
                                    ['date_from',
                                     'date_to',
                                     'client_site',
                                     'client_id',
                                     'node',
                                     'report_types',
                        ]);
                        $model->addRule(['client_site'], 'integer');
                        $model->addRule(['report_types'], 'required');
                        $form = ActiveForm::begin([
                        'id' => 'print-reports-form',
                        'fieldConfig' => [
                            'options' => [
                                'tag' => 'span',
                            ],
                        ],
                        'method' => 'get',
                        'action' =>['/client-site/print-reports'],
                    ]) ?>
                        <?php 
                        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
                        $forceSites = [];
                        if(!empty($allowedSites) && (Yii::$app->user->identity->role != User::ROLE_SUPER)){

                            foreach ($allowedSites as $key => $value) {
                               array_push($forceSites,$value['site_id']);
                            }
                            if(Yii::$app->user->identity->role == User::ROLE_AUDITOR && !empty($clientId)){
                                $clietSiteData = ArrayHelper::map(ClientSite::find()->where(['in','client_id',$clientId])->andWhere(['in','id',$forceSites])->asArray()->all(), 'id', 'name');
                            }else{
                                $clietSiteData = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->andWhere(['in','id',$forceSites])->asArray()->all(), 'id', 'name');
                            }                                
                        }else{
                            $clietSiteData = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->asArray()->all(), 'id', 'name');
                        }
                        echo $form->field($model, 'client_id')->hiddenInput()->label(false);
                        echo $form->field($model, 'client_site', [
                            'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
                        ])->dropDownList($clietSiteData, ['prompt' => 'Select Site']);
                         ?>
                        

                        <div class="form-group form-md-checkboxes">
                            <div class="md-checkbox-list">
                                <div class="md-checkbox has-info">
                                    <input type="checkbox" class="md-check" id="report-types-select-all" />
                                   <label for="report-types-select-all"><span></span><span class="check"></span><span class="box"></span>Select all</label>
                                </div>
                                <?php echo $form->field($model, 'report_types')
                                         ->checkboxList(ArrayHelper::map(ReportType::find()->asArray()->where(['IN', 'id', $clientReportArr])->all(), 'id', 'name'), [
                                             'item' => function($index, $label, $name, $checked, $value) {
                                                 return "<div class=\"col-sm-4\"><div class=\"md-checkbox\"><input id='{$index}' type='checkbox' {$checked} name='{$name}' value='{$value}' tabindex='3'><label for='{$index}'><span></span><span class=\"check\"></span><span class=\"box\"></span>{$label}</label></div></div>";
                                             }
                                         ]); ?>
                            </div>
                        </div>
                        <div class="form-group margin-bottom-submit">
                            
                        </div>
                    </div>
                

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <?php echo Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
          </div>         

        <?php ActiveForm::end() ?>
        </div>
      </div>
    </div>
    <div class="modal fade" id="getSitesWithLateReport" tabindex="-1" role="dialog" aria-labelledby="LateReportLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="LateReportLabel">Sites with alarms</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2);                            
                        ?>
                        <div class="col-md-12">
                            <!-- <h2 class="title">Sites with alarms</h2> -->
                            <div class="modal-sitealaram">
                                <ul class="list-unstyled">
                                <?php
                                $ArrayCount = 0;
                                if(!empty($MySites)){
                                    $LateSites = array();
                                    foreach ($MySites as $MySite) { 
                                        $mySiteId = $MySite['id'];
                                        $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                        if(!empty($lateReports)){
                                            foreach ($lateReports as $client=>$reports) {
                                                if(isset($reports['late'])){
                                                    foreach ($reports['late'] as $key => $report) {
                                                        $LatesiteName = $report['sop']['clientSite']['name'];
                                                        array_push($LateSites, $LatesiteName);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if(!empty($LateSites)){
                                        $FinalArray = array_unique($LateSites);
                                        $ArrayCount = count($FinalArray);
                                        $i=1;
                                        foreach ($FinalArray as $key => $site) { ?>
                                            <li><a href="#" title=""><img src="images/site-alaram.svg" alt=""><?php echo $i.'. '.$site; ?></a></li>
                                        <?php 
                                            $i++;
                                        }
                                    }else{?>
                                        <li>No alarms found.</li>
                                    <?php }
                                }
                                ?>                        
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            
                </div>         

            </div>
        </div>
    </div>
<?php
    // unset($_SESSION['fromDate']);
    // unset($_SESSION['toDate']);
?>
<?php }else{ //paste your code here?>      
            
    <link href="/css/style.css" rel="stylesheet">       
<link href="/css/responsive.css" rel="stylesheet">      
<div class="page_caption">      
    <div class="container">     
        <div class="row">       
            <div class="col-sm-12">     
                <h1>Dashboard</h1>      
            </div>      
        </div>      
    </div>      
</div>      
<div class="container static-content">      
    <p><strong>A robust management protocol, especially containing verifications and validations... that’s how we operate.</strong></p>     
    <p>Victoria, Australia is the legislative pioneer in the field of rigorous systems based auditing of cooling towers.   The high standards of legislative requirements existing in Victoria, Australia based on the use of a comprehensive auditing process clearly demonstrate that the auditing process will increasingly become the singularly most effective strategy for cooling tower management in the 21st Century. Our experience internationally speaks likewise to the value of the auditing process as being one of the most efficient ways of managing most associated risks, be that physical contamination, public health issues, production interruption and at worst legal culpability.</p>     
    <p>Cooling tower auditing is based on a simple approach; a well defined management plan that brings together and documents the associated monitoring and risk management that is in place. This documentation is audited every year to ensure both legislative compliance and operational rigor. Although seemingly sounding simple, at its heart it addresses many of the fundamental operational and risk issues associated with cooling towers.</p>      
    <p>Auditing has many benefits for example it can lead to a more robust system especially if there are interlocking verifications such as independent microbiology testing and review of corrosion Key Performance Indicators (KPI’s).</p>       
</div>      
<?php }        
//bahar nu if puru
 }else{ ?>
    <div class="container">
        <div class="page-container"><?php
            echo RedRocketSideNav::widget([
                'currentPage' => $this->params['currentPage'],
                'currentChild' => $this->params['currentChild'] ?? '',
            ]); ?>
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1><?php echo Html::encode($this->title) ?></h1>
                        </div>


                    </div>
                    <?php echo Breadcrumbs::widget([
                        'itemTemplate' => "<li>{link}<i class=\"fa fa-circle\"></i></li>\n",
                        'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                        'options' => ['class' => 'page-breadcrumb breadcrumb'],
                    ]); ?>

                <?php
                    foreach (Yii::$app->session->getAllFlashes() as $key => $message) :
                        echo '<div class="alert alert-' . $key . '">' . $message . '</div>';
                    endforeach;
                ?>

            <?php echo $content ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php $this->registerJs(    
    "$(document).on('ready',(function(){            
    $(document).on('click', '.showModalButton11', function () {         
        if ($('#mailModal').data('bs.modal').isShown) { 
            $('#mailModal').find('#modalContent11') 
                    .load($(this).attr('value'));                               
        } else {    
            $('#mailModal').modal('show');  
            $('#mailModal').find('#modalContent11') 
                    .load($(this).attr('value'));   
                
        }   
    }); 
 }));"  
);  
?>
<div id="bottom-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12"><?php echo Html::a('rmpsystems.com', 'http://rmpsystems.com', ['class' => 'btn btn-link']) ?></div>
        </div>
    </div>
</div>

<?php $this->endBody() ?><!--[if lt IE 9]>
<script src="/js/plugins/respond.min.js"></script>
<script src="/js/plugins/excanvas.min.js"></script>
<![endif]-->

</body>
</html>
<?php $this->endPage() ?>


