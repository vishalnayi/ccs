<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use common\models\ReportType;
use common\models\ReportInterval;
use yii\widgets\ActiveForm;
use GuzzleHttp\Client;


AppAsset::register($this);
$clientId = Yii::$app->user->identity->client_id;
$userRole = Yii::$app->user->identity->role;
$vaultLink = Yii::$app->user->identity->vault_link;


$this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language ?>">
<head>
    <meta charset="<?php echo Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?php echo Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php
//    $this->registerCssFile('/css/layout.min.css');
//    $this->registerCssFile('/css/default.min.css');
    ?>
    <link href="/css/layout.min.css" rel="stylesheet">
    <link href="/css/default.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/responsive.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="page-container-bg-solid page-sidebar-closed-hide-logo page-md page-boxed">
<?php $this->beginBody();
    echo RedRocketAdminNav::widget();
?>
<?php if($this->params['currentPage'] == 'Dashboard'){ ?>

    <link href="/assets/4234c4f1/themes/smoothness/jquery-ui.css" rel="stylesheet">
    <section class="dashboard">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-3">
                    <div class="left-side">
                        <h2 class="title">Summary of All Compliance</h2>
                        <div class="prograss"> <span style="display:none;"><?php echo ClientSite::getDashboardCompliance($clientId,0); ?></span></div>
                        
                        <p>Compliance rate average across all my sites</p>

                        <div class="site">                            
                            <?php $totalSites = ClientSite::getClientSites($clientId,1); ?>
                            <h3><?php echo $totalSites; ?> Sites</h3>
                            <p>Monitored with CleanCloud Systems</p>
                        </div>
                        <div class="total-audite">
                            <h3><?php echo ClientSite::getDashboardCompliance($clientId,1); ?></h3>
                            <p>Total Reports/Audits Monitored to date</p>
                        </div>

                        <div class="last-report">
                            <?php $lastReport = ClientSite::getDashboardCompliance($clientId,6); ?>
                            <p>Report last generated <?php echo $lastReport; ?> for the previous 12 months</p>
                            <!-- <a href="#">View Metric Report</a> -->
                        </div>
                        <?php if($vaultLink!=""){ ?>
                            <div class="vault-button">        
                                <a target="_blank" href="<?php echo $vaultLink;?>" class="btn bluebtn">Go to Vault</a>
                            </div>
                        <?php } ?>

                    </div>
                </div>
                <?php 
                    $MySites =  ClientSite::getClientSites($clientId,2); 
                ?>
                <div class="col-xs-12 col-md-9">
                    <div class="right-side-content">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-9">
                                <h2 class="title">View My Sites</h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Location</th>
                                                    <th>Audit Period</th>
                                                    <th>Current <br/> Compliance</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            if(!empty($MySites)){
                                                $i=1;
                                                $statusClass = '';
                                                foreach ($MySites as $MySite) { 
                                                    $mySiteId = $MySite['id'];
                                                    $Compliance = ClientSite::getDashboardCompliance($clientId,2,$mySiteId);
                                                    $AuditPeriod = ClientSite::getDashboardCompliance($clientId,3,$mySiteId);
                                                    if($Compliance<50){
                                                        $statusClass = 'reject';
                                                    }elseif($Compliance>=50 && $Compliance<70){
                                                        $statusClass = 'pending';
                                                    }elseif($Compliance>=70){
                                                        $statusClass = 'approve';    
                                                    }
                                                    ?>
                                                    <tr>
                                                        <td><a href="site-detailview?sid=<?php echo $mySiteId; ?>" title=""><?php echo $i.'. '.$MySite['name']; ?></a></td>
                                                        <td><?php echo $AuditPeriod; ?> </td>
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $Compliance; ?>%</td>
                                                        <td class="view-unknown"><a href="#myModal" data-toggle="modal" onclick="getReport(<?php echo $mySiteId;?>);"> View Report</a></td>
                                                    </tr>
                                                <?php $i++;
                                                    if($i>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <td colspan="3">No data found...</td>
                                                </tr>
                                            <?php }?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php if($totalSites>5){ ?>
                                        <div class="view-more"><a href="/site-overview">View All</a></div>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-3">
                                <h2 class="title">Manage Late Report Alarms</h2>
                                <div class="alarm-buttons">
                                    <ul>
                                        <li><a href="/site-operational-program/create" class="primaryalarm">Primary Alarm</a></li>
                                        <li><a href="/secondary-alarm" class="secondaryalarm">Secondary Alarm</a></li>
                                        <li><a href="/territory-alarm" class="overdue">Territory Alarm</a></li>
                                    </ul>
                                </div>      
                            </div>
                        </div>
                        <hr>
                        <?php 
                            $MyReports =  ClientSite::getMySitesReports($clientId); 
                            $ReportCount =  count($MyReports); 
                        ?>
                        <div class="row">
                            <div class="col-md-7">
                                <h2 class="title">View My Reports</h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Report Type</th>
                                                    <th>Audit Period</th>
                                                    <th>Name of Supplier</th>
                                                    <th>Current <br/> Compliance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $j=1;
                                            if(!empty($MyReports)){
                                                $j=1;
                                                $statusClass = '';
                                                foreach ($MyReports as $MyReport) {
                                                    $AuditPeriod = ClientSite::getDashboardCompliance($clientId,4,"",$MyReport['doctype_id']);
                                                    $RCompliance = ClientSite::getDashboardCompliance($clientId,5,"",$MyReport['doctype_id']);
                                                    if($RCompliance<50){
                                                        $statusClass = 'reject';
                                                    }elseif($RCompliance>=50 && $RCompliance<70){
                                                        $statusClass = 'pending';
                                                    }elseif($RCompliance>=70){
                                                        $statusClass = 'approve';    
                                                    }

                                                ?>                   
                                                    <tr>
                                                        <td title="<?php echo $MyReport['report_type'];?>"><?php echo $j.'. '.substr($MyReport['report_type'], 0,8); if(strlen($MyReport['report_type'])>8){ echo "..."; }?></td>
                                                        <td><?php echo $AuditPeriod; ?> </td>
                                                        <td><?php echo $MyReport['provider_name']; ?> </td>
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $RCompliance; ?>%</td>
                                                    </tr>
                                                <?php $j++;
                                                    if($j>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <td colspan="3">No data found...</td>
                                                </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    </div>                                   
                                    <?php if($ReportCount>5){ ?>
                                        <div class="view-more"><a href="/reports-overview">View All</a></div>
                                    <?php } ?>                                     
                                    <!-- <div class="view-more"><a href="javascript:void(0);">View More</a></div> -->
                                </div>
                            </div>
                            <?php
                                $model = new SiteOperationalProgram(); 
                                $form = ActiveForm::begin([
                                    'id' => 'node-form',
                                    'fieldConfig' => [
                                        'options' => [
                                            'tag' => 'span',
                                        ],
                                    ],
                                    'action' =>['/site-operational-program/create'],
                                ]);
                            ?>
                            <div class="col-md-5">
                                <h2 class="title">Create Primary Alarm</h2>
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="">
                                            <label>Name</label>
                                            <!-- <input type="text" name="" class="form-control" value="RMP Systems"> -->
                                            <?php echo $form->field($model, 'name', [
                                                'template' => '{input}{error}',
                                            ]); ?>                                        
                                        </div>      
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="">
                                            <label>Site</label>
                                            <!-- <input type="text" name="" class="form-control right-date" id="startdate" value="Scheduled Dec 24"> -->
                                            <?php

                                                echo $form->field($model, 'site_id', [
                                                    'template' => '{input}{error}',
                                                ])->dropDownList(ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Site --']);
                                            ?>
                                        </div>      
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="">
                                            <label>Report Type</label>
                                            <?php 
                                                echo $form->field($model, 'report_type_id', [
                                                    'template' => '{input}{error}',
                                                ])->dropDownList(ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --']);
                                            ?>
                                        </div>      
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="">
                                            <label>Interval Type Id</label>
                                            <?php echo $form->field($model, 'report_interval_id', [
                                                'template' => '{input}{error}',
                                            ])->dropDownList(ArrayHelper::map(ReportInterval::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Type --']); ?>                                           
                                        </div>      
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="form-group">
                                            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn mln-cat' : 'btn mln-cat']) ?>
                                        </div>                                     
                                        <!-- <button class="btn mln-cat">Upload Reports</button> -->                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php ActiveForm::end(); ?>
                        <hr>

                        <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2);
                        ?>
                        <div class="row">
                            <div class="col-md-7">
                                <h2 class="title">Unknown Reports <span id="TotalReports"></span></h2>
                                <div class="report-list">                               
                                    <div class="table-responsive">
                                        <table class="table">
                                          <thead>
                                            <tr>
                                              <th>Location</th>
                                              <th>Audit Period</th>
                                              <th>Total <br/> Reports</th>
                                              <th>Action</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <?php 
                                            if(!empty($MySites)){
                                                $i=1;
                                                $statusClass = '';
                                                $totalOtherReports = 0;
                                                foreach ($MySites as $MySite) { 
                                                    $mySiteId = $MySite['id'];
                                                    $AuditPeriod = ClientSite::getDashboardCompliance($clientId,9,$mySiteId);
                                                    $Compliance = ClientSite::getDashboardCompliance($clientId,10,$mySiteId);
                                                    $totalOtherReports = $totalOtherReports + $Compliance;
                                                    if($Compliance>20){
                                                        $statusClass = 'reject';
                                                    }elseif($Compliance>5 && $Compliance<=20){
                                                        $statusClass = 'pending';
                                                    }elseif($Compliance<5){
                                                        $statusClass = 'approve';    
                                                    }
                                                    ?>
                                                    <tr>
                                                        <td><a href="client-site/print-reports?DynamicModel%5Bclient_site%5D=<?php echo $mySiteId; ?>&DynamicModel%5Breport_types%5D%5B%5D=9" title=""><?php echo $i.'. '.$MySite['name']; ?></a></td>
                                                        <td><?php echo $AuditPeriod; ?> </td>
                                                        <td class="<?php echo $statusClass; ?>"><?php echo $Compliance; ?></td>
                                                        <td class="view-unknown"><a href="client-site/print-reports?DynamicModel%5Bclient_site%5D=<?php echo $mySiteId; ?>&DynamicModel%5Breport_types%5D%5B%5D=9" title="">View Report</a></td>
                                                    </tr>
                                                <?php $i++;
                                                    if($i>5){
                                                        break;
                                                    }
                                                } 
                                            }else{?>
                                                <tr>
                                                    <td colspan="3">No data found...</td>
                                                </tr>
                                            <?php }?>
                                            <input type="hidden" id="hiddenTotal" value="<?php echo $totalOtherReports; ?>">
                                          </tbody>
                                        </table>
                                    </div>                                    
                                    <?php if($totalSites>5){ ?>
                                        <div class="view-more"><a href="/report-type-list">View All</a></div>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <h2 class="title">Sites with alarms</h2>
                                <div class="site-alaram">
                                    <ul class="list-unstyled">
                                    <?php
                                    $ArrayCount = 0;
                                    if(!empty($MySites)){
                                        $LateSites = array();
                                        foreach ($MySites as $MySite) { 
                                            $mySiteId = $MySite['id'];
                                            $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                            if(!empty($lateReports)){
                                                foreach ($lateReports as $client=>$reports) {
                                                    if(isset($reports['late'])){
                                                        foreach ($reports['late'] as $key => $report) {
                                                            $LatesiteName = $report['sop']['clientSite']['name'];
                                                            array_push($LateSites, $LatesiteName);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if(!empty($LateSites)){
                                            $FinalArray = array_unique($LateSites);
                                            $ArrayCount = count($FinalArray);
                                            $i=1;
                                            foreach ($FinalArray as $key => $site) { ?>
                                                <li><!-- <a href="#" title=""> --><img src="images/site-alaram.svg" alt=""><?php echo $i.'. '.$site; ?><!-- </a> --></li>
                                            <?php 
                                                $i++;
                                                if($i>5){
                                                    break;
                                                }
                                            }
                                        }else{?>
                                            <li>No records found</li>
                                        <?php }
                                    }
                                    ?>                                 
                                    </ul>
                                </div>
                                <?php if($ArrayCount>5){ ?>
                                    <div class="view-more"><a href="#getSitesWithLateReport" data-toggle="modal" >View All</a></div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="modal fade site-report-modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">View Reports</h4>
          </div>
          <div class="modal-body">
               <div class="portlet-body form">
                    <?php 
                        $model = DynamicModel::validateData(
                                    ['date_from',
                                     'date_to',
                                     'client_site',
                                     'node',
                                     'report_types',
                        ]);
                        $model->addRule(['client_site'], 'integer');
                        $model->addRule(['report_types'], 'required');
                        $form = ActiveForm::begin([
                        'id' => 'print-reports-form',
                        'fieldConfig' => [
                            'options' => [
                                'tag' => 'span',
                            ],
                        ],
                        'method' => 'get',
                        'action' =>['/client-site/print-reports'],
                    ]) ?>

                        <?php echo $form->field($model, 'client_site', [
                            'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
                        ])->dropDownList(ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientId])->asArray()->all(), 'id', 'name'), ['prompt' => 'Select Site']) ?>
                        

                        <div class="form-group form-md-checkboxes">
                            <div class="md-checkbox-list">
                                <div class="md-checkbox has-info">
                                    <input type="checkbox" class="md-check" id="report-types-select-all" />
                                   <label for="report-types-select-all"><span></span><span class="check"></span><span class="box"></span>Select all</label>
                                </div>
                                <?php echo $form->field($model, 'report_types')
                                         ->checkboxList(ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name'), [
                                             'item' => function($index, $label, $name, $checked, $value) {
                                                 return "<div class=\"col-sm-4\"><div class=\"md-checkbox\"><input id='{$index}' type='checkbox' {$checked} name='{$name}' value='{$value}' tabindex='3'><label for='{$index}'><span></span><span class=\"check\"></span><span class=\"box\"></span>{$label}</label></div></div>";
                                             }
                                         ]); ?>
                            </div>
                        </div>
                        <div class="form-group margin-bottom-submit">
                            
                        </div>
                    </div>
                

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <?php echo Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
          </div>         

        <?php ActiveForm::end() ?>
        </div>
      </div>
    </div>
    <div class="modal fade" id="getSitesWithLateReport" tabindex="-1" role="dialog" aria-labelledby="LateReportLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="LateReportLabel">Sites with alarms</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2);                            
                        ?>
                        <div class="col-md-12">
                            <!-- <h2 class="title">Sites with alarms</h2> -->
                            <div class="modal-sitealaram">
                                <ul class="list-unstyled">
                                <?php
                                $ArrayCount = 0;
                                if(!empty($MySites)){
                                    $LateSites = array();
                                    foreach ($MySites as $MySite) { 
                                        $mySiteId = $MySite['id'];
                                        $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                        if(!empty($lateReports)){
                                            foreach ($lateReports as $client=>$reports) {
                                                if(isset($reports['late'])){
                                                    foreach ($reports['late'] as $key => $report) {
                                                        $LatesiteName = $report['sop']['clientSite']['name'];
                                                        array_push($LateSites, $LatesiteName);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if(!empty($LateSites)){
                                        $FinalArray = array_unique($LateSites);
                                        $ArrayCount = count($FinalArray);
                                        $i=1;
                                        foreach ($FinalArray as $key => $site) { ?>
                                            <li><a href="#" title=""><img src="images/site-alaram.svg" alt=""><?php echo $i.'. '.$site; ?></a></li>
                                        <?php 
                                            $i++;
                                        }
                                    }else{?>
                                        <li>No records found</li>
                                    <?php }
                                }
                                ?>                        
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            
                </div>         

            </div>
        </div>
    </div>
<?php }else{ ?>
    <div class="container">
        <div class="page-container"><?php
            echo RedRocketSideNav::widget([
                'currentPage' => $this->params['currentPage'],
                'currentChild' => $this->params['currentChild'] ?? '',
            ]); ?>
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1><?php echo Html::encode($this->title) ?></h1>
                        </div>


                    </div>
                    <?php echo Breadcrumbs::widget([
                        'itemTemplate' => "<li>{link}<i class=\"fa fa-circle\"></i></li>\n",
                        'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                        'options' => ['class' => 'page-breadcrumb breadcrumb'],
                    ]); ?>

                <?php
                    foreach (Yii::$app->session->getAllFlashes() as $key => $message) :
                        echo '<div class="alert alert-' . $key . '">' . $message . '</div>';
                    endforeach;
                ?>

            <?php echo $content ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<div id="bottom-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12"><?php echo Html::a('rmpsystems.com', 'http://rmpsystems.com', ['class' => 'btn btn-link']) ?></div>
        </div>
    </div>
</div>

<?php $this->endBody() ?><!--[if lt IE 9]>
<script src="/js/plugins/respond.min.js"></script>
<script src="/js/plugins/excanvas.min.js"></script>
<![endif]-->

</body>
</html>
<?php $this->endPage() ?>
