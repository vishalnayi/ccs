<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use \frontend\widgets\RedRocketAdminNav;
use \frontend\widgets\RedRocketSideNav;
use common\models\User;
use common\models\ClientSite;
use common\models\SiteOperationalProgram;
use  yii\web\Session;
use common\models\UserClientAccess;
$session = Yii::$app->session;

AppAsset::register($this);
$allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
$client = array_column($allowedClients, 'client_id');
if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
    $clientId = $client;
}else{
    $clientId = Yii::$app->user->identity->client_id;
}
$userRole = Yii::$app->user->identity->role;


if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
    $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
    $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}else{
    $CrDate = date('d-m-Y');
    $dateNew = strtotime($CrDate.' -1 year');
    $pastDate = date('d-m-Y', $dateNew);

    /*$session['fromDate'] = $pastDate;*/
    /*$session['toDate'] = $CrDate;*/
    $session->set('fromDate', $pastDate);
    $session->set('toDate', $CrDate);

    $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
}

$this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language ?>">
<head>
    <meta charset="<?php echo Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?php echo Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php
//    $this->registerCssFile('/css/layout.min.css');
//    $this->registerCssFile('/css/default.min.css');
    ?>
    <link href="/css/layout.min.css" rel="stylesheet">
    <link href="/css/default.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.min.css" rel="stylesheet">
    <link href="/css/rmp-custom.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/responsive.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="page-container-bg-solid page-sidebar-closed-hide-logo page-md page-boxed">
<?php $this->beginBody();
    echo RedRocketAdminNav::widget();
?>


    <link href="/assets/4234c4f1/themes/smoothness/jquery-ui.css" rel="stylesheet">
    <?php
        $FromDate = $_SESSION['fromDate'];
        $toDate = $_SESSION['toDate'];

    ?>
    
    <section class="manage-site">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="back-button">            
                    <a class="btn bluebtn" href="javascript:history.go(-1)">Back</a>
                </div>
                <h2 class="title">Overview of Sites</h2>
                <div class="overview-site">
                    <div class="scroll-bar">
                        <?php 
                            $MySites =  ClientSite::getClientSites($clientId,2);
                        ?>
                        <?php 
                        if(!empty($MySites)){
                            $LateSites = array();
                            foreach ($MySites as $MySite) { 
                                $mySiteId = $MySite['id'];
                                $lateReports = SiteOperationalProgram::findLateReportsDashboard($mySiteId);
                                if(!empty($lateReports)){                  
                                    foreach ($lateReports as $client=>$reports) {
                                        if(isset($reports['late'])){
                                            foreach ($reports['late'] as $key => $report) {
                                                $LatesiteID = $report['sop']['site_id'];
                                                array_push($LateSites, $LatesiteID);
                                            }
                                        }
                                    }
                                }
                            }
                            $i=1;
                            $statusClass = '';
                            foreach ($MySites as $MySite) { 
                                $mySiteId = $MySite['id'];
                                //$Compliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,2,$mySiteId);
                                $Compliance = ClientSite::getSitesComplianceStaticsDashboard($FromDate,$toDate,$mySiteId,5);
                                $MySiteReports =  ClientSite::getClientSitesReports($mySiteId);
                            ?>
                                <div class="site-listing">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-4">
                                            <div class="site-info">
                                                <h3><?php echo $MySite['name']; ?><?php          
                                                            if(!empty($LateSites) && in_array($mySiteId, $LateSites)){  ?>
                                                                <img src="images/site-alaram.svg" alt="" style="width:10%;">
                                                        <?php  } ?></h3>
                                                <p><?php echo $MySite['site_address']; ?></p>

                                                <h4>Site Contact</h4>
                                                <p><?php echo $MySite['manager_name']; ?></p>
                                                <p><strong><small>Tower Manager</small></strong></p>
                                                <p><a href="tel:<?php echo $MySite['contact_number']; ?>"><?php echo $MySite['contact_number']; ?></a></p>
                                                <p><a href="mailto:<?php echo $MySite['email_address']; ?>"><?php echo $MySite['email_address']; ?></a></p>
                                                <h4>Addtional Comment</h4>
                                                <p><?php echo $MySite['comment']; ?></p>
                                            </div>
                                            <div class="site-progress">
                                                <div class="prograss"><span style="display:none;"><?php echo $Compliance; ?>%</span></div>
                                                <h3>Overall Compliance Rate</h3>
                                            </div>
                                        </div>

                                            
                                        <div class="col-xs-12 col-md-8">
                                            <div class="report-list">                               
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th class="left-th">Report Type</th>
                                                                <th>No of. <br/> Reports</th>
                                                                <th>Frequency</th>
                                                                <th>Last Report <br/> Received</th>
                                                                <th>Next Report </th>
                                                                <th>Supplier</th>
                                                                <th>Overall <br/> Compliance</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php 
                                                            if(!empty($MySiteReports)){
                                                                $j=1;
                                                                $statusClass = '';
                                                                foreach ($MySiteReports as $MyReport) { 
                                                                    $AuditPeriod = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,7,$mySiteId,$MyReport['doctype_id']);
                                                                    $auditDate =  explode('-', $AuditPeriod);
                                                                    $firstReceived =!empty($auditDate[0])?$auditDate[0]:"-";
                                                                    $lastReceived =!empty($auditDate[1])?$auditDate[1]:"-";
                                                                    if($lastReceived != "-"){
                                                                         $loadFileHrefReport = ClientSite::gatherSiteReportInfoForLoadFile($mySiteId,$FromDate,$toDate,$lastReceived,$MyReport['doctype_id']);   
                                                                    }
                                                                    $totalReports = ClientSite::getReportCountForMyReports($mySiteId,$FromDate,$toDate,$MyReport['doctype_id']);
                                                                    $nextReportDate = ClientSite::getNextReportDateMyReports($mySiteId,$FromDate,$toDate,$MyReport['doctype_id']);
                                                                    $frequency = ClientSite::getFrequencyForReport($mySiteId,$FromDate,$toDate,$MyReport['doctype_id']);
                                                                    $RCompliance = ClientSite::getDashboardCompliance($FromDate,$toDate,$clientId,8,$mySiteId,$MyReport['doctype_id']);
                                                                    if($RCompliance<90){
                                                                        $statusClass = 'reject';
                                                                    }elseif($RCompliance>=90 && $RCompliance<=99){
                                                                        $statusClass = 'pending';
                                                                    }elseif($RCompliance==100){
                                                                        $statusClass = 'approve';    
                                                                    }
                                                                    ?>
                                                                    <tr>
                                                                        <td class="left-th"><?php echo $MyReport['report_type']; ?></td>
                                                                        <td><?php echo $totalReports; ?></td>
                                                                        <td><?php echo $frequency;?></td>
                                                                        <?php if(isset($loadFileHrefReport) && $loadFileHrefReport!=''){ ?>
                                                                                <td class="view-unknown"><a href="<?php echo $loadFileHrefReport; ?>" title="see report" target = "_blank"> <?php echo $lastReceived; ?> </a></td>
                                                                            <?php }else{ ?> 
                                                                                 <td><?php echo $lastReceived; ?></td>
                                                                            <?php } ?>
                                                                        <td><?php echo $nextReportDate; ?></td>
                                                                        <td><?php echo $MyReport['provider_name']; ?></td>
                                                                        <td class="<?php echo $statusClass; ?>"><?php echo $RCompliance; ?>%</td>
                                                                    </tr>
                                                                <?php } 
                                                            } ?>                                                
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <a href="site-detailview?sid=<?php echo $mySiteId; ?>" class="btn bluebtn">View this Site</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                        }?>
                    </div>
                </div>
            </div>          
        </div>
        <div class="row" style="display: none;">
            <div class="col-md-12">             
                <div class="site-bottom">
                    <h2 class="title">Contact details of suppliers</h2>
                    <ul>
                        <li>RMP Systems</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                        <li>Supplier Name Here</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                        <li>Another Supplier Name</li>
                        <li><a href="#" class="btn bluebtn">Read Details</a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<div id="bottom-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12"><?php echo Html::a('rmpsystems.com', 'http://rmpsystems.com', ['class' => 'btn btn-link']) ?></div>
        </div>
    </div>
</div>

<?php $this->endBody() ?><!--[if lt IE 9]>
<script src="/js/plugins/respond.min.js"></script>
<script src="/js/plugins/excanvas.min.js"></script>
<![endif]-->

</body>
</html>
<?php $this->endPage() ?>
