<?php
// TODO: BenPitt Notes
// THIS IS NOT REQUIRED ANYMORE
// Please check out frontend/widgets/views/sideNav.php

use kartik\sidenav\SideNav;
use common\models\User;

$items = [];

$items[] = [ 'url' => '/', 'label' => 'Home'];
    if($user->role == User::ROLE_SUPER) {
$items[] = ['label' => 'Client', 'url' => ['/client']];
$items[] = ['label' => 'Switch User', 'url' => ['/user/switch-user']];
$items[] = ['label' => 'Sync Owncloud', 'url' => ['/site-operational-program/sync-owncloud']];
$items[] = ['label' => 'Find New Sites', 'url' => ['/client-site/find-new-sites']];
$items[] = ['label' => 'Show Orphan Sites', 'url' => ['/client-site/show-orphan-sites']];
$items[] = ['label' => '--------'];
    } elseif($user->role == User::ROLE_ADMIN) {
        $items[] = ['label' => 'Client', 'url' => ['/client/view/?id='. $user->client_id]];
    }

if($user->role >= User::ROLE_ADMIN) {
    $items[] = ['label' => 'User', 'url' => ['/user']];
} elseif($user->role == User::ROLE_USER) {
    $items[] = ['label' => 'User', 'url' => ['/user/view/?id='. $user->id]];
}

$items[] = ['label' => 'Node', 'url' => ['/node']];
$items[] = ['label' => 'Node Tree', 'url' => ['/node/node-tree']];
$items[] = ['label' => 'Site', 'url' => ['/client-site']];
$items[] = ['label' => 'Site Operational Program', 'url' => ['/site-operational-program']];
$items[] = ['label' => 'Print Reports', 'url' => ['/client-site/print-reports']];

echo SideNav::widget([
    'type' => SideNav::TYPE_DEFAULT,
    'heading' => 'Menu',
    'items' => $items,
]);
