<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\ClientSite */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Client Site email credentials',
]) . ' ' . $model->name;
$this->params['currentPage'] = 'Sites';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Client Sites'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form-email', [
    'model' => $model,
    'client' => $client,
    'userRole' => $userRole,
]);

echo $this->render('@app/views/partials/_portlet-end');
