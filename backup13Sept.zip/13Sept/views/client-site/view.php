<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\User;
use common\components\CheckPermissionHelper;

/* @var $this yii\web\View */
/* @var $model common\models\ClientSite */

$this->title = $model->name;
$this->params['currentPage'] = 'Sites';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Client Sites'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

$update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','update',Yii::$app->user->identity->role);
$delete = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','delete',Yii::$app->user->identity->role);
?>
<div class="portlet-body form">
    <?php echo DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'label' => 'Node',
                'value' => $model->node ? $model->node->name : '',
            ],
            'name',
            [
                'label' => 'Client Name',
                'value' => isset($model->client) ? $model->client->name : null,
            ],
            'site_address',
            'manager_name',
            'contact_number',
            'directory',
            'comment',
            'created_at',
            'updated_at',
        ],
    ]) ?>
    <div class="form-actions">
        <div class="col-xs-12">
            <?php if($update){ echo Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']); } ?>
            <?php if($delete){ echo  Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger',
                'data' => [
                    'confirm' => Yii::t('app', 'If you delete this site, you\'ll need to contact site administrators to add it back.'),
                    'method' => 'post',
                ],
            ]); } ?>
            <?php if(Yii::$app->user->identity->role == User::ROLE_SUPER){ 
                echo Html::a('Back', ['client-site/index'], ['class' => 'btn btn-info']);
            }?>
        </div>
    </div>
</div>
<?php echo $this->render('@app/views/partials/_portlet-end');
