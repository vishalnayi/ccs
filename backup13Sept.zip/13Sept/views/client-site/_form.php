<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use common\models\Node;
use common\models\Client;
use common\models\User;
use common\models\Provider;
use common\models\ReportCategory;
use wbraganca\multiselect\MultiSelectWidget;

/* @var $this yii\web\View */
/* @var $model common\models\ClientSite */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'client-site-form',
    'enableClientValidation' => false,
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'site_address', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($model, 'manager_name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($model, 'contact_number', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput();

echo $form->field($model, 'directory', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true, 'readonly'=>!$setDirectoryAccess]);

if($userRole > User::ROLE_USER) :

echo $form->field($model, 'node_id', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(Node::find()->where(['client_id' => $client->id])->asArray()->all(), 'id', 'name'), ['prompt' => '-- No parent --']);

endif;

echo $form->field($model, 'comment', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}</div>',
])->textArea();

if($userRole === User::ROLE_SUPER) :

echo $form->field($model, 'client_id', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(Client::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- No parent --']);

?>
    <span class="caption-subject bold">Email settings</span>
<?php

echo $form->field($model, 'email_address', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'email_username', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'email_password', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

?><div style="margin-bottom: 30px;"><?php

echo $form->field($model, 'download_documents', [
    'template' => '<span class="form-group form-md-line-input form-md-floating-label" style="width:400px;">{input}{label}{error}</span>',
])->checkBox();
?>
    <span class="form-group" style="width: 300px;">
            <button id="test-email-credentials" style="margin-left: 100px;">Test</button>
            <img src="/images/loader/blank.gif" id="test-result" style="padding-left: 20px;" />
    </span>
</div>

<?php endif; ?>

    <div class="form-group">

    <div class="form-group">
        <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>

<script>
    window.onload = function() {
        jQuery('#test-email-credentials').click(function(event) {
            var username = $('#clientsite-email_username').val();
            var password = $('#clientsite-email_password').val();
            uri = encodeURI('&username='+ username +'&password='+ password);
            $.ajax({
                url: '//'+ window.location.hostname +'/client-site/test-email-credentials?'+ uri,
                beforeSend: updateImage('ajax-loader.gif'),
            }).done(function(data) {
               if(data.success == true) {
                  imgSrc = 'success.gif';
               } else {
                  imgSrc = 'failed.gif';
               }

               updateImage(imgSrc);
            });

            event.preventDefault();
        });
    };

    function updateImage(imgSrc) {
        var path = '/images/loader/';
        $('#test-result').attr('src', path + imgSrc);
    }
</script>
