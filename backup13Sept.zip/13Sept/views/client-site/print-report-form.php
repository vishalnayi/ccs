<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use common\components\CheckPermissionHelper;
use kartik\select2\Select2; 
use common\models\User;
use yii\helpers\ArrayHelper;
use common\models\Client;
use yii\helpers\Url;
use common\models\UserClientAccess;
$this->title = Yii::t('app', 'Print Reports');
$this->params['currentPage'] = 'Print Reports';
$this->params['breadcrumbs'][] = $this->title;

$this->registerJs("jQuery('#report-types-select-all').change(function(){jQuery('.book').prop('checked',this.checked?'checked':'');})");

echo $this->render('@app/views/partials/_portlet-start'); ?>
<div class="portlet-body form">
<?php $form = ActiveForm::begin([
    'id' => 'print-reports-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ],
    'method' => 'get',
]) ?>
<?php if(Yii::$app->user->identity->role == User::ROLE_SUPER || Yii::$app->user->identity->role == User::ROLE_AUDITOR):
if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
            $client = array_column($allowedClients, 'client_id'); 
            $clientsData = ArrayHelper::map(Client::find()->where(['in','id',$client])->orderBy([
                  'name' => SORT_ASC      
                ])->asArray()->all(), 'id', 'name');
        }else{
            $clientsData = ArrayHelper::map(Client::find()->orderBy([
                'name' => SORT_ASC      
            ])->asArray()->all(), 'id', 'name');
        }

$rt = [];
$str = "";
echo $form->field($model, 'client_id', [
                    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
                ])->label('Client')->widget(Select2::classname(), [
                'data' => $clientsData,
                //'theme'=>'material',                 
                'options' => [ 
                    'placeholder' => 'Select Client',
                    'onchange'=>'
                        $.get( "'.Url::toRoute('/client-site/lists-html').'", { id: $(this).val(),fromDate : "'.$_SESSION['fromDate'].'",toDate : "'.$_SESSION['toDate'].'" } )
                            .done(function( data ) { 
                                data = JSON.parse(data)
                                console.log(data);
                                $.each( data, function( key, value ) {
                                    if(key == "0"){
                                        $("#clientSiteListId").html(value);
                                    }else if(key == "1"){
                                         $("#clientNodeListId").html(value);
                                    }else if(key == "2"){
                                       $("#reportTypeChecklist").replaceWith(value);
                                     
                                    }
                                });
                            }
                        );'
                ],
                'pluginOptions' => [
                    'allowClear' => false
                ],   
            ])->label(false);
endif;
 ?>
    <?php echo $form->field($model, 'node', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
    ])->dropDownList($nodes, ['prompt' => 'Select Node','id'=>'clientNodeListId']) ?>

    <h3 class="text-center">OR</h3>

    <?php echo $form->field($model, 'client_site', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
    ])->dropDownList($clientSites, ['prompt' => 'Select Site','id'=>'clientSiteListId']) ?>
    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'date_from')->widget(\yii\jui\DatePicker::className(), [
                                                'dateFormat' => 'yyyy-MM-dd',
            ]) ?>
        </div>
        <div class="col-sm-6">
            <?= $form->field($model, 'date_to')->widget(\yii\jui\DatePicker::className(), [
                                                'dateFormat' => 'yyyy-MM-dd',
            ]) ?>
        </div>
    </div>

    <div class="form-group form-md-checkboxes" id="reportTypeChecklist">
        <div class="md-checkbox-list">
            <div class="md-checkbox has-info">
                <input type="checkbox" class="md-check" id="report-types-select-all" />
               <label for="report-types-select-all"><span></span><span class="check"></span><span class="box"></span>Select all</label>
            </div>
            <?php
            // echo "<pre>";
            // print_r($reportTypes);
            // die;
             echo $form->field($model, 'report_types')
                     ->inline(false)
                     ->checkboxList($reportTypes, [
                         'item' => function($index, $label, $name, $checked, $value) {
                             return "<div class=\"col-sm-4\"><div class=\"md-checkbox\"><input id='{$index}' class='book' type='checkbox' {$checked} name='{$name}' value='{$value}' tabindex='3'><label for='{$index}'><span></span><span class=\"check\"></span><span class=\"box\"></span>{$label}</label></div></div>";
                         }
                     ]); ?>
        </div>
    </div>
    <div class="form-group margin-bottom-submit">
        <?php echo Html::submitButton('Submit', ['class' => 'btn btn-primary','id'=>"print_form_submit"]); 
        echo Html::a('Download All', [''], ['class' => 'btn btn-primary print_all','style'=>'margin-left:10px;']);
        echo Html::hiddenInput('print_all','');
        ?>
    </div>

<?php ActiveForm::end() ?>
</div>
<?php echo $this->render('@app/views/partials/_portlet-end'); ?>
<?php $view = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Print Reports','view',Yii::$app->user->identity->role); ?>
<?php if($siteListReports) {
    if($view == '1'){
            echo $this->render('/site-operational-program/reports', ['siteListReports' => $siteListReports]);
    }else{
        throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
    }
} 


$this->registerJs('$(document).ready(function () {
    
    $(".print_all").on("click", function() {

        $("input[name=print_all]").val("1");        
        $( "#print-reports-form" ).submit();
       
    });

    $("#print_form_submit").on("click", function() {

        $("input[name=print_all]").val("");        
      
       
    });
});');

?>