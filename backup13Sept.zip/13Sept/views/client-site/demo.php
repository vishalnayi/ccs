<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php

use yii\helpers\Html;
use common\models\User;
use common\models\ClientSite;
use common\models\UserSiteAccess;

use common\models\UserClientAccess;


//getNextReportDateMyReports

$this->title = 'Upcoming Schedule';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Calendar'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title; 


$allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
$client = array_column($allowedClients, 'client_id');
if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
    $clientId = $client;
}else{
    $clientId = Yii::$app->user->identity->client_id;
}
//$clientId = 12;
$MySites =  ClientSite::getSitesWithPrimaryAlramSet($clientId);  

    function random_color_part() {
      return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
  }

  function random_color() {
    return random_color_part() . random_color_part() . random_color_part();
  }

//echo random_color();
$site_color = array(); 
$sitesListing = array_unique(array_column($MySites, 'site_id')); ?>

<div class="row">
  <div class="col-md-12">
    <div class="portlet light">
    <div class="portlet-title">
      <div class="caption font-dark">
        <span class="caption-subject bold uppercase"> <?php echo Html::encode('Sites color code') ?></span>
      </div>
    </div>
 <div class="table-responsive">
    <table class="table cms-table">
      <thead>
        <tr>
          <th>Color</th>
          <th>Site</th>
          <th>Frequency</th>
        </tr>
      </thead>
      <tbody>
   
              <?php foreach ($MySites as $key => $site) { 
                  if(!isset( $site_color[$site['site_id']] )){
                    $color = '#'.random_color();        
                    $site_color[$site['site_id']] = $color;
       
              ?>
                <tr>
                  <td><span style="height: 25px;width: 25px;background-color:<?php echo $color;?>;border-radius: 25%;display: inline-block;"></span></td>
                  <td><?php echo $site['site_name']; ?></td>
                  <td><?php echo $site['frequency']; ?></td>
                </tr>

                  <?php  } } ?>
      </tbody>
    </table>      
  </div>
 <?php   echo $this->render('@app/views/partials/_portlet-end');?>               

<?php 
$events = array();
foreach ($MySites as $key => $site) {
  $nextReportDate = ClientSite::getNextReportDateMyReports($site['site_id'],$_SESSION['fromDate'],$_SESSION['toDate'],$site['doctype_id']);
  $date_now = date("Y-m-d"); // this format is string comparable
  $date_replace = str_replace('/', '-', $nextReportDate);
  $next_date = date('Y-m-d',strtotime($date_replace));

  if ($next_date > $date_now) {
    $Event = new \yii2fullcalendar\models\Event();
    $Event->id = $key;
    $Event->title = $site['report_type'];
    $Event->start = $next_date;
    $Event->color = $site_color[$site['site_id']] ;
    $events[] = $Event;
  }  
}

  ?>
  
  <?= \yii2fullcalendar\yii2fullcalendar::widget(array(
      'events'=> $events,
  ));
  ?>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
    $('.fullcalendar ').fullCalendar({
    //defaultView: 'agendaWeek',
    firstDay :moment().weekday(),
    viewRender: function(currentView){
        var minDate = moment();
        // Past
        if (minDate >= currentView.start && minDate <= currentView.end) {
            $(".fc-prev-button").prop('disabled', true); 
            $(".fc-prev-button").addClass('fc-state-disabled'); 
        }
        else {
            $(".fc-prev-button").removeClass('fc-state-disabled'); 
            $(".fc-prev-button").prop('disabled', false); 
        }

    }
});
});
</script>