<?php

use yii\helpers\Html;
use fedemotta\datatables\DataTables;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use common\models\User;
use common\models\UserClientAccess;
use common\models\Client;
use common\models\ImportForm;
use common\models\ClientListForm;
use common\components\CheckPermissionHelper;
use kartik\select2\Select2;
/* @var $this yii\web\View */
/* @var $searchModel common\models\ClientSiteSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Client Sites');
$this->params['currentPage'] = 'Sites';
$this->params['currentChild'] = 'Modify Sites';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="caption font-dark">
                            <i class="icon-users font-dark"></i>
                            <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                        </div>
                    </div>
                    <?php if ($userRole == User::ROLE_SUPER) : ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="text-right">
                            <a href="/import_sites_sample_data.csv">Download Sample file</a> 
                        </div>
                    </div>
                    <?php endif ?>
                </div>
            </div>
            <div class="portlet-body">

                <?php if ($userRole == User::ROLE_SUPER) : ?>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <p><?php echo Html::a(Yii::t('app', 'Create Client Site'), ['create'], ['class' => 'btn btn-success']) ?></p>        
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                             <div class="Import-client text-right">
                                <?php 
                                    $modelF = New ImportForm;
                                    $form = ActiveForm::begin([
                                        'id' => 'import-client-sites-form',
                                        'fieldConfig' => [
                                            'options' => [
                                                'enctype' => 'multipart/form-data',
                                            ],
                                        ],
                                        'action' =>['/client-site/import'],
                                    ]);

                                    //$form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]);

                                    echo $form->field($modelF, 'file')->fileInput(); ?>

                                    <button class="btn btn-success">Submit</button>
                                <?php 
                                    ActiveForm::end();
                                ?>
                            </div>   
                        </div>
                    </div>
                <?php endif;
                if ($userRole == User::ROLE_SUPER || $userRole == User::ROLE_AUDITOR) :
                    if($userRole == User::ROLE_AUDITOR){
                            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
                            $client = array_column($allowedClients, 'client_id'); 
                            $clientsData = ArrayHelper::map(Client::find()->where(['in','id',$client])->orderBy(['name'=>'SORT_ASC'])->asArray()->all(), 'id', 'name');
                        }
                        else{
                            $clientsData = ArrayHelper::map(Client::find()->orderBy(['name'=>'SORT_ASC'])->asArray()->all(), 'id', 'name');} 
                ?>
                    <div class="row">  
                    <?php 
                        $modelClient = New ClientListForm;
                        $form = ActiveForm::begin([
                            'id' => 'client-list-form',                                     
                            'action' =>['/client-site/index'],
                        ]); ?>                     
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                            <div class="Import-client text-left">
                                <?php 
                                    echo $form->field($modelClient, 'client_list_id')->widget(Select2::classname(), [
                                        'data' => $clientsData,
                                        'options' => [
                                            'placeholder'=>'Search sites by client'],
                                            'pluginOptions' => [
                                                'allowClear' => false
                                            ],   
                                    ])->label(false); ?>
                            </div>   
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="Import-client text-right">
                                <button class="btn btn-success">Search</button>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="Import-client text-left">
                             <?= Html::a(Yii::t('app', 'Clear'), ['client-site/index'], ['class' => 'btn btn-success']) ?>
                            </div>
                        </div>
                        <?php 
                            ActiveForm::end();
                        ?>
                           
                    </div>
                <?php endif ?>
                <?php  
                      $create = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','create',Yii::$app->user->identity->role);
                      $update = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','update',Yii::$app->user->identity->role);
                      $view = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','view',Yii::$app->user->identity->role);
                      $delete = CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','delete',Yii::$app->user->identity->role);
                       
                      if($view == 0 && $update == 0 &&  $delete== 0 ){
                        $visibleActionCol = 0;
                      }else{
                         $visibleActionCol = 1;
                      }

                      if(Yii::$app->user->identity->role == User::ROLE_SUPER){
                        $visibleCheckboxCol = 1;
                      }else{
                        $visibleCheckboxCol = 0;
                      }
                ?>
                <?php echo DataTables::widget([
                    'dataProvider' => $dataProvider,
                    'filterModel' => $searchModel,
                    'columns' => [
                        'id',
                        [
                            'label' => 'Node',
                            'value' => function($data) {
                                return $data->node ? $data->node->name : '';
                            },
                        ],
                        [
                            'label' => 'Client Name',
                            'value' => function($data) {
                                return $data->client->name ?? '';
                            },
                        ],
                        [
                            'label' => 'Site Name',
                            'value' => function($data) {
                                return $data->name ?? '';
                            },
                        ],
                        
                        'directory',
                        // 'created_at',
                        // 'updated_at',

                        [
                            'class' => 'yii\grid\ActionColumn',
        // removed delete function as a quick fix as delete functions aren't working OK
        //                    'template' => '{view} {update} {update-category-provider} {delete}',
                            'visible' => $visibleActionCol,
                            'template' => '{view} {update} {update-category-provider} {delete}',
                            'headerOptions' => ['class' => 'actions'],
                            'buttons' => [
                                //view button
                                'view' => function ($url, $model, $key) {
                                    $view =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','view',Yii::$app->user->identity->role);                                   
                                    $visible = $view != 1 ? ' visible-false': '';

                                    return Html::a('<i class="icon-magnifier"></i>', $url, [
                                        'title' => Yii::t('yii', 'View'),
                                        'aria-label' => Yii::t('yii', 'View'),
                                        'data-pjax' => '0',
                                        'class'=>'btn btn-icon-only btn-circle grey-salsa'.$visible,
                                    ]);
                                },
                                'update' => function ($url, $model, $key) {
                                    $update =  CheckPermissionHelper::getUserPermissionAccess(Yii::$app->user->identity->id,'Client Sites','update',Yii::$app->user->identity->role);
                                    $visible = $update != 1 ? ' visible-false': '';

                                    return Html::a('<i class="icon-pencil"></i>', $url, [
                                        'title' => Yii::t('yii', 'Update'),
                                        'aria-label' => Yii::t('yii', 'Update'),
                                        'data-pjax' => '0',
                                        'class'=>'btn green btn-icon-only btn-circle filter-submit'.$visible,
                                    ]);
                                },
                                'update-category-provider' => function ($url, $model, $key) {
                                    $url = Url::toRoute(['client-site-report-category/index', 'clientSiteId' => $key]);
                                    if (!Yii::$app->user->identity->isSuper()) {
                                        return;
                                    }
                                    return Html::a('<i class="fa-file"></i>', $url, [
                                        'title' => Yii::t('yii', 'Update category provider'),
                                        'aria-label' => Yii::t('yii', 'Update Category Provider'),
                                        'data-pjax' => '0',
                                        'class'=>'btn green btn-icon-only btn-circle filter-submit',
                                        'visible' => false,
                                    ]);
                                },
                                'delete' => function ($url, $model, $key) {
                                    $visible = Yii::$app->user->identity->role != User::ROLE_SUPER ? 'visible-false': '';
                                    
                                    return Html::a('<i class="icon-trash"></i>', $url, [
                                        'title' => Yii::t('yii', 'Delete'),
                                        'aria-label' => Yii::t('yii', 'Delete'),
                                        'data-confirm' => Yii::t('yii', 'If you delete this site, you\'ll need to restore from archive site to add it back.'),
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                        'class'=>'btn red btn-icon-only btn-circle filter-cancel '.$visible,
                                    ]);

                                }
                            ],
                        ],
                    ],
                    'clientOptions' => [
                        "lengthMenu"=> [[10, 25, 50, -1], [10, 25, 50, Yii::t('app',"All")]],
                        "info"=>true,
                        "paging" => true,
                        "searching" => true,
                        "responsive"=>true,
                        "dom"=> 'lfTrtip',
                        "tableTools"=>[
                            "aButtons"=> []
                        ],
                    ],
                    'tableOptions' => [
                        "class"=> 'table table-striped table-bordered table-hover table-checkable order-column dataTable'
                    ],
                ]); ?>
            </div>
        </div>
    </div>
</div>
