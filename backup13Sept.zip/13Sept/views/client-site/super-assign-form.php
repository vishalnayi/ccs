<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\Node;
use common\models\Client;

/* @var $this yii\web\View */
/* @var $model common\models\ClientSite */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'client-site-update-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ]
]);

echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'directory', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true, 'readonly'=>'readonly']);

echo $form->field($model, 'client_id', [
    'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',])->dropDownList(ArrayHelper::map(Client::find()->all(), 'id', 'name'), ['prompt' => '-- Select Client --']); ?>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
