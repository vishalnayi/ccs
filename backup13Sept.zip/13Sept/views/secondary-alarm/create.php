<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\SiteReport */

$this->title = Yii::t('app', 'Create Secondary Alarm');
$this->params['currentPage'] = 'Sites';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Secondary Alarm'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
    'client' => $client,
]);

echo $this->render('@app/views/partials/_portlet-end');
