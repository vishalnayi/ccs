<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use yii\helpers\Url;
use kartik\sortable\Sortable;
/* @var $this yii\web\View */
/* @var $model common\models\Provider */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Providers'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title; 
?>
<div class="provider-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',            
            'name',
            'job_title',
            'street',
            'suburb',
            'state','postcode','phone','mobile',
            'email',
            'website',
            'comment',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>




<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
        <div class="portlet-title">
            <div class="caption font-dark">
                <span class="caption-subject bold uppercase"> <?php echo Html::encode('Clients') ?></span>
            </div>
        </div>

<div class="table-responsive">
        <table class="table cms-table">
            <thead>
                <tr>
                  <th>Client Name</th>
                  <th>Dashboard</th>
                  <th>PDF</th>                 
                </tr>
            </thead>
            <tbody>
   
            <?php   
            if(!empty($clients)){



                foreach ($clients as $client) : 
                  
                ?>
                     <tr>
                        <td><?php echo $client['client']['name']; ?></td>
                     
                        
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="chk_contact" value="client_dashboard" class="checkbox" client_id ="<?php echo $client['client_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrence');?>" <?php if($client['display_dashboard'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <input type="hidden" name="contact_id" id="contact_id" value="<?php echo $contactId;?>">
                            </td>
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="chk_contact" value="client_pdf" class="checkbox" client_id ="<?php echo $client['client_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrence');?>" <?php if($client['display_pdf'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </td>                            
                        
                                
                    </tr>
            <?php endforeach;
            }else{ ?>
                <tr>
                    <td colspan="3">No data found.</td>
                </tr>
           <?php } 

            ?>

            </tbody>
        </table>
    </div>
 <?php   echo $this->render('@app/views/partials/_portlet-end');?>

 <div class="row">
    <div class="col-md-12">
        <div class="portlet light">
        <div class="portlet-title">
            <div class="caption font-dark">
                <span class="caption-subject bold uppercase"> <?php echo Html::encode('Sites') ?></span>
            </div>
        </div>

<div class="table-responsive">
        <table class="table cms-table">
            <thead>
                <tr>
                  <th>Site Name</th>
                  <th>Dashboard</th>
                  <th>PDF</th>                 
                </tr>
            </thead>
            <tbody>
   
            <?php  
            if(!empty($sites)){       
                foreach ($sites as $site) : 
                  
                ?>
                     <tr>
                        <td><?php echo $site['site']['name']; ?></td>
                     
                        
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="site_chkcontact" value="site_dashboard" class="checkbox" site_id ="<?php echo $site['site_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrencesite');?>" <?php if($site['display_dashboard'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <input type="hidden" name="contact_id" id="contact_id" value="<?php echo $contactId;?>">
                            </td>
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="site_chkcontact" value="site_pdf" class="checkbox" site_id ="<?php echo $site['site_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrencesite');?>" <?php if($site['display_pdf'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </td>                            
                        
                                
                    </tr>
            <?php endforeach;
            }else{ ?>
                <tr>
                    <td colspan="3">No data found.</td>
                </tr>
           <?php } ?>

            </tbody>
        </table>
      
    </div>
 <?php   echo $this->render('@app/views/partials/_portlet-end');?>
 <div class="row">
    <div class="col-md-12">
        <div class="portlet light">
        <div class="portlet-title">
            <div class="caption font-dark">
                <span class="caption-subject bold uppercase"> <?php echo Html::encode('Suppliers') ?></span>
            </div>
        </div>
 <div class="table-responsive">
        <table class="table cms-table">
            <thead>
                <tr>
                  <th>Supplier Name</th>
                  <th>Dashboard</th>
                  <th>PDF</th>                 
                </tr>
            </thead>
            <tbody>
   
            <?php  
            if(!empty($suppliers)){       
                foreach ($suppliers as $supplier) : 
                  
                ?>
                     <tr>
                        <td><?php echo $supplier['supplier']['name']; ?></td>
                     
                        
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="supplier_chkcontact" value="supplier_dashboard" class="checkbox" supplier_id ="<?php echo $supplier['supplier_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrencesupplier');?>" <?php if($supplier['display_dashboard'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <input type="hidden" name="contact_id" id="contact_id" value="<?php echo $contactId;?>">
                            </td>
                            <td>
                                <div class="">
                                    <label class="checkboxe">
                                        <input type="checkbox" name="supplier_chkcontact" value="supplier_pdf" class="checkbox" supplier_id ="<?php echo $supplier['supplier_id'];?>" url="<?php echo Url::toRoute('/contact/setprefrencesupplier');?>" <?php if($supplier['display_pdf'] == 1){ ?>checked=true<?php } ?>>        
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </td>                            
                        
                                
                    </tr>
            <?php endforeach;
            }else{ ?>
                <tr>
                    <td colspan="3">No data found.</td>
                </tr>
           <?php } ?>

            </tbody>
        </table>
      
    </div>
 <?php   echo $this->render('@app/views/partials/_portlet-end');?>
    <script type="text/javascript">
        var sList = "";
        $('input[type=checkbox]').each(function () {
            var sThisVal = (this.checked ? "1" : "0");
            //var sThisVal = (this.val());
            sList += (sList=="" ? sThisVal : "," + sThisVal);
        });
        console.log (sList);

$(document).on('change', 'input[name=site_chkcontact]', function() {
    var sList = "";       
            if(this.checked) {
                // alert($(this).attr('site_id'));
                // alert($(this).attr('url'));
                // alert($(this).attr('value'));
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'site_id':$(this).attr('site_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'1'},
                }).done(function() {
                  //alert('success');
                });
                    // checkbox is checked
            }else{
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'site_id':$(this).attr('site_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'0'},
                }).done(function() {
                  //alert('no dashboard');
                });
            }
});
        $(document).on('change', 'input[name=chk_contact]', function() {
            var sList = "";       
            if(this.checked) {
                // alert($(this).attr('client_id'));
                // alert($(this).attr('url'));
                // alert($(this).attr('value'));
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'client_id':$(this).attr('client_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'1'},
                }).done(function() {
                  //alert('success');
                });
                    // checkbox is checked
            }else{
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'client_id':$(this).attr('client_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'0'},
                }).done(function() {
                  //alert('no dashboard');
                });
            }
        });

        $(document).on('change', 'input[name=supplier_chkcontact]', function() {
    var sList = "";       
            if(this.checked) {
            
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'supplier_id':$(this).attr('supplier_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'1'},
                }).done(function() {
                  //alert('success');
                });
                    // checkbox is checked
            }else{
                $.ajax({
                  url: $(this).attr('url'),
                  type: "POST",
                  data: {'supplier_id':$(this).attr('supplier_id'),'contact_id':$('#contact_id').val(),'type':$(this).attr('value'),'check':'0'},
                }).done(function() {
                  //alert('no dashboard');
                });
            }
});
    </script>