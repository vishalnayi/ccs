<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\base\DynamicModel;
use common\models\User;
use common\models\Contact;
use common\models\Client;
use kartik\select2\Select2; 
use common\models\UserClientAccess;
use freesoftwarefactory\select3\Select3Widget;
/* @var $this yii\web\View */
/* @var $model common\models\Provider */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="provider-form">
	<?php
	$modelContactDynamicField = DynamicModel::validateData(
                                    ['client_id','site_id','supplier_id']);
                        
    $modelContactDynamicField->addRule(['client_id','site_id','supplier_id'], 'required'); 
    ?>
    <?php $form = ActiveForm::begin(); ?>

    <?=  $form->field($model, 'name', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput(['maxlength' => true]);

	echo $form->field($model, 'job_title', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

	echo $form->field($model, 'street', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

	echo $form->field($model, 'suburb', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

    echo $form->field($model, 'postcode', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->textInput();

	echo $form->field($model, 'state', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

	echo $form->field($model, 'email', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

	echo $form->field($model, 'website', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

	

	echo $form->field($model, 'phone', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
	])->textInput();

    echo $form->field($model, 'mobile', [
        'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
    ])->textInput();

	echo $form->field($model, 'comment', [
    	'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}</div>',
		])->textArea(); 

	if( Yii::$app->user->identity->role == User::ROLE_SUPER  || Yii::$app->user->identity->role == User::ROLE_ADMIN || Yii::$app->user->identity->role == User::ROLE_AUDITOR):
		//if($model->isNewRecord):
		if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
  			$allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->asArray()->all();
    		$client = array_column($allowedClients, 'client_id');	
  			$clientsData = ArrayHelper::map(Client::find()->where(['in','id',$client])->orderBy([
                          'name' => SORT_ASC      
                        ])->asArray()->all(), 'id', 'name');
		}else{
			$clientsData = ArrayHelper::map(Client::find()->orderBy([
                        'name' => SORT_ASC      
                      ])->asArray()->all(), 'id', 'name');
		}
		//endif;
  		echo $form->field($modelContactDynamicField, 'client_id', ['template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',])->dropDownList($clientsData,array('multiple'=>true,'onchange'=>'if($(this).val() == null){
                      $("#dynamicmodel-client_id select ul li:first-child").prop("selected", true); 
                    }                           
                    $.get( "'.Url::toRoute('/client-site/lists').'", { id: $(this).val(),type:"contact" } )
                    .done(function( data ) { 
                    	var result = jQuery.parseJSON(data);
				        var dropdown2OptionList = [];
				        jQuery.each(result, function(i, item)
				        {
				        	dropdown2OptionList.push({
				                "label": item["label"],
				                "value": item["value"]
				            })
				        });
                              
	                    $("#dynamicmodel-site_id").multiselect({
	            			enableFiltering: true,           
	            			maxHeight: 250,
	            			includeSelectAllOption: true,
	            			enableCaseInsensitiveFiltering: true
	          			});
                       	$("#dynamicmodel-site_id").multiselect("dataprovider", dropdown2OptionList);  
                    	$("#dynamicmodel-site_id").multiselect("rebuild");                
                                           
                    });' ))->label(false);
 
	endif;
	echo $form->field($modelContactDynamicField, 'site_id', ['template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',])->dropDownList($clientSites,array('multiple'=>true ))->label(false);
    echo $form->field($modelContactDynamicField, 'supplier_id', ['template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',])->dropDownList($supplier,array('multiple'=>true ))->label(false);

	// echo  $form->field($modelContactDynamicField, 'site_id')
 //          ->widget(Select3Widget::className(), 
 //          [
 //              'id'=>'clientSiteListId',
 //              'prompt' => 'Select Sites',
 //              'options' => $clientSites,
 //              'autoSelectOptions'=>$selectedOptions,
 //              'allSelectable' => true,
 //              'allSelectableLabel' => "",
 //              'visibleAtStartup' => false,
 //          ])->label('Site'); 

		// echo $form->field($model, 'client_id', [
  //       	'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
		// ])->dropDownList(ArrayHelper::map(Client::find()->asArray()->all(), 'id', 'name'), ['prompt' => '-- Select Client --']); 
		?>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
    	$("#dynamicmodel-client_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });
    	$("#dynamicmodel-site_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });
        $("#dynamicmodel-supplier_id").multiselect({
            enableFiltering: true,           
            maxHeight: 250,
            includeSelectAllOption: true,
            enableCaseInsensitiveFiltering: true
          });
    	 <?php if(isset($selectedClients) && $selectedClients != '' && isset($model->id)){ ?>
    		$('#dynamicmodel-client_id').multiselect('select', [<?php echo $selectedClients; ?>]);
    	<?php } ?>
    	 <?php if(isset($selectedSites) && $selectedSites != '' && isset($model->id)){ ?>
    		$('#dynamicmodel-site_id').multiselect('select', [<?php echo $selectedSites; ?>]);
    	<?php } ?>
        <?php if(isset($selectedSupplier) && $selectedSupplier != '' && isset($model->id)){ ?>
            $('#dynamicmodel-supplier_id').multiselect('select', [<?php echo $selectedSupplier; ?>]);
        <?php } ?>
   	});
</script>
