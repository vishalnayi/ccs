<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\DocumentSearchTerm */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Document Search Term',
]) . $model->id;
$this->params['currentPage'] = 'Document Search Term';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Document Search Terms'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
'model' => $model,
]);

echo $this->render('@app/views/partials/_portlet-end'); ?>
