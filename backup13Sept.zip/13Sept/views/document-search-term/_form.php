<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm; //Use Bootstrap ActiveForm to create the additional Checkbox templating.
use yii\helpers\ArrayHelper;

use common\models\ReportType;
use common\models\ReportCategory;
use common\models\Provider;

/* @var $this yii\web\View */
/* @var $model common\models\DocumentSearchTerm */
/* @var $form yii\widgets\ActiveForm */


$checkboxTemplate = "{beginWrapper}\n<div class=\"md-checkbox\">\n{input}\n{label}\n</div>\n{error}\n{endWrapper}";

$form = ActiveForm::begin([
    'id' => 'update-document-search-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
            ],
        ]
    ]);

echo $form->field($model, 'report_category_id', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportCategory::find()->asArray()->all(), 'id', 'name'));

echo $form->field($model, 'provider_id', [
  'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name'));

//dd(ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name'));
echo $form->field($model, 'report_type_id', [
  'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->dropDownList(ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name'));

echo $form->field($model, 'search_term', [
  'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true]);

echo $form->field($model, 'weight', [
  'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->dropDownList([1=>1,2=>2,3=>3,4=>4,5=>5,6=>6,7=>7,8=>8,9=>9,10=>10]);

echo $form->field($model, 'doctype_id', [
  'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->dropDownList(ReportType::getDocTypes());


echo $form->field($model, 'enabled', [
        'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
        'template' => $checkboxTemplate,
        ])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Enabled </label>");
?>

<h4>Term applies to which attributes:</h4>

<?php

echo $form->field($model, 'search_from_address', [
        'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
        'template' => $checkboxTemplate,
        'disabled' => true])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search from Address </label>");

echo $form->field($model, 'search_subject', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate,
  'disabled' => true])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search Subject</label>");

echo $form->field($model, 'search_message_html', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search Message HTML</label>");

echo $form->field($model, 'search_message_text', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search from Text</label>");

echo $form->field($model, 'search_filename', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate,
  'disabled' => true])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search Filename</label>");

echo $form->field($model, 'search_document_text', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search document text</label>");

echo $form->field($model, 'search_image_fingerprint', [
  'options' =>  ['class' => 'form-group form-md-checkboxes']
])->checkbox([
  'template' => $checkboxTemplate,
  'disabled' => true])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search image fingerprint</label>");

?>

    <fieldset class="form-group material-fieldset">
        <?php
        echo $form->field($model, 'search_section', [
          'options' =>  ['class' => 'form-group form-md-checkboxes']
        ])->checkbox([
          'template' => $checkboxTemplate])->label("<span class=\"inc\"></span><span class=\"check\"></span><span class=\"box\"></span>Search Section</label>");
        ?>
        <div class="col-sm-3 col-xs-6">
<?php
        echo $form->field($model, 'x1', [
           'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->textInput(); ?>
        </div>
        <div class="col-sm-3 col-xs-6">
<?php        echo $form->field($model, 'y1', [
          'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->textInput(); ?>
        </div>
        <div class="col-sm-3 col-xs-6">
<?php
        echo $form->field($model, 'x2', [
           'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->textInput(); ?>
        </div>
        <div class="col-sm-3 col-xs-6">
<?php        echo $form->field($model, 'y2', [
          'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
        ])->textInput(); ?>
        </div>

    </fieldset>

<div class="form-group">
  <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
