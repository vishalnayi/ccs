<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\DocumentSearchTerm */

$this->title = Yii::t('app', 'Create Document Search Term');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Document Search Terms'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = 'Document Search Term';
$this->params['currentChild'] = 'Create Document Search Terms';

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
  'model' => $model,
]);

echo $this->render('@app/views/partials/_portlet-end'); ?>
