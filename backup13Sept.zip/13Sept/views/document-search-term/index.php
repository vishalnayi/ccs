<?php

use yii\helpers\Html;
use fedemotta\datatables\DataTables;

/* @var $this yii\web\View */
/* @var $searchModel common\models\DocumentSearchTermSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Document Search Terms');
$this->params['currentPage'] = 'Document Search Term';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-magnifier font-dark"></i>
                    <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                </div>
            </div>
            <div class="portlet-body document-search-term-index">
                <p><?php echo Html::a(Yii::t('app', 'Create Document Search Term'), ['create'], ['class' => 'btn btn-success']) ?></p>

                <?php echo DataTables::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                  ['class' => 'yii\grid\SerialColumn'],
                  'id',
                  [
                    'label' => 'Report Category',
                    'value' => function ($data) {
                      return $data['reportCategory']['name'];
                    },
                  ],
                  [
                    'label' => 'Provider',
                    'value' => function ($data) {
                      return $data->provider->name;
                    },
                  ],
                  [
                    'label' => 'Report Type',
                    'value' => function ($data) {
                      return $data->reportType->name ?? '<unknown>';
                    },
                  ],
                  [
                    'label' => 'Doc Type',
                    'value' => function ($data) {
                      return $data->getDocType() ?? '';
                    },
                  ],
                  'search_term',
                  [
                    'label' => 'Enabled',
                    'value' => function ($data) {
                      return $data->enabled ? 'Yes' : 'No';
                    },
                  ],
                  [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{view} {update} {delete}',
                    'headerOptions' => ['class' => 'actions'],
                    'buttons' => [
                      //view button
                      'view' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-magnifier"></i>', $url, [
                          'title' => Yii::t('yii', 'View'),
                          'aria-label' => Yii::t('yii', 'View'),
                          'data-pjax' => '0',
                          'class' => 'btn btn-icon-only btn-circle grey-salsa',
                        ]);
                      },
                      'update' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-pencil"></i>', $url, [
                          'title' => Yii::t('yii', 'Update'),
                          'aria-label' => Yii::t('yii', 'Update'),
                          'data-pjax' => '0',
                          'class' => 'btn green btn-icon-only btn-circle filter-submit',
                        ]);
                      },
                      'delete' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-trash"></i>', $url, [
                          'title' => Yii::t('yii', 'Delete'),
                          'aria-label' => Yii::t('yii', 'Delete'),
                          'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                          'data-method' => 'post',
                          'data-pjax' => '0',
                          'class' => 'btn red btn-icon-only btn-circle filter-cancel',
                        ]);

                      }
                    ],
                  ],
                ],
                'clientOptions' => [
                  "lengthMenu" => [[10, 25, 50, -1], [10, 25, 50, Yii::t('app', "All")]],
                  "info" => true,
                  "paging" => true,
                  "searching" => true,
                  "responsive" => true,
                  "dom" => 'lfTrtip',
                  "tableTools" => [
                    "aButtons" => []
                  ],
                ],
                'tableOptions' => [
                  "class" => 'table table-striped table-bordered table-hover table-checkable order-column dataTable'
                ]
              ]); ?>
            </div>
        </div>
    </div>
</div>
