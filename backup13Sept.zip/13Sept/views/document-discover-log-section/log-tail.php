<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\DocumentDiscoverLogSection */

    $s3 = Yii::$app->s3Helper;
    $image = $s3->getFile($model->filepath, $model->bucket)['Body'];

?>
<div class="document-discover-log-section-view">


    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'filepath',
            'text',
            [
                'label' => 'image',
                'format' => 'raw',
                'value' => '<img src="data:image/png;base64,'. base64_encode($image) .'" />',//$model->document_image_cropped,
            ],
        ],
    ]) ?>

</div>
