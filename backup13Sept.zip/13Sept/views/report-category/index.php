<?php

use yii\helpers\Html;
use yii\grid\GridView;
use fedemotta\datatables\DataTables;

/* @var $this yii\web\View */
/* @var $searchModel common\models\ReportCategorySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Report Categories');
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = 'Report Categories';
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-magnifier font-dark"></i>
                    <span class="caption-subject bold uppercase"> <?php echo Html::encode($this->title) ?></span>
                </div>
            </div>
            <div class="portlet-body report-category-index">
                <p><?php echo Html::a(Yii::t('app', 'Create Report Category'), ['create'], ['class' => 'btn btn-success']) ?></p>
    <?= DataTables::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            'created_at',
            'updated_at',

                    [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{view} {update} {delete}',
                    'headerOptions' => ['class' => 'actions'],
                    'buttons' => [
                      //view button
                      'view' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-magnifier"></i>', $url, [
                          'title' => Yii::t('yii', 'View'),
                          'aria-label' => Yii::t('yii', 'View'),
                          'data-pjax' => '0',
                          'class' => 'btn btn-icon-only btn-circle grey-salsa',
                        ]);
                      },
                      'update' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-pencil"></i>', $url, [
                          'title' => Yii::t('yii', 'Update'),
                          'aria-label' => Yii::t('yii', 'Update'),
                          'data-pjax' => '0',
                          'class' => 'btn green btn-icon-only btn-circle filter-submit',
                        ]);
                      },
                      'delete' => function ($url, $model, $key) {
                        return Html::a('<i class="icon-trash"></i>', $url, [
                          'title' => Yii::t('yii', 'Delete'),
                          'aria-label' => Yii::t('yii', 'Delete'),
                          'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                          'data-method' => 'post',
                          'data-pjax' => '0',
                          'class' => 'btn red btn-icon-only btn-circle filter-cancel',
                        ]);

                      }
                    ],
                  ],
        ],
    ]); ?>
            </div>
        </div>
    </div>
</div>
