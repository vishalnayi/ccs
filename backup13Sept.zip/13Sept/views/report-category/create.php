<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ReportCategory */

$this->title = Yii::t('app', 'Create Report Category');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Report Categories'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title;

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
]);

echo $this->render('@app/views/partials/_portlet-end');
