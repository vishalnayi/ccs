<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ReportType */

$this->title = Yii::t('app', 'Create Report Type');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Report Types'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = $this->title;
?>
<div class="report-type-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
