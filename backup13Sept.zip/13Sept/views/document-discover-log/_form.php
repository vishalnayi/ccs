<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\DocumentDiscoverLog */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="document-discover-log-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'report_type_id')->textInput() ?>

    <?= $form->field($model, 'from_address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'subject')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'message_html')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'message_text')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'message_filename')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'message_document_text')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
