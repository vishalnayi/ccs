<?php

use yii\helpers\Html;
use yii\grid\GridView;
use fedemotta\datatables\DataTables;

/* @var $this yii\web\View */
/* @var $searchModel common\models\DocumentDiscoverLogSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light portlet-fit portlet-datatable bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-magnifier font-dark"></i>
                    <span class="caption-subject bold uppercase">Time record (seconds)</span>
                </div>
            </div>
            <div class="portlet-body document-search-term-index">

            <table class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer">
                <tr role="row"><th>Total time</th><th>Discovery</th><th>Create paths</th><th>Save documents</th><th>Debug images</th></tr>
                <tr role="row"><td><?= $model->time_total ?></td><td><?= $model->time_discover ?></td><td><?= $model->time_create_paths ?></td><td><?= $model->time_save_file ?></td><td><?= $model->time_debug_images_upload ?></td></tr>
            </table>

            </div>
        </div>
    </div>
</div>
