<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\DocumentDiscoverLog */

$this->title = 'Document Discover Log';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Document Discover Logs'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $model->id;
$this->params['currentPage'] = $model->id;
$this->params['currentChild'] = 'View Document Search Terms';
?>
<div class="document-discover-log-view">

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'label' => 'Provider',
                'value' => $model->provider->name ?? 'unknown',
            ],
            [
                'label' => 'Report Category',
                'value' => $model->reportType->reportCategory->name ?? 'unknown',
            ],
            [
                'label' => 'Report Type',
                'value' => $model->reportType->name ?? 'unknown',
            ],
            'date',
            'from_address',
            [
                'label' => 'subject',
                'value' => $model->subject_formatted,
                'format' => 'raw',
                'contentOptions' => ['class' => 'tooltip-demo well'],
            ],
            //'message_html',
            [
                'label' => 'message',
                'value' => $model->message_html,
                'format' => 'raw',
                'contentOptions' => ['class' => 'tooltip-demo well'],
            ],
            //'message_text',
            'root_path',
            'mirror_path',
            [
                'label' => 'Document Text',
                'value' => $model->document_text_formatted,
                'format' => 'raw',
                'contentOptions' => ['class' => 'tooltip-demo well'],
            ],
            'created_at',
        ],
    ]) ?>

</div>

<?php
    echo $this->render('time-view', ['model' => $model]);
?>

<?php
    foreach ($model->sectionLogs as $sectionLog) {
        echo $this->render('/document-discover-log-section/log-tail', ['model' => $sectionLog]);
    }
?>
