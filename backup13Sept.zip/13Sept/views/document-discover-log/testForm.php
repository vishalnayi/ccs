<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use common\models\ReportCategory;
use common\models\Provider;

/* @var $this yii\web\View */
/* @var $searchModel common\models\DocumentDiscoverLogSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Document Discover Test');
$this->params['breadcrumbs'][] = $this->title;
$this->params['currentPage'] = 'Document Discovery Test'; 
?>
<div class="document-discover-log-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

    <?= $form->field($model, 'report_category_id')->dropdownList(ArrayHelper::map(ReportCategory::find()->all(), 'id', 'name')) ?>

    <?= $form->field($model, 'provider_id')->dropdownList(ArrayHelper::map(Provider::find()->all(), 'id', 'name')) ?>
    
    <?= $form->field($model, 'file')->fileInput() ?>
    
    <button>Submit</button>

    <h2>Test Result</h2>
    
    <?php ActiveForm::end() ?>
    <?php if ($log) :
        echo $this->render('view', ['model' => $log]);
    endif ?>
</div>
