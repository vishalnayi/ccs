<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\DocumentDiscoverLog */

$this->title = Yii::t('app', 'Create Document Discover Log');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Document Discover Logs'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="document-discover-log-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
