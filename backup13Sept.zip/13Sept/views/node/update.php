<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Node */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Node',
]) . ' ' . $model->name;
$this->params['currentPage'] = 'Nodes';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Nodes'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');

echo $this->render('@app/views/partials/_portlet-start');

echo $this->render('_form', [
    'model' => $model,
    'client' => $client,
    'existing_parent_id' => $existing_parent_id,
]);

echo $this->render('@app/views/partials/_portlet-end');
