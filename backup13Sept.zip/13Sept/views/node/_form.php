<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\Node;


/* @var $this yii\web\View */
/* @var $model common\models\Node */
/* @var $form yii\widgets\ActiveForm */

$form = ActiveForm::begin([
    'id' => 'node-form',
    'fieldConfig' => [
        'options' => [
            'tag' => 'span',
        ],
    ],
    'enableClientValidation'=>false,
]);

echo $form->field($model, 'name', [
    'template' => '<div class="form-group form-md-line-input form-md-floating-label">{input}{label}{error}</div>',
])->textInput(['maxlength' => true, 'disabled' => !$model->isNewRecord]);

echo $form->field($model, 'parent_id', [
        'template' => '<div class="form-group form-md-line-input">{input}{label}{error}</div>',
    ])->dropDownList(ArrayHelper::map(Node::find()->where(['client_id' => $client->id])->asArray()->all(), 'id', 'name'), ['prompt' => '-- No parent --']);

?>

    <input type="hidden" name="Node[existing_parent_id]" value="<?= $existing_parent_id ?>" />

    <div class="form-group">
        <?php echo Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

