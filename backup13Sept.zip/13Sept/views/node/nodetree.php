<?php

use yii\helpers\Html;

$this->title = Yii::t('app', 'Node Tree');
$this->params['currentPage'] = 'Nodes';
$this->params['currentChild'] = 'Modify Node tree';
$this->params['breadcrumbs'][] = $this->title;

echo $this->render('@app/views/partials/_portlet-start'); ?>

    <div id="nodetree_div" class="tooltip-demo well"></div>

<?php echo $this->render('@app/views/partials/_portlet-end');
