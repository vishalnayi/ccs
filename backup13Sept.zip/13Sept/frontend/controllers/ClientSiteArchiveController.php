<?php

namespace frontend\controllers;

use Yii;
use common\models\ClientSite;
use common\models\ClientSiteArchive;
use common\models\ClientSiteSearch;
use common\models\ClientSiteArchiveSearch;
use common\models\User;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use common\models\ImportForm;
use common\models\ClientListForm;
use yii\web\UploadedFile;
use  yii\web\Session;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use common\models\Client;
/**
 * ClientSiteController implements the CRUD actions for ClientSite model.
 */
class ClientSiteArchiveController extends BaseController
{
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }


    /**
     * Lists all ClientSite models.
     * @return mixed
     */
    public function actionIndex()
    {
        if(Yii::$app->request->post()){              
            $modelClient = new ClientListForm();
            $modelClient->load(Yii::$app->request->post());
        }
        $this->checkCommonAccess('index');
        $searchModel = new ClientSiteArchiveSearch();
        $params = Yii::$app->request->queryParams;
        
        if(!$this->isSuper()) {
            $params['forceClient'] = $this->user->client_id;
        }
        if($this->isAuditor()){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();

            $params['isAuditor'] = true; 
            $params['forceClient'] = array_column($allowedClients, 'client_id');
        }
        if(Yii::$app->request->post() && isset($modelClient->client_list_id)){
            $params['forceClient'] = $modelClient->client_list_id;
        }
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
       
        if(!empty($allowedSites) && (!$this->isSuper())){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
            $params['forceSites'] = $forceSites;
        }


        $dataProvider = $searchModel->search($params);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }
   

    /**
     * Displays a single ClientSite model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('view', $model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new ClientSite model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new ClientSite();

        $this->checkCreateAccess('create', $model);
             
        $model->scenario = $this->setScenario($model->scenario);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {            
            // $users = $model->client->users;
            // foreach($users as $user){
            //     $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$user->id])->asArray()->all();
            //     if(!empty($allowedSites)){
            //         $modelUserSiteAccess = new UserSiteAccess();
            //         $modelUserSiteAccess->user_id = $user->id;
            //         $modelUserSiteAccess->site_id = $model->id;
            //         $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
            //         $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
            //         $modelUserSiteAccess->save(); 
            //     }                       
            // }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'client' => $this->user->client,
                'userRole' => $this->user->role,
                'setDirectoryAccess' => $this->user->role == User::ROLE_SUPER,
            ]);
        }
    }

   

    /**
     * Deletes an existing ClientSite model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('delete', $model);
        $model->delete();
        return $this->redirect(['index']);
    }

    /**
     * Deletes an existing ClientSite model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionRestore($id)
    {

        $model = $this->findModel($id);        
        $clientSiteModel = new ClientSite();       
        $clientSiteModel->id = $model->id;
        $clientSiteModel->node_id = $model->node_id;
        $clientSiteModel->client_id = $model->client_id;
        $clientSiteModel->provider_id = $model->provider_id;
        $clientSiteModel->report_category_id = $model->report_category_id;
        $clientSiteModel->name = $model->name;
        $clientSiteModel->directory = $model->directory;
        $clientSiteModel->email_address = $model->email_address;
        $clientSiteModel->email_username = $model->email_username;
        $clientSiteModel->email_password = $model->email_password;
        $clientSiteModel->download_documents = $model->download_documents;
        $clientSiteModel->site_address = $model->site_address;
        $clientSiteModel->manager_name = $model->manager_name;
        // $clientSiteModel->manager_name1 = $model->manager_name1;
        // $clientSiteModel->contact_number1 = $model->contact_number1;
        $clientSiteModel->contact_number = $model->contact_number;
        $clientSiteModel->comment = $model->comment;
        $clientSiteModel->created_at = $model->created_at;
        $clientSiteModel->updated_at = $model->updated_at;

        if($clientSiteModel->save(false)){
            $model->delete();
        }

        //$this->checkAccess('restore', $model);
       
        return $this->redirect(['index']);
    }

    /**
     * Finds the ClientSiteArchive model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientSite the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {

        if (($model = ClientSiteArchive::findOne($id)) !== null) {
            return $model;
        } else {
            //die('else');
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
   
  
   

    protected function checkAccess($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action === 'restore') {           
            if($params['client_id'] != $user['client_id']) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN || $this->user->role == User::ROLE_USER){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Print Reports','index');
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        }
        if($action == 'show-orphan-sites') {
            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }


    protected function checkCreateAccess()
    {
        if ($this->user->role !== User::ROLE_SUPER) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
    }



}
