<?php

namespace frontend\controllers;

use Yii;
use common\models\Node;
use common\models\NodeSearch;
use common\models\User;
use common\models\ClientSite;
use common\models\ReportCategory;
use common\models\SiteOperationalProgram;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * NodeController implements the CRUD actions for Node model.
 */
class NodeController extends BaseController
{
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Node models.
     * @return mixed
     */
    public function actionIndex()
    {
        $this->checkCommonAccess('index');
        $searchModel = new NodeSearch();
        $params = Yii::$app->request->queryParams;
        if(!$this->isSuper()) {
            $params['forceClient'] = $this->user->client_id;
        }
        $dataProvider = $searchModel->search($params);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Node model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('view', $model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionNodeTree()
    {
        $nodes = Node::getNodeChildren($this->user->client_id);
        return $this->render('nodetree', ['nodes' => $nodes]);
    }

    /**
     * Creates a new Node model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Node();
        $this->checkCommonAccess('create', $model);

        $model->client_id = $this->user->client_id;

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'client' => $this->user->client,
                'existing_parent_d' => 0,
            ]);
        }
    }

    /**
     * Updates an existing Node model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('update', $model);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'client' => $this->user->client,
                'existing_parent_id' => $model->parent_id,
            ]);
        }
    }

    /**
     * Deletes an existing Node model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('delete', $model);

        $model->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Node model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Node the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Node::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionGetNodeChildren()
    {
        $parentId = Yii::$app->request->get('id', false);
        $catId = Yii::$app->request->get('catId', false);
        $path = Yii::$app->request->get('path', '');
        $parent = $this->splitTreeId($parentId);
        if($parent['type'] == 'site' || $parent['type'] == 'dir') {
            $site = ClientSite::find()->where(['id' => $parent['id']])->one();
            $reportCategory = ReportCategory::find()->where(['id' => $parent['catId']])->one();
            $this->checkCommonAccess('view', $site);
            $sop = new SiteOperationalProgram;
            $nodes = $sop->searchSiteDirectory($this->user->client_id, $parent, $reportCategory);
            if (!$parent['path']) {
                $nodes2 = $sop->searchSiteDirectory($this->user->client_id, $parent, false);
                $nodes = array_merge($nodes, $nodes2);
            }
        } else {
            $nodes = Node::getNodeChildren($this->user->client_id, $parent['id']);
        }
        $this->returnJson($nodes);
    }

    protected function splitTreeId($id)
    {
        if($id == false) {
            return ['id' => false];
        }

        $id = explode('|', $id);
        return [
                'type' => $id[0] ?? 'node',
                'id' => $id[1] ?? false,
                'argType' => $id[2] ?? false,
                'catId' => $id[3] ?? false,
                'path' => $id[4] ?? false,

        ];
    }

    public function actionList()
    {
        $owncloud = Yii::$app->owncloudHelper;
        $owncloud->test();
    }
}
