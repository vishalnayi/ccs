<?php

namespace frontend\controllers;

use Yii;
use common\models\ClientSite;
use common\models\ClientSiteReportCategory;
use common\models\ClientSiteReportCategorySearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\ImportForm;
use yii\web\UploadedFile;
use common\models\User;
use common\models\Provider;
use common\models\ReportCategory;

/**
 * ClientSiteReportCategoryController implements the CRUD actions for ClientSiteReportCategory model.
 */
class ClientSiteReportCategoryController extends BaseController
{
    public $layout = 'dashboard';

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all ClientSiteReportCategory models.
     * @return mixed
     */
    public function actionIndex($clientSiteId)
    {
        $this->checkAccess('index');

        $searchModel = new ClientSiteReportCategorySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'clientSiteId' => $clientSiteId,
        ]);
    }

    /**
     * Import multiple clientsitereport category model.
     * If import is successful, the browser will be redirected to the 'index' page.
     * @return mixed
     */
    public function actionImport()
    {
        $model = new ImportForm();        

        if (Yii::$app->request->isPost ) {
            $clientSiteId = Yii::$app->request->post()['ImportForm']['site_id'];
            $params['clientSiteId'] = $clientSiteId;
            
            $model->file = UploadedFile::getInstance($model, 'file');
            if ( $model->file ){
                $time = time();
                $model->file->saveAs('../uploads/' .$time. '.' . $model->file->extension);
                $model->file = '../uploads/'.$time. '.' . $model->file->extension;

                $csvfile = fopen($model->file, 'r');
                $theData = fgets($csvfile);               
                $i = 0; 
                $j=1;
                while (!feof($csvfile)) 
                {
                    $csv_data[] = fgets($csvfile, 1024);                
                    $csv_array = explode(",", $csv_data[$i]);                    
                    if(!empty(trim($csv_array[0]))){   
                        // $siteName = trim($csv_array[0]);                          
                        // $countSites = ClientSite::find()->where(['name' => $siteName])->count();                   
                        // if($countSites > 0){
                        // $clientsite = ClientSite::find('id')
                        //     ->where(['name' => $siteName])
                        //     ->one();                                  
                        //     $siteID = $clientsite['id'];                              
                        // }
                        $siteID = $clientSiteId;
                        $reportCategoryName = trim($csv_array[0]);                     
                        $countCategory = ReportCategory::find()->where(['name' => $reportCategoryName])->count();                     
                        if($countCategory > 0){
                        $reportCategory = ReportCategory::find('id')
                            ->where(['name' => $reportCategoryName])
                            ->one();                                  
                            $reportCategoryID = $reportCategory['id'];                             
                        }

                        $providerName = trim($csv_array[1]);                     
                        $countProvider = Provider::find()->where(['name' => $providerName])->count();                     
                        if($countProvider > 0){
                        $provider = Provider::find('id')
                            ->where(['name' => $providerName])
                            ->one();                                  
                            $providerID = $provider['id'];                              
                        }

                        if(isset($siteID) && $siteID > 0 && isset($providerID) && $providerID > 0 && isset($reportCategoryID) && $reportCategoryID > 0){
                            $modelFind = ClientSiteReportCategory::find()->where(['report_category_id'=>$reportCategoryID,'client_site_id'=>$siteID,'provider_id'=>$providerID])->all();
                            if(empty($modelFind)){
                                $crdate = date('Y-m-d H:i:s');
                                $modelCsrc = new ClientSiteReportCategory();
                                $modelCsrc->client_site_id = $siteID;
                                $modelCsrc->report_category_id = $reportCategoryID;
                                $modelCsrc->provider_id = $providerID;
                                $modelCsrc->created_at = $crdate;
                                $modelCsrc->updated_at = $crdate;                             
                                $modelCsrc->save();
                            }
                        }                        
                      }
                      $i++;
                    $j++;
                    }
                    
                }
              
                unlink(Yii::$app->basePath . '/uploads/'.$model->file); 

            }
            
        $this->redirect(array('client-site-report-category/index','clientSiteId'=>$clientSiteId));        

    }

    /**
     * Displays a single ClientSiteReportCategory model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);

        $this->checkAccess('view');

        return $this->render('view', [
            'model' => $model,
            'clientSiteId' => $model->client_site_id,
        ]);
    }

    /**
     * Creates a new ClientSiteReportCategory model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($clientSiteId)
    {
        $model = new ClientSiteReportCategory();

        $this->checkAccess('create');

        $model->client_site_id = $clientSiteId;
        $clientSite = ClientSite::find()->where(['id' => $clientSiteId])->one();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'clientSite' => $clientSite,
            ]);
        }
    }

    /**
     * Updates an existing ClientSiteReportCategory model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        $this->checkAccess('update');

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'clientSite' => $model->clientSite,
            ]);
        }
    }

    /**
     * Deletes an existing ClientSiteReportCategory model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        $this->checkAccess('delete');
        return $this->redirect(Yii::$app->request->referrer);
        //return $this->redirect(['index']);
    }

    /**
     * Finds the ClientSiteReportCategory model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientSiteReportCategory the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = ClientSiteReportCategory::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function checkAccess($action)
    {
        // Currently all actions are only available for the super user.
        if($this->user->role != User::ROLE_SUPER) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }

        return true;
    }
}
