<?php

namespace frontend\controllers;

use Yii;    
use common\models\SiteOperationalProgram;   
use common\models\SiteOperationalProgramSearch; 
use common\models\ClientSiteReportCategory; 
use common\models\User; 
use common\models\Client;   
use common\models\ClientSite;   
use common\models\ReportType;   
use common\models\ReportCategory;   
use yii\web\Controller; 
use yii\web\NotFoundHttpException;  
use yii\filters\VerbFilter; 
use common\models\ImportForm;   
use yii\web\UploadedFile;   
use common\models\UserSiteAccess;   
use common\models\UserClientAccess; 
use yii\base\DynamicModel;
use yii\helpers\ArrayHelper;
use common\models\Provider;

/**
 * SiteOperationalProgramController implements the CRUD actions for SiteOperationalProgram model.
 */
class SiteOperationalProgramController extends BaseController
{
    public $layout = 'dashboard';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all SiteOperationalProgram models.
     * @return mixed
     */
    public function actionIndex()
    {
        $filter = null;

        if(!$this->isSuper()) {
            $filter['clientId'] = $this->user->client_id;
        }
        if($this->isAuditor()){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();

            $filter['isAuditor'] = true; 
            $filter['forceClient'] = array_column($allowedClients, 'client_id');
        }
        $searchModel = new SiteOperationalProgramSearch();
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
       
        if(!empty($allowedSites) && (!$this->isSuper())){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
            $filter['forceSites'] = $forceSites;
        }
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $filter);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

    /**
     * Displays a single SiteOperationalProgram model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        //$this->checkAccess('update', $model);
        $this->checkAccess('view', $model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionGetproviderbysite()
    {
        $data = Yii::$app->request->get();     
        $providers = ClientSiteReportCategory::find()
                ->where(['client_site_id'=>$data['id']])
                ->all();   
        
        $response = [];
        if (!empty($providers)) {
            foreach($providers as $key => $provider) {
                $arr = [];
                $arr['label'] = $provider->provider->name;
                $arr['value'] = $provider->provider_id;
                array_push($response,$arr);               
            }
        }else{
            $arr = ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name'); 
            foreach ($arr as $key => $value) {
               $a = [];
               $a['label'] = $value;
               $a['value'] = $key;
               array_push($response,$a); 
            }
        }  
        echo json_encode($response);        
    }


    public function actionResetalarms(){
        $model = SiteOperationalProgram::find()->all();
        foreach ($model as $key => $m) {
            $mSop = SiteOperationalProgram::findOne($m->id);

            $mSop->is_sent_primary = 0;
            $mSop->secondary_alarm_date = NULL;
            $mSop->is_sent_secondary = 0;
            $mSop->is_sent_territory = 0;
            $mSop->territory_alarm_date = NULL;   
            $mSop->save();
        }
        echo "check db";
        die;
    }

    public function actionFilldb(){
        $model = SiteOperationalProgram::find()->all();
        foreach ($model as $key => $m) {
            if(!empty($m->additional_emails)){
            if (strpos($m->additional_emails, 'alerts@cleancloudsystems.com') !== false) {
            }else{
                $m->additional_emails = 'alerts@cleancloudsystems.com,'.$m->additional_emails;
                $m->save();
            }  
            }else{
                $m->additional_emails = 'alerts@cleancloudsystems.com,';
                $m->save();
            }
        }
       echo "check db"; die;
    }

    /**
     * Creates a new SiteOperationalProgram model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new SiteOperationalProgram();
       // $modelDynamic = SiteOperationalProgram::getDynamicCreateModel();
        $this->checkAccess('create', $model);

        if ($model->load(Yii::$app->request->post()) ) {         
            $model->provider_ids = implode(",",$model->provider_ids); 
            $exists = SiteOperationalProgram::find()->where(['site_id'=>$model->site_id,'report_type_id'=>$model->report_type_id])->all();
            if(isset($exists[0]) && !empty($exists[0])){
                $exists = $exists[0];
                if(($exists->provider_ids == $model->provider_ids) && ($exists->report_interval_id == $model->report_interval_id)){
                    $model->save();
                    return $this->redirect(['view', 'id' => $model->id]);
                }else{                        
                    return $this->render('create', [
                    'model' => $model,
                    'client' => $this->user->client,
                    'error' =>'Please select right supplier and report interval.',
                    ]);
                }
            }else{
                $model->save();
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            return $this->render('create', [
                'model' => $model,
                'client' => $this->user->client,
            ]);
        }
    }

    /**
     * Updates an existing SiteOperationalProgram model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $providers = ClientSiteReportCategory::find()
                ->where(['client_site_id'=>$model->site_id])
                ->all();  
                $response = [];
        if (!empty($providers)) {
            foreach($providers as $key => $provider) {
                $response[$provider->provider->id] = $provider->provider->name;
            }
        }else{
            $response = ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name');
        }  
        $this->checkAccess('update', $model);   
        if ($model->load(Yii::$app->request->post())){
            $model->provider_ids = implode(',',$model->provider_ids);
            $exists = SiteOperationalProgram::find()->where(['site_id'=>$model->site_id,'report_type_id'=>$model->report_type_id])->andWhere(['<>','id', $id])->all();
            
            if(isset($exists[0]) && !empty($exists[0])){
                $exists = $exists[0];
                if(($exists->provider_ids == $model->provider_ids) && ($exists->report_interval_id == $model->report_interval_id)){
                    $model->save();
                    return $this->redirect(['view', 'id' => $model->id]);                
                }else{                    
                    return $this->render('update', [
                    'model' => $model,
                    'client' => $this->user->client,
                    'providerData' => $response,
                    'error' =>'Please select right supplier and report interval.',
                    ]);
                }
            }else{
                $model->save();    
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            if (strpos($model->additional_emails, 'alerts@cleancloudsystems.com,') === false) {
                $model->additional_emails = "alerts@cleancloudsystems.com,".$model->additional_emails;
            }
            return $this->render('update', [
                'model' => $model,
                'client' => $this->user->client,
                'providerData' => $response,
            ]);
        }
    }

    /**
     * Import multiple client model.
     * If import is successful, the browser will be redirected to the 'index' page.
     * @return mixed
     */
    public function actionImport()
    {
        $model = new ImportForm();        

        if (Yii::$app->request->isPost ) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ( $model->file ){
                $time = time();
                $model->file->saveAs('../uploads/' .$time. '.' . $model->file->extension);
                $model->file = '../uploads/'.$time. '.' . $model->file->extension;

                $csvfile = fopen($model->file, 'r');
                $theData = fgets($csvfile);
                $i = 0; 
                $j=1;
                while (!feof($csvfile)) 
                {
                    $csv_data[] = fgets($csvfile, 1024);
                    $csv_array = explode(",", $csv_data[$i]);                    
                    if(!empty(trim($csv_array[0]))){   
                        
                        $SiteName = trim($csv_array[1]);
                        $SiteQry = "SELECT id FROM client_site WHERE name='".$SiteName."'";
                        $conn = Yii::$app->getDb();
                        $command = $conn->createCommand($SiteQry);
                        $getSite = $command->queryOne();

                        $ReportName = trim($csv_array[2]);
                        $ReportQry = "SELECT id FROM report_type WHERE name='".$ReportName."'";
                        $conn = Yii::$app->getDb();
                        $command = $conn->createCommand($ReportQry);
                        $getReport = $command->queryOne();

                        $IntervalName = trim($csv_array[3]);
                        $IntervalQry = "SELECT id FROM report_interval WHERE name='".$IntervalName."'";
                        $conn = Yii::$app->getDb();
                        $command = $conn->createCommand($IntervalQry);
                        $getInterval = $command->queryOne();

                        $SecondIntervalName = trim($csv_array[5]);
                        // $SecondIntervalQry = "SELECT id FROM report_interval WHERE name=".$SecondIntervalName;
                        // $conn = Yii::$app->getDb();
                        // $command = $conn->createCommand($SecondIntervalQry);
                        // $getSecondInterval = $command->queryOne();

                        $TerritoryIntervalName = trim($csv_array[7]);
                        // $TerritoryIntervalQry = "SELECT id FROM report_interval WHERE name=".$TerritoryIntervalName;
                        // $conn = Yii::$app->getDb();
                        // $command = $conn->createCommand($TerritoryIntervalQry);
                        // $TerritorygetInterval = $command->queryOne();

                        $reportname = trim($csv_array[0]);
                        $site_id = $getSite['id'];
                        $report_type_id = $getReport['id'];
                        $report_interval_id = $getInterval['id'];
                        $primary_alarm = 1;
                        $secondary_alarm = (trim(strtolower($csv_array[4])) == 'yes')?1:0;
                        $secondary_alarm_interval_id = trim($csv_array[5]);
                        $territory_alarm = (trim(strtolower($csv_array[6])) == 'yes')?1:0;
                        $territory_alarm_interval_id = trim($csv_array[7]);
                        $additionalEmail = (trim($csv_array[8])!='')?trim($csv_array[8]):'""';
                        $crdate = date('Y-m-d H:i:s');

                        if($site_id!='' && $report_type_id !='' && $report_interval_id !='' && $reportname != ''){
                            // $modelSOP = new SiteOperationalProgram();
                            // $modelSOP->site_id=$site_id;
                            // $modelSOP->report_type_id=$report_type_id;
                            // $modelSOP->report_interval_id=$report_interval_id;
                            // $modelSOP->primary_alarm=$primary_alarm;
                            // $modelSOP->secondary_alarm=$secondary_alarm;
                            // $modelSOP->secondary_interval_id=$secondary_alarm_interval_id;
                            // $modelSOP->territory_alarm=$territory_alarm;
                            // $modelSOP->territory_interval_id=$territory_alarm_interval_id;
                            // $modelSOP->name=  $reportname;                          
                            // $modelSOP->additional_emails=$additionalEmail;
                            // $modelSOP->created_at=$crdate;
                            // $modelSOP->updated_at=$crdate;
                            // $modelSOP->save();

                            $sql = "INSERT INTO `site_operational_program`(`site_id`, `report_type_id`, `report_interval_id`, `primary_alarm`,  `secondary_alarm`, `secondary_interval_id`, `territory_alarm`, `territory_interval_id`, `name`, `additional_emails`, `created_at`, `updated_at`) VALUES ('".$site_id."', '".$report_type_id."', '".$report_interval_id."','".$primary_alarm."','".$secondary_alarm."','".$secondary_alarm_interval_id."','".$territory_alarm."','".$territory_alarm_interval_id."','".$reportname."','".$additionalEmail."','".$crdate."','".$crdate."')";
                            $conn = Yii::$app->getDb();
                            $query = $conn->createCommand($sql)->execute();
                        }else{
                            $query = '';
                        }

                    }
                    $i++;
                    $j++;
                }

                if ($query){
                    unlink(Yii::$app->basePath . '/uploads/'.$model->file);
                }

            }
            $filter = null;

            if(!$this->isSuper()) {
                $filter['clientId'] = $this->user->client_id;
            }
            $searchModel = new SiteOperationalProgramSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $filter);
           
            return $this->render('index', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'userRole' => $this->user->role,
            ]);
        }
    }

    /**
     * Deletes an existing SiteOperationalProgram model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        $this->checkAccess('delete', $model);

        $model->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the SiteOperationalProgram model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return SiteOperationalProgram the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = SiteOperationalProgram::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionCbre(){
        $site = ClientSite::findOne('43');

        $files = SiteOperationalProgram::renameCBREClient($site,'26');
                    //$files = SiteOperationalProgram::checkDishaDemo_new($site);
                    echo "<pre>";
                    print_r($files);
                    die;
    }

    public function actionDemo(){
        //die('hello');
        // $clients = Client::find()->asArray()->all();   
        // $client = (array_unique(array_column($clients, 'id')));
        // echo "<pre>";
        // print_r($client);
        // die;

        // $site = ClientSite::findOne('72');
        //             $files = SiteOperationalProgram::checkDishaDemo_new($site);
        //             echo "files ".$site->directory;
        // echo "<pre>";
        //  print_r($files);
        //  die;


         $clientSiteReportCategories = ClientSiteReportCategory::find()->where(['!=','provider_id','7'])->asArray()->all();
         
         $sitesWithoutIntegra = (array_unique(array_column($clientSiteReportCategories, 'client_site_id')));
                   $c = array( '46',
    '47',
    '48',
    '49',
    '50',
    '51',
    '52');
foreach ($c as $key => $c) {
    # code...

         $sites = ClientSite::find()->where(['client_id'=>$c])->all();
         $client = Client::find()->where(['id'=>$c])->all();

        
            // echo "<pre>";    
            // print_r($sites);
            // die;

         foreach ($sites as $key => $site) {
             if(in_array($site->id, $sitesWithoutIntegra)){
                    $files = SiteOperationalProgram::checkDishaDemo_new($site);
               if($files){
                    echo " ****** Done Client site ".$site->id." and site name ".$site->name." and sitee directory ".$site->directory." ******** ";
               }else{
                    echo "<pre>";
                    print_r($files);
                    die;
               }

             }else{
                echo "Not renming Client : 1 and site ".$site->id;
             }
         }
             
        } 
        //$site = ClientSite::findOne('104');   
        //echo "<pre>";
       // $sops = SiteOperationalProgram::find()->where(['site_id'=>'171'])->all(); 
       // $sops = ReportType::find()->where(['id'=>16])->all(); 
        // print_r($sops);  
        // //die;
        // print_r($site->directory);  die;
        // print_r($site->reportCategories);
        // print_r($site->clientSiteReportCategories);
        // print_r($site->searchTerms);
        // die;
        //$files = SiteOperationalProgram::checkDishaDemo($site);
        //echo "<pre>";
        //print_r($files);
        die;
    }

    public function actionLoadFile()
    {
        $document = Yii::$app->request->get('document');
        $filename = Yii::$app->request->get('filename');
        $type = Yii::$app->request->get('type');
        $site = ClientSite::getSiteFromDocumentPath($document);
        $this->checkAccess('download-doc', $site);
        
        $s3 = Yii::$app->s3Helper;
        $doc = $s3->getFile($document, $this->bucket);

        if(isset($type) && $type == 'inline'){
            header('Content-type: '. $doc['ContentType']);
            header('Content-Disposition:inline;filename="'. $filename .'"');            
        }else{
            header('Content-type: '. $doc['ContentType']);
            header('Content-Disposition:attachment;filename="'. $filename .'"');
        }
        
        echo $doc['Body'];
    }

    public function actionLateToleranceReports()
    {
        $this->checkAccess('late-tolerance-reports');

        $reports = SiteOperationalProgram::findLateReports();
       
        $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all(); 
        return $this->render('late-tolerance-reports', 
                ['reports' => $reports ,'allowedClients'=>$allowedClients]);        
    }

    public function actionSendAlerts()
    {
        $this->checkAccess('send-alerts');

        $reports = SiteOperationalProgram::findLateReports();
        foreach($reports as $client=>$reports) {
            $client = Client::findOne($client);
            $mailBody = $this->renderPartial('//site-operational-program/email-alerts',
                ['reports' => $reports,
                 'client' => $client,
                ],
            true);
            $client->sendAlert($mailBody);
        }

        return 'Reports sent';
    }

    public function actionSyncOwncloud()
    {
        $this->checkAccess('sync-owncloud');

        shell_exec('/var/www/dev/owncloud-update.sh > /dev/null 2>/dev/null &');

        Yii::$app->session->setFlash('success', 'Syncing Owncloud files in the background. It may take some time.');

        $this->redirect('/');
    }

    public function checkAccess($action, $model=null, $params=[])
    {
        if($action === 'sync-owncloud') {
            if($this->user->role != User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        } elseif($action === 'update' || $action === 'view') {
            if($model->site->client_id != $this->user->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN || $this->user->role == User::ROLE_USER){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Site Reports',$action);                        
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        } elseif($action === 'create') {
            if($this->user->role !== User::ROLE_SUPER && $this->user->role !== User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Site Reports',$action);
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        } elseif($action === 'delete') {
            if($this->user->role == User::ROLE_USER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Site Reports',$action);
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
            if($this->user->client_id !== $model->site->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        } elseif($action === 'send-alerts') {
            if($this->user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        } elseif($action === 'download-doc') {
            if($this->isAuditor()){
                $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();              
                $clients = array_column($allowedClients, 'client_id');
                if(!in_array($model->client_id, $clients)){
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                }
            }elseif($this->user->client_id !== $model->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }
}
