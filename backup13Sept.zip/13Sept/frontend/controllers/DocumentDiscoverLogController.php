<?php

namespace frontend\controllers;

use Yii;
use common\models\DocumentDiscoverLog;
use common\models\DocumentDiscoverLogSearch;
use common\models\UploadForm;
use common\models\ReportType;
use common\models\ClientSite;
use common\models\DocumentSearchTerm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * DocumentDiscoverLogController implements the CRUD actions for DocumentDiscoverLog model.
 */
class DocumentDiscoverLogController extends BaseController
{
    public $layout = 'dashboard';

    public function init()
    {
        parent::init();

        if(!$this->user->isSuper()) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all DocumentDiscoverLog models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new DocumentDiscoverLogSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single DocumentDiscoverLog model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Displays a single DocumentDiscoverLog model.
     * @param integer $id
     * @return mixed
     */
    public function actionTest()
    {
       $log = null;
       $model = new UploadForm();
       $documentRetriever = Yii::$app->documentRetriever;
       $clientSite = new ClientSite;
       $reportType = new ReportType;
       $reportHelper = Yii::$app->reportHelper;

       $reportCategoryId = Yii::$app->request->post('UploadForm')['report_category_id'] ?? null;
       $providerId = Yii::$app->request->post('UploadForm')['provider_id'] ?? null;

        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            $model->report_category_id = $reportCategoryId;
            $model->provider_id = $providerId;
            $searchTerms = DocumentSearchTerm::find()->where(['report_category_id' => $reportCategoryId])
                                                     ->where(['provider_id' => $providerId])
                                                     ->all();

            if ($model->file && $model->validate()) {
                $extension = getFileExtension($model->file->name);
                $documentPdfFilename = $documentRetriever->getPdfDocumentLocation($model->file->tempName, $extension);

                $document['time_start'] = time();
                $document['subject'] = $document['messageHtml'] = '==== Test upload ====';
                $document['documentFilename'] = $model->file->tempName;
                $document['documentPdfFilename'] = $documentPdfFilename;
                $document['documentExtension'] = $extension;
                $document['documentText'] = $documentRetriever->getDocumentText($documentPdfFilename);
                $document['documentImagePath'] = $reportHelper->convertDocumentToImage($documentPdfFilename, $extension);
                $document = $reportType->findReportType($document, $searchTerms);
                $document['time_report_discovery_end'] = time();
                $document['time_create_paths_end'] = time();
                $document['time_file_saved_end'] = time();
                $log = $clientSite->log($document, '', '', '');
            }
        }

        return $this->render('testForm', ['model' => $model,
        								  'log'   => $log,
        ]);
    }

    /**
     * Deletes an existing DocumentDiscoverLog model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the DocumentDiscoverLog model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return DocumentDiscoverLog the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = DocumentDiscoverLog::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
