<?php

namespace frontend\controllers;

use Yii;
use common\models\ClientSite;
use common\models\ClientSiteArchive;
use common\models\ClientSiteSearch;
use common\models\SiteOperationalProgram;
use common\models\ReportType;
use common\models\Node;
use common\models\User;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use common\models\ImportForm;
use common\models\ClientListForm;
use yii\web\UploadedFile;
use  yii\web\Session;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use common\models\Client;

/**
 * ClientSiteController implements the CRUD actions for ClientSite model.
 */
class ClientSiteController extends BaseController
{
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all ClientSite models.
     * @return mixed
     */
    public function actionIndex()
    {
        if(Yii::$app->request->post()){   
            $modelClient = new ClientListForm();
            $modelClient->load(Yii::$app->request->post());
        }
        $this->checkCommonAccess('index');
        $searchModel = new ClientSiteSearch();
        $params = Yii::$app->request->queryParams;
        if((!$this->isSuper())) {
            $params['forceClient'] = $this->user->client_id;
        }
        if($this->isAuditor()){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();

            $params['isAuditor'] = true; 
            $params['forceClient'] = array_column($allowedClients, 'client_id');
        }
        if(($this->isSuper() && (Yii::$app->request->post() && isset($modelClient->client_list_id)))) {
            $params['forceClient'] = $modelClient->client_list_id;
        }
        if(($this->isAuditor() && (Yii::$app->request->post() && isset($modelClient->client_list_id)))) {
            $params['forceClient'] = $modelClient->client_list_id;
        }
        //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
       
        if(!empty($allowedSites) && (!$this->isSuper())){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
            $params['forceSites'] = $forceSites;
        }

        $dataProvider = $searchModel->search($params);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

    public function actionSchedulecalendar()
    {
        return $this->render('demo');
    }
    /**
     * To get list of sites by client id.
     * @param integer $id (client id)
     * @return json formate to display in select3 widget
     */
    public function actionLists()
    {
        $data = Yii::$app->request->get(); 
        $countClientSite = ClientSite::find()
                ->where(['in','client_id',$data['id']])
                ->count();

        $clientsites = ClientSite::find()
                ->where(['in','client_id',$data['id']])
                ->all();
        $arr = [];
        if($countClientSite > 0 )
        {            
            if(isset($data['type']) && $data['type']=='contact'){
                //formate for select 3 widget { 123 : 'some' , 456 : 'thing' }
                foreach($clientsites as $site ){
                    $ar = [];
                    $ar['value'] = $site->id;              
                    $ar['label'] = $site->name;  
                    array_push($arr, $ar);
                }
            }else{
                //formate for select 3 widget { 123 : 'some' , 456 : 'thing' }
                foreach($clientsites as $site ){
                    $arr[$site->id] = $site->name;              
                } 
            }                      
        }
        echo json_encode($arr);
    }

    public function actionListsHtmlOld($id)
    {
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
        $availablesite = array_column($allowedSites, 'site_id');

        if($this->isAuditor() && !empty($allowedSites)){         
            $countClientSite = ClientSite::find()
                ->where(['client_id' => $id])->andWhere(['in','id', $availablesite])
                ->count();    

             $clientsites = ClientSite::find()
                ->where(['client_id' => $id])->andWhere(['in','id', $availablesite])
                ->all();  
        }else{
            $countClientSite = ClientSite::find()
                ->where(['client_id' => $id])
                ->count();    

            $clientsites = ClientSite::find()
                ->where(['client_id' => $id])
                ->all();
        }  
        $str="<option value=''>Select Site</option>";    
        if($countClientSite > 0 )  { 

            foreach($clientsites as $l){ 
                $str .= "<option  value='". $l->id."'>".$l->name."</option>";
            } 
        }
        $strNode = "<option value=''>Select Node</option>";
        $countNodes = Node::find()->where(['client_id' => $id])->count();
       
        $clientnodes = Node::find()
                ->where(['client_id' => $id])->orderBy('name')
                ->all();       
        if($countNodes > 0 )  {   
            foreach($clientnodes as $node){ 
                $strNode.= "<option  value='". $node->id."'>".$node->name."</option>";
            } 
        }

        if($this->isAuditor() && !empty($allowedSites)){
           
            $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->andWhere(['in','id', $availablesite])->all(), 'id', 'name'); 

            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->andWhere(['in','id', $availablesite])->all(), 'id', 'id');
            
        }else{
            $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->all(), 'id', 'name'); 

            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->all(), 'id', 'id');
        }
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['IN', 'site_id', $clientSitesArr])->all(), 'report_type_id', 'report_type_id');
        $nodes = ArrayHelper::map(Node::find()->where(['client_id' => $id])->orderBy('name')->all(), 'id', 'name'); 
        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->where(['IN', 'id', $clientReportArr])->all(), 'id', 'name');

        $arr = [];

        $strChecklist = '<div class="form-group form-md-checkboxes"><div class="md-checkbox-list" id="reportTypeChecklist">
            <div class="md-checkbox has-info">
                <input type="checkbox" class="md-check" id="report-types-select-all" />
               <label for="report-types-select-all"><span></span><span class="check"></span><span class="box"></span>Select all</label>
            </div>
            <span class="field-dynamicmodel-report_types required">
            <label class="control-label">Report Types</label>
            <input type="hidden" name="DynamicModel[report_types]" value=""><div id="dynamicmodel-report_types" aria-required="true">';
            $i=0;
        foreach ($reportTypes as $key => $value) {
            $strChecklist.= ' <div class="col-sm-4"><div class="md-checkbox"><input id="'.$i.'" type="checkbox" class="book" name="DynamicModel[report_types][]" value="'.$key.'" tabindex="3"><label for="0"><span></span><span class="check"></span><span class="box"></span>'.$value.'</label></div></div>';
                    $i++;
        }
         
        $strChecklist.= '<p class="help-block help-block-error"></p>
                    </span></div></div></div> <script>jQuery("#report-types-select-all").change(function(){jQuery(".book").prop("checked",this.checked?"checked":"");})</script>';

        array_push($arr, $str);
        array_push($arr, $strNode);
        array_push($arr, $strChecklist);
       

        echo json_encode($arr);
    }

    public function actionListsHtml($id)
    {
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
        $availablesite = array_column($allowedSites, 'site_id');

        if($this->isAuditor() && !empty($allowedSites)){         
            $countClientSite = ClientSite::find()
                ->where(['client_id' => $id])->andWhere(['in','id', $availablesite])
                ->count();    

             $clientsites = ClientSite::find()
                ->where(['client_id' => $id])->andWhere(['in','id', $availablesite])
                ->all();  
        }else{
            $countClientSite = ClientSite::find()
                ->where(['client_id' => $id])
                ->count();    

            $clientsites = ClientSite::find()
                ->where(['client_id' => $id])
                ->all();
        }  
        $str="<option value=''>Select Site</option>";    
        if($countClientSite > 0 )  { 

            foreach($clientsites as $l){ 
                $str .= "<option  value='". $l->id."'>".$l->name."</option>";
            } 
        }
        $strNode = "<option value=''>Select Node</option>";
        $countNodes = Node::find()->where(['client_id' => $id])->count();
       
        $clientnodes = Node::find()
                ->where(['client_id' => $id])->orderBy('name')
                ->all();       
        if($countNodes > 0 )  {   
            foreach($clientnodes as $node){ 
                $strNode.= "<option  value='". $node->id."'>".$node->name."</option>";
            } 
        }

        if($this->isAuditor() && !empty($allowedSites)){
           
            $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->andWhere(['in','id', $availablesite])->all(), 'id', 'name'); 

            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->andWhere(['in','id', $availablesite])->all(), 'id', 'id');
            
        }else{
            $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->all(), 'id', 'name'); 

            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $id])->all(), 'id', 'id');
        }
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['IN', 'site_id', $clientSitesArr])->all(), 'report_type_id', 'report_type_id');
        $nodes = ArrayHelper::map(Node::find()->where(['client_id' => $id])->orderBy('name')->all(), 'id', 'name'); 
        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->where(['IN', 'id', $clientReportArr])->all(), 'id', 'name');
        $cSites = array_keys($clientSites);
        $MyReports =  ClientSite::getMySitesReports(Yii::$app->user->identity->client_id);
            $sitesWithoutPrimaryAlarmSet = $cSites;
         // $sitesWithoutPrimaryAlarmSet = array();
         // array_push($sitesWithoutPrimaryAlarmSet, '30');
         //      echo "<pre>";
         // print_r($sitesWithoutPrimaryAlarmSet);
         // die; 
            if(!empty($sitesWithoutPrimaryAlarmSet)){
                  $FromDate = $_GET['fromDate'];
                  $toDate = $_GET['toDate'];
                $reportsWithoutPA = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,$MyReports);
                $reportTypes = array();
                foreach ($reportsWithoutPA as $key => $report) {
                    if($report['id'] != "" && $report['name'] != ""){
                        $reportTypes[$report['id']] = $report['name'];
                    }
                }
                // echo "<pre>";
                // print_r($reportTypes);
                // die;
               
            }

        $arr = [];

        $strChecklist = '<div class="form-group form-md-checkboxes"><div class="md-checkbox-list" id="reportTypeChecklist">
            <div class="md-checkbox has-info">
                <input type="checkbox" class="md-check" id="report-types-select-all" />
               <label for="report-types-select-all"><span></span><span class="check"></span><span class="box"></span>Select all</label>
            </div>
            <span class="field-dynamicmodel-report_types required">
            <label class="control-label">Report Types</label>
            <input type="hidden" name="DynamicModel[report_types]" value=""><div id="dynamicmodel-report_types" aria-required="true">';
            $i=0;
        foreach ($reportTypes as $key => $value) {
            $strChecklist.= ' <div class="col-sm-4"><div class="md-checkbox"><input id="'.$i.'" type="checkbox" class="book" name="DynamicModel[report_types][]" value="'.$key.'" tabindex="3"><label for="'.$i.'"><span></span><span class="check"></span><span class="box"></span>'.$value.'</label></div></div>';
                    $i++;
        }
         
        $strChecklist.= '<p class="help-block help-block-error"></p>
                    </span></div></div></div> <script>jQuery("#report-types-select-all").change(function(){jQuery(".book").prop("checked",this.checked?"checked":"");})</script>';

        array_push($arr, $str);
        array_push($arr, $strNode);
        array_push($arr, $strChecklist);
       

        echo json_encode($arr);
    }

    public function actionNodeList($id)
    {
        $countNodes = Node::find()->where(['client_id' => $id])->count();
       
        $clientnodes = Node::find()
                ->where(['client_id' => $id])->orderBy('name')
                ->all();       
        if($countNodes > 0 )  {   
            foreach($clientnodes as $node){ 
                echo "<option  value='". $node->id."'>".$node->name."</option>";
            } 
        }
        
    }

    public function actionTestS3Iterator()
    {
        $s3 = Yii::$app->s3Helper;
        $s3->fileExists('', 'myfile.jpg');
    }

    /**
     * Displays a single ClientSite model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->checkCommonAccess('view', $model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new ClientSite model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new ClientSite();

        $this->checkCreateAccess('create', $model);

        $model->scenario = $this->setScenario($model->scenario);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            // $users = $model->client->users;
            // foreach($users as $user){
            //     $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$user->id])->asArray()->all();
            //     if(!empty($allowedSites)){
            //         $modelUserSiteAccess = new UserSiteAccess();
            //         $modelUserSiteAccess->user_id = $user->id;
            //         $modelUserSiteAccess->site_id = $model->id;
            //         $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
            //         $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
            //         $modelUserSiteAccess->save(); 
            //     }                       
            // }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'client' => $this->user->client,
                'userRole' => $this->user->role,
                'setDirectoryAccess' => $this->user->role == User::ROLE_SUPER,
            ]);
        }
    }

    /**
     * Updates an existing ClientSite model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $model->scenario = $this->setScenario($model->scenario);
        $permissions = $this->checkCommonAccess('update', $model);
        if($permissions == 0) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            $form = $this->user->role == User::ROLE_SUPER ? 'super-assign-form' : 'update';
            return $this->render('update', [
                'model' => $model,
                'client' => $this->user->client,
                'form' => $form,
                'userRole' => $this->user->role,
                'setDirectoryAccess' => false,
            ]);
        }
    }

    /**
     * Deletes an existing ClientSite model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);        
        $this->checkCommonAccess('delete', $model);
        $clientSiteArchiveModel = new ClientSiteArchive();
        $clientSiteArchiveModel->id = $model->id;
        $clientSiteArchiveModel->node_id = $model->node_id;
        $clientSiteArchiveModel->client_id = $model->client_id;
        $clientSiteArchiveModel->provider_id = $model->provider_id;
        $clientSiteArchiveModel->report_category_id = $model->report_category_id;
        $clientSiteArchiveModel->name = $model->name;
        $clientSiteArchiveModel->directory = $model->directory;
        $clientSiteArchiveModel->email_address = $model->email_address;
        $clientSiteArchiveModel->email_username = $model->email_username;
        $clientSiteArchiveModel->email_password = $model->email_password;
        $clientSiteArchiveModel->download_documents = $model->download_documents;
        $clientSiteArchiveModel->site_address = $model->site_address;
        $clientSiteArchiveModel->manager_name = $model->manager_name;    
        $clientSiteArchiveModel->contact_number = $model->contact_number;
        $clientSiteArchiveModel->comment = $model->comment;
        $clientSiteArchiveModel->created_at = $model->created_at;
        $clientSiteArchiveModel->updated_at = $model->updated_at;

        if($clientSiteArchiveModel->save(false)){
            $model->delete();
        }
        //$model->delete();
        // $model->client_id = 0;
        // $model->node_id = 0;
        // $model->save();
        return $this->redirect(['index']);
    }

    /**
     * Finds the ClientSite model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientSite the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = ClientSite::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionFindNewSites()
    {
        $site = new ClientSite;
        $newSites = $site->findNewSites();

        Yii::$app->getSession()->setFlash('info', 'New sites found: '. $newSites);

        $this->redirect('/client-site/show-orphan-sites');
    }

    public function actionTest($id)
    {
        $clientSite = ClientSite::find($id)->one();

        $clientSite->getSearchTerms();
    }

    public function actionPrintReports()
    {
        $reportList = [];
        $model = SiteOperationalProgram::getReportFormModel();
        $sites = [];

        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();

        $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
        }

        $permissions = $this->getUserPermissionAccess($this->user->id,'Print Reports','view');
        if($permissions == 0 && $this->user->role != User::ROLE_SUPER && $this->user->role != User::ROLE_AUDITOR) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        } 
        if($model->load(Yii::$app->request->get()) && $model->validate()) {
            $is_print_all = Yii::$app->request->get('print_all');            

            $clientSite = ClientSite::findOne($model->client_site);
            $node = Node::findOne($model->node);
            if($this->user->role != User::ROLE_SUPER && $this->user->role != User::ROLE_AUDITOR){
                if($clientSite) {             
                    $this->checkAccess('print-reports', null, ['client_id' => $clientSite->client_id]);
                } elseif($node) {                 
                    $this->checkAccess('print-reports', null, ['client_id' => $node->client_id]);
                }
            }
            // $dateRange = [
            //     'date_from' => $model->date_from,
            //     'date_to' => $model->date_to,
            // ];
            $dateRange = [
                'date_from' => date('Y-m-d', strtotime($model->date_from)),
                'date_to' => date('Y-m-d', strtotime($model->date_to)),
            ];
            if($node) {
                $sites = $node->findClientSites();
            } elseif($clientSite) {
                $sites[] = $clientSite;
            }
            foreach($sites as $site) {
                if(!empty($allowedSites) && (!$this->isSuper()) ){
                    if( in_array($site->id, $forceSites) ){
                        $reportList[] = $this->gatherSiteReportInfo($site, $model, $dateRange);
                    }
                }else{
                    $reportList[] = $this->gatherSiteReportInfo($site, $model, $dateRange);
                }
            }
            if($this->user->role != User::ROLE_SUPER && $this->user->role != User::ROLE_AUDITOR){
                $clientID = Yii::$app->user->identity->client_id;
            }else{
                $clientID = $model->client_id;
            }
             // code for print all
            if(isset($is_print_all) && $is_print_all == '1'){
                
                $mySiteListReports = $reportList;
                $site_folder = [];
                foreach($mySiteListReports as $reports) {

                    foreach($reports as $key=>$myreportList) {
                        if(!in_array($myreportList['clientSite']['name'], $site_folder)){
                            array_push($site_folder,$myreportList['clientSite']['name']);
                        }
                        if (!file_exists(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'])) {
                            $old_umask = umask(0);
                            mkdir(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'], 0777, true);
                            umask($old_umask);
                            if (!file_exists(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'].'/'. $myreportList['name'])) {
                                $old_umask = umask(0); 
                                mkdir(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'].'/'. $myreportList['name'], 0777, true);
                                umask($old_umask);
                               
                               
                            }
                        }else{
                            if (!file_exists(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'].'/'. $myreportList['name'])) {
                                $old_umask = umask(0);                  
                                 mkdir(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'].'/'. $myreportList['name'], 0777, true);
                                umask($old_umask);
                            }
                        }
                        //create file
                         if (isset($myreportList['reports'])) {
                            foreach($myreportList['reports'] as $report) {
                                $document = $report['filePath'];
                                $filenameArr = explode('/', $report['filePath']);
                                $filename = end($filenameArr);
                               
                                $s3 = Yii::$app->s3Helper;
                                $doc = $s3->getFile($document, 'nextcloud-prod');
                                
                                file_put_contents(Yii::$app->basePath . '/uploads/'.$myreportList['clientSite']['name'].'/'. $myreportList['name'].'/'.$filename, $doc['Body']);
        
                            }
                         }
                    
                    } 
                }
                //create zip and download zip file
                foreach ($site_folder as $key => $folder) {
                    $zip = new \ZipArchive();
                    $filename = Yii::$app->basePath . '/uploads/'.$folder.".zip";
                  
                    if ($zip->open($filename, \ZipArchive::CREATE)!==TRUE) {
                      exit("cannot open <$filename>\n");
                    }

                    $dir = Yii::$app->basePath . '/uploads/'.$folder.'/';
                    $this->createZip($zip,$dir);
                     if(ini_get('zlib.output_compression')) {
                        ini_set('zlib.output_compression', 'Off');
                     }
                    //download file
                     ob_end_flush();              
                     flush();
                     //header('Content-Type: application/zip');
                     header('Content-Disposition: attachment; filename="'.basename($filename).'"');
                     header('Expires: 0');
                     //header("Content-Transfer-Encoding: chunked");
                     header('Content-Length: ' . filesize($filename));
                     header("Content-Type: application/zip;");
                     set_time_limit(0);
                     ini_set('memory_limit', '1024M');
                    // ob_end_clean(); 
                  
                     readfile($filename);
                     // delete file
                     unlink($filename);                     
                     $this->delete_files(Yii::$app->basePath . '/uploads/'.$folder);
                 
                  

                }
               
            }
        }else{
             if(!$this->isSuper()){
                $clientID = Yii::$app->user->identity->client_id;
            }else{
                $clientIdObj = Client::find()->select(['id'])->orderBy(['name'=>'SORT_ASC'])->one();            
                $clientID = $clientIdObj->id; 
            }   
        }
        // To display all report list in print report form
        /*$clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => Yii::$app->user->identity->client_id])->all(), 'id', 'name');
        $nodes = ArrayHelper::map(Node::find()->where(['client_id' => Yii::$app->user->identity->client_id])->orderBy('name')->all(), 'id', 'name');
        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->all(), 'id', 'name');*/

        // to display only created reports for print report form

        if(!$this->isSuper() && !empty($allowedSites)){

            $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientID])->andWhere(['in','id',$forceSites])->all(), 'id', 'name'); 

            $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientID])->andWhere(['in','id',$forceSites])->all(), 'id', 'id');

        }else{
           $clientSites = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientID])->all(), 'id', 'name'); 

           $clientSitesArr = ArrayHelper::map(ClientSite::find()->where(['client_id' => $clientID])->all(), 'id', 'id');
        }
        
        $clientReportArr = ArrayHelper::map(SiteOperationalProgram::find()->where(['IN', 'site_id', $clientSitesArr])->all(), 'report_type_id', 'report_type_id');
        $nodes = ArrayHelper::map(Node::find()->where(['client_id' => $clientID])->orderBy('name')->all(), 'id', 'name');
        $reportTypes = ArrayHelper::map(ReportType::find()->asArray()->where(['IN', 'id', $clientReportArr])->all(), 'id', 'name');
        //MY ADDITION FOR REPORT TYPES FOR FUNCTIONALITY WITHOUT PRIMARY ALARM SET
        $cSites = array_keys($clientSites);        
        $MyReports =  ClientSite::getMySitesReports(Yii::$app->user->identity->client_id);
        $sitesWithoutPrimaryAlarmSet = $cSites;
    
            if(!empty($sitesWithoutPrimaryAlarmSet)){
                  $FromDate = $_SESSION['fromDate'];
                  $toDate = $_SESSION['toDate'];
                $reportsWithoutPA = ClientSite::getReportsStaticsForSitesWithoutAlarm($FromDate,$toDate,$sitesWithoutPrimaryAlarmSet,5,$MyReports);
                $reportTypes = array();
                foreach ($reportsWithoutPA as $key => $report) {
                    if($report['id'] != "" && $report['name'] != ""){
                        $reportTypes[$report['id']] = $report['name'];
                    }
                }
            }

        return $this->render('print-report-form', 
                ['clientId' => Yii::$app->user->identity->client_id,
                 'model' => $model,
                 'clientSites' => $clientSites,
                 'nodes' => $nodes,
                 'reportTypes' => $reportTypes,
                 'siteListReports' => $reportList,
        ]);
    }

    // Create zip
    protected function createZip($zip,$dir){
      if (is_dir($dir)){

        if ($dh = opendir($dir)){
           while (($file = readdir($dh)) !== false){
     
             // If file
             if (is_file($dir.$file)) {
                if($file != '' && $file != '.' && $file != '..'){
            
                   $zip->addFile($dir.$file);
                }
             }else{
                // If directory
                if(is_dir($dir.$file) ){

                  if($file != '' && $file != '.' && $file != '..'){

                    // Add empty directory
                    $zip->addEmptyDir($dir.$file);

                    $folder = $dir.$file.'/';
     
                    // Read data of the folder
                    $this->createZip($zip,$folder);
                  }
                }
     
             }
     
           }
           closedir($dh);
         }
      }
    }

    protected function delete_files($target) {
        if(is_dir($target)){
            $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned

            foreach( $files as $file ){
                $this->delete_files( $file );      
            }

            rmdir( $target );
        } elseif(is_file($target)) {
            unlink( $target );  
        }
    }

    protected function gatherSiteReportInfo($clientSite, $model, $dateRange)
    {
        $reportTypes = SiteOperationalProgram::find()->where(['site_id' => $clientSite->id,
                                                              'report_type_id' => $model->report_types,
                                                   ])->with(['reportType','reportInterval','clientSite'])
                                                     ->asArray()
                                                     ->all();
        $rts = [];
        $docTypeWithAlarams = array();

        foreach($reportTypes as $type) {
            if(isset($type['reportType'])) {
                array_push($docTypeWithAlarams,$type['reportType']['doctype_id']);
                
                $rts[$type['reportType']['doctype_id']] = $type;

            }
        }

        $selectedDocTypesData = ReportType::find()->select('doctype_id')->where(['id' => $model->report_types,
                                               ])->asArray()->all();
        
        $docTypes = array_column($selectedDocTypesData, 'doctype_id');
        $docTypeWithoutAlarams = array_diff($docTypes, $docTypeWithAlarams);
        
        $sop = new SiteOperationalProgram;
        $rts['9999'] = $sop->buildOthersReportType($clientSite);
        //dd($rts);
        $reportsWithAlarms = $sop->findS3Reports($rts, $clientSite, $dateRange);
       

        $reportsWithoutAlarms = $sop->findS3ReportsDashboardStatics($rts, $clientSite,6, $dateRange,$docTypeWithoutAlarams);
       
        foreach ($reportsWithoutAlarms as $key => $reports) {
            if($key != 9999 && in_array($key, $docTypeWithoutAlarams)){
                $reportTypeName = ReportType::find()->select('name')->where(['doctype_id' => $key,
                                                   ])->asArray()->all();
                $reportsWithAlarms[$key] = $reports;
                $reportsWithAlarms[$key]['name'] = $reportTypeName[0]['name'];              
            }
        }
        
      //  return $reports;

        return $reportsWithAlarms;
    }

    /**
     * Import multiple client model.
     * If import is successful, the browser will be redirected to the 'index' page.
     * @return mixed
     */
    public function actionImport()
    {
        $model = new ImportForm();        

        if (Yii::$app->request->isPost ) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ( $model->file ){
                $time = time();
                $model->file->saveAs('../uploads/' .$time. '.' . $model->file->extension);
                $model->file = '../uploads/'.$time. '.' . $model->file->extension;

                $csvfile = fopen($model->file, 'r');
                $theData = fgets($csvfile);
                $i = 0; 
                $j=1;
                while (!feof($csvfile)) 
                {
                    $csv_data[] = fgets($csvfile, 1024);
                    $csv_array = explode(",", $csv_data[$i]);
                    if(!empty(trim($csv_array[0]))){   
                         $NodeName = trim($csv_array[0]);                     
                        $countNodes = Node::find()->where(['name' => $NodeName])->count();                     
                        if($countNodes > 0){
                           $clientnodes = Node::find('id')
                                ->where(['name' => $NodeName])
                                ->one();                                  
                                $nodeID = $clientnodes['id'];                              
                            }else{
                                $crdate = date('Y-m-d H:i:s');
                                $modelNode = new Node();
                                $modelNode->name = str_replace(" ", "_",$NodeName);
                                $modelNode->depth = '0';
                                $modelNode->created_at = $crdate;
                                $modelNode->updated_at = $crdate;
                                $modelNode->save();
                                $nodeID = $modelNode->id;
                                // echo $nodeID;
                                // die;
                            }
                        // $NodeName = trim($csv_array[0]);
                        // $NodeQry = "SELECT id FROM node WHERE name='".$NodeName."'";
                        // $conn = Yii::$app->getDb();
                        // $command = $conn->createCommand($NodeQry);
                        // $getNode = $command->queryOne();

                        $ClientName = trim($csv_array[1]);
                        $ClinetQry = "SELECT id FROM client WHERE name='".$ClientName."'";
                        $conn = Yii::$app->getDb();
                        $command = $conn->createCommand($ClinetQry);
                        $getClient = $command->queryOne();
                        //print_r($getClient); die;

                        $node_id = $nodeID;
                        $client_id = $getClient['id'];
                        $site_name = trim($csv_array[2]);
                        $directory = trim($csv_array[3]);
                        $email_address = trim($csv_array[4]);
                        $email_username = trim($csv_array[5]);
                        $email_password = trim($csv_array[6]);
                        $download_documents = trim($csv_array[7]);
                        $site_address = (trim($csv_array[8])!='')?str_replace(';', ',', trim($csv_array[8])):'""';
                        $manager_name = (trim($csv_array[9])!='')?trim($csv_array[9]):'""';
                        $contact_number = (trim($csv_array[10])!='')?trim($csv_array[10]):'""';
                        $comments = (trim($csv_array[11])!='')?trim($csv_array[11]):'""';
                        $crdate = date('Y-m-d H:i:s');

                        $modelClient = new ClientSite();
                        $modelClient->node_id = $node_id;
                        $modelClient->client_id = $client_id;
                        $modelClient->name = $site_name;
                        $modelClient->directory = $directory;
                        $modelClient->email_address = $email_address;
                        $modelClient->email_username = $email_username;
                        $modelClient->email_password = $email_password;
                        $modelClient->download_documents = $download_documents;
                        $modelClient->site_address = $site_address;
                        $modelClient->manager_name = $manager_name;
                        $modelClient->contact_number = $contact_number;
                        $modelClient->comment = $comments;
                        $modelClient->created_at = $crdate;
                        $modelClient->updated_at = $crdate;
                        $modelClient->save();

                        // $sql = 'INSERT INTO client_site(`node_id`, `client_id`, `name`, `directory`, `email_address`, `email_username`, `email_password`, `download_documents`, `site_address`, `manager_name`, `contact_number`, `comment`, `created_at`,`updated_at`) VALUES ("'.$node_id.'", "'.$client_id.'", '.$site_name.','.$directory.','.$email_address.','.$email_username.','.$email_password.','.$download_documents.','.$site_address.','.$manager_name.','.$contact_number.','.$comments.',"'.$crdate.'","'.$crdate.'")';
                        // $conn = Yii::$app->getDb();
                        // echo $conn->createCommand($sql)->getRawSql();
                        // die;
                        // $query = $conn->createCommand($sql)->execute();

                    }
                    $i++;
                    $j++;
                }
                
                //if ($query){
                    unlink(Yii::$app->basePath . '/uploads/'.$model->file);
               // }

            }
            $this->checkCommonAccess('index');

            $searchModel = new ClientSiteSearch();
            $params = Yii::$app->request->queryParams;
            if(!$this->isSuper()) {
                $params['forceClient'] = $this->user->client_id;
            }
            $dataProvider = $searchModel->search($params);

            return $this->render('index', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'userRole' => $this->user->role,
            ]);
        }
    }
    public function actionDashboardFilter()
    {

        $DateRangeExp = explode(' to ', Yii::$app->request->post('filter_date_range'));
        $session = Yii::$app->session;

        $session->set('fromDate', $DateRangeExp[0]);
        $session->set('toDate', $DateRangeExp[1]);
        return Yii::$app->response->redirect(['/']);
        
    }
    public function actionClearFilter()
    {
        $session = Yii::$app->session;
        $CrDate = date('d-m-Y');
        $dateNew = strtotime($CrDate.' -1 year');
        $pastDate = date('d-m-Y', $dateNew);
        $session->set('fromDate', $pastDate);
        $session->set('toDate', $CrDate);
        return Yii::$app->response->redirect(['/']);
        
    }

    /**
     * Test email credentials
     */
    public function actionTestEmailCredentials()
    {
        if($this->user->role !== User::ROLE_SUPER) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }

        $username = Yii::$app->request->get('username');
        $password = Yii::$app->request->get('password');

        $documentReceiver = Yii::$app->documentRetriever;
        $test = $documentReceiver->testEmailCredentials($username, $password);

        Yii::$app->response->format = \yii\web\response::FORMAT_JSON;
        return ['success' => $test];
    }

    protected function checkAccess($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action === 'print-reports') {           
            if($params['client_id'] != $user['client_id']) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN || $this->user->role == User::ROLE_USER){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Print Reports','index');
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        }
        if($action == 'show-orphan-sites') {
            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }


    protected function checkCreateAccess()
    {
        if ($this->user->role !== User::ROLE_SUPER) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
    }

}
