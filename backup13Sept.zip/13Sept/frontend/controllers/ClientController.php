<?php

namespace frontend\controllers;

use Yii;
use common\models\Client;
use common\models\User;
use common\models\ClientSearch;
use common\models\UserSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\ImportForm;
use yii\web\UploadedFile;
use common\models\UploadImageForm;
use common\models\UserClientAccess;
use kartik\mpdf\Pdf;
use yii\helpers\Url;
use common\models\MailForm;
/**
 * ClientController implements the CRUD actions for Client model.
 */
class ClientController extends Controller
{
    var $user;
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    public function init()
    {
        parent::init();

        if(Yii::$app->user->isGuest) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }

        $this->user = Yii::$app->user->identity;
    }

    /**
     * Lists all Client models.
     * @return mixed
     */
    public function actionIndex()
    {
        $this->checkAccess('index');

        if($this->user->role == User::ROLE_AUDITOR){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();
            $params['forceClient'] = array_column($allowedClients, 'client_id');
            $searchModel = new ClientSearch();
            $dataProvider = $searchModel->search($params);
        }else{
            $searchModel = new ClientSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        }

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Client model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);

        $this->checkAccess('view', $model);

        $userSearchModel = new UserSearch();
        $userDataProvider = $userSearchModel->search(['UserSearch' => ['client_id' => $model->id]]);

        return $this->render('view', [
            'model' => $model,
            'userDataProvider' => $userDataProvider,
        ]);
    }

    /**
     * Creates a new Client model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Client();
        $modelF = new UploadImageForm();

        $this->checkAccess('create');

        if ($model->load(Yii::$app->request->post())) {
           $modelF->file = UploadedFile::getInstance($modelF, 'file');
            $img_url = $modelF->upload();
            $model->img_url = $img_url;

            if ($model->save()) {
                // file is uploaded successfully
               return $this->redirect(['view', 'id' => $model->id]);
            }else {
                return $this->render('create', [
                    'model' => $model,
                    'modelF'=>$modelF,

                ]);
            }
           // return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'modelF'=>$modelF,

            ]);
        }
    }

    /**
     * Updates an existing Client model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $modelF = new UploadImageForm();

        $this->checkAccess('update');

        if ($model->load(Yii::$app->request->post()) ) {
            if (UploadedFile::getInstance($modelF,'file'))
            {
                $modelF->file = UploadedFile::getInstance($modelF,'file');
                $img_url = $modelF->upload();
                $model->img_url = $img_url;
            } 
            $model->save();
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'modelF' => $modelF,
            ]);
        }
    }

    public function actionMailreport()
    {        
        $id = Yii::$app->request->get('id');
        $model = new MailForm();      
        if ($model->load(Yii::$app->request->post())){
            $session = Yii::$app->session;        
        $ref = (explode('/',Yii::$app->request->referrer));        
        if($ref[3]=='client'){
            if(isset($_SESSION['fromPrintDate']) && isset($_SESSION['toPrintDate'])){
                $CrDate = date('d-m-Y', strtotime($_SESSION['toPrintDate']));
                $pastDate = date('d-m-Y', strtotime($_SESSION['fromPrintDate']));
                $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
            }else{
                $CrDate = date('d-m-Y');
                $dateNew = strtotime($CrDate.' -1 year');
                $pastDate = date('d-m-Y', $dateNew);
                $session->set('fromPrintDate', $pastDate);
                $session->set('toPrintDate', $CrDate);
                $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
            }
            $FromDate = $_SESSION['fromPrintDate'];
            $toDate = $_SESSION['toPrintDate'];
        }else{
            if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
                $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
                $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
                $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
            }else{
                $CrDate = date('d-m-Y');
                $dateNew = strtotime($CrDate.' -1 year');
                $pastDate = date('d-m-Y', $dateNew);
                $session->set('fromDate', $pastDate);
                $session->set('toDate', $CrDate);
                $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
            }
            $FromDate = $_SESSION['fromDate'];
            $toDate = $_SESSION['toDate']; 
        }
           $client = Client::findOne($model->clientId);                    
            $content =  $this->renderPartial('print_client_dashboard.php',['clientId'=>$model->clientId,'FromDate'=>$FromDate,'toDate'=>$toDate]);
            $pdf = new Pdf(); // or new Pdf();
            $mpdf = $pdf->api; // fetches mpdf api
           // $mpdf->SetHeader('Kartik Header'); // call methods or set any properties
            $mpdf->WriteHtml($content); // call mpdf write html
            $mailContent = $mpdf->Output('', 'S');
            $client->sendPdfAlert('Please find attached pdf.',$mailContent,$model->email,$model->clientId,$FromDate,$toDate);
            if($ref[3]=='client'){
                return $this->redirect('index');
            }else{
                $this->goHome();
            } 
        }else{
            $model->clientId = $id;
            return $this->renderPartial('add_mail_id', [
                    'model' => $model,
            ]);
        } 
    }

    public function actionPrint(){ 
        $session = Yii::$app->session;      
        $ref = (explode('/',Yii::$app->request->referrer));
        if($ref[3]=='client'){
            if(isset($_SESSION['fromPrintDate']) && isset($_SESSION['toPrintDate'])){
                $CrDate = date('d-m-Y', strtotime($_SESSION['toPrintDate']));
                $pastDate = date('d-m-Y', strtotime($_SESSION['fromPrintDate']));
                $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
            }else{
                $CrDate = date('d-m-Y');
                $dateNew = strtotime($CrDate.' -1 year');
                $pastDate = date('d-m-Y', $dateNew);
                $session->set('fromPrintDate', $pastDate);
                $session->set('toPrintDate', $CrDate);
                $RangeValue = $_SESSION['fromPrintDate'].' to '.$_SESSION['toPrintDate'];
            }
            $FromDate = $_SESSION['fromPrintDate'];
            $toDate = $_SESSION['toPrintDate'];
        }else{
            if(isset($_SESSION['fromDate']) && isset($_SESSION['toDate'])){
                $CrDate = date('d-m-Y', strtotime($_SESSION['toDate']));
                $pastDate = date('d-m-Y', strtotime($_SESSION['fromDate']));
                $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
            }else{
                $CrDate = date('d-m-Y');
                $dateNew = strtotime($CrDate.' -1 year');
                $pastDate = date('d-m-Y', $dateNew);
                $session->set('fromDate', $pastDate);
                $session->set('toDate', $CrDate);
                $RangeValue = $_SESSION['fromDate'].' to '.$_SESSION['toDate'];
            }
            $FromDate = $_SESSION['fromDate'];
            $toDate = $_SESSION['toDate']; 
        }
        $clientId = Yii::$app->request->get('id');        
        $content =  $this->renderPartial('print_client_dashboard.php',['clientId'=>$clientId,'FromDate'=>$FromDate,'toDate'=>$toDate]);
        $cssInline= '.kv-heading-1{font-size:50px}';
        $pdf = new Pdf([
            // set to use core fonts only
            'mode' => Pdf::MODE_CORE, 
            // A4 paper format
            'format' => Pdf::FORMAT_A4, 
            // portrait orientation
            'orientation' => Pdf::ORIENT_PORTRAIT, 
            // stream to browser inline
            'destination' => Pdf::DEST_BROWSER, 
            // your html content input
            'content' => $content, 
            'cssInline' => $cssInline, 
             // set mPDF properties on the fly
            'options' => ['title' => ''],
             // call mPDF methods on the fly
            'methods' => [ 
                //'SetHeader'=>['RMP Print Dashboard'], 
                'SetFooter'=>['{PAGENO}'],                
            ]
        ]);
    
        // return the pdf output as per the destination setting
        return $pdf->render();
    }
    /**
    * Imports multiple records to Client model.
    * If creation is successful, the browser will be reloaded to the same page.
    * @return mixed
    */

    public function actionImport()
    {
        $model = new ImportForm();        

        if (Yii::$app->request->isPost ) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ( $model->file ){
                $time = time();
                $model->file->saveAs('../uploads/' .$time. '.' . $model->file->extension);
                $model->file = '../uploads/'.$time. '.' . $model->file->extension;

                $csvfile = fopen($model->file, 'r');
                $theData = fgets($csvfile);
                $i = 0; 
                $j=1;
                while (!feof($csvfile)) 
                {
                    $csv_data[] = fgets($csvfile, 1024);
                    $csv_array = explode(",", $csv_data[$i]);
                       
                    if(!empty($csv_array[0])){
                        $modelClient = new Client();
                        $crdate = date('Y-m-d H:i:s');
                        $modelClient->client_id = trim($csv_array[0]);
                        $modelClient->name =  trim($csv_array[1]);
                       // $modelClient->name =  str_replace(" ","_",trim($csv_array[1]));
                        $modelClient->created_at = $crdate;
                        $modelClient->updated_at = $crdate;                      
                        $modelClient->save();  
                    }
                    $i++;
                    $j++;
                }
                //if ($query){
                    unlink(Yii::$app->basePath . '/uploads/'.$model->file);
                //}

            }
            $searchModel = new ClientSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

            return $this->render('index', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
            ]);
        }
    }
    
    /**
     * Deletes an existing Client model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->checkAccess('delete');

        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Client model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Client the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Client::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function checkAccess($action, $model=null, $params=[])
    {
        if($action == 'view') {
            if($this->user->client_id != $model->id && $this->user->role != User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'update' || $action == 'create' || $action == 'delete' || $action == 'index') {
            if($this->user->role != User::ROLE_SUPER) {
                if($this->user->role == User::ROLE_AUDITOR && $action == 'index'){

                }else{
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');}
            }
        }
    }
}
