<?php

namespace frontend\controllers;

use Yii;
use common\models\TertiaryAlarm;
use common\models\TertiaryAlarmSearch;
use common\models\User;
use common\models\Client;
use common\models\ClientSite;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;

/**
 * TertiaryAlarmController implements the CRUD actions for TertiaryAlarm model.
 */
class TertiaryAlarmController extends BaseController
{
    public $layout = 'dashboard';

    public $bucket;

    public function init()
    {
        $this->bucket = Yii::$app->s3Helper->nextcloudBucket;

        parent::init();
    }

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all TertiaryAlarm models.
     * @return mixed
     */
    public function actionIndex()
    {
        $filter = null;        
        //$filter['secondary_alarm'] = 1;
        if(!$this->isSuper()) {
            $filter['clientId'] = $this->user->client_id;
        }
        if($this->isAuditor()){
            $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();

            $filter['isAuditor'] = true; 
            $filter['forceClient'] = array_column($allowedClients, 'client_id');
        }
         //for site access user wise. use common\models\UserSiteAccess;
        $allowedSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$this->user->id])->asArray()->all();
       
        if(!empty($allowedSites) && (!$this->isSuper())){
            $forceSites = [];
            foreach ($allowedSites as $key => $value) {
               array_push($forceSites,$value['site_id']);
            }
            $filter['forceSites'] = $forceSites;
        }
        $searchModel = new TertiaryAlarmSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $filter);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

    /**
     * Displays a single TertiaryAlarm model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        //$this->checkAccess('update', $model);
        $this->checkAccess('view', $model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new TertiaryAlarm model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new TertiaryAlarm();
        $this->checkAccess('create', $model);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'client' => $this->user->client,
            ]);
        }
    }

    /**
     * Updates an existing TertiaryAlarm model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess('update', $model);
        $is_sent_secondary = 0;
        if($model->is_sent_secondary == 1){
            $is_sent_secondary = 1;
        }
        
        if ($model->load(Yii::$app->request->post())) {
            if($is_sent_secondary == 1){
                $TertiaryDate = strtotime(date('Y-m-d'));               
                $model->territory_alarm_date = date('Y-m-d',strtotime('+'.$model->territory_interval_id, $TertiaryDate));
            }
            $model->save();
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            // if (strpos($model->additional_emails_territory, 'alerts_demo@cleancloudsystems.com,') === false) {
            //     $model->additional_emails_territory = "alerts_demo@cleancloudsystems.com,".$model->additional_emails_territory;
            // }
             
            return $this->render('update', [
                'model' => $model,
                'client' => $this->user->client,
            ]);
        }
    }

    /**
     * Deletes an existing TertiaryAlarm model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        $model->territory_alarm = 0;
        $model->territory_interval_id = 0;
        $model->save();


        //$model->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the TertiaryAlarm model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return TertiaryAlarm the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = TertiaryAlarm::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionLoadFile()
    {
        $document = Yii::$app->request->get('document');
        $filename = Yii::$app->request->get('filename');

        $site = ClientSite::getSiteFromDocumentPath($document);
        $this->checkAccess('download-doc', $site);

        $s3 = Yii::$app->s3Helper;
        $doc = $s3->getFile($document, $this->bucket);

        header('Content-type: '. $doc['ContentType']);
        header('Content-Disposition:attachment;filename="'. $filename .'"');

        echo $doc['Body'];
    }

    public function actionSendAlerts()
    {
        $this->checkAccess('send-alerts');

        $reports = TertiaryAlarm::findLateReports();
        foreach($reports as $client=>$reports) {
            $client = Client::findOne($client);
            $mailBody = $this->renderPartial('//site-operational-program/email-alerts',
                ['reports' => $reports,
                 'client' => $client,
                ],
            true);
            $client->sendAlert($mailBody);
        }

        return 'Reports sent';
    }

    public function actionSyncOwncloud()
    {
        $this->checkAccess('sync-owncloud');

        shell_exec('/var/www/dev/owncloud-update.sh > /dev/null 2>/dev/null &');

        Yii::$app->session->setFlash('success', 'Syncing Owncloud files in the background. It may take some time.');

        $this->redirect('/');
    }

    public function checkAccess($action, $model=null, $params=[])
    {
        if($action === 'sync-owncloud') {
            if($this->user->role != User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        } elseif($action === 'update' || $action === 'view') {
            if($model->site->client_id != $this->user->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN || $this->user->role == User::ROLE_USER){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Tertiary Alarm',$action);
               
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        } elseif($action === 'create') {
            if($this->user->role !== User::ROLE_SUPER && $this->user->role !== User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Tertiary Alarm',$action);
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        } elseif($action === 'delete') {
            if($this->user->role == User::ROLE_USER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
            if($this->user->client_id !== $model->site->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }elseif($this->user->role == User::ROLE_ADMIN){
                $permissions = $this->getUserPermissionAccess($this->user->id,'Tertiary Alarm',$action);
                if($permissions == 0) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                } 
            }
        } elseif($action === 'send-alerts') {
            if($this->user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        } elseif($action === 'download-doc') {
            if($this->user->client_id !== $model->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }
}
