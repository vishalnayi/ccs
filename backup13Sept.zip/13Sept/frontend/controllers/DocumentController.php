<?php

namespace frontend\controllers;

use Yii;
use common\models\Document;
use common\models\Report;
use common\models\DocumentSearch;
use common\models\ClientSite;
use common\models\ReportType;
use common\models\Provider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\User;

/**
 * DocumentController implements the CRUD actions for Document model.
 */
class DocumentController extends BaseController
{
    public $layout = 'dashboard';

    public function init()
    {
        parent::init();
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Document models.
     * @return mixed
     */
    public function REMOVEDactionIndex()
    {
        $searchModel = new DocumentSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Document model.
     * @param integer $id
     * @return mixed
     */
    public function REMOVEDactionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Document model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function REMOVEDactionCreate()
    {
        $model = new Document();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Document model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function REMOVEDactionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Document model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function REMOVEDactionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionMoveDocument()
    {
        $request = Yii::$app->request;
        $report = new Report;

        $model = new Document;
        if ($request->isGet) {
            $model->load(Yii::$app->request->queryParams);
        } else {
            $model->load($request->post());
        }

        $siteId = $model->site_id ?? null;
        $clientSite = ClientSite::find()->where(['id' => $model->site_id])->one();

        $this->checkClientSiteAccess('move-document', $clientSite);

        $model->scenario = 'move-document';
        $sitePath = ClientSite::OWNCLOUD_DIRECTORY .'/'. $clientSite->directory;
        if ($request->post() && $model->validate()) {
            try {
                $reportType = ReportType::find()->where(['id' => $model->report_type_id])->one();

                $ext = getFileExtension($model->existing_filename);
                $existingPath = $sitePath .'/'. $model->existing_path .'/';
                $document = ['date' => $model->new_datetime,
                             'reportTypeId' => $model->report_type_id,
                             'providerId' => $model->provider_id,
                             'documentExtension' => $ext,
                ];
                $oldReportType = $reportType->findReportTypeFromFilename($model->existing_filename);
                Yii::error('Value of oldReportType '. $oldReportType->name);
                $oldDate = $this->getOldDate($model->existing_filename);
                // Get existing mirror path the oldMirror Path below doesn't work...
                list($oldRootPath, $oldMirrorPath) = $report->getReportPaths($clientSite->directory,
                                                                       $clientSite->getMirrorPath(),
                                                                       $oldReportType->id,
                                                                       $oldDate);
                list($newRootPath, $newMirrorPath) = $report->getReportPaths($clientSite->directory,
                                                                       $clientSite->getMirrorPath(),
                                                                       $reportType->id,
                                                                       $model->new_datetime);
                $newFilename = $report->getFilename($document, $newRootPath,$clientSite->client_id);
                
                $s3 = Yii::$app->s3Helper;
                Yii::error('Moving file: '. $model->existing_path .'/'. $model->existing_filename .'  to  '. $newRootPath .'/'. $newFilename);
                $s3->movePathUpdated($model->existing_path .'/'. $model->existing_filename,
                                     $newRootPath .'/'. $newFilename,
                                     $reportType->bucket 
                );

             //   Yii::error('Delete original mirror file: '. $oldMirrorPath .'/'. $model->existing_filename);
             //   $s3->deleteFile($oldMirrorPath .'/'. $model->existing_filename,
             //                   $reportType->bucket 
             //   );
                Yii::error('Movig mirror file: '. $oldMirrorPath .'/'. $model->existing_filename .'  to  '. $newMirrorPath .'/'. $newFilename);
                $s3->movePathUpdated($oldMirrorPath .'/'. $model->existing_filename,
                                     $newMirrorPath .'/'. $newFilename,
                                     $reportType->bucket 
                );

                if($this->user->role == User::ROLE_AUDITOR){                    
                    return $this->redirect(['client-site/print-reports']);
                }else{
                    return $this->redirect(['node/node-tree']);
                }
           } catch (\yii\base\ErrorException $e) {
               sendErrorEmail(get_class($this), 'MoveDocument', $e->getMessage());
               Yii::$app->session->setFlash('error', 'There was a problem renaming the file. Diagnostic email sent to administrator');
           }
        }

        $datetimeArr = explode('_', $model->existing_filename);       
        $datetime = $datetimeArr[0]." ".$datetimeArr[1];
        $datetime = new \Datetime($datetime);
        $model->new_datetime = $datetime->format('Y-m-d H:i');
        $reportType = new ReportType;
        $model->report_type_id = $reportType->findReportTypeFromFilename($model->existing_filename)->id;
        $explodeFileName = explode('_', $model->existing_filename);
        $model->provider_id = isset($explodeFileName)?(isset($explodeFileName[3])?$explodeFileName[3]:""):""; //3rd index for supplier

        return $this->render('move', ['model' => $model,
                                      'siteName' => $clientSite->name,
                                      'reportType' => ReportType::find()->all(),
                                      'providerId' => Provider::find()->all(),
                                  ]);
    }

    public function actionDeleteDocument()
    {
        $request = Yii::$app->request;
        $report = new Report;

        $model = new Document;
        if ($request->isGet) {
            $model->load(Yii::$app->request->queryParams);
        } else {
            $model->load($request->post());
        }

        $siteId = $model->site_id ?? null;
        $clientSite = ClientSite::find()->where(['id' => $model->site_id])->one();

        $this->checkClientSiteAccess('delete-document', $clientSite);

        $model->scenario = 'delete-document';
        $sitePath = ClientSite::OWNCLOUD_DIRECTORY .'/'. $clientSite->directory;
        if ($request->post() && $model->validate()) {
            try {
                $reportType = ReportType::find()->where(['id' => $model->report_type_id])->one();

                $ext = getFileExtension($model->existing_filename);
                $existingPath = $sitePath .'/'. $model->existing_path .'/';
                $document = ['date' => $model->new_datetime,
                             'reportTypeId' => $model->report_type_id,
                             'documentExtension' => $ext,
                ];
                $oldReportType = $reportType->findReportTypeFromFilename($model->existing_filename);
                Yii::error('Value of oldReportType '. $oldReportType->name);
                $oldDate = $this->getOldDate($model->existing_filename);
                // Get existing mirror path the oldMirror Path below doesn't work...
                list($oldRootPath, $oldMirrorPath) = $report->getReportPaths($clientSite->directory,
                                                                       $clientSite->getMirrorPath(),
                                                                       $oldReportType->id,
                                                                       $oldDate);
                
                $s3 = Yii::$app->s3Helper;
                Yii::error('Deleting file: '. $model->existing_path .'/'. $model->existing_filename);
                $s3->removePath($model->existing_path .'/'. $model->existing_filename,$reportType->bucket);

             //   Yii::error('Delete original mirror file: '. $oldMirrorPath .'/'. $model->existing_filename);
             //   $s3->deleteFile($oldMirrorPath .'/'. $model->existing_filename,
             //                   $reportType->bucket 
             //   );
                Yii::error('Deleting mirror file: '. $oldMirrorPath .'/'. $model->existing_filename);
                $s3->removePath($oldMirrorPath .'/'. $model->existing_filename,$reportType->bucket);

                if($this->user->role == User::ROLE_AUDITOR){                    
                    return $this->redirect(['client-site/print-reports']);
                }else{
                    return $this->redirect(['node/node-tree']);
                }
           } catch (\yii\base\ErrorException $e) {
               sendErrorEmail(get_class($this), 'DeleteDocument', $e->getMessage());
               Yii::$app->session->setFlash('error', 'There was a problem deleting the file. Diagnostic email sent to administrator');
           }
        }

        $datetime = substr($model->existing_filename, 0, strrpos($model->existing_filename, '_'));
        $datetime = str_replace('_', ' ', $datetime);
        
        $datetimeArr = explode(' ', $datetime);
        
        if(count($datetimeArr) == 4){
        	array_pop($datetimeArr);
        	$datetime = implode(' ', $datetimeArr);
        }
     
       //$datetimeArr = explode('_', $model->existing_filename);       
        $datetime = $datetimeArr[0]." ".$datetimeArr[1];
        $datetime = new \Datetime($datetime);
       // $datetime = new \Datetime($datetime);
        $model->new_datetime = $datetime->format('Y-m-d H:i');
        $reportType = new ReportType;
        $model->report_type_id = $reportType->findReportTypeFromFilename($model->existing_filename)->id;

        return $this->render('delete', ['model' => $model,
                                      'siteName' => $clientSite->name,
                                      'reportType' => ReportType::find()->all(),
                                  ]);
    }

    /**
     * Get date from filename
     */
    protected function getOldDate($filename)
    {
        $filename = substr($filename, 0, strrpos($filename, '.'));
        $attrs = explode('_', $filename);

        return $attrs[0] .' '. $attrs[1];
    }

    protected function checkClientSiteAccess($action, $model)
    {
        if ($action == 'move-document') {
            if (!$model) {
                throw new \yii\web\NotFoundHttpException('Record not found');
            }
            if($model->client_id != $this->user->client_id && $this->user->role != User::ROLE_SUPER && $this->user->role != User::ROLE_AUDITOR) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }

    /**
     * Finds the Document model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Document the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Document::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
