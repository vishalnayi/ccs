<?php

namespace frontend\controllers;

use Yii;
use common\models\Client;
use common\models\User;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use common\models\UserPermissions;

/**
 * ClientController implements the CRUD actions for Client model.
 */
class BaseController extends Controller
{
    public $user;
    public $role;
    public $termsAccepted;

    public function init()
    {
        parent::init();

        if(Yii::$app->user->isGuest) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
        //if user has not yet accepted terms and conditions redirect to form


        $this->user = Yii::$app->user->identity;
        $this->role = Yii::$app->user->identity->role;
    }

    public function isSuper()
    {
        return $this->role == User::ROLE_SUPER;
    }

    public function isAuditor()
    {
        return $this->role == User::ROLE_AUDITOR;
    }

    public function setScenario($scenario)
    {
        return $this->user->role == User::ROLE_SUPER ? 'super-user' : $scenario;
    }

    public function checkCommonAccess($action, $model=null, $params=[])
    {

        $user = $this->user;

        if($action == 'index') {

        }
        if($action == 'view' || $action == 'update' || $action == 'delete' || $action == 'create') {
            if($action == 'create' && $this->role == User::ROLE_ADMIN) {
                $permissionCreate = $this->getUserPermissionAccess($this->user->id,'Client Sites',$action);
                return $permissionCreate;
            }
            if($action == 'update' || $action == 'delete' || $action == 'create') {
                if($this->user->role == User::ROLE_ADMIN) {
                    $permissionCreate = $this->getUserPermissionAccess($this->user->id,'Client Sites',$action);
                    return $permissionCreate;
                }
                if($this->user->role == User::ROLE_USER) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                }
            }
            if(Yii::$app->user->identity->role === User::ROLE_SUPER) {
                return true;
            }

            if($model->client_id != $user->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }

    public function getUserPermissionAccess($userid,$module_name,$action,$role=''){  
        // select up.p_field_1,up.p_field_2,up.p_field_3,up.p_field_4,r.module_name,u.role,u.email from user_permissions up join user u on up.user_id = u.id JOIN rights_modules r on up.user_rights_id = r.id where up.user_id = 1 ORDER BY r.id
        $permissions = UserPermissions::find()->select(['user_permissions.user_id','user_permissions.p_field_1','user_permissions.p_field_2','user_permissions.p_field_3','user_permissions.p_field_4','r.module_name','u.role','u.email'])
            ->innerJoin('user u','user_permissions.user_id=u.id')
            ->innerJoin('rights_modules r','user_permissions.user_rights_id=r.id')
            ->where(['user_permissions.user_id'=>$userid,'r.module_name'=>$module_name])
          //  ->createCommand()->getRawSql();           
           ->asArray()->all();

           if($role == User::ROLE_SUPER){
                return 1;
           }elseif(!empty($permissions)){
                if($action == 'index') {
                    if($permissions[0]['p_field_1'] == 0) {
                       return 0;
                    }else{
                        return 1;
                    }
                }elseif($action == 'view') {
                    if($permissions[0]['p_field_1'] == 0) {
                      return 0;
                    }else{
                        return 1;
                    }
                }elseif($action == 'create') {
                    if($permissions[0]['p_field_2'] == 0) {
                        return 0;
                    }else{
                        return 1;
                    }
                }elseif($action == 'update') {
                    if($permissions[0]['p_field_3'] == 0) {
                        return 0;
                    }else{
                        return 1;
                    }
                }elseif($action == 'delete') {
                    if($permissions[0]['p_field_4'] == 0) {
                        return 0;
                    }else{
                        return 1;
                    }
                } 
           }else{
              return 0;
           } 
    }

    public function checkCommonAccessOld($action, $model=null, $params=[])
    {

        $user = $this->user;

        if($action == 'index') {

        }
        if($action == 'view' || $action == 'update' || $action == 'delete' || $action == 'create') {
            if($action == 'create' && $this->role == User::ROLE_ADMIN) {
                return true;
            }
            if($action == 'update' || $action == 'delete' || $action == 'create') {
                if($this->user->role == User::ROLE_USER) {
                    throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
                }
            }
            if(Yii::$app->user->identity->role === User::ROLE_SUPER) {
                return true;
            }

            if($model->client_id != $user->client_id) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }

    public function returnJson(array $object)
    {
       Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
       $json = json_encode($object);
       
       echo $json;
    }
}
