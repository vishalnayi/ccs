<?php

namespace frontend\controllers;

use Yii;
use common\models\User;
use common\models\UserSearch;
use common\models\UserClientAccess;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * UserController implements the CRUD actions for User model.
 */
class SupplierOverviewController extends BaseController
{
    protected $switchUserTimeout = 1000;
    public $layout = 'supplier-overview';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                /*'actions' => [
                    'delete' => ['post'],
                ],*/
            ],
        ];
    }

    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {
       // $this->checkAccess('index', '');

        $searchModel = new UserSearch();
        $params = Yii::$app->request->queryParams;
        if($this->user->role != User::ROLE_SUPER) {
           if($this->user->role == User::ROLE_AUDITOR){
                $allowedClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$this->user->id])->asArray()->all();                  
                $params['forceClient'] = array_column($allowedClients, 'client_id');
            }else{
                $params['forceClient'] = $this->user->client_id;
            }
        }
        $dataProvider = $searchModel->search($params);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    

    protected function checkAccess($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action == 'index') {

            if($user->role == User::ROLE_AUDITOR){

            }elseif($user->role < User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        /*if($action == 'view' || $action == 'update') {

            if($model->id != $user->id &&
                $model->client_id != $user->client_id &&
                $user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'delete' || $action == 'create') {
            if($user->role < User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'switch-user') {
            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }*/
    }
}
