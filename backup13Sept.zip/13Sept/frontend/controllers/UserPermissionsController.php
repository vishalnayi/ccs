<?php

namespace frontend\controllers;

use Yii;
use common\models\User;
use common\models\RightsModules;
use common\models\UserPermissions;
use common\models\UserPermissionsSearch;
use common\models\UserSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

/**
 * UserController implements the CRUD actions for User model.
 */
class UserPermissionsController extends BaseController
{
    protected $switchUserTimeout = 1000;
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {
        $this->checkAccess('index', '');

        $searchModel = new UserSearch();
        $params = Yii::$app->request->queryParams;
        if($this->user->role != User::ROLE_SUPER) {
            $params['forceClient'] = $this->user->client_id;
        }
        $dataProvider = $searchModel->search($params);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

    /**
     * Displays a single User model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $searchModel = new UserPermissionsSearch();
        $params['user_id'] = $id;
        
        $dataProvider = $searchModel->search($params);
        $userModel = User::findOne($id);
        return $this->render('view', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'model'=>$userModel
           
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new UserPermissions();
        $modelUser = new User;
        $this->checkAccess('create', $model);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'modelUser'=>$modelUser,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }

    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $modelUser = User::findOne($id);
        $model =new UserPermissions();

        $this->checkAccess('update', $model);
        $post = Yii::$app->request->post();
        $post['user_id'] = $id;
        $post['role'] = $modelUser->role;

        if($this->customeSave($post)){
            return $this->redirect(['view', 'id' => $modelUser->id]);
        }       
        else {
            return $this->render('update', [
                'model' => $model,
                'modelUser'=>$modelUser,                
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }

    }

    /**
     * Upsert an multiple UserPermission model(If record already exists update else insert).
     * If multiple update or insert is successful, the browser will be redirected to the 'view' page.
     * @param post array
     * @return boolean
     */
    public function customeSave($insert){
        if(isset($_POST['txt_permission'])){
            $user_id = $insert['user_id'];
           
            $i = 0;
            foreach($_POST['txt_permission'] as  $kt => $permission){
                //if any of the access of add edit and delete is given then we must give view access
                if($permission[2] == '1' || $permission[3] == '1' || $permission[4]== '1'){
                    $permission[1] = '1';
                }

                $model = UserPermissions::find()->where(['user_rights_id'=>$kt ,'user_id'=>$user_id])->one(); 

                if ($model == null) {

                  $model = new UserPermissions;  
                   $model->user_id= $user_id;                                   

                }

                    $model->user_role = $insert['role'];
                    $model->user_rights_id = $kt;
                    $model->p_field_1 = $permission[1];
                    $model->p_field_2 = $permission[2];
                    $model->p_field_3 = $permission[3];
                    $model->p_field_4 = $permission[4];
                    $model->status = '1';  

                //update set needed values

                if($model->save()){
                    $i++;
                }
                      
            }


            if($i == count($_POST['txt_permission'])){
                return true;
            }else{
                return false;
            }
           
        }


    }


    /**
     * Upsert an multiple UserPermission model(If record already exists update else insert).
     * If multiple update or insert is successful, the browser will be redirected to the 'view' page.
     * @param post array
     * @return boolean
     */
    public function actionSavep(){
        $modelUser = User::find()->all();
        foreach ($modelUser as $key => $user) {
           
            for($kt=1; $kt<=7; $kt++){
                $model = new UserPermissions;
                $model->user_id= $user->id;                                   
                $model->user_role = $user->role;
                $model->user_rights_id = $kt;
                $model->p_field_1 = 1;
                $model->p_field_2 = 1;
                $model->p_field_3 = 1;
                $model->p_field_4 = 1;
                $model->status = '1';  
                //update set needed values
                $model->save();
            }  
        }
    }


    public function actionUpdateTerms($id)
    {
         $model = $this->findModel($id);
         $this->checkAccess('update', $model);
         $model->terms_accepted='y';

        if ($model->update()) {
            return $this->goHome();
            // return $this->redirect('/layouts/dashboard');
        }

        // return $this->goHome();
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess('delete', $model);
        $model->delete();

        return $this->redirect(['index']);
    }


    public function getUserPermission($userid){
        // select up.p_field_1,up.p_field_2,up.p_field_3,up.p_field_4,r.module_name,u.role,u.email from user_permissions up join user u on up.user_id = u.id JOIN rights_modules r on up.user_rights_id = r.id where up.user_id = 1 ORDER BY r.id
        $upData = UserPermissions::find()->select(['user_permissions.user_id','user_permissions.p_field_1','user_permissions.p_field_2','user_permissions.p_field_3','user_permissions.p_field_4','r.module_name','u.role','u.email'])
            ->innerJoin('user u','user_permissions.user_id=u.id')
              ->innerJoin('rights_modules r','user_permissions.user_rights_id=r.id')
            ->where(['user_permissions.user_id'=>$userid])           
           ->asArray()->all();
        return $upData;
    }
    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = UserPermissions::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function findUserPermissionByUSerModel($id)
    {
        if (($model = UserPermissions::find()->where(['user_id'=>$id])->all()) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }


    protected function checkAccess($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action == 'index') {

            if($user->role < User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'view' || $action == 'update') {

            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'delete' || $action == 'create') {
            if($user->role < User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'switch-user') {
            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }
}
