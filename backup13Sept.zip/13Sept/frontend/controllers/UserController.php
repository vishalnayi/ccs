<?php

namespace frontend\controllers;

use Yii;
use common\models\User;
use common\models\ImportForm;
use yii\web\UploadedFile;
use common\models\UserSearch;
use common\models\UserSiteAccess;
use common\models\UserClientAccess;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\UserPermissions;
use common\models\ClientListForm;
use common\models\ClientSite;
use common\models\Client;
use common\components\CheckPermissionHelper;

/**
 * UserController implements the CRUD actions for User model.
 */
class UserController extends BaseController
{
    protected $switchUserTimeout = 1000;
    public $layout = 'dashboard';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndexold()
    {
        $this->checkAccess('index', '');

        $searchModel = new UserSearch();
        $params = Yii::$app->request->queryParams;
        if($this->user->role != User::ROLE_SUPER) {
            $params['forceClient'] = $this->user->client_id;
        }
        $dataProvider = $searchModel->search($params);

        return $this->render('index_bulk', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

     /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {

        if(Yii::$app->request->post()){              
            $modelClient = new ClientListForm();
            $modelClient->load(Yii::$app->request->post());           
        }

        $this->checkAccess('index', '');
        $searchModel = new UserSearch();
        $params = Yii::$app->request->queryParams;
        if($this->user->role != User::ROLE_SUPER) {
            $params['forceClient'] = $this->user->client_id;
        }
        if(Yii::$app->request->post() && isset($modelClient->client_list_id)){
            $params['forceClient'] = $modelClient->client_list_id;
        }
        $dataProvider = $searchModel->search($params);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'userRole' => $this->user->role,
        ]);
    }

    /**
     * Displays a single User model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess('view', $model);

        return $this->render('view', [
            'model' => $this->findModel($id),
            'userRole' => $this->user->role,
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreateOld()
    {
        $model = new User();
        $this->checkAccess('create', $model);
        $ClientSiteOptions = [];
        $selectedOptions = [];
        $client = Client::find()->orderBy(['name'=>'SORT_ASC'])->one();
        $clientSites = ClientSite::find()->where(['client_id'=>$client->id])->asArray()->all();
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        }  
        $modelClient = New ClientListForm();
        //$model->ip_address = Yii::$app->request->userIP;
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            if($modelClient->load(Yii::$app->request->post())){
               $sitevalues = json_decode(base64_decode($modelClient->client_list_id),true);
               foreach ($sitevalues as $key => $value) {
                    if($value == "true"){
                        $modelUserSiteAccess = new UserSiteAccess();
                        $modelUserSiteAccess->user_id = $model->id;
                        $modelUserSiteAccess->site_id = $key;
                        $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserSiteAccess->save(); 
                    }              
               }              
            }
            //To set permissions of all modules for created user to 1
            for($kt=1; $kt<=7; $kt++){
                $modelUP = new UserPermissions;
                $modelUP->user_id= $model->id;                                   
                $modelUP->user_role = $model->role;
                $modelUP->user_rights_id = $kt;
                $modelUP->p_field_1 = 1;
                $modelUP->p_field_2 = 1;
                $modelUP->p_field_3 = 1;
                $modelUP->p_field_4 = 1;
                $modelUP->status = '1'; 
                $modelUP->created_at = date('Y-m-d H:i:s'); 
                $modelUP->updated_at = date('Y-m-d H:i:s'); 
                
                //update set needed values
                $modelUP->save();
            }  
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'clientSites'=>$ClientSiteOptions,
                'selectedOptions' =>$selectedOptions,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }

     public function actionCreate()
    {
        $model = new User();
        $this->checkAccess('create', $model); 
        $ClientSiteOptions = [];
        $selectedOptions = [];
        $client = Client::find()->orderBy(['name'=>SORT_ASC])->one();
       // echo $client->id; die;
        $clientSites = ClientSite::find()->where(['client_id'=>$client->id])->asArray()->all();
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        }  
        $modelClient = New ClientListForm();        
       // $model->ip_address = Yii::$app->request->userIP;
        if ($model->load(Yii::$app->request->post())) {        
            if($model->role == User::ROLE_AUDITOR){
                $clientIds = $model->client_id;
                $model->client_id = 149; // client id for Client Auditor_Client                 
                if($model->save()){                  
                }else{
                    return $this->render('create', [
                        'model' => $model,
                        'clientSites'=>$ClientSiteOptions,
                        'selectedOptions' =>$selectedOptions,
                        'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
                    ]);
                }
                if(!empty($clientIds) && is_array($clientIds)){           
                    foreach($clientIds as $clientID){
                        $modelUserClientAccess = new UserClientAccess();
                        $modelUserClientAccess->user_id = $model->id;
                        $modelUserClientAccess->client_id = $clientID;
                        $modelUserClientAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserClientAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserClientAccess->save();
                    }
                }
            }else{
                //$model->client_id = (($model->client_id)[0]);  
                // echo "<pre>";
                // print_r($model);
                // die;
                $model->save();

            }
            if($modelClient->load(Yii::$app->request->post())){
               $sitevalues = json_decode(base64_decode($modelClient->client_list_id),true);
               foreach ($sitevalues as $key => $value) {
                    if($value == "true"){
                        $modelUserSiteAccess = new UserSiteAccess();
                        $modelUserSiteAccess->user_id = $model->id;
                        $modelUserSiteAccess->site_id = $key;
                        $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserSiteAccess->save(); 
                    }              
               }              
            }
            
            for($kt=1; $kt<=7; $kt++){
                $modelUP = new UserPermissions;
                $modelUP->user_id= $model->id;                                   
                $modelUP->user_role = $model->role;
                $modelUP->user_rights_id = $kt;
                $modelUP->p_field_1 = 1;
                $modelUP->p_field_2 = 1;
                $modelUP->p_field_3 = 1;
                $modelUP->p_field_4 = 1;
                $modelUP->status = '1'; 
                $modelUP->created_at = date('Y-m-d H:i:s'); 
                $modelUP->updated_at = date('Y-m-d H:i:s');                 
                //update set needed values
                $modelUP->save();
            }  

            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'clientSites'=>$ClientSiteOptions,
                'selectedOptions' =>$selectedOptions,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }

     /**
     * Import multiple client model.
     * If import is successful, the browser will be redirected to the 'index' page.
     * @return mixed
     */
    public function actionImport()
    {
        $model = new ImportForm();        

        if (Yii::$app->request->isPost ) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ( $model->file ){
                $time = time();
                $model->file->saveAs('../uploads/' .$time. '.' . $model->file->extension);
                $model->file = '../uploads/'.$time. '.' . $model->file->extension;

                $csvfile = fopen($model->file, 'r');
                $theData = fgets($csvfile);
                $i = 0; 
                $j=1;
                while (!feof($csvfile)) 
                {
                    $csv_data[] = fgets($csvfile, 1024);
                    $csv_array = explode(",", $csv_data[$i]);

                    if(!empty(trim($csv_array[0]))){   
                        
                        $ClientName = trim($csv_array[0]);
                        $ClinetQry = "SELECT id FROM client WHERE name='".$ClientName."'";
                        $conn = Yii::$app->getDb();
                        $command = $conn->createCommand($ClinetQry);
                        $getClient = $command->queryOne();

                        $modelUser = new User();
                        $modelUser->client_id =  $getClient['id'];
                        $modelUser->username = trim($csv_array[1]);
                        $modelUser->role  = trim($csv_array[2]);
                        $modelUser->password_hash =  Yii::$app->security->generatePasswordHash(trim($csv_array[3]));
                        $modelUser->email = trim($csv_array[4]);
                        $modelUser->status = 10;
                        $modelUser->created_at = date('Y-m-d H:i:s');
                        $modelUser->updated_at = date('Y-m-d H:i:s');
                        $modelUser->terms_accepted = 'n';
                       // $modelUser->ip_address = Yii::$app->request->userIP;
                        if($modelUser->save()){
                               //To set permissions of all modules for created user to 1
                            for($kt=1; $kt<=7; $kt++){
                                $modelUP = new UserPermissions;
                                $modelUP->user_id= $modelUser->id;                                   
                                $modelUP->user_role = $modelUser->role;
                                $modelUP->user_rights_id = $kt;
                                $modelUP->p_field_1 = 1;
                                $modelUP->p_field_2 = 1;
                                $modelUP->p_field_3 = 1;
                                $modelUP->p_field_4 = 1;
                                $modelUP->status = '1'; 
                                $modelUP->created_at = date('Y-m-d H:i:s'); 
                                $modelUP->updated_at = date('Y-m-d H:i:s'); 
                                
                                //update set needed values
                                $modelUP->save();
                            } 
                        }
                      
                        

                    }
                    $i++;
                    $j++;
                }
                
               // if ($query){
                    unlink(Yii::$app->basePath . '/uploads/'.$model->file);
                //}

            }
            $this->checkAccess('index', '');
            $searchModel = new UserSearch();
            $params = Yii::$app->request->queryParams;
            if($this->user->role != User::ROLE_SUPER) {
                $params['forceClient'] = $this->user->client_id;
            }
            $dataProvider = $searchModel->search($params);

            return $this->render('index', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'userRole' => $this->user->role,
            ]);
        }
    }


    /**
     * Creates a new Development model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionDevelopment()
    {
        $model = new User();
        $this->checkAccess('development', $model);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('development', [
                'model' => $model,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }

    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdateOld($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess('update', $model);
        $ClientSiteOptions = [];
        $clientSites = ClientSite::find()->where(['client_id'=>$model->client_id])->asArray()->all();
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        } 
        $modelUserSiteAccess = UserSiteAccess::find()->where(['user_id'=>$id])->all();

        $selectedOptions = [];
        foreach ($modelUserSiteAccess as $key => $access) {        
           array_push($selectedOptions,$access->site_id);   
        }
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
             $modelClient = New ClientListForm();
            if($modelClient->load(Yii::$app->request->post())){
               $sitevalues = json_decode(base64_decode($modelClient->client_list_id),true);
               
               foreach ($sitevalues as $key => $value) {
                    if($value == "true"){
                        //find from table if exists then do nothing otherwise add record in table
                        $isExist = UserSiteAccess::find()->where(['user_id'=>$model->id,'site_id'=>$key])->one();
                        if(!$isExist){
                            $modelUserSiteAccess = new UserSiteAccess();
                            $modelUserSiteAccess->user_id = $model->id;
                            $modelUserSiteAccess->site_id = $key;
                            $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
                            $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
                            $modelUserSiteAccess->save(); 
                        }
                    }else{
                       //if find from table then delete the raw from table
                        $isExist = UserSiteAccess::find()->where(['user_id'=>$model->id,'site_id'=>$key])->one();
                        if($isExist){
                            $modelUserSiteAccess = UserSiteAccess::findOne($isExist->id);
                            $modelUserSiteAccess->delete();
                        }
                    }              
               }              
            }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'clientSites'=>$ClientSiteOptions,
                'selectedOptions' =>$selectedOptions,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $ClientSiteOptions = [];   
        $selectedClients = [];   
        if($model->role == User::ROLE_AUDITOR){
            $modelUserClientAccess = UserClientAccess::find()->where(['user_id'=>$id])->all();
            $selectedClients = [];
            foreach ($modelUserClientAccess as $key => $access) {        
               array_push($selectedClients,$access->client_id);   
            }
            $model->client_id = implode(',', $selectedClients);
           
            $clientSites = ClientSite::find()->where(['in','client_id',UserClientAccess::find()->select('client_id')->where(['user_id'=>$id])->all()])->asArray()->all();
        }else{
            $clientSites = ClientSite::find()->where(['client_id'=>$model->client_id])->asArray()->all();
        }        
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        }       
        $this->checkAccess('update', $model);
        $modelUserSiteAccess = UserSiteAccess::find()->where(['user_id'=>$id])->all();

        $selectedOptions = [];
        foreach ($modelUserSiteAccess as $key => $access) {        
           array_push($selectedOptions,$access->site_id);   
        }
        if ($model->load(Yii::$app->request->post())) {
            $clientIds = $model->client_id;
           // $model->client_id = ($model->role == User::ROLE_AUDITOR)?'149':(($model->client_id)[0]);
            $model->client_id = ($model->role == User::ROLE_AUDITOR)?'149':($model->client_id);
            $model->save();
            //if role is auditor save or update clients to user client access table
            if($model->role == User::ROLE_AUDITOR){
                $existsClients = UserClientAccess::find()->select('client_id')->where(['user_id'=>$model->id])->asArray()->all();
                $arrayDbclientIDs = array_column($existsClients, 'client_id');
                $common = array_intersect($clientIds,$arrayDbclientIDs);
                //find the diffrende between common and first array and diffrence between common and second array 
                $deleteClients = array_diff($arrayDbclientIDs, $common);
                $addClients = array_diff($clientIds,$common);
               
                if(!empty($addClients)){
                   foreach($addClients as $clientID){                       
                        $modelUserClientAccess = new UserClientAccess();
                        $modelUserClientAccess->user_id = $model->id;
                        $modelUserClientAccess->client_id = $clientID;
                        $modelUserClientAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserClientAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserClientAccess->save();
                    } 
                }
                if(!empty($deleteClients)){
                UserClientAccess::deleteAll(['AND',['in','client_id' , $deleteClients],['user_id'=>$model->id]]);
                }
                
            }else{
                //check if record exists for user in user_client_access tabel if exists delete it.
                UserClientAccess::deleteAll(['user_id'=>$model->id]);
            }
            //site update
             $modelClient = New ClientListForm();
            if($modelClient->load(Yii::$app->request->post())){
               $sitevalues = json_decode(base64_decode($modelClient->client_list_id),true);
               
               $selectedSites = [];
               foreach ($sitevalues as $key => $value) {
                    $isExist = UserSiteAccess::find()->where(['user_id'=>$model->id,'site_id'=>$key])->one();
                    if($value == "true"){
                        //find from table if exists then do nothing otherwise add record in table 
                        array_push($selectedSites, $key);    
                        
                    }             
               }

               $existsSites = UserSiteAccess::find()->select('site_id')->where(['user_id'=>$model->id])->asArray()->all();            
                $arrayDbsiteIDs = array_column($existsSites, 'site_id');               
                $commonvalue = array_intersect($selectedSites,$arrayDbsiteIDs);

                //find the diffrende between common and first array and diffrence between common and second array 
                $deleteSites = array_diff($arrayDbsiteIDs,$commonvalue);                
                $addSites = array_diff($selectedSites,$commonvalue);
               
                if(!empty($addSites)){
                   foreach($addSites as $siteID){                       
                        $modelUserSiteAccess = new UserSiteAccess();
                            $modelUserSiteAccess->user_id = $model->id;
                            $modelUserSiteAccess->site_id = $siteID;
                            $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
                            $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
                            $modelUserSiteAccess->save();
                    } 
                }
                if(!empty($deleteSites)){
                    UserSiteAccess::deleteAll(['AND',['in','site_id' , $deleteSites],['user_id'=>$model->id]]);
                } 

            }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {   
            return $this->render('update', [
                'model' => $model,
                'selectedClients'=>$selectedClients,
                'clientSites'=>$ClientSiteOptions,
                'selectedOptions' =>$selectedOptions,
                'superUser' => Yii::$app->user->identity->role == User::ROLE_SUPER ? true : false,
            ]);
        }
    }




    public function actionUpdateTerms($id)
    {   
        $model = $this->findModel($id);
        $this->checkAccess('update', $model);
        $model->terms_accepted='y';

        if ($model->update()) {
            return $this->goHome();
            // return $this->redirect('/layouts/dashboard');
        }

        // return $this->goHome();
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess('delete', $model);
        $model->delete();

        return $this->redirect(['index']);
    }
     /**
     * Deletes multiple selected user's record User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.     
     * @return mixed
     */
    public function actionBulkdelete(){
        $action=Yii::$app->request->post('action');
        $selection=(array)Yii::$app->request->post('selection');//typecasting
        User::deleteAll(['id' => $selection]);
        return $this->redirect(['index']);
      
    }
    
    public function actionSwitchUser()
    {
        $this->checkAccess('switch-user', '');
 
        $id = Yii::$app->request->post('id', false);
        if(!$id) {
            return $this->render('user-switch-form');
        }

        $user = $this->findModel($id);
        Yii::$app->user->switchIdentity($user, $this->switchUserTimeout);

        $this->redirect('user-switched');
    }

    public function actionUserSwitched()
    {
        return $this->render('user-switched', ['user' => Yii::$app->user->identity]);
    }

    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }




    protected function checkAccess($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action == 'switch-user') {
            
            if(($user->role !== User::ROLE_SUPER) && ($user->role !== User::ROLE_AUDITOR)) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }

        if($user->role !== User::ROLE_SUPER  && $action != 'switch-user'){
            
            $permissions = $this->getUserPermissionAccess($user->id,'Users',$action);
            
            if($permissions == 0) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }               
        }        
        
    }

   

    protected function checkAccessOld($action, $model=null, $params=[])
    {
        $user = $this->user;

        if($action == 'index') {
            if($user->role < User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'view' || $action == 'update') {

            if($model->id != $user->id &&
                $model->client_id != $user->client_id &&
                $user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'delete' || $action == 'create') {
            if($user->role < User::ROLE_ADMIN) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
        if($action == 'switch-user') {
            if($user->role !== User::ROLE_SUPER) {
                throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
            }
        }
    }
}
