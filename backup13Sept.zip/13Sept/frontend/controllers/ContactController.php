<?php

namespace frontend\controllers;

use Yii;
use common\models\Contact;
use common\models\Client;
use common\models\ClientSite;
use common\models\Provider;
use common\models\User;
use yii\helpers\ArrayHelper;
use common\models\ContactSearch;
use yii\web\Controller; 
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\ClientContact;
use common\models\SiteContact;
use common\models\SupplierContact;
/**
 * ContactController implements the CRUD actions for Contact model.
 */
class ContactController extends BaseController
{
    public $layout = 'dashboard';

    public function init()
    {
        parent::init();

        if(!$this->user->isSuper()) {
            throw new \yii\web\ForbiddenHttpException('Insufficient privileges');
        }
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Contact models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ContactSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Contact model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $searchModel = new ContactSearch();
        $clients = ClientContact::find()->with('client')->where(['contact_id'=>$id])->asArray()->all();
        // echo "<pre>";
        // print_r($clients);
        // die;
        $sites = SiteContact::find()->with('site')->where(['contact_id'=>$id])->asArray()->all();
        $suppliers = SupplierContact::find()->with('supplier')->where(['contact_id'=>$id])->asArray()->all();
        return $this->render('view', [
            'model' => $this->findModel($id),
            'clients' => $clients,
            'sites' => $sites,
            'suppliers' => $suppliers,
            'contactId' => $id,
        ]);
    }

    public function actionSetprefrence()
    {

        $clientContact = ClientContact::find()->where(['contact_id'=>$_POST['contact_id'],'client_id'=>$_POST['client_id']])->one();

        if($_POST['type'] == 'client_dashboard'){
            if($_POST['check']==1){
                $clientContact->display_dashboard = 1;
            }elseif($_POST['check'] == 0){              
                $clientContact->display_dashboard = 0;
            }
        }elseif($_POST['type'] == 'client_pdf'){
            if($_POST['check']==1){
                $clientContact->display_pdf = 1;
            }elseif($_POST['check'] == 0){
                $clientContact->display_pdf = 0;
            }
        }
        $clientContact->save();
        echo 1;       
    }

    public function actionSetprefrencesite()
    {

        $siteContact = SiteContact::find()->where(['contact_id'=>$_POST['contact_id'],'site_id'=>$_POST['site_id']])->one();

        if($_POST['type'] == 'site_dashboard'){
            if($_POST['check']==1){
                $siteContact->display_dashboard = 1;
            }elseif($_POST['check'] == 0){              
                $siteContact->display_dashboard = 0;
            }
        }elseif($_POST['type'] == 'site_pdf'){
            if($_POST['check']==1){
                $siteContact->display_pdf = 1;
            }elseif($_POST['check'] == 0){
                $siteContact->display_pdf = 0;
            }
        }
        $siteContact->save();
        echo 1;       
    }

     public function actionSetprefrencesupplier()
    {

        $supplierContact = SupplierContact::find()->where(['contact_id'=>$_POST['contact_id'],'supplier_id'=>$_POST['supplier_id']])->one();

        if($_POST['type'] == 'supplier_dashboard'){
            if($_POST['check']==1){
                $supplierContact->display_dashboard = 1;
            }elseif($_POST['check'] == 0){              
                $supplierContact->display_dashboard = 0;
            }
        }elseif($_POST['type'] == 'supplier_pdf'){
            if($_POST['check']==1){
                $supplierContact->display_pdf = 1;
            }elseif($_POST['check'] == 0){
                $supplierContact->display_pdf = 0;
            }
        }
        $supplierContact->save();
        echo 1;       
    }

    /**
     * Creates a new Contact model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Contact();
        if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
            $modelUserClientAccess = UserClientAccess::find()->where(['user_id'=>Yii::$app->user->identity->id])->all();
            
           
            $clientSites = ClientSite::find()->where(['in','client_id',UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->all()])->asArray()->all();
        }else{
            $clientSites = ClientSite::find()->where(['client_id'=>Yii::$app->user->identity->client_id])->asArray()->all();
        }        
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        } 
        $supplierList = ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name');

        //$model->load(Yii::$app->request->post());
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            $clientContactData = array();
            $contact_id = $model->id;
            $modelClient = Contact::getDynamicClientModel();
            if($modelClient->load(Yii::$app->request->post())){
               $clientIdArr =  $modelClient->client_id;
               $siteIdArr =  $modelClient->site_id;
               $supplierIdArr =  $modelClient->supplier_id;
               if(!empty($clientIdArr)){
                foreach ($clientIdArr as $key => $client_id) {
                   $clientContactModel = new ClientContact();
                   $clientContactModel->contact_id = $contact_id;
                   $clientContactModel->client_id = $client_id;
                   $clientContactModel->save();
                }
               }
               if(!empty($siteIdArr)){
                foreach ($siteIdArr as $key => $site_id) {
                   $siteContactModel = new SiteContact();
                   $siteContactModel->contact_id = $contact_id;
                   $siteContactModel->site_id = $site_id;
                   $siteContactModel->save();
                }
               } 
               if(!empty($supplierIdArr)){
                foreach ($supplierIdArr as $key => $supplier_id) {
                   $supplierContactModel = new SupplierContact();
                   $supplierContactModel->contact_id = $contact_id;
                   $supplierContactModel->supplier_id = $supplier_id;
                   $supplierContactModel->save();
                }
               } 
                
            }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'clientSites'=>$ClientSiteOptions,  
                'supplier'=>$supplierList,              
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Contact model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id); 
        $ClientSiteOptions = [];   

        $supplierList = ArrayHelper::map(Provider::find()->asArray()->all(), 'id', 'name');

        if(Yii::$app->user->identity->role == User::ROLE_AUDITOR){
            $modelUserClientAccess = UserClientAccess::find()->where(['user_id'=>Yii::$app->user->identity->id])->all();
            
           
            $clientSites = ClientSite::find()->where(['in','client_id',UserClientAccess::find()->select('client_id')->where(['user_id'=>Yii::$app->user->identity->id])->all()])->asArray()->all();
        }elseif(Yii::$app->user->identity->role == User::ROLE_SUPER){
            $clientSites = ClientSite::find()->asArray()->all();  
        }else{
            $clientSites = ClientSite::find()->where(['client_id'=>Yii::$app->user->identity->client_id])->asArray()->all();            
        }        
        

        //get selected clients
        $clientData = ClientContact::find()->where(['contact_id'=>$id])->asArray()->all();
        $client = array_column($clientData, 'client_id');  
        $selectedClientsArr = ArrayHelper::map(Client::find()->where(['in','id',$client])->asArray()->all(), 'id', 'id');
        if(!empty($selectedClientsArr)){
            $selectedClients = implode(',', $selectedClientsArr);
        }else{
            $selectedClients = "";
        }

        if(!empty($selectedClientsArr)){
             $clientSites = ClientSite::find()->where(['in','client_id',$selectedClientsArr])->asArray()->all();
        }
        foreach ($clientSites as $key => $site) {
            $ClientSiteOptions[$site['id']] = $site['name'];
        } 
        // echo "<pre>";
        // print_r($ClientSiteOptions);
        // print_r($supplier);
        // die;
        //get selected sites
        $siteData = SiteContact::find()->where(['contact_id'=>$id])->asArray()->all();
        $site = array_column($siteData, 'site_id');  
        $selectedSites = ArrayHelper::map(ClientSite::find()->where(['in','id',$site])->asArray()->all(), 'id', 'id');
        if(!empty($selectedSites)){
            $selectedSites = implode(',', $selectedSites);
        }else{
            $selectedSites = "";
        }
        //get selected suppliers

        $supplierData = SupplierContact::find()->where(['contact_id'=>$id])->asArray()->all();
        $supplier = array_column($supplierData, 'supplier_id');  
        $selectedSupplier = ArrayHelper::map(ClientSite::find()->where(['in','id',$supplier])->asArray()->all(), 'id', 'id');
        if(!empty($selectedSites)){
            $selectedSupplier = implode(',', $selectedSupplier);
        }else{
            $selectedSupplier = "";
        }

       
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            $modelClient = Contact::getDynamicClientModel();
            $modelClient->load(Yii::$app->request->post());
            if($modelClient!=NULL){
               $clientIds =  !empty($modelClient->client_id)?$modelClient->client_id:array();
               $siteIds =  !empty($modelClient->site_id)?$modelClient->site_id:array();
               $supplierIds =  !empty($modelClient->supplier_id)?$modelClient->supplier_id:array();
            }else{
                $clientIds = array();
                $siteIds = array();
                $supplierIds = array();
            }
            $existsClients = ClientContact::find()->select('client_id')->where(['contact_id'=>$model->id])->asArray()->all();
                $arrayDbclientIDs = array_column($existsClients, 'client_id');
                $common = array_intersect($clientIds,$arrayDbclientIDs);
                //find the diffrende between common and first array and diffrence between common and second array 
                $deleteClients = array_diff($arrayDbclientIDs, $common);
                $addClients = array_diff($clientIds,$common);

            $existsSites = SiteContact::find()->select('site_id')->where(['contact_id'=>$model->id])->asArray()->all();
                $arrayDbsiteIDs = array_column($existsSites, 'site_id');
                $common = array_intersect($siteIds,$arrayDbsiteIDs);
                //find the diffrende between common and first array and diffrence between common and second array 
                $deleteSites = array_diff($arrayDbsiteIDs, $common);
                $addSites = array_diff($siteIds,$common);
               
            $existsSupplier = SupplierContact::find()->select('supplier_id')->where(['contact_id'=>$model->id])->asArray()->all();
                $arrayDbsupplierIDs = array_column($existsSupplier, 'supplier_id');
                $common = array_intersect($supplierIds,$arrayDbsupplierIDs);
                //find the diffrende between common and first array and diffrence between common and second array 
                $deleteSuppliers = array_diff($arrayDbsupplierIDs, $common);
                $addSuppliers = array_diff($supplierIds,$common);
                if(!empty($addClients)){
                   foreach($addClients as $clientID){                       
                        $modelUserClientAccess = new ClientContact();
                        $modelUserClientAccess->contact_id = $model->id;
                        $modelUserClientAccess->client_id = $clientID;
                        $modelUserClientAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserClientAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserClientAccess->save();
                    } 
                }
                if(!empty($deleteClients)){
                    ClientContact::deleteAll(['AND',['in','client_id' , $deleteClients],['contact_id'=>$model->id]]);
                }
                if(!empty($addSites)){
                   foreach($addSites as $siteID){                       
                        $modelUserSiteAccess = new SiteContact();
                        $modelUserSiteAccess->contact_id = $model->id;
                        $modelUserSiteAccess->site_id = $siteID;
                        $modelUserSiteAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserSiteAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserSiteAccess->save();
                    } 
                }
                if(!empty($deleteSites)){
                    SiteContact::deleteAll(['AND',['in','site_id' , $deleteSites],['contact_id'=>$model->id]]);
                }
                if(!empty($addSuppliers)){
                   foreach($addSuppliers as $supplierID){                       
                        $modelUserSupplierAccess = new SupplierContact();
                        $modelUserSupplierAccess->contact_id = $model->id;
                        $modelUserSupplierAccess->supplier_id = $supplierID;
                        $modelUserSupplierAccess->created_at = date('Y-m-d H:i:s');
                        $modelUserSupplierAccess->updated_at = date('Y-m-d H:i:s');  
                        $modelUserSupplierAccess->save();
                    } 
                }
                if(!empty($deleteSuppliers)){
                    SupplierContact::deleteAll(['AND',['in','supplier_id' , $deleteSuppliers],['contact_id'=>$model->id]]);
                }
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'clientSites'=>$ClientSiteOptions,                
                'selectedClients'=>$selectedClients,
                'selectedSites'=>$selectedSites,
                'supplier'=>$supplierList,                
                'selectedSupplier'=>$selectedSupplier,
            ]);
        }
    }

    /**
     * Deletes an existing Contact model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        ClientContact::deleteAll(['contact_id'=>$id]);
        SiteContact::deleteAll(['contact_id'=>$id]);
        SupplierContact::deleteAll(['contact_id'=>$id]);
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Contact model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Contact the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Contact::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
