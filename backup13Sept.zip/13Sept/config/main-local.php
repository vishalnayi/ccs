<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'C2x7ZxO_z2UOUXyHkw8Qq_TjKkRIjPtf',
        ],
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] =  [
                            'class' => 'yii\gii\Module',
                            'allowedIPs' => ['192.168.33.1','172.31.14.75','34.208.102.63','172.31.11.11','50.112.207.170','172.31.17.55','169.254.169.254','172.104.108.109','44.225.84.206','172.104.108.109','54.149.179.37','35.164.80.70','172.31.21.178'],
    ];
}

return $config;

